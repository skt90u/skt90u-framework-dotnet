﻿#region Imports
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using DataAnnotationsContrib.Interfaces;
using DataAnnotationsContrib.Tests.Framework;
using Microsoft.VisualStudio.TestTools.UnitTesting;
#endregion

namespace DataAnnotationsContrib.Tests
{
    public class TrivialYesNoAttribute : ValidationAlgorithmAttribute
    {
        public TrivialYesNoAttribute()
            : base(new TrivialYesNoAlgorithm())
        { }
    }

    /// <summary>
    /// </summary>
    [TestClass]
    public class TrivialYesNoAlgorithmAttributeTest : AttributeTest<TrivialYesNoAttribute, TrivialYesNoAlgorithmAttributeTest.Target>
    {
        #region Data
        private static readonly List<string> __validValues = new List<string>()
        {
            "yes"
        };
        private static readonly List<string> __inValidValues = new List<string>()
        {
            "",
            "               ",
            null,
            "no"
        };
        #endregion

        public TrivialYesNoAlgorithmAttributeTest()
            : base("StringProperty", __validValues, __inValidValues)
        { }

        #region Types
        public class Target
        {
            [TrivialYesNo]
            public string StringProperty { get; set; }
        }
        #endregion

        #region Tests
        [TestMethod]
        public void AllValidValuesShouldValidateTrue()
        {
            TestAllValidValuesShouldValidateTrue();
        }
        [TestMethod]
        public void AllInvalidValuesShouldValidateFalse()
        {
            TestAllInvalidValuesShouldValidateFalse();
        }
        #endregion
    }
}
