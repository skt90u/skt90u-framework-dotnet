﻿#region Imports
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using DataAnnotationsContrib.Interfaces;
using DataAnnotationsContrib.Tests.Framework;
using Microsoft.VisualStudio.TestTools.UnitTesting;
#endregion

namespace DataAnnotationsContrib.Tests
{
    public class TrivialYesNoAlgorithm : IValidationAlgorithm<string>
    {
        #region IValidationAlgorithm<string> Members
        public bool Validate(string value)
        {
            return (value == "yes");
        }
        public bool Validate(string value, out IList<string> validationMessages)
        {
            validationMessages = new List<string>();
            if (value != "yes")
            {
                validationMessages.Add("value was not yes");
                return false;
            }
            return true;
        }
        #endregion

        #region IValidationAlgorithm Members
        public bool Validate(object value)
        {
            return Validate(value as string);
        }
        public bool Validate(object value, out IList<string> validationMessages)
        {
            return Validate(value as string, out validationMessages);
        }
        #endregion
    }

    /// <summary>
    /// </summary>
    [TestClass]
    public class TrivialYesNoAlgorithmTest : ValidationAlgorithmTest<TrivialYesNoAlgorithm>
    {
        #region Data
        private static readonly List<string> __validValues = new List<string>()
        {
            "yes"
        };
        private static readonly List<string> __inValidValues = new List<string>()
        {
            "",
            "               ",
            null,
            "no"
        };
        #endregion

        public TrivialYesNoAlgorithmTest()
            : base(__validValues, __inValidValues)
        { }

        #region Tests
        [TestMethod]
        public void AllValidValuesShouldValidateTrue()
        {
            TestAllValidValuesShouldValidateTrue();
        }
        [TestMethod]
        public void AllInvalidValuesShouldValidateFalse()
        {
            TestAllInvalidValuesShouldValidateFalse();
        }
        #endregion
    }
}
