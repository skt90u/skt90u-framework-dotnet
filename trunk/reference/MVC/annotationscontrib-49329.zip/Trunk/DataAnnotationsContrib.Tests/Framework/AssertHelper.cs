#region Imports
using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using Microsoft.VisualStudio.TestTools.UnitTesting;
#endregion

namespace DataAnnotationsContrib.Tests.Framework
{
    /// <summary>
    /// </summary>
    public static class AssertHelper
    {
        #region Constants and Enums
        #endregion

        #region Inner Classes and Structures
        #endregion

        #region Delegates and Events
        #endregion

        #region Instance and Shared Fields
        #endregion

        #region Constructors
        #endregion

        #region Properties
        #endregion

        #region Private and Protected Methods
        private static int DetectLength(IEnumerable enumerable)
        {
            int expectedLength = 0;
            foreach (object obj in enumerable)
            {
                expectedLength++;
            }
            return expectedLength;
        }
        private static void TraceItems(IEnumerable items, string itemsName)
        {
            TestHelper.Trace("First 3 items in {0}:", itemsName);
            TestHelper.Trace(items, 3);
        }
        #endregion

        #region Public Methods
        public static void AssertStringEmpty(string value)
        {
            Assert.IsTrue(value == "", "String not empty.");
        }
        public static void AssertStringNotEmpty(string value)
        {
            Assert.IsFalse(value == "", "String empty.");
        }
        public static void AssertStringNullOrEmpty(string value)
        {
            Assert.IsTrue(String.IsNullOrEmpty(value), "String not null or empty.");
        }
        public static void AssertStringNotNullOrEmpty(string value)
        {
            Assert.IsFalse(String.IsNullOrEmpty(value), "String null or empty.");
        }

        public static void AssertCollectionEmpty(ICollection collection, string collectionName)
        {
            TraceItems(collection, collectionName);
            Assert.IsNotNull(collection, String.Format("Collection '{0}' was null.", collectionName));
            Assert.AreEqual(0, collection.Count, String.Format("Collection '{0}' was not empty (count was not zero).", collectionName));
        }
        public static void AssertCollectionEmpty<T>(ICollection<T> collection, string collectionName)
        {
            TraceItems(collection, collectionName);
            Assert.IsNotNull(collection, String.Format("Collection '{0}' was null.", collectionName));
            Assert.AreNotEqual(0, collection.Count, String.Format("Collection '{0}' was not empty (count was not zero).", collectionName));
        }
        public static void AssertCollectionNotEmpty(ICollection collection, string collectionName)
        {
            Assert.IsNotNull(collection, String.Format("Collection '{0}' was null.", collectionName));
            Assert.AreNotEqual(0, collection.Count, String.Format("Collection '{0}' was empty (count was zero).", collectionName));
        }
        public static void AssertCollectionNotEmpty<T>(ICollection<T> collection, string collectionName)
        {
            Assert.IsNotNull(collection, String.Format("Collection '{0}' was null.", collectionName));
            Assert.AreNotEqual(0, collection.Count, String.Format("Collection '{0}' was empty (count was zero).", collectionName));
        }
        public static void AssertCollectionCount(ICollection collection, int count, string collectionName)
        {
            Assert.IsNotNull(collection, String.Format("Collection '{0}' was null.", collectionName));
            Assert.AreEqual(count, collection.Count, String.Format("Collection '{0}' did not contain {1} items.", collectionName, count));
        }
        public static void AssertCollectionCount<T>(ICollection<T> collection, int count, string collectionName)
        {
            Assert.IsNotNull(collection, String.Format("Collection '{0}' was null.", collectionName));
            Assert.AreEqual(count, collection.Count, String.Format("Collection '{0}' did not contain {1} items.", collectionName, count));
        }

        public static void AssertCollectionContains<T>(ICollection<T> collection, T item, string collectionName)
        {
            TraceItems(collection, collectionName);
            Assert.IsNotNull(collection, String.Format("Collection '{0}' was null.", collectionName));
            Assert.IsTrue(collection.Contains(item), String.Format("Collection '{0}' did not contain the expected '{1}' item.", collectionName, item));
        }
        public static void AssertCollectionNotContains<T>(ICollection<T> collection, T item, string collectionName)
        {
            TraceItems(collection, collectionName);
            Assert.IsNotNull(collection, String.Format("Collection '{0}' was null.", collectionName));
            Assert.IsFalse(collection.Contains(item), String.Format("Collection '{0}' did contains the unexpected '{1}' item.", collectionName, item));
        }

        public static void AssertListEmpty(IList List, string listName)
        {
            Assert.IsNotNull(List, String.Format("List '{0}' was null.", listName));
            Assert.AreEqual(0, List.Count, String.Format("List '{0}' was not empty (count was not zero).", listName));
        }
        public static void AssertListEmpty<T>(IList<T> list, string listName)
        {
            Assert.IsNotNull(list, String.Format("List '{0}' was null.", listName));
            Assert.AreNotEqual(0, list.Count, String.Format("List '{0}' was not empty (count was not zero).", listName));
        }
        public static void AssertListNotEmpty(IList list, string listName)
        {
            Assert.IsNotNull(list, String.Format("List '{0}' was null.", listName));
            Assert.AreNotEqual(0, list.Count, String.Format("List '{0}' was empty (count was zero).", listName));
        }
        public static void AssertListNotEmpty<T>(IList<T> list, string listName)
        {
            Assert.IsNotNull(list, String.Format("List '{0}' was null.", listName));
            Assert.AreNotEqual(0, list.Count, String.Format("List '{0}' was empty (count was zero).", listName));
        }
        public static void AssertListCount(IList list, int count, string listName)
        {
            Assert.IsNotNull(list, String.Format("List '{0}' was null.", listName));
            Assert.AreEqual(count, list.Count, String.Format("List '{0}' did not contain {1} items.", listName, count));
        }
        public static void AssertListCount<T>(IList<T> list, int count, string listName)
        {
            Assert.IsNotNull(list, String.Format("List '{0}' was null.", listName));
            Assert.AreEqual(count, list.Count, String.Format("List '{0}' did not contain {1} items.", listName, count));
        }

        public static void AssertArrayEmpty(Array array, string arrayName)
        {
            TraceItems(array, arrayName);
            Assert.IsNotNull(array, String.Format("Array '{0}' was null", arrayName));
            Assert.AreEqual(0, array.Length, String.Format("Array '{0}' was not zero length.", arrayName));
        }
        public static void AssertArrayNotEmpty(Array array, string arrayName)
        {
            Assert.IsNotNull(array, String.Format("Array '{0}' was null.", arrayName));
            Assert.AreNotEqual(0, array.Length, String.Format("Array '{0}' was zero length.", arrayName));
        }
        public static void AssertArrayCount(Array array, int count, string arrayName)
        {
            Assert.IsNotNull(array, String.Format("Array '{0}' was null.", arrayName));
            Assert.AreEqual(0, array.Length, String.Format("Array '{0}' did not contain {1} items.", arrayName, count));
        }
        #endregion

        #region Event Handlers
        #endregion

        #region Base Class Overrides
        #endregion
    }
}