﻿#region Imports
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using DataAnnotationsContrib;
using DataAnnotationsContrib.Interfaces;
using Microsoft.VisualStudio.TestTools.UnitTesting;
#endregion

namespace DataAnnotationsContrib.Tests.Framework
{
    /// <summary>
    /// </summary>
    [TestClass]
    public abstract class Test
    {
        #region Infrastructure
        public TestContext TestContext { get; set; }

        // [TestInitialize()]
        // public void MyTestInitialize() { }
        //
        // [TestCleanup()]
        // public void MyTestCleanup() { }
        #endregion
    }
}
