﻿#region Imports
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using DataAnnotationsContrib.Interfaces;
using DataAnnotationsContrib.Tests.Framework;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using DataAnnotationsContrib.Finance;
#endregion

namespace DataAnnotationsContrib.Tests.Finance
{
    /// <summary>
    /// </summary>
    [TestClass]
    public class Iso9362SWIFTBICAlgorithmTest : ValidationAlgorithmTest<Iso9362SWIFTBICAlgorithm>
    {
        #region Data
        private static readonly List<string> __validValues = new List<string>()
        {
            //Probably not the most reliable source but at least its free.
            //http://swift-codes.blogspot.com/2008/01/all-major-banks-swift-codes.html
            "CHASUS33", //USD	JPMorgan Chase Manhattan Bank, NEW YORK	CHASUS33	001-1-406717
            "IRVTUS3N", //USD	Bank of New York, New York	IRVTUS3N	8900330937
            "BOFAUS3N", //USD	Bank of America,New York ,USA.	BOFAUS3N	6550492079
            "ABNAUS33", //USD	ABN AMRO Bank, New York, USA.	ABNAUS33	574-0748188-41
            "AEIBUS33", //USD	American Express Bank, New York, USA.	AEIBUS33	745844
            "CHASGB2L", //GBP	JPMorgan Chase Manhattan Bank, London, UK	CHASGB2L	111-35191
            "RBOSGB2L", //GBP	Royal Bank of Scotland, London	RBOSGB2L	10005149
            "DEUTGB2L", //GBP	Deutsche , London	DEUTGB2L	84003011320000GBP000LDN
            "LOYDGB22", //GBP	LLoyds Bank, London, UK	LOYDGB22	1015444
            "SMBCJPJT", //JPY	Sumitomo , Tokyo	SMBCJPJT	4313
            "CHASJPJT", //JPY	JPMorgan Chase Manhattan Bank, Tokyo,Japan	CHASJPJT	01-42-453539
            "CHASDEFX", //EUR	JPMorgan Chase Manhattan Bank, FRANFURT	CHASDEFX	6231602308
            "AEIBDEFX", //EUR	American Express Bank, Frankfurt	AEIBDEFX	18102010
            "ABNADEFF", //EUR	ABN Amro Bank, Frankfurt, Germany	ABNADEFF	07370005602675019EUR
            "EBILAEAD", //AED	Emirates Bank International, Dubai,UAE	EBILAEAD	0004-808439-784
            "ANZBAU3M", //AUD	ANZ Melbourne, Australia	ANZBAU3M	568204AUD00001
            "ANZBNZ22XXX", //NZD	ANZ National Bank Limited,Wellington, NZ	ANZBNZ22XXX	568204NZD00001
            "NOSCCATT", //CAD	Bank of Nova Scotia, Canada	NOSCCATT	5271202445 - 11
            "UBSWCHZH", //CHF	Union Bank Of Switzerland, Zurich, Switzerland	UBSWCHZH	02300000094169050000E
            "NDEADKKK", //DKK	Nordea Bank, Copenhagen, Denmark	NDEADKKK	5000015611
            "SCBLHKHH", //HKD	Standard Chartered Bank, Hongkong	SCBLHKHH	44709406528
            "NBBKSESS", //SEK	Nordbanken, Stockholm, Sweden	NBBKSESS	39527909511
            "AAALSARI", //SAR	Saudi Holandi Bank, Saudi Arabia	AAALSARI	031 002 605 275
            "DBSSSGSG", //SGD	DBS, Singapore	DBSSSGSG	003-901438-4 HDFC BANK LIMITED
            "CHASSGSG", //SGD	JPMorgan Chase Manhattan Bank, Singapore	CHASSGSG	111874122
        };
        private static readonly List<string> __inValidValues = new List<string>()
        {
            "DBSSSGS",
            "DBSSSGSGR",
            "DBSSSGSGXXXX",
            "12BSSSGSG",
            "DBS3SSGSG",
        };
        #endregion

        public Iso9362SWIFTBICAlgorithmTest()
            : base(__validValues, __inValidValues)
        { }

        #region Tests
        [TestMethod]
        public void AllValidValuesShouldValidateTrue()
        {
            TestAllValidValuesShouldValidateTrue();
        }
        [TestMethod]
        public void AllInvalidValuesShouldValidateFalse()
        {
            TestAllInvalidValuesShouldValidateFalse();
        }

        [TestMethod]
        public void ShouldExtractBankIdentifier()
        {
            Assert.AreEqual("CHAS", Iso9362SWIFTBICAlgorithm.ExtractBankIdentifier(__validValues[0]));
        }
        [TestMethod]
        public void ShouldExtractCountryCode()
        {
            Assert.AreEqual("US", Iso9362SWIFTBICAlgorithm.ExtractCountryCode(__validValues[0]));
        }
        [TestMethod]
        public void ShouldExtractLocationIdentifier()
        {
            Assert.AreEqual("33", Iso9362SWIFTBICAlgorithm.ExtractLocationIdentifier(__validValues[0]));
        }
        [TestMethod]
        public void ShouldExtractBranchIdentifier()
        {
            Assert.AreEqual("", Iso9362SWIFTBICAlgorithm.ExtractBranchIdentifier(__validValues[0]));
        }
        [TestMethod]
        public void ShouldExtractPrimaryBranchFlag()
        {
            Assert.AreEqual(true, Iso9362SWIFTBICAlgorithm.ExtractPrimaryBranchFlag(__validValues[0]));
        }
        #endregion
    }
}
