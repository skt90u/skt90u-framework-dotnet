﻿#region Imports
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using DataAnnotationsContrib.Finance;
using DataAnnotationsContrib.Interfaces;
using DataAnnotationsContrib.Tests.Framework;
using Microsoft.VisualStudio.TestTools.UnitTesting;
#endregion

namespace DataAnnotationsContrib.Tests.Finance
{
    /// <summary>
    /// </summary>
    [TestClass]
    public class PaymentCardNumberAttributeTest : AttributeTest<PaymentCardNumberAttribute, PaymentCardNumberAttributeTest.Target>
    {
        private static readonly List<string> __validValues = new List<string>()
        {
            "4375376734347670"
        };
        private static readonly List<string> __inValidValues = new List<string>()
        {
            "4375376734347671"
        };

        public PaymentCardNumberAttributeTest()
            : base("StringProperty", __validValues, __inValidValues)
        { }

        public class Target
        {
            [PaymentCardNumber]
            public string StringProperty { get; set; }
        }

        [TestMethod]
        public void AllValidValuesShouldValidateTrue()
        {
            TestAllValidValuesShouldValidateTrue();
        }
        [TestMethod]
        public void AllInvalidValuesShouldValidateFalse()
        {
            TestAllInvalidValuesShouldValidateFalse();
        }
    }
}
