﻿#region Imports
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using DataAnnotationsContrib.Interfaces;
using DataAnnotationsContrib.Tests.Framework;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using DataAnnotationsContrib.Finance;
#endregion

namespace DataAnnotationsContrib.Tests.Finance
{
    /// <summary>
    /// </summary>
    [TestClass]
    public class PaymentCardNumberAlgorithmTest : ValidationAlgorithmTest<PaymentCardNumberAlgorithm>
    {
        #region Data
        private static readonly List<string> __validValues = new List<string>()
        {
            //https://www.paypal.com/en_US/vhelp/paypalmanager_help/credit_card_numbers.htm
            "347124434528162", //Amex
            "30073688170373", //Diners
            "6011504678737813", //Discover
            "3553506461032220", //JCB
            "5020550026845544", //Maestro
            "5171664153814558", //Mastercard
            "6767268816243201", //Solo
            "6759345027075265", //Switch
            "4375376734347670", //Visa
            "4504111714054606", //Visa
            "4175003607265639", //Visa Electron

            //Verisign (via http://credit-card-information.elliottback.com/).
            "5105105105105100", //Mastercard
            "5555555555554444", //Mastercard
            "4222222222222", //Visa
            "4111111111111111", //Visa
            "4012888888881881", //Visa
            "378282246310005", //Amex
            "371449635398431", //Amex
            "378734493671000", //Amex
            //Don't 100% know the issuer for these last few numbers.
            "38520000023237", //Diners?
            "30569309025904", //Diners?
            "6011111111111117", //Discover?
            "6011000990139424", //Discover?
            "3530111333300000", //JCB?
            "3566002020360505", //JCB?
        };
        private static readonly List<string> __inValidValues = new List<string>()
        {
            "437537673434767", //Length
            "43753767343476701",
            "43 75 37 67 34 34 76 70", //Format
            "4375376 734347670",
            "437537673434768", //Checksum Digits
            "247124434528162"
        };
        #endregion

        public PaymentCardNumberAlgorithmTest()
            : base(__validValues, __inValidValues)
        { }

        #region Tests
        [TestMethod]
        public void AllValidValuesShouldValidateTrue()
        {
            TestAllValidValuesShouldValidateTrue();
        }
        [TestMethod]
        public void AllInvalidValuesShouldValidateFalse()
        {
            TestAllInvalidValuesShouldValidateFalse();
        }

        [TestMethod]
        public void ShouldExtractIndustryCorrectly()
        {
            Assert.AreEqual(PaymentCardNumberAlgorithm.IndustryIdentifier.TravelAndEntertainment, PaymentCardNumberAlgorithm.ExtractIndustry(__validValues[0]));
            Assert.AreEqual(PaymentCardNumberAlgorithm.IndustryIdentifier.TravelAndEntertainment, PaymentCardNumberAlgorithm.ExtractIndustry(__validValues[1]));
            Assert.AreEqual(PaymentCardNumberAlgorithm.IndustryIdentifier.MerchandisingAndBanking, PaymentCardNumberAlgorithm.ExtractIndustry(__validValues[2]));
            Assert.AreEqual(PaymentCardNumberAlgorithm.IndustryIdentifier.TravelAndEntertainment, PaymentCardNumberAlgorithm.ExtractIndustry(__validValues[3]));
            Assert.AreEqual(PaymentCardNumberAlgorithm.IndustryIdentifier.BankingAndFinancial2, PaymentCardNumberAlgorithm.ExtractIndustry(__validValues[4]));
            Assert.AreEqual(PaymentCardNumberAlgorithm.IndustryIdentifier.BankingAndFinancial2, PaymentCardNumberAlgorithm.ExtractIndustry(__validValues[5]));
            Assert.AreEqual(PaymentCardNumberAlgorithm.IndustryIdentifier.MerchandisingAndBanking, PaymentCardNumberAlgorithm.ExtractIndustry(__validValues[6]));
            Assert.AreEqual(PaymentCardNumberAlgorithm.IndustryIdentifier.MerchandisingAndBanking, PaymentCardNumberAlgorithm.ExtractIndustry(__validValues[7]));
            Assert.AreEqual(PaymentCardNumberAlgorithm.IndustryIdentifier.BankingAndFinancial1, PaymentCardNumberAlgorithm.ExtractIndustry(__validValues[8]));
            Assert.AreEqual(PaymentCardNumberAlgorithm.IndustryIdentifier.BankingAndFinancial1, PaymentCardNumberAlgorithm.ExtractIndustry(__validValues[9]));
            Assert.AreEqual(PaymentCardNumberAlgorithm.IndustryIdentifier.BankingAndFinancial1, PaymentCardNumberAlgorithm.ExtractIndustry(__validValues[10]));
        }
        [TestMethod]
        public void ShouldExtractIssuerCorrectly()
        {
            Assert.AreEqual(PaymentCardNumberAlgorithm.IssuerIdentifier.Amex, PaymentCardNumberAlgorithm.ExtractIssuer(__validValues[0]));
            Assert.AreEqual(PaymentCardNumberAlgorithm.IssuerIdentifier.DinersClub, PaymentCardNumberAlgorithm.ExtractIssuer(__validValues[1]));
            Assert.AreEqual(PaymentCardNumberAlgorithm.IssuerIdentifier.Discover, PaymentCardNumberAlgorithm.ExtractIssuer(__validValues[2]));
            Assert.AreEqual(PaymentCardNumberAlgorithm.IssuerIdentifier.JCB, PaymentCardNumberAlgorithm.ExtractIssuer(__validValues[3]));
            Assert.AreEqual(PaymentCardNumberAlgorithm.IssuerIdentifier.Maestro, PaymentCardNumberAlgorithm.ExtractIssuer(__validValues[4]));
            Assert.AreEqual(PaymentCardNumberAlgorithm.IssuerIdentifier.MasterCard, PaymentCardNumberAlgorithm.ExtractIssuer(__validValues[5]));
            Assert.AreEqual(PaymentCardNumberAlgorithm.IssuerIdentifier.Solo, PaymentCardNumberAlgorithm.ExtractIssuer(__validValues[6]));
            Assert.AreEqual(PaymentCardNumberAlgorithm.IssuerIdentifier.Switch, PaymentCardNumberAlgorithm.ExtractIssuer(__validValues[7]));
            Assert.AreEqual(PaymentCardNumberAlgorithm.IssuerIdentifier.VISA, PaymentCardNumberAlgorithm.ExtractIssuer(__validValues[8]));
            Assert.AreEqual(PaymentCardNumberAlgorithm.IssuerIdentifier.VISA, PaymentCardNumberAlgorithm.ExtractIssuer(__validValues[9]));
            Assert.AreEqual(PaymentCardNumberAlgorithm.IssuerIdentifier.VISAElectron, PaymentCardNumberAlgorithm.ExtractIssuer(__validValues[10]));

            Assert.AreEqual(PaymentCardNumberAlgorithm.IssuerIdentifier.MasterCard, PaymentCardNumberAlgorithm.ExtractIssuer(__validValues[11]));
            Assert.AreEqual(PaymentCardNumberAlgorithm.IssuerIdentifier.MasterCard, PaymentCardNumberAlgorithm.ExtractIssuer(__validValues[12]));
            Assert.AreEqual(PaymentCardNumberAlgorithm.IssuerIdentifier.VISA, PaymentCardNumberAlgorithm.ExtractIssuer(__validValues[13]));
            Assert.AreEqual(PaymentCardNumberAlgorithm.IssuerIdentifier.VISA, PaymentCardNumberAlgorithm.ExtractIssuer(__validValues[14]));
            Assert.AreEqual(PaymentCardNumberAlgorithm.IssuerIdentifier.VISA, PaymentCardNumberAlgorithm.ExtractIssuer(__validValues[15]));
            Assert.AreEqual(PaymentCardNumberAlgorithm.IssuerIdentifier.Amex, PaymentCardNumberAlgorithm.ExtractIssuer(__validValues[16]));
            Assert.AreEqual(PaymentCardNumberAlgorithm.IssuerIdentifier.Amex, PaymentCardNumberAlgorithm.ExtractIssuer(__validValues[17]));
            Assert.AreEqual(PaymentCardNumberAlgorithm.IssuerIdentifier.Amex, PaymentCardNumberAlgorithm.ExtractIssuer(__validValues[18]));
            //Don't 100% know the issuer for these last few numbers.
            //Assert.AreEqual(PaymentCardNumberAlgorithm.IssuerIdentifier.DinersClub, PaymentCardNumberAlgorithm.ExtractIssuer(__validValues[19]));
            //Assert.AreEqual(PaymentCardNumberAlgorithm.IssuerIdentifier.Discover, PaymentCardNumberAlgorithm.ExtractIssuer(__validValues[20]));
            //Assert.AreEqual(PaymentCardNumberAlgorithm.IssuerIdentifier.Discover, PaymentCardNumberAlgorithm.ExtractIssuer(__validValues[21]));
            //Assert.AreEqual(PaymentCardNumberAlgorithm.IssuerIdentifier.JCB, PaymentCardNumberAlgorithm.ExtractIssuer(__validValues[22]));
            //Assert.AreEqual(PaymentCardNumberAlgorithm.IssuerIdentifier.JCB, PaymentCardNumberAlgorithm.ExtractIssuer(__validValues[23]));
        }
        #endregion
    }
}
