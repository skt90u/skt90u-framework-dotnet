﻿#region Imports
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using DataAnnotationsContrib.Interfaces;
using DataAnnotationsContrib.Tests.Framework;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using DataAnnotationsContrib.Finance;
#endregion

namespace DataAnnotationsContrib.Tests.Finance
{
    /// <summary>
    /// </summary>
    [TestClass]
    public class Iso6166ISINAlgorithmTest : ValidationAlgorithmTest<Iso6166ISINAlgorithm>
    {
        #region Data
        private static readonly List<string> __validValues = new List<string>()
        {
            //http://en.wikipedia.org/wiki/International_Securities_Identifying_Number
            "US0378331005", //Apple Shares
            "AU0000XVGZA3", //Treasury Corp Victoria
            "GB0002634946", ///BAE Systems
        };
        private static readonly List<string> __inValidValues = new List<string>()
        {
            "FR555",
            "34343578331005",
            "US0378331008", //Checksum
        };
        #endregion

        public Iso6166ISINAlgorithmTest()
            : base(__validValues, __inValidValues)
        { }

        #region Tests
        [TestMethod]
        public void AllValidValuesShouldValidateTrue()
        {
            TestAllValidValuesShouldValidateTrue();
        }
        [TestMethod]
        public void AllInvalidValuesShouldValidateFalse()
        {
            TestAllInvalidValuesShouldValidateFalse();
        }

        [TestMethod]
        public void ShouldExtractCountryCode()
        {
            Assert.AreEqual("US", Iso6166ISINAlgorithm.ExtractCountryCode(__validValues[0]));
            Assert.AreEqual("AU", Iso6166ISINAlgorithm.ExtractCountryCode(__validValues[1]));
            Assert.AreEqual("GB", Iso6166ISINAlgorithm.ExtractCountryCode(__validValues[2]));
        }

        [TestMethod]
        public void ShouldExtractNSIN()
        {
            Assert.AreEqual("037833100", Iso6166ISINAlgorithm.ExtractNSIN(__validValues[0], false));
            Assert.AreEqual("0000XVGZA", Iso6166ISINAlgorithm.ExtractNSIN(__validValues[1], false));
            Assert.AreEqual("XVGZA", Iso6166ISINAlgorithm.ExtractNSIN(__validValues[1], true));
            Assert.AreEqual("000263494", Iso6166ISINAlgorithm.ExtractNSIN(__validValues[2], false));
            Assert.AreEqual("263494", Iso6166ISINAlgorithm.ExtractNSIN(__validValues[2], true));
        }
        #endregion
    }
}
