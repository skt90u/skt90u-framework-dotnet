﻿#region Imports
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using DataAnnotationsContrib.Interfaces;
using DataAnnotationsContrib.Tests.Framework;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections;
using DataAnnotationsContrib.Common;
#endregion

namespace DataAnnotationsContrib.Tests
{
    /// <summary>
    /// </summary>
    [TestClass]
    public class AlgorithmHelperTests
    {
        #region Tests
        [TestMethod]
        public void SumDigitsOfInt32CalculatesCorrectly()
        {
            Assert.AreEqual(6, AlgorithmHelper.SumDigits(15));
            Assert.AreEqual(45, AlgorithmHelper.SumDigits(123456789));
            Assert.AreEqual(46, AlgorithmHelper.SumDigits(Int32.MaxValue));
            Assert.AreEqual(0, AlgorithmHelper.SumDigits(0));
        }
        [TestMethod]
        public void CollapseDigitsOfInt32CalculatesCorrectly()
        {
            Assert.AreEqual(6, AlgorithmHelper.CollapseDigits(15));
            Assert.AreEqual(9, AlgorithmHelper.CollapseDigits(123456789));
            Assert.AreEqual(1, AlgorithmHelper.CollapseDigits(Int32.MaxValue));
            Assert.AreEqual(0, AlgorithmHelper.CollapseDigits(0));
        }

        [TestMethod]
        public void SumDigitsOfStringCalculatesCorrectly()
        {
            Assert.AreEqual(0, AlgorithmHelper.SumDigits(""));
            Assert.AreEqual(6, AlgorithmHelper.SumDigits("15"));
            Assert.AreEqual(45, AlgorithmHelper.SumDigits("123456789"));
            Assert.AreEqual(225, AlgorithmHelper.SumDigits("01234567890123456789012345678901234567890123456789"));
        }
        [TestMethod]
        public void CollapseDigitsOfStringCalculatesCorrectly()
        {
            Assert.AreEqual(0, AlgorithmHelper.CollapseDigits(""));
            Assert.AreEqual(6, AlgorithmHelper.CollapseDigits("15"));
            Assert.AreEqual(9, AlgorithmHelper.CollapseDigits("123456789"));
            Assert.AreEqual(9, AlgorithmHelper.CollapseDigits("01234567890123456789012345678901234567890123456789"));
        }
        #endregion
    }
}
