﻿#region Imports
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using DataAnnotationsContrib.Common;
using DataAnnotationsContrib.Interfaces;
using DataAnnotationsContrib.Tests.Framework;
using Microsoft.VisualStudio.TestTools.UnitTesting;
#endregion

namespace DataAnnotationsContrib.Tests.CheckDigits
{
    /// <summary>
    /// </summary>
    [TestClass]
    public class LuhnMod10CheckDigitAlgorithmTest : CheckDigitAlgorithmTest<LuhnMod10CheckDigitAlgorithm>
    {
        #region Data
        private static readonly List<string> __validValues = new List<string>()
        {
            "4408041234567893",
            "4417123456789113"
        };
        private static readonly List<string> __inValidValues = new List<string>()
        {
            "4408041234567890",
            "4417123456789116"
        };
        private static readonly List<string> __applyValues = new List<string>()
        {
            "123412341234333",
            "1",
            "145634256",
            "123412341234334636234128699334333",
        };
        #endregion

        public LuhnMod10CheckDigitAlgorithmTest()
            : base(__validValues, __inValidValues, __applyValues)
        { }

        protected override ICheckDigitAlgorithm CreateAlgorithm()
        {
            return new LuhnMod10CheckDigitAlgorithm(Enums.CheckDigitPosition.End);
        }

        #region Tests
        [TestMethod]
        public void AllValidValuesShouldVerifyTrue()
        {
            TestAllValidValuesShouldVerifyTrue();
        }
        [TestMethod]
        public void AllInvalidValuesShouldVerifyFalse()
        {
            TestAllInvalidValuesShouldVerifyFalse();
        }
        [TestMethod]
        public void ApplyAndRemoveChecksumAgrees()
        {
            TestApplyAndRemoveChecksumAgrees();
        }
        #endregion
    }
}
