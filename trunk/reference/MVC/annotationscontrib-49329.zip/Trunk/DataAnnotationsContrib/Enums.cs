#region Imports
using System;
#endregion

namespace DataAnnotationsContrib
{
    /// <summary>
    /// </summary>
    public class Enums
    {
        public enum CheckDigitPosition
        {
            Start,
            End
        }
    }
}