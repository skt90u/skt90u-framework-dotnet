#region Imports
using System;
using System.Collections.Generic;
using System.Linq;
#endregion

namespace DataAnnotationsContrib.Interfaces
{
    /// <summary>
    /// </summary>
    public interface IMultipartValueAlgorithm
    {
        #region Delegates and Events
        #endregion

        #region Properties
        #endregion

        #region Public Methods
        MultipartValueDetails ExtractComponents(string value);
        #endregion
    }
}