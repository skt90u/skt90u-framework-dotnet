﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using Telerik.Web.Mvc.Extensions;
using Telerik.Web.Mvc.Infrastructure;
using Telerik.Web.Mvc.UI;

namespace Jmelosegui.Mvc.Controls
{
    public class GoogleMap : ViewComponentBase
    {
        #region Public Properties

        public GoogleMapClientEvents ClientEvents { get; private set; }

        public bool DisableDoubleClickZoom { get; set; }

        public bool Draggable { get; set; }

        public int Height { get; set; }

        private double latitude;
        public double Latitude
        {
            get
            {
                if (latitude == 0)
                    latitude = 23;
                return latitude;
            }
            set { latitude = value; }
        }

        private double longitude;
        public double Longitude
        {
            get
            {
                if (longitude == 0)
                    longitude = -82;
                return longitude;
            }
            set { longitude = value; }
        }

        public MapType MapType { get; set; }

        public MapTypeControlStyle MapTypeControlStyle { get; set; }

        public ControlPosition MapTypeControlPosition { get; set; }

        public bool MapTypeControlVisible { get; set; }

        public IList<Marker> Markers { get; private set; }

        public NavigationControlType NavigationControlType { get; set; }

        public ControlPosition NavigationControlPosition { get; set; }

        public bool NavigationControlVisible { get; set; }

        public bool ScaleControlVisible { get; set; }

        public ControlPosition ScaleControlPosition { get; set; }

        public int Width { get; set; }

        public int Zoom { get; set; }

        #endregion

        #region Constructor

        public GoogleMap(ViewContext viewContext, IClientSideObjectWriterFactory clientSideObjectWriterFactory)
            : base(viewContext, clientSideObjectWriterFactory)
        {
            ScriptFileNames.AddRange(new[] { "telerik.common.js", "jmelosegui.googlemap.js" });

            Initialize();
        }

        private void Initialize()
        {
            ClientEvents = new GoogleMapClientEvents();
            DisableDoubleClickZoom = false;
            Draggable = true;
            MapType = MapType.Roadmap;
            MapTypeControlPosition = ControlPosition.TopRight;
            MapTypeControlVisible = true;
            Markers = new List<Marker>();
            NavigationControlType = NavigationControlType.Default;
            NavigationControlPosition = ControlPosition.TopLeft;
            NavigationControlVisible = true;
            ScaleControlVisible = false;
            ScaleControlPosition = ControlPosition.BottomLeft;
            Height = 300;
            Width = 550;
        }

        #endregion

        #region Override Methods

        public override void WriteInitializationScript(System.IO.TextWriter writer)
        {
            IClientSideObjectWriter objectWriter = ClientSideObjectWriterFactory.Create(Id, "GoogleMap", writer);

            objectWriter.Start();

            objectWriter.Append("ClientID", Id);
            objectWriter.Append("DisableDoubleClickZoom", DisableDoubleClickZoom, false);
            objectWriter.Append("Draggable", Draggable, true);
            objectWriter.Append("Height", Height);
            objectWriter.Append("Latitude", Latitude);
            objectWriter.Append("Longitude", Longitude);
            objectWriter.Append("MapType", MapType, MapType.Roadmap);
            objectWriter.Append("MapTypeControlPosition", MapTypeControlPosition, ControlPosition.TopRight);
            objectWriter.Append("MapTypeControlVisible", MapTypeControlVisible, true);
            objectWriter.Append("MapTypeControlStyle", MapTypeControlStyle, MapTypeControlStyle.Default);
            objectWriter.Append("NavigationControlPosition", NavigationControlPosition, ControlPosition.TopRight);
            objectWriter.Append("NavigationControlType", NavigationControlType, NavigationControlType.Default);
            objectWriter.Append("NavigationControlVisible", NavigationControlVisible, true);
            objectWriter.Append("ScaleControlVisible", ScaleControlVisible, false);
            objectWriter.Append("ScaleControlPosition", ScaleControlPosition, ControlPosition.BottomLeft);
            objectWriter.Append("Width", Width);
            objectWriter.Append("Zoom", (Zoom == 0) ? 6 : Zoom);

            if (Markers.Any())
            {
                var markers = new List<IDictionary<string, object>>();

                Markers.Each(m => markers.Add(m.CreateSerializer().Serialize()));

                if (markers.Any())
                {
                    objectWriter.AppendCollection("Markers", markers);
                }
            }

            objectWriter.AppendClientEvent("onLoad", ClientEvents.OnLoad);
            objectWriter.AppendClientEvent("onClick", ClientEvents.OnClick);

            objectWriter.Complete();

            base.WriteInitializationScript(writer);
        }

        protected override void WriteHtml(System.Web.UI.HtmlTextWriter writer)
        {
            Guard.IsNotNull(writer, "writer");

            writer.Write(@"<script type=""text/javascript"" src=""http://maps.google.com/maps/api/js?sensor=false&language=es""></script>");
            var builder = new GoogleMapBuilder(this);
            IHtmlNode rootTag = builder.Build();
            rootTag.WriteTo(writer);

            if (Markers.Any(m => m.Window != null))
            {
                //Build Container for InfoWindows
                IHtmlNode infoWindowsRootTag = new HtmlTag("div")
                    .Attribute("id", "{0}-InfoWindowsHolder".FormatWith(this.Id))
                    .Attribute("style", "display: none");

                Markers.Where(m => m.Window != null).Each(m =>
                {
                    IHtmlNode markerInfoWindows = new HtmlTag("div")
                        .Attribute("id", "{0}Marker{1}".FormatWith(Id, m.Index));
                    m.Window.Template.Apply(markerInfoWindows);
                    infoWindowsRootTag.Children.Add(markerInfoWindows);
                });

                infoWindowsRootTag.WriteTo(writer);
            }
            base.WriteHtml(writer);
        }

        #endregion

        public void BindTo<TGoogleMapOverlay, TDataItem>(IEnumerable<TDataItem> dataSource, Action<OverlayBindingFactory<TGoogleMapOverlay>> action)
            where TGoogleMapOverlay : Overlay
        {
            Guard.IsNotNull(action, "action");
            var factory = new OverlayBindingFactory<TGoogleMapOverlay>();
            action(factory);

            foreach (TDataItem dataItem in dataSource)
            {
                Overlay overlay = null;

                if (typeof(Marker).IsAssignableFrom(typeof(TGoogleMapOverlay)))
                {
                    overlay = new Marker(this);
                    Markers.Add((Marker)overlay);
                }
                factory.Binder.ItemDataBound((TGoogleMapOverlay)overlay, dataItem);
            }
        }
    }

}
