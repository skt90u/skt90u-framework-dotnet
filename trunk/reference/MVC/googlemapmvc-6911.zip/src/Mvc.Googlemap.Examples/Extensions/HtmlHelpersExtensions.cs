using System;
using System.Linq;
using System.Text;
using System.Web.Mvc;
using System.Web.Mvc.Html;
using System.Web.UI;
using Telerik.Web.Mvc.Extensions;

namespace Telerik.Web.Mvc.Examples
{
    public static class HtmlHelpersExtensions
    {
        public static ExampleConfigurator Configurator(this HtmlHelper instance, string title)
        {
            return new ExampleConfigurator(instance).Title(title);
        }

        public static string ExampleTitle(this HtmlHelper helper)
        {
            var sitemap = (XmlSiteMap)helper.ViewData["jmelosegui.googlemap.examples"];
            var controller = (string) helper.ViewContext.RouteData.Values["controller"];
            var action = (string) helper.ViewContext.RouteData.Values["action"];

            SiteMapNode exampleSiteMapNode = sitemap.RootNode.ChildNodes
                .SelectRecursive(node => node.ChildNodes)
                .FirstOrDefault(node => controller.Equals(node.ControllerName, StringComparison.OrdinalIgnoreCase) &&
                                        action.Equals(node.ActionName, StringComparison.OrdinalIgnoreCase));

            if (exampleSiteMapNode != null)
            {
                return exampleSiteMapNode.Title;
            }

            return string.Empty;
        }

        public static string CheckBox(this HtmlHelper instance, string id, bool isChecked, string labelText)
        {
            return (new StringBuilder())
                .Append(instance.CheckBox(id, isChecked))
                .Append("<label for=\"")
                .Append(id)
                .Append("\">")
                .Append(labelText)
                .Append("</label>")
                .ToString();
        }
    }

    public class ExampleConfigurator : IDisposable
    {
        public const string CssClass = "configurator";

        private readonly HtmlHelper htmlHelper;
        private readonly HtmlTextWriter writer;
        private MvcForm form;
        private string title;

        public ExampleConfigurator(HtmlHelper instance)
        {
            htmlHelper = instance;
            writer = new HtmlTextWriter(instance.ViewContext.HttpContext.Response.Output);
        }

        #region IDisposable Members

        public void Dispose()
        {
            End();
        }

        #endregion

        public ExampleConfigurator Title(string title)
        {
            this.title = title;

            return this;
        }

        public ExampleConfigurator Begin()
        {
            writer.AddAttribute(HtmlTextWriterAttribute.Class, CssClass);
            writer.RenderBeginTag(HtmlTextWriterTag.Div);

            writer.AddAttribute(HtmlTextWriterAttribute.Class, CssClass + "-legend");
            writer.RenderBeginTag(HtmlTextWriterTag.H3);
            writer.Write(title);
            writer.RenderEndTag();

            return this;
        }

        public ExampleConfigurator End()
        {
            writer.RenderEndTag(); // fieldset

            if (form != null)
            {
                form.EndForm();
            }

            return this;
        }

        public ExampleConfigurator PostTo(string action, string controller)
        {
            form = htmlHelper.BeginForm(action, controller);
            return this;
        }
    }
}