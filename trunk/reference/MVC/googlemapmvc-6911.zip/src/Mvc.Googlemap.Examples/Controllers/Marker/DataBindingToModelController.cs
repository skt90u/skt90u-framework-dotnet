﻿using System.Web.Mvc;
using Mvc.Googlemap.Examples.App_Data;

namespace Mvc.Googlemap.Examples.Controllers
{
    public partial class MarkerController
    {
        public ActionResult DataBindingToModel()
        {
            return View(DataContext.GetMarkersData());
        }
    }
}