﻿using System.Web.Mvc;

namespace Mvc.Googlemap.Examples.Controllers
{
    public partial class MarkerController
    {
        public ActionResult SimpleMarker()
        {
            return View();
        }
    }
}