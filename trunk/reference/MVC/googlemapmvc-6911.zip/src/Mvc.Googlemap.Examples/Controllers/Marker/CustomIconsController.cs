﻿using System.Web.Mvc;

namespace Mvc.Googlemap.Examples.Controllers
{
    public partial class MarkerController
    {
        public ActionResult CustomIcons()
        {
            return View();
        }
    }
}