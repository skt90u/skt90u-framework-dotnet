﻿using System.Web.Mvc;
using Jmelosegui.Mvc.Controls;

namespace Mvc.Googlemap.Examples.Controllers
{
    public partial class BasicController
    {
        public ActionResult UIControls(UIControlModel model)
        {
            return View(model);
        }

    }

    public class UIControlModel
    {
        public UIControlModel()
        {
            ShowScaleControl = false;
            ScaleControlPosition = ControlPosition.BottomLeft;

            ShowNavigationControl = true;
            NavigationControlType = NavigationControlType.Default;
            NavigationControlPosition = ControlPosition.TopLeft;

            ShowMapType = true;
            MapTypeControl = MapType.Roadmap;
            MapTypeControlStyle = MapTypeControlStyle.Default;
            MapTypeControlPosition = ControlPosition.TopRight;
        }

        public bool ShowScaleControl { get; set; }
        public ControlPosition ScaleControlPosition { get; set; }

        public bool ShowNavigationControl { get; set; }
        public NavigationControlType NavigationControlType { get; set; }
        public ControlPosition NavigationControlPosition { get; set; }

        public bool ShowMapType { get; set; }
        public MapType MapTypeControl { get; set; }
        public MapTypeControlStyle MapTypeControlStyle { get; set; }
        public ControlPosition MapTypeControlPosition { get; set; }
    }
}
