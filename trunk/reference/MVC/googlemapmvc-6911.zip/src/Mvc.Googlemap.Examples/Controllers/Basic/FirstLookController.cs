﻿using System.Web.Mvc;

namespace Mvc.Googlemap.Examples.Controllers
{
    public partial class BasicController
    {
        public ActionResult FirstLook(int?height, int? width)
        {
            ViewData["height"] = height ?? 300;
            ViewData["width"] = width ?? 880;
            return View();
        }
    }
}