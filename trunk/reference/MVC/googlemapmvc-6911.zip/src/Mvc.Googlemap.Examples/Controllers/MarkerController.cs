﻿using System.Web.Mvc;
using Mvc.Googlemap.Examples.Filters;

namespace Mvc.Googlemap.Examples.Controllers
{
    [AutoPopulateSourceCode]
    [PopulateProductSiteMap(SiteMapName = "examples", ViewDataKey = "jmelosegui.googlemap.examples")]
    public partial class MarkerController : Controller
    {
        /* left only because of the attributes, which are example-agnostic */
    }
}
