﻿using Telerik.Web.Mvc;

namespace Mvc.Googlemap.Examples.Filters
{
    public class PopulateProductSiteMapAttribute : PopulateSiteMapAttribute
    {
        public override void OnResultExecuting(System.Web.Mvc.ResultExecutingContext filterContext)
        {
            base.OnResultExecuting(filterContext);

            filterContext.Controller.ViewData["jmelosegui.googlemap.examples"] = (XmlSiteMap)filterContext.Controller.ViewData[ViewDataKey]; ;
        }
    }
}
