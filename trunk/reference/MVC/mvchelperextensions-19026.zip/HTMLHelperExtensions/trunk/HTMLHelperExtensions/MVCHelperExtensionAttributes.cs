﻿using System;

namespace MVCHelperExtensions
{
  /// <summary>
  /// Attribute class that specifies the name of the index action to use
  /// when generating a URL to an IEnumerably collection of the class to
  /// which it is applied
  /// </summary>
  [AttributeUsage(AttributeTargets.Class, AllowMultiple = false)]
  public class MVCHelperIndexMethodNameAttribute : Attribute
  {
    public string IndexMethodName { get; set; }

    public MVCHelperIndexMethodNameAttribute(string indexMethodName)
    {
      IndexMethodName = indexMethodName;
    }
  }

  /// <summary>
  /// Attribute class that specifies the name of the details action to use
  /// when generating a URL to an instance of the class to which it is applied
  /// </summary>
  [AttributeUsage(AttributeTargets.Class, AllowMultiple = false)]
  public class MVCHelperDetailsMethodNameAttribute : Attribute
  {
    public string DetailsMethodName { get; set; }

    public MVCHelperDetailsMethodNameAttribute(string detailsMethodName)
    {
      DetailsMethodName = detailsMethodName;
    }
  }

  /// <summary>
  /// Attribute class that specifies the name of the edit action to use
  /// when generating a URL to an instance of the class to which it is applied
  /// </summary>
  [AttributeUsage(AttributeTargets.Class, AllowMultiple = false)]
  public class MVCHelperEditMethodNameAttribute : Attribute
  {
    public string EditMethodName { get; set; }

    public MVCHelperEditMethodNameAttribute(string editMethodName)
    {
      EditMethodName = editMethodName;
    }
  }

  /// <summary>
  /// Attribute class that specifies the name of the create action to use
  /// when generating a URL to an instance of the class to which it is applied
  /// </summary>
  [AttributeUsage(AttributeTargets.Class, AllowMultiple = false)]
  public class MVCHelperNewMethodNameAttribute : Attribute
  {
    public string NewMethodName { get; set; }

    public MVCHelperNewMethodNameAttribute(string newMethodName)
    {
      NewMethodName = newMethodName;
    }
  }
  
  /// <summary>
  /// Attribute class which marks a property or field of the target class
  /// to be used as a unique identifier when generating a URL to an instance
  /// of that class.
  /// </summary>
  /// <remarks>
  /// Is there a way to limit a property attribute to one-per-class?
  /// Also, is there a way to only allow this attribute to be applied to a particular property type (int)?
  /// </remarks>
  [AttributeUsage(AttributeTargets.Property | AttributeTargets.Field, AllowMultiple = false)]
  public class MVCHelperIdentifierAttribute : Attribute
  {
  }

  /// <summary>
  /// Attribute class that specifies the name of the controller to use
  /// when generating a URL to an instance or collection of the class
  /// to which it is applied.
  /// </summary>
  [AttributeUsage(AttributeTargets.Class, AllowMultiple=false)]
  public class MVCHelperControllerNameAttribute : Attribute
  {
    public string ControllerName { get; set; }

    public MVCHelperControllerNameAttribute(string controllerName)
    {
      ControllerName = controllerName;
    }
  }
}
