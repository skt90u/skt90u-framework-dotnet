﻿namespace MVCHelperExtensions
{
  /// <summary>
  /// Static class containing default (conventional) values for 
  /// controller names and actions.
  /// </summary>
  public static class MVCHelpersDefaultValues
  {
    /// <summary>
    /// If no MVCHelperIndexMethodNameHelperAttribute is found then this will be used by default (convention).
    /// </summary>
    public const string INDEX_ACTION_NAME_DEFAULT = "Index";
    /// <summary>
    /// If no MVCHelperDetailsMethodNameAttribute is found then this will be used by default (convention).
    /// </summary>
    public const string DETAILS_ACTION_NAME_DEFAULT = "Details";
    /// <summary>
    /// If no MVCHelperEditMethodNameAttribute is found then this will be used by default (convention).
    /// </summary>
    public const string EDIT_ACTION_NAME_DEFAULT = "Edit";
    /// <summary>
    /// If no MVCHelperNewMethodNameAttribute is found then this will be used by default (convention).
    /// </summary>
    public const string NEW_ACTION_NAME_DEFAULT = "Create"; // Following MVC's poorly named method

    /// <summary>
    /// If no identifying property is found for a model instance, then we will look for any properties
    /// matching one of the names listed here (in order)
    /// </summary> 
    public static string[] DEFAULT_IDENTIFYING_PROPERTY_NAMES = { "ID", "Id", "id", "_ID", "_Id", "_id" };
  }
}
