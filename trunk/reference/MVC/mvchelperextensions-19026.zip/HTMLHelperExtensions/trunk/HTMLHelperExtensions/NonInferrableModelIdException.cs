﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MVCHelperExtensions
{
  /// <summary>
  /// Exception thrown when the HTMLHelper extension methods cannot infer a model's id property
  /// </summary>
  public class NonInferrableModelIdException : Exception
  {
    public NonInferrableModelIdException() : base() { }
    public NonInferrableModelIdException(string message) : base(message) { }
  }
}
