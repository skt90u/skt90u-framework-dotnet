﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Mvc;
using System.Web.Mvc.Html;
using System.Web.WebPages;

namespace MVCControlsToolkit.Core
{
    public class TemplateInvoker<T>:IViewDataContainer, ITemplateInvoker
    {
        private string fileTemplate;
        private Func<HtmlHelper<T>, string> functionTemplate;
        private Func<HtmlHelper<T>, HelperResult> helperTemplate;
        public TemplateInvoker(object template)
        {
            helperTemplate = template as Func<HtmlHelper<T>, HelperResult>;
            functionTemplate = template as Func<HtmlHelper<T>, string>;
            fileTemplate = template as string;
            if (functionTemplate == null && fileTemplate == null && helperTemplate==null)
                throw (new ArgumentException(Resources.templateNotValid));
        }
        public TemplateInvoker()
        {
        }
        internal static Type ExtractModelType(object template)
        {
            
            string fileTemplate = template as string;
            if (fileTemplate == null)
            {
                Type[] res = template.GetType().GetGenericArguments();
                if (res.Length == 0)
                {
                    throw (new ArgumentException(Resources.NotIstantiatedType));
                }
                else
                {
                    res=res[0].GetGenericArguments();
                    if (res.Length == 0 || res[0].ContainsGenericParameters)
                        throw (new ArgumentException(Resources.NotIstantiatedType));
                    return res[0];
                }
            }
            
            else
            {
                throw (new ArgumentException(Resources.TypeSafeTemplateNotValid));
            }
        }
        internal HtmlHelper<T> BuildHelper<M>(HtmlHelper<M> fatherHelper, ViewDataDictionary viewDictionary)
        {
            ControllerContext controllerContext = new ControllerContext
                    (
                        fatherHelper.ViewContext.HttpContext,
                        fatherHelper.ViewContext.RouteData,
                        fatherHelper.ViewContext.Controller
                    );
            ViewContext viewContext = new ViewContext(
                controllerContext,
                fatherHelper.ViewContext.View,
                viewDictionary,
                fatherHelper.ViewContext.TempData,
                fatherHelper.ViewContext.Writer

                    );
            viewContext.ClientValidationEnabled = fatherHelper.ViewContext.ClientValidationEnabled;
            viewContext.FormContext = fatherHelper.ViewContext.FormContext;
            this.ViewData = viewDictionary;
            return new HtmlHelper<T>(
                viewContext,
                this
                );
        }
        public string  Invoke<M>(HtmlHelper<M> fatherHelper, ViewDataDictionary viewDictionary)
        {
            if (fileTemplate != null)
            {
                string res = fatherHelper.Partial(fileTemplate, viewDictionary).ToString();
                return res;
            }
            else if (helperTemplate != null)
            {
                return helperTemplate(BuildHelper(fatherHelper, viewDictionary)).ToString();
            }
            else if (functionTemplate != null)
            {               
                return functionTemplate(BuildHelper(fatherHelper, viewDictionary));
            }
            return string.Empty;
        }
        public string Invoke<M>(HtmlHelper<M> fatherHelper,T model, string prefix)
        {
            ViewDataDictionary<T> dataDictionary = new ViewDataDictionary<T>(model);
            dataDictionary.TemplateInfo.HtmlFieldPrefix = prefix;
            BasicHtmlHelper.CopyRelevantErrors(dataDictionary.ModelState, fatherHelper.ViewData.ModelState, dataDictionary.TemplateInfo.HtmlFieldPrefix);

            return Invoke(fatherHelper, dataDictionary);
        }
        public string Invoke<M>(HtmlHelper<M> fatherHelper, object model, string prefix)
        {
            return Invoke<M>(fatherHelper, (T)model, prefix);
        }


        ViewDataDictionary _ViewData;
        public ViewDataDictionary ViewData
        {
            get
            {
                return _ViewData;
            }
            set
            {
                _ViewData=value;
            }
        }
    }
}
