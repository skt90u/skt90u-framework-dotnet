﻿/* ****************************************************************************
 *
 * Copyright (c) Francesco Abbruzzese. All rights reserved.
 * francesco@dotnet-programming.com
 * http://www.dotnet-programming.com/
 * 
 * This software is subject to the the license at http://mvccontrolstoolkit.codeplex.com/license  
 * and included in the license.txt file of this distribution.
 * 
 * You must not remove this notice, or any other, from this software.
 *
 * ***************************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Web.Mvc;
using System.Web.Mvc.Html;
using MVCControlsToolkit.Core;
using System.Collections;

namespace MVCControlsToolkit.Controls
{
    public class DualSelect<TModel, TEnumerable, TChoiceItem, TValue, TDisplay>
        where TEnumerable : IEnumerable
        where TValue : IConvertible
    {
        static string DualSelect_Separator = ";;;";
        static string DualSelect_SelectAvial = "_AvialSelect";
        static string DualSelect_SelectSelected = "_SelSelect";
        internal HtmlHelper<TModel> CurrHtmlHelper{get;set;}
        private string _prefix;
        internal string Prefix{
            get
            {return _prefix;}
            set
            {
                _prefix=value;
                controlId = BasicHtmlHelper.AddField(
                     CurrHtmlHelper.ViewContext.ViewData.TemplateInfo.GetFullHtmlFieldName(_prefix), 
                    "$.PackedValue").Replace("$", "_").Replace(".", "_");
            }
        }
        private TEnumerable _value;
        private System.Collections.Generic.HashSet<string> valuesSet = null;
        internal TEnumerable Value 
        {
            get
            {
                return _value;
            }
            set
            {
                _value = value;
                valuesSet = new HashSet<string>();
                foreach (object o in _value as IEnumerable)
                {
                    if (o != null) valuesSet.Add(((TValue)o).ToString());  
                }
            }
        }
        private List<SelectListItem> allItems;
        private Dictionary<string, SelectListItem> allItemsDictionary=null;
        private ChoiceList<TChoiceItem, TValue, TDisplay> _currChoiceList=null;
        internal ChoiceList<TChoiceItem, TValue, TDisplay> CurrChoiceList
        {
            get
            {
                return _currChoiceList;
            }
            set
            {
                _currChoiceList = value;
                allItemsDictionary=new Dictionary<string, SelectListItem>();
                allItems=new List<SelectListItem>();
                foreach (TChoiceItem x in _currChoiceList.Items)
                {
                    SelectListItem currItem=
                        new SelectListItem()
                        {
                            Value=(_currChoiceList.ValueSelector(x)as IConvertible).ToString(),
                            Text= _currChoiceList.DisplaySelector(x).ToString(),
                            Selected=false
                        };
                    allItemsDictionary.Add(
                        _currChoiceList.ValueSelector(x).ToString(),
                        currItem);
                    allItems.Add(currItem);
                }
            }
        }
        private string controlId = string.Empty;
        protected string RenderPackedList()
        {
            PackedList<IEnumerable<TValue>, TValue> displayModel = new PackedList<IEnumerable<TValue>, TValue>();

            displayModel.ImportFromModel(Value, new object[] { DualSelect_Separator });

            StringBuilder sb = new StringBuilder();
            sb.Append(BasicHtmlHelper.RenderDisplayInfo(CurrHtmlHelper,
                typeof(PackedList<IEnumerable<TValue>, TValue>),
                Prefix));

            sb.Append(
                CurrHtmlHelper. Hidden(BasicHtmlHelper.AddField(Prefix, "$.Separator"), 
                DualSelect_Separator)).ToString();

            sb.Append(CurrHtmlHelper.Hidden(
                        BasicHtmlHelper.AddField(Prefix, "$.PackedValue"),
                        displayModel.PackedValue));
            return sb.ToString();
        }
        public MvcHtmlString SelectedItems(IDictionary<string, object> htmlAttributes=null)
        {
            List<SelectListItem> selected = new List<SelectListItem>();
            foreach (TValue val in Value)
            {
                if(allItemsDictionary.ContainsKey(val.ToString())) selected.Add(allItemsDictionary[val.ToString()]);
            }

            return MvcHtmlString.Create
                (
                   RenderPackedList()+
                   CurrHtmlHelper.ListBox(
                    controlId+DualSelect_SelectSelected,
                    selected,
                    htmlAttributes).ToString()
                );
        }
        public MvcHtmlString AvailableItems(IDictionary<string, object> htmlAttributes=null)
        {
            List<SelectListItem> NotSelected = new List<SelectListItem>();
            foreach (SelectListItem sel in allItems)
            {
                if (!valuesSet.Contains(sel.Value)) NotSelected.Add(sel);
            }
            return MvcHtmlString.Create
                (
                   
                   CurrHtmlHelper.ListBox(
                    controlId + DualSelect_SelectAvial,
                    NotSelected,
                    htmlAttributes).ToString()
                );
        }
        public MvcHtmlString SelectButton(string displayName, ManipulationButtonStyle buttonStyle = ManipulationButtonStyle.Button, IDictionary<string, object> htmlAttributes = null)
        {
            if (htmlAttributes == null) htmlAttributes = new Dictionary<string, object>(2);
            htmlAttributes.Add("onclick", string.Format(
                "javascript:return DualSelect_MoveElement('{0}', true)", controlId));
            return BaseButton(displayName, buttonStyle, htmlAttributes);
            
        }
        public MvcHtmlString GoUpButton(string displayName, ManipulationButtonStyle buttonStyle = ManipulationButtonStyle.Button, IDictionary<string, object> htmlAttributes = null)
        {
            if (htmlAttributes == null) htmlAttributes = new Dictionary<string, object>(2);
            htmlAttributes.Add("onclick", string.Format(
                "javascript:return DualSelect_Move_Up('{0}', false)", controlId));
            return BaseButton(displayName, buttonStyle, htmlAttributes);

        }
        public MvcHtmlString GoDownButton(string displayName, ManipulationButtonStyle buttonStyle = ManipulationButtonStyle.Button, IDictionary<string, object> htmlAttributes = null)
        {
            if (htmlAttributes == null) htmlAttributes = new Dictionary<string, object>(2);
            htmlAttributes.Add("onclick", string.Format(
                "javascript:return DualSelect_Move_Down('{0}', false)", controlId));
            return BaseButton(displayName, buttonStyle, htmlAttributes);

        }
        public MvcHtmlString SelectAllButton(string displayName, ManipulationButtonStyle buttonStyle = ManipulationButtonStyle.Button, IDictionary<string, object> htmlAttributes = null)
        {
            if (htmlAttributes == null) htmlAttributes = new Dictionary<string, object>(2);
            htmlAttributes.Add("onclick", string.Format(
                "javascript:return DualSelect_MoveAll('{0}', true)", controlId));
            return BaseButton(displayName, buttonStyle, htmlAttributes);
        }
        public MvcHtmlString UnSelectButton(string displayName, ManipulationButtonStyle buttonStyle = ManipulationButtonStyle.Button, IDictionary<string, object> htmlAttributes = null)
        {
            if (htmlAttributes == null) htmlAttributes = new Dictionary<string, object>(2);
            htmlAttributes.Add("onclick", string.Format(
                "javascript:return DualSelect_MoveElement('{0}', false)", controlId));
            return BaseButton(displayName, buttonStyle, htmlAttributes);
        }
        public MvcHtmlString ClearSelectionButton(string displayName, ManipulationButtonStyle buttonStyle = ManipulationButtonStyle.Button, IDictionary<string, object> htmlAttributes = null)
        {
            if (htmlAttributes == null) htmlAttributes = new Dictionary<string, object>(2);
            htmlAttributes.Add("onclick", string.Format(
                "javascript:return DualSelect_MoveAll('{0}', false)", controlId));
            return BaseButton(displayName, buttonStyle, htmlAttributes);
        }

        protected MvcHtmlString BaseButton(string displayName,
            ManipulationButtonStyle buttonStyle, IDictionary<string, object> htmlAttributes)
        {
            switch (buttonStyle)
            {
                case ManipulationButtonStyle.Button:
                    return MvcHtmlString.Create
                         (
                         string.Format("<input type=\"button\" value=\"{0}\" {1} />",
                                CurrHtmlHelper.Encode(displayName),
                                BasicHtmlHelper.GetAttributesString(htmlAttributes))
                         );
                case ManipulationButtonStyle.Image:
                    htmlAttributes["src"] = displayName;
                    BasicHtmlHelper.SetDefaultStyle(htmlAttributes, "cursor", "pointer");
                    return MvcHtmlString.Create
                         (
                         string.Format("<img {1} />",
                                displayName,
                                BasicHtmlHelper.GetAttributesString(htmlAttributes))
                         );
                default:
                    htmlAttributes["href"] = "javascript:void(0);";
                    return MvcHtmlString.Create
                         (
                         string.Format("<a {1}>{0}</a>",
                                CurrHtmlHelper.Encode(displayName),
                                BasicHtmlHelper.GetAttributesString(htmlAttributes))
                         );

            }
        }

    }
}
