﻿/* ****************************************************************************
 *
 * Copyright (c) Francesco Abbruzzese. All rights reserved.
 * francesco@dotnet-programming.com
 * http://www.dotnet-programming.com/
 * 
 * This software is subject to the the license at http://mvccontrolstoolkit.codeplex.com/license  
 * and included in the license.txt file of this distribution.
 * 
 * You must not remove this notice, or any other, from this software.
 *
 * ***************************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Web.Mvc;
using System.Web.Mvc.Html;
using MVCControlsToolkit.Core;
using MVCControlsToolkit.Controls;

namespace MVCControlsToolkit.Controls.Bindings
{
    internal class BindingsBuilder<M> : IBindingsBuilder<M>
        where M : class
    {
        private static string methodScript=
            @"
            <script language='javascript' type='text/javascript'>
                {0}.{1} = {2};     
            </script>
            ";
        private StringBuilder sb;
        private StringBuilder cssStringBuilder;
        private StringBuilder styleStringBuilder;
        private System.IO.TextWriter writer;
        private string modelName;
        private string modelPrefix;
        private string validationType;
        private string hiddenId;
        public BindingsBuilder(System.IO.TextWriter writer, string modelName, string modelPrefix, string validationType, string hiddenId)
        {
            
            this.writer = writer;
            this.modelName = modelName;
            this.modelPrefix = modelPrefix;
            this.validationType = validationType;
            this.hiddenId = hiddenId;
        }
        public string VerifyFormValid()
        {
            if (writer == null) return string.Empty;
            return string.Format(
                "if(!MvcControlsToolkit_FormIsValid('{0}', '{1}')) return;",
                hiddenId,
                validationType
                );
        }
        public string VerifyFieldsValid<F>(
            Expression<Func<M, F>> expression, 
            params LambdaExpression[] otherExpressions)
        {
            if (writer == null) return string.Empty;
            string firstParam =
                string.Format(
                " if(!MvcControlsToolkit_Validate('{0}', '{1}')) return; ",
                BasicHtmlHelper.IdFromName(GetFullName(expression)),
                validationType);
            if (otherExpressions != null && otherExpressions.Length > 0)
            {
                StringBuilder sb = new StringBuilder();
                sb.Append(firstParam);
                foreach (LambdaExpression expr in otherExpressions)
                {
                    sb.Append(
                        string.Format(
                            " if(!MvcControlsToolkit_Validate('{0}', '{1}')) return; ",
                            BasicHtmlHelper.IdFromName(BasicHtmlHelper.AddField(
                                modelPrefix, 
                                ExpressionHelper.GetExpressionText(expr))),
                            validationType)
                        );
                }
                return sb.ToString();
            }
            else
                return firstParam;
        }
        public LambdaExpression L<F>(Expression<Func<M, F>> expression)
        {
            return expression;
        }
        public IBindingsBuilder<M> Add(string binding)
        {
            if (writer == null) return this;
            if (sb == null) sb = new StringBuilder();
            if (sb.Length > 0) sb.Append(", ");
            sb.Append(binding);
            return this;
        }
        public IBindingsBuilder<M> AddMethod(string name, string javaScriptCode)
        {
            
            if (writer != null) 
                writer.Write(string.Format(methodScript, modelName, name, javaScriptCode));
            return this;
        }
        public IBindingsBuilder<M> CSS<F>(
            string className,
            Expression<Func<M, F>> expression,
            string format = null,
            params LambdaExpression[] otherExpressions)
        {
            if (expression == null) throw (new ArgumentNullException("expression"));
            if (string.IsNullOrWhiteSpace(className)) throw (new ArgumentNullException("className"));
            if (writer == null) return this;
            if (cssStringBuilder == null) cssStringBuilder = new StringBuilder();
            cssStringBuilder.Append(BindingsExtensions.standardString<M, F>(className, expression, format, otherExpressions));
            return this;
        }
        
        public IBindingsBuilder<M> Style<F>(
            string stypePropertyName,
            Expression<Func<M, F>> expression,
            string format = null,
            params LambdaExpression[] otherExpressions )
        {
            if (expression == null) throw (new ArgumentNullException("expression"));
            if (string.IsNullOrWhiteSpace(stypePropertyName)) throw (new ArgumentNullException("stypePropertyName"));
            if (writer == null) return this;
            if (styleStringBuilder == null) styleStringBuilder = new StringBuilder();
            cssStringBuilder.Append(BindingsExtensions.standardString<M, F>(stypePropertyName, expression, format, otherExpressions));
            return this;
        }
        public string GetFullName<F>(Expression<Func<M, F>> expression)
        {
            if (expression == null) throw (new ArgumentNullException("expression"));
            return BasicHtmlHelper.AddField(modelPrefix, ExpressionHelper.GetExpressionText(expression));
        }
        public MvcHtmlString Get()
        {
            if (writer == null) return MvcHtmlString.Create(string.Empty);
            if (cssStringBuilder != null && cssStringBuilder.Length > 0)
            {
                Add("css: {"); sb.Append(cssStringBuilder.ToString()); sb.Append("}");
            }
            cssStringBuilder = null;
            if (styleStringBuilder != null && styleStringBuilder.Length > 0)
            {
                Add("style: {"); sb.Append(cssStringBuilder.ToString()); sb.Append("}");
            }
            styleStringBuilder = null;
            if (sb != null)
            {
                string res = sb.ToString();
                sb = null;
                return MvcHtmlString.Create(res);
            }
            else 
                return MvcHtmlString.Create(string.Empty);
        }
    }
}
