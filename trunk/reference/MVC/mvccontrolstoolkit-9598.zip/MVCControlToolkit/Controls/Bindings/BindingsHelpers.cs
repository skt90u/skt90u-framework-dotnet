﻿/* ****************************************************************************
 *
 * Copyright (c) Francesco Abbruzzese. All rights reserved.
 * francesco@dotnet-programming.com
 * http://www.dotnet-programming.com/
 * 
 * This software is subject to the the license at http://mvccontrolstoolkit.codeplex.com/license  
 * and included in the license.txt file of this distribution.
 * 
 * You must not remove this notice, or any other, from this software.
 *
 * ***************************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Web.Mvc;
using System.Web.Mvc.Html;
using MVCControlsToolkit.Core;
using MVCControlsToolkit.Controls;
using System.Web.Script.Serialization;

namespace MVCControlsToolkit.Controls.Bindings
{
    
    public static class BindingsHelpers
    {
        private static string rootBingingScript =
            @"
            <script language='javascript' type='text/javascript'>
                var {0} = ko.mapping.fromJSON('{1}'); 
                $(document).ready(function()
                {{
                     ko.applyBindings({0}); 
                }});
            </script>
            ";
        private static string elementBingingScript =
            @"
            <script language='javascript' type='text/javascript'>
                var {0} = ko.mapping.fromJSON('{1}'); 
                $(document).ready(function()
                {{
                     ko.applyBindings({0}, document.getElementById('{2}')); 
                }});
            </script>
            ";
        public static IBindingsBuilder<T> ClientViewModel<VM, T>(
            this HtmlHelper<VM> htmlHelper,
            string uniqueName,
            Expression<Func<VM, T>> expression,
            string htmlElementId = null
            )
            where T:class, new()
        {
            if (uniqueName == null) throw (new ArgumentNullException("uniqueName"));
            if (expression == null) throw (new ArgumentNullException("expression"));
            string partialPrefix = ExpressionHelper.GetExpressionText(expression);
            string prefix = htmlHelper.ViewData.TemplateInfo.GetFullHtmlFieldName(partialPrefix);
            T model = null;
            try
            {
                model = expression.Compile().Invoke(htmlHelper.ViewData.Model);
            }
            catch
            {
            }
            string validationType = null;

            switch (MvcEnvironment.Validation(htmlHelper))
            {
                case ValidationType.StandardClient: validationType = "StandardClient"; break;
                case ValidationType.UnobtrusiveClient: validationType = "UnobtrusiveClient"; break;
                default: validationType = "Server"; break;
            }
            if (model == null)
                return new BindingsBuilder<T>(null, uniqueName, prefix, validationType, null);

            string script = null;
            if (htmlElementId == null) script = rootBingingScript;
            else script = elementBingingScript;

            ModelTranslator<T> translator = new ModelTranslator<T>();
            translator.ImportFromModel(model);
             
            htmlHelper.ViewContext.Writer.Write(
                BasicHtmlHelper.RenderDisplayInfo(htmlHelper, 
                typeof(ModelTranslator<T>),
                partialPrefix));
            string jsonHiddenId = BasicHtmlHelper.IdFromName(
                BasicHtmlHelper.AddField(prefix, "$.JSonModel"));
            
            htmlHelper.ViewContext.Writer.Write(
                htmlHelper.Hidden(
                    BasicHtmlHelper.AddField(partialPrefix, 
                    "$.JSonModel"),
                    translator.JSonModel
                    )
                );
            string jsonModel = string.Format(script, uniqueName, translator.JSonModel, htmlElementId);
            htmlHelper.ViewContext.Writer.Write(jsonModel );

            
            IBindingsBuilder<T> result =
                new BindingsBuilder<T>(htmlHelper.ViewContext.Writer, uniqueName, prefix, validationType, jsonHiddenId);
            result.AddMethod("save", string.Format(@"
                    function(){{
                        document.getElementById('{0}').value = ko.mapping.toJSON(this);
                    }}",
                       jsonHiddenId));
            result.AddMethod("saveAndSubmit", string.Format(@"
                    function(){{
                        this.save();
                        if(MvcControlsToolkit_FormIsValid('{0}', '{1}')){{
                            $('#{0}').parents('form').submit();
                        }}
                    }}",
                       jsonHiddenId,
                       validationType
                       ));
            return result;
        }


    }
}
