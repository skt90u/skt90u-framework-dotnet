﻿/* ****************************************************************************
 *
 * Copyright (c) Francesco Abbruzzese. All rights reserved.
 * francesco@dotnet-programming.com
 * http://www.dotnet-programming.com/
 * 
 * This software is subject to the the license at http://mvccontrolstoolkit.codeplex.com/license  
 * and included in the license.txt file of this distribution.
 * 
 * You must not remove this notice, or any other, from this software.
 *
 * ***************************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Web.Mvc;
using System.Web.Mvc.Html;

namespace MVCControlsToolkit.Controls.Bindings
{
    public interface IBindingsBuilder<M>
        where M : class
    {
        IBindingsBuilder<M> Add(string binding);
        IBindingsBuilder<M> AddMethod(string name, string javaScriptCode);
        IBindingsBuilder<M> CSS<F>(
            string className,
            Expression<Func<M, F>> expression,
            string format = null,
            params LambdaExpression[] otherExpressions);
        IBindingsBuilder<M> Style<F>(
            string stypePropertyName,
            Expression<Func<M, F>> expression,
            string format = null,
            params LambdaExpression[] otherExpressions);
            string GetFullName<F>(Expression<Func<M, F>> expression);
        string VerifyFieldsValid<F>(
                Expression<Func<M, F>> expression,
                params LambdaExpression[] otherExpressions);
        string VerifyFormValid();
        LambdaExpression L<F>(Expression<Func<M, F>> expression);
        MvcHtmlString Get();
    }
}
