﻿/* ****************************************************************************
 *
 * Copyright (c) Francesco Abbruzzese. All rights reserved.
 * francesco@dotnet-programming.com
 * http://www.dotnet-programming.com/
 * 
 * This software is subject to the the license at http://mvccontrolstoolkit.codeplex.com/license  
 * and included in the license.txt file of this distribution.
 * 
 * You must not remove this notice, or any other, from this software.
 *
 * ***************************************************************************/
using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;
using MVCControlsToolkit.Core;
using MVCControlsToolkit.Controls;
using System.Web.Script.Serialization;
using System.Reflection;
using System.ComponentModel.DataAnnotations;

namespace MVCControlsToolkit.Controls.Bindings
{
    internal class ModelTranslator<T>: IDisplayModel, IUpdateModelState
    {
        public string JSonModel { get; set; }
        private string prefix;
        private System.Web.Mvc.ModelStateDictionary modelState;
        public object ExportToModel(Type TargetType, params object[] context)
        {
            JavaScriptSerializer serializer = new JavaScriptSerializer();
            T result=serializer.Deserialize<T>(JSonModel);
            Validate(result, null, null, prefix); 
            return result;
        }
        private void Validate(object x, object father, string propertyName,  string currPrefix)
        {
            if (x == null) return;
            if (x is IConvertible)
            {
                if (father == null) return;
                
                ValidationContext ctx = new ValidationContext(father, null, null);
                ctx.MemberName = propertyName;
                List<ValidationResult> errors = new List<ValidationResult>();
                bool success = Validator.TryValidateProperty(x, ctx, errors);
                if (!success)
                {
                    foreach (ValidationResult vs in errors)
                    {
                        modelState.AddModelError(currPrefix, vs.ErrorMessage); 
                    }
                }
            }
            else if (x is IEnumerable)
            {
                int i = 0;
                foreach (object y in x as IEnumerable)
                {
                    Validate(y, null, null,
                        BasicHtmlHelper.AddField(currPrefix,
                        string.Format("[{0}]", i)
                        ));
                }
            }
            else
            {
                Type currType = x.GetType();
                if (currType.IsClass)
                {
                    List<ValidationResult> errors = new List<ValidationResult>();
                    bool success = Validator.TryValidateObject(x, new ValidationContext(x, null, null), errors, true);
                    ValidationAttribute[] attrs=currType.GetCustomAttributes(typeof(ValidationAttribute), true) as ValidationAttribute[];
                    
                    foreach (ValidationAttribute attr in attrs)
                    {
                        ValidationResult vs = attr.GetValidationResult(x, new ValidationContext(x, null, null));
                        if (vs!= null && vs != ValidationResult.Success)
                            modelState.AddModelError(currPrefix, vs.ErrorMessage);
                    }
                    
                    foreach (PropertyInfo prop in currType.GetProperties())
                    {
                        
                        Validate(prop.GetValue(x, new object[0]),
                            x,
                            prop.Name,
                            BasicHtmlHelper.AddField(currPrefix, prop.Name));
                    }
                }
            }
        }
        public void ImportFromModel(object model, params object[] context)
        {
            JavaScriptSerializer serializer = new JavaScriptSerializer();
            JSonModel = serializer.Serialize(model);
        }

        public void GetCurrState(string currPrefix, int updateIndex, System.Web.Mvc.ModelStateDictionary modelState)
        {
            if (currPrefix == "model") currPrefix = string.Empty;
            this.prefix = currPrefix;
            this.modelState = modelState;
        }

        public bool MoveState
        {
            get { return false; }
        }
    }
}
