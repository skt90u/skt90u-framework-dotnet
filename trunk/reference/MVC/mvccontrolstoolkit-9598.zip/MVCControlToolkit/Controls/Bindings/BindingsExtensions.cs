﻿/* ****************************************************************************
 *
 * Copyright (c) Francesco Abbruzzese. All rights reserved.
 * francesco@dotnet-programming.com
 * http://www.dotnet-programming.com/
 * 
 * This software is subject to the the license at http://mvccontrolstoolkit.codeplex.com/license  
 * and included in the license.txt file of this distribution.
 * 
 * You must not remove this notice, or any other, from this software.
 *
 * ***************************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Web.Mvc;
using System.Web.Mvc.Html;

namespace MVCControlsToolkit.Controls.Bindings
{
    public static class BindingsExtensions
    {
        public static IBindingsBuilder<T> Visible<T, F>(
            this IBindingsBuilder<T> bindingsBuilder,
            Expression<Func<T, F>> expression,
            string format = null,
            params LambdaExpression[] otherExpressions)
            where T : class
        {
            if (expression == null) throw (new ArgumentNullException("expression"));
            bindingsBuilder.Add(
                standardString<T, F>("visible", expression, format, otherExpressions)
                );
            return bindingsBuilder;
        }
        public static IBindingsBuilder<T> Text<T, F>(
            this IBindingsBuilder<T> bindingsBuilder,
            Expression<Func<T, F>> expression,
            string format = null,
            params LambdaExpression[] otherExpressions)
            where T : class
        {
            if (expression == null) throw (new ArgumentNullException("expression"));
            bindingsBuilder.Add(
                standardString<T, F>("text", expression, format, otherExpressions)
                );
            return bindingsBuilder;
        }
        public static IBindingsBuilder<T> Enable<T, F>(
            this IBindingsBuilder<T> bindingsBuilder,
            Expression<Func<T, F>> expression,
            string format = null,
            params LambdaExpression[] otherExpressions)
            where T : class
        {
            if (expression == null) throw (new ArgumentNullException("expression"));
            bindingsBuilder.Add(
                standardString<T, F>("enable", expression, format, otherExpressions)
                );
            return bindingsBuilder;
        }
        public static IBindingsBuilder<T> Disable<T, F>(
            this IBindingsBuilder<T> bindingsBuilder,
            Expression<Func<T, F>> expression,
            string format = null,
            params LambdaExpression[] otherExpressions)
            where T : class
        {
            if (expression == null) throw (new ArgumentNullException("expression"));
            bindingsBuilder.Add(
                standardString<T, F>("disable", expression, format, otherExpressions)
                );
            return bindingsBuilder;
        }
        public static IBindingsBuilder<T> Value<T, F>(
            this IBindingsBuilder<T> bindingsBuilder,
            Expression<Func<T, F>> expression,
            string format = null,
            params LambdaExpression[] otherExpressions)
            where T : class
        {
            if (expression == null) throw (new ArgumentNullException("expression"));
            bindingsBuilder.Add(
                standardString<T, F>("value", expression, format, otherExpressions)
                );
            return bindingsBuilder;
        }
        public static IBindingsBuilder<T> Checked<T, F>(
            this IBindingsBuilder<T> bindingsBuilder,
            Expression<Func<T, F>> expression,
            string format = null,
            params LambdaExpression[] otherExpressions)
            where T : class
        {
            if (expression == null) throw (new ArgumentNullException("expression"));
            bindingsBuilder.Add(
                standardString<T, F>("checked", expression, format, otherExpressions)
                );
            return bindingsBuilder;
        }
        public static IBindingsBuilder<T> Click1<T, F>(
            this IBindingsBuilder<T> bindingsBuilder,
            Expression<Func<T, F>> expression,
            string format = null,
            params Expression[] otherExpressions)
            where T : class
        {
            if (expression == null) throw (new ArgumentNullException("expression"));
            
            return bindingsBuilder;
        }
        public static IBindingsBuilder<T> Options<T, F>(
            this IBindingsBuilder<T> bindingsBuilder,
            Expression<Func<T, F>> expression,
            string format = null,
            params LambdaExpression[] otherExpressions)
            where T : class
        {
            if (expression == null) throw (new ArgumentNullException("expression"));
            bindingsBuilder.Add(
                standardString<T, F>("options", expression, format, otherExpressions)
                );
            return bindingsBuilder;
        }
        public static IBindingsBuilder<T> SelectedOptions<T, F>(
            this IBindingsBuilder<T> bindingsBuilder,
            Expression<Func<T, F>> expression,
            string format = null,
            params LambdaExpression[] otherExpressions)
            where T : class
        {
            if (expression == null) throw (new ArgumentNullException("expression"));
            bindingsBuilder.Add(
                standardString<T, F>("selectedOptions", expression, format, otherExpressions)
                );
            return bindingsBuilder;
        }
        public static IBindingsBuilder<T> Template<T, F>(
            this IBindingsBuilder<T> bindingsBuilder,
            Expression<Func<T, F>> expression,
            string format = null,
            params LambdaExpression[] otherExpressions)
            where T : class
        {
            if (expression == null) throw (new ArgumentNullException("expression"));
            bindingsBuilder.Add(
                standardString<T, F>("template", expression, format, otherExpressions)
                );
            return bindingsBuilder;
        }
        public static IBindingsBuilder<T> UniqueName<T>(this IBindingsBuilder<T> bindingsBuilder)
            where T : class
        {
            bindingsBuilder.Add(
                "uniqueName: true"
                );
            return bindingsBuilder;
        }
        public static IBindingsBuilder<T> Click<T, F>(
            this IBindingsBuilder<T> bindingsBuilder,
            Expression<Func<T, F>> expression,
            string format = null,
            params LambdaExpression[] otherExpressions)
            where T : class
        {
            if (expression == null) throw (new ArgumentNullException("expression"));
            bindingsBuilder.Add(
                standardString<T, F>("click", expression, format, otherExpressions)
                );
            return bindingsBuilder;
        }
        public static IBindingsBuilder<T> Submit<T, F>(
            this IBindingsBuilder<T> bindingsBuilder,
            Expression<Func<T, F>> expression,
            string format = null,
            params LambdaExpression[] otherExpressions)
            where T : class
        {
            if (expression == null) throw (new ArgumentNullException("expression"));
            bindingsBuilder.Add(
                standardString<T, F>("submit", expression, format, otherExpressions)
                );
            return bindingsBuilder;
        }

        internal static string standardString<T, F>(
            string bindingName,
            Expression<Func<T, F>> expression,
            string format,
            params LambdaExpression[] otherExpressions)
            where T : class
        {
            if (format == null)
            {
                return bindingName + ": " + ExpressionHelper.GetExpressionText(expression);
            }
            else if (otherExpressions == null || otherExpressions.Length == 0)
            {
                return bindingName + ": " + string.Format(format, ExpressionHelper.GetExpressionText(expression)+"()");
            }
            else
            {
                string[] args = new string[otherExpressions.Length + 1];
                args[0] = ExpressionHelper.GetExpressionText(expression);
                int index = 1;
                foreach (LambdaExpression currExpression in otherExpressions)
                {
                    args[index] = ExpressionHelper.GetExpressionText(currExpression)+"()";
                    index++;
                }
                return bindingName + ": " + string.Format(format, args);
            }
        }

    }
}
