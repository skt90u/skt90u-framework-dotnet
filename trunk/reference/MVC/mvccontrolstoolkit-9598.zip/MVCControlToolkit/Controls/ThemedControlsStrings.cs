﻿/* ****************************************************************************
 *
 * Copyright (c) Francesco Abbruzzese. All rights reserved.
 * francesco@dotnet-programming.com
 * http://www.dotnet-programming.com/
 * 
 * This software is subject to the the license at http://mvccontrolstoolkit.codeplex.com/license  
 * and included in the license.txt file of this distribution.
 * 
 * You must not remove this notice, or any other, from this software.
 *
 * ***************************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Reflection;
using System.Web;

namespace MVCControlsToolkit.Controls
{
    public static class ThemedControlsStrings
    {
        public static Type ResourceType{get; set;}
        public static string DefaultTheme;
        public static string GetTheme()
        {
            if (HttpContext.Current.Items.Contains("MvcControlsToolkitTheme"))
            {
                return HttpContext.Current.Items["MvcControlsToolkitTheme"] as string;
            }
            return DefaultTheme;
        }
        public static void SetTheme(string theme)
        {
            HttpContext.Current.Items["MvcControlsToolkitTheme"] = theme;
        }
        public static string Get(string key, string name)
        {
            if (ResourceType == null) ResourceType = typeof(ControlsResources);
            string result = null;
            try
            {
                PropertyInfo prop = ResourceType.GetProperty(key+"_"+name, System.Reflection.BindingFlags.Public | System.Reflection.BindingFlags.Static);
                if (prop == null)
                    prop = ResourceType.GetProperty(key, System.Reflection.BindingFlags.Public | System.Reflection.BindingFlags.Static);
                prop = typeof(ControlsResources).GetProperty(key, System.Reflection.BindingFlags.Public | System.Reflection.BindingFlags.Static);
                if (prop != null) result = prop.GetValue(null, null) as string;
                
            }
            catch
            {
            }
            return result;
        }
    }
}
