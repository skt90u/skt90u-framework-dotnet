﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Web.Mvc;
using System.Web.Mvc.Html;
using MVCControlsToolkit.Core;
using System.Globalization;

namespace MVCControlsToolkit.Controls
{
    public static class RangeHelpers
    {
        public static MvcHtmlString Range<VM>(
            this HtmlHelper<VM> htmlHelper,
            string name,
            double value)
        {
            if (name == null) throw (new ArgumentNullException("name"));
            name =
                  htmlHelper.ViewContext.ViewData.TemplateInfo.GetFullHtmlFieldName(
                      name);
            return MvcHtmlString.Create(
                string.Format("<input type='range' name='{0}' id='{1}' value='{2}'/>",
                name, BasicHtmlHelper.IdFromName(name),
                value.ToString(CultureInfo.InvariantCulture)));

        }
        public static MvcHtmlString Range<VM>(
            this HtmlHelper<VM> htmlHelper,
            string name,
            double value,
            object htmlAttributes)
        {
            if (name == null) throw (new ArgumentNullException("name"));
            name =
                  htmlHelper.ViewContext.ViewData.TemplateInfo.GetFullHtmlFieldName(
                      name);
            return MvcHtmlString.Create(
                string.Format("<input type='range' name='{0}' id='{1}' value='{2}' {3}/>",
                name, BasicHtmlHelper.IdFromName(name),
                value.ToString(CultureInfo.InvariantCulture),
                BasicHtmlHelper.GetAttributesString(htmlAttributes)));

        }
        public static MvcHtmlString Range<VM>(
            this HtmlHelper<VM> htmlHelper,
            string name,
            double value,
            IDictionary<string, object> htmlAttributes = null)
        {
            if (name == null) throw (new ArgumentNullException("name"));
            name =
                  htmlHelper.ViewContext.ViewData.TemplateInfo.GetFullHtmlFieldName(
                      name);
            return MvcHtmlString.Create(
                string.Format("<input type='range' name='{0}' id='{1}' value='{2}' {3}/>",
                name, BasicHtmlHelper.IdFromName(name),
                value.ToString(CultureInfo.InvariantCulture),
                BasicHtmlHelper.GetAttributesString(htmlAttributes)));
        }
        public static MvcHtmlString RangeFor<VM, T>(
            this HtmlHelper<VM> htmlHelper,
            Expression<Func<VM, T>> expression)
        {
            if (expression == null) throw (new ArgumentNullException("expression"));

            var name =
                  htmlHelper.ViewContext.ViewData.TemplateInfo.GetFullHtmlFieldName(
                      ExpressionHelper.GetExpressionText(expression));
            T originalValue = default(T);
            try
            {
                originalValue = expression.Compile().Invoke(htmlHelper.ViewData.Model);
            }
            catch { }
            double value = Convert.ToDouble(originalValue);
            return MvcHtmlString.Create(
                string.Format("<input type='range' name='{0}' id='{1}' value='{2}'/>",
                name, BasicHtmlHelper.IdFromName(name),
                value.ToString(CultureInfo.InvariantCulture)));

        }
        public static MvcHtmlString RangeFor<VM, T>(
            this HtmlHelper<VM> htmlHelper,
            Expression<Func<VM, T>> expression,
            object htmlAttributes )
        {
            if (expression == null) throw (new ArgumentNullException("expression"));

            var name =
                  htmlHelper.ViewContext.ViewData.TemplateInfo.GetFullHtmlFieldName(
                      ExpressionHelper.GetExpressionText(expression));
            T originalValue = default(T);
            try
            {
                originalValue = expression.Compile().Invoke(htmlHelper.ViewData.Model);
            }
            catch { }
            double value = Convert.ToDouble(originalValue);
            return MvcHtmlString.Create(
                string.Format("<input type='range' name='{0}' id='{1}' value='{2}' {3}/>",
                name, BasicHtmlHelper.IdFromName(name),
                value.ToString(CultureInfo.InvariantCulture),
                BasicHtmlHelper.GetAttributesString(htmlAttributes)));

        }
        public static MvcHtmlString RangeFor<VM, T>(
            this HtmlHelper<VM> htmlHelper,
            Expression<Func<VM, T>> expression,
            IDictionary<string, object> htmlAttributes)
        {
            if (expression == null) throw (new ArgumentNullException("expression"));

            var name =
                  htmlHelper.ViewContext.ViewData.TemplateInfo.GetFullHtmlFieldName(
                      ExpressionHelper.GetExpressionText(expression));
            T originalValue = default(T);
            try
            {
                originalValue = expression.Compile().Invoke(htmlHelper.ViewData.Model);
            }
            catch { }
            double value = Convert.ToDouble(originalValue);
            return MvcHtmlString.Create(
                string.Format("<input type='range' name='{0}' id='{1}' value='{2}', {3}/>",
                name, BasicHtmlHelper.IdFromName(name),
                value.ToString(CultureInfo.InvariantCulture),
                BasicHtmlHelper.GetAttributesString(htmlAttributes)));

        }
    }
}
