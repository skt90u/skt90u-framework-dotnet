﻿/* ****************************************************************************
 *
 * Copyright (c) Francesco Abbruzzese. All rights reserved.
 * francesco@dotnet-programming.com
 * http://www.dotnet-programming.com/
 * 
 * This software is subject to the the license at http://mvccontrolstoolkit.codeplex.com/license  
 * and included in the license.txt file of this distribution.
 * 
 * You must not remove this notice, or any other, from this software.
 *
 * ***************************************************************************/
using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;
using System.Web.Mvc;
using System.Web.Mvc.Html;
using MVCControlsToolkit.Core;
using System.ComponentModel.DataAnnotations;
using MVCControlsToolkit.DataAnnotations;
using System.Linq.Expressions;
using System.Reflection;

namespace MVCControlsToolkit.Controls
{
    public enum ItemType { Simple, AutoDelete, HandlesDelete }
    
    public static class CoreHTMLHelpers
    {
        private static string ajaxSubmitEnablerScript = @"
            <script language='javascript' type='text/javascript'>
                 $(document).ready(function () {{
                     $('#{0}').submit(function (event) {{ return false; }})
                 }})
            </script>
        ";

        public static MvcHtmlString TemplateFor<VM>(
            this HtmlHelper<VM> htmlHelper,
            object template)
        {
            if (template == null) throw new ArgumentNullException("template");
                return MvcHtmlString.Create(
                    new TemplateInvoker<VM>(template).Invoke(htmlHelper, htmlHelper.ViewData));
        }
        public static MvcHtmlString TemplateFor<VM, T>(
            this HtmlHelper<VM> htmlHelper,
            Expression<Func<VM, T>> expression,
            object template)
        {
            if (template == null) throw new ArgumentNullException("template");
            if (expression == null)
                return MvcHtmlString.Create(
                    new TemplateInvoker<VM>(template).Invoke(htmlHelper, htmlHelper.ViewData));
            
            string prefix = htmlHelper.ViewData.TemplateInfo.GetFullHtmlFieldName(
                ExpressionHelper.GetExpressionText(expression));
            T model = default(T);
            return MvcHtmlString.Create(
                new TemplateInvoker<T>(template).Invoke(
                htmlHelper,
                model,
                prefix));
        }

        public static MvcHtmlString IsValid<VM>(this HtmlHelper<VM> htmlHelper)
        {
            return htmlHelper.GenericInput(InputType.Hidden, "IsValid",
                htmlHelper.ViewData.ModelState.IsValid ? "True" : "False", null);
        }
        public static MvcHtmlString AjaxSubmitEnabler<VM>(this HtmlHelper<VM> htmlHelper, string formName, bool addPrefix=true)
        {
            if (addPrefix) formName=BasicHtmlHelper.IdFromName(htmlHelper.ViewData.TemplateInfo.GetFullHtmlFieldName(formName));
            return MvcHtmlString.Create(
                string.Format(ajaxSubmitEnablerScript, formName));
        }
        public static string PrefixedName<VM>(this HtmlHelper<VM> htmlHelper, string localName)
        {
            return BasicHtmlHelper.AddField(htmlHelper.ViewData.TemplateInfo.HtmlFieldPrefix, localName);
        }
        public static string PrefixedId<VM>(this HtmlHelper<VM> htmlHelper, string localName)
        {
            return BasicHtmlHelper.IdFromName(BasicHtmlHelper.AddField(htmlHelper.ViewData.TemplateInfo.HtmlFieldPrefix, localName));
        }
        public static string ItemContainerId<VM>(this HtmlHelper<VM> htmlHelper)
        {
            return htmlHelper.PrefixedId("Container");
        }
        public static string StandardIdFor<VM, T>(this HtmlHelper<VM> htmlHelper, Expression<Func<VM, T>> expression)
        {
            return htmlHelper.PrefixedId(ExpressionHelper.GetExpressionText(expression));
        }
        public static string ValueFor<VM, T>(this HtmlHelper<VM> htmlHelper, Expression<Func<VM, T>> expression)
        {
            if (expression == null) throw (new ArgumentNullException("expression"));
            string res=string.Empty;
            try
            {
                res=Convert.ToString(expression.Compile().Invoke(htmlHelper.ViewData.Model));
            }
            catch
            {
            }
            return res;
        }
        public static string FormattedDisplay<VM, T>(this HtmlHelper<VM> htmlHelper, Expression<Func<VM, T>> expression)
        {
            if(expression == null) throw(new ArgumentNullException("expression"));
            string fieldName = ExpressionHelper.GetExpressionText(expression);
            T res = default(T);
            try
            {
                res = expression.Compile().Invoke(htmlHelper.ViewData.Model);
            }
            catch
            {
            }
            PropertyAccessor pa = new PropertyAccessor(fieldName, typeof(VM));
            FormatAttribute[] fa = pa[typeof(FormatAttribute)] as FormatAttribute[];
            if (fa != null && fa.Length > 0) return fa[0].GetDisplay(res);
            DisplayFormatAttribute[] dfa = pa[typeof(DisplayFormatAttribute)] as DisplayFormatAttribute[];
            if (dfa != null && dfa.Length > 0) return new FormatAttribute(dfa[0]).GetDisplay(res);
            return Convert.ToString(res);
        }
        private static string displayFieldScript =
           @"
            <span id = '{1}'>{0}</span>
            <script language='javascript' type='text/javascript'>
              var {1}_True = '{2}';
            </script>   
            ";
        private static string displayImageEnumlFieldScript =
           @"
            <img id = '{1}' src'{0}'/>
            <script language='javascript' type='text/javascript'>
              var {1}_True = '{2}';
            </script>   
            ";
        private static string displayBoolFieldScript =
           @"
            <input id='{1}' type='checkbox' {0} />
            <script language='javascript' type='text/javascript'>
              var {1}_True = '{2}';
            </script>   
            ";
        private static MvcHtmlString DisplayEnum<VM>(HtmlHelper<VM> htmlHelper, object value, int index, string id, string[] displayValues = null, string[] imageUrls = null)
        {
            if (imageUrls != null && index < imageUrls.Length && imageUrls[index] != null)
            {
                return MvcHtmlString.Create(
                        string.Format(displayImageEnumlFieldScript,
                        imageUrls[index],
                        id,
                        Convert.ToString(value)));
            }
            else if (displayValues != null && index < displayValues.Length && displayValues[index] != null)
            {
                return MvcHtmlString.Create(
                        string.Format(displayFieldScript,
                        htmlHelper.Encode(displayValues[index]),
                        id,
                        Convert.ToString(value)));
            }
            else
            {
                
                return MvcHtmlString.Create(
                        string.Format("<span id = '{1}'>{0}</span>",
                        Convert.ToString(value),
                        id));
            }
        }
        public static MvcHtmlString DisplayField<VM, T>(this HtmlHelper<VM> htmlHelper, Expression<Func<VM, T>> expression, string format = null, 
            string[] displayValues=null, string[] imageUrls=null)
        {
            if (expression == null) throw (new ArgumentNullException("expression"));
            string fieldName = ExpressionHelper.GetExpressionText(expression);
            string fRes = null;
            bool mustEncode = true;
            T res = default(T);
            try
            {
                res = expression.Compile().Invoke(htmlHelper.ViewData.Model);
            }
            catch
            {
            }
            string id = BasicHtmlHelper.IdFromName(htmlHelper.ViewData.TemplateInfo.GetFullHtmlFieldName(fieldName));
            if (typeof(T) == typeof(bool))
            {
                bool val = Convert.ToBoolean(res);
                int index = val ? 1 : 0;
                if (displayValues == null && imageUrls == null)
                {
                    return MvcHtmlString.Create(
                        string.Format(displayBoolFieldScript,
                        val ? "checked = ' checked'" : "",
                        id,
                        Convert.ToString(val)));
                }
                else
                {
                    return DisplayEnum(htmlHelper, val, index, id, displayValues, imageUrls);
                }
            }
            else if (typeof(T) == typeof(bool?))
            {
                bool? val = res as bool?;
                int index = 0;
                if (val != null & val.HasValue)
                    index = val.Value ? 2 : 1;
                return DisplayEnum(htmlHelper, val, index, id, displayValues, imageUrls);
            }
            else if (typeof(T).IsEnum)
            {
                object val = res;
                int index = Convert.ToInt32(val);
                return DisplayEnum(htmlHelper, val, index, id, displayValues, imageUrls);
            }
            bool changed = true;
            if (format != null && res != null)
            {
                fRes = string.Format(format, res);
            }
            else
            {
                PropertyAccessor pa = new PropertyAccessor(fieldName, typeof(VM));
                FormatAttribute[] fa = pa[typeof(FormatAttribute)] as FormatAttribute[];

                if (fa != null && fa.Length > 0)
                {
                    mustEncode = fa[0].HtmlEncode;
                    fRes = fa[0].GetDisplay(res);
                }
                else

                {
                    DisplayFormatAttribute[] dfa = pa[typeof(DisplayFormatAttribute)] as DisplayFormatAttribute[];
                    if (dfa != null && fa.Length > 0)
                    {
                        mustEncode = dfa[0].HtmlEncode;
                        fRes = new FormatAttribute(dfa[0]).GetDisplay(res);
                    }
                    else
                    {
                        if (res == null)
                        {
                            fRes = string.Empty;
                            changed = false;
                        }
                        else
                        {
                            fRes = BasicHtmlHelper.GetStandardValue(res);
                            changed = false;
                        }
                    }
                }
            }

            if (changed)
            {
                return MvcHtmlString.Create(
                       string.Format(displayFieldScript,
                       mustEncode ? htmlHelper.Encode(fRes) : fRes, id, BasicHtmlHelper.GetStandardValue(res)));
            }
            else
            {
                return MvcHtmlString.Create(
                        string.Format("<span id = '{1}'>{0}</span>", 
                        mustEncode ? htmlHelper.Encode(fRes) : fRes, id));
            }
        }
        public static HtmlHelper<NM> TransformedHelper<VM, M, NM>(
           this HtmlHelper<VM> htmlHelper,
           Expression<Func<VM, M>> expression,
           NM newModel,
           params object[] args)
            where NM : IDisplayModel
        {
            return
                RenderWith(htmlHelper,
                    InvokeTransform(htmlHelper,
                        expression,
                        newModel,
                        args));
        }
        public static HtmlHelper<NM> TransformedUpdateHelper<VM, M, NM>(
           this HtmlHelper<VM> htmlHelper,
           Expression<Func<VM, M>> expression,
           NM newModel,
           params object[] args)
            where NM : IUpdateModel
        {
            return
                RenderWith(htmlHelper,
                    InvokeUpdateTransform(htmlHelper,
                        expression,
                        newModel,null, args));
        }
        public static RenderInfo<NM> InvokeTransform<VM, M, NM>(
            this HtmlHelper<VM> htmlHelper,
            Expression<Func<VM, M>> expression,
            NM newModel,
            object[] args = null)
            where NM : IDisplayModel
            
        {
            
            if (expression == null) throw (new ArgumentNullException("expression"));
            if (newModel == null) throw (new ArgumentNullException("newModel"));
            
            var fullPropertyPath =
                  htmlHelper.ViewContext.ViewData.TemplateInfo.GetFullHtmlFieldName(
                      ExpressionHelper.GetExpressionText(expression));
             M originalValue=default(M);
             try
            {
                originalValue = expression.Compile().Invoke(htmlHelper.ViewData.Model);
            }
            catch{}

            newModel.ImportFromModel(originalValue, args);
            string shortPrefix=ExpressionHelper.GetExpressionText(expression);
            return new RenderInfo<NM>
            {
                PartialRendering = BasicHtmlHelper.RenderDisplayInfo(htmlHelper, typeof(NM), shortPrefix),
                
                Prefix = string.IsNullOrWhiteSpace(fullPropertyPath) ? "$" : fullPropertyPath+".$",

                PartialPrefix = string.IsNullOrWhiteSpace(shortPrefix) ? "$" : shortPrefix + ".$",

                Model=newModel

            };
        }

        public static RenderInfo<NM> InvokeTransform<VM, M, NM>(
            this HtmlHelper<VM> htmlHelper,
            RenderInfo<M> renderInfo,
            NM newModel,
            object[] args = null)
            where NM : IDisplayModel
            
        {
            
            if (renderInfo == null) throw (new ArgumentNullException("renderInfo"));
            if (newModel == null) throw (new ArgumentNullException("newModel"));
            
            var fullPropertyPath = renderInfo.Prefix;
            newModel.ImportFromModel(renderInfo.Model, args);

            return new RenderInfo<NM>
            {
                PartialRendering = BasicHtmlHelper.RenderDisplayInfo(htmlHelper, typeof(NM), renderInfo.PartialPrefix),

                Prefix = string.IsNullOrWhiteSpace(fullPropertyPath) ? "$" : fullPropertyPath + ".$",

                PartialPrefix = string.IsNullOrWhiteSpace(renderInfo.PartialPrefix) ? "$" : renderInfo.PartialPrefix + ".$",

                Model=newModel

            };
        }

        public static RenderInfo<NM> InvokeUpdateTransform<VM, M, NM>(
            this HtmlHelper<VM> htmlHelper,
            Expression<Func<VM, M>> expression,
            NM newModel,
            string[] expressions=null,
            object[] pars=null)
            where NM : IUpdateModel
            
        {
            if (newModel == null) throw (new ArgumentNullException("newModel"));
            if (expression == null) throw (new ArgumentNullException("expression"));
            if (expressions == null) expressions = new string[0];

            
            string partialPrefix = ExpressionHelper.GetExpressionText(expression);
            string toRender = BasicHtmlHelper.RenderUpdateInfo<M>(htmlHelper, newModel, ref partialPrefix, expressions);
            var prefix =
                 htmlHelper.ViewContext.ViewData.TemplateInfo.GetFullHtmlFieldName(
                     partialPrefix);
            object[] args = new object[expressions.Length];
           
            M model=default(M);
            try
            {
                model = expression.Compile().Invoke(htmlHelper.ViewData.Model);
            }
            catch
            {
            }
            if (model != null)
            {
                int index = 0;
                foreach (string exp in expressions)
                {
                    try
                    {
                        args[index] = new PropertyAccessor(model, exp).Value;
                    }
                    catch
                    {
                    }
                    
                    index++;
                }
            }

            newModel.ImportFromModel(model, args, expressions, pars);

            return new RenderInfo<NM>
            {
                Prefix = string.IsNullOrWhiteSpace(prefix) ? "$" : prefix+".$",
                PartialPrefix = string.IsNullOrWhiteSpace(partialPrefix) ? "$" : partialPrefix + ".$",
                Model = newModel,
                PartialRendering = toRender
            };
        }

        public static RenderInfo<NM> InvokeUpdateTransform<VM, M, NM>(
            this HtmlHelper<VM> htmlHelper,
            RenderInfo<M> renderInfo,
            NM newModel,
            string[] expressions = null,
            object[] pars=null)
            where NM : IUpdateModel
        {
            if (newModel == null) throw (new ArgumentNullException("newModel"));
            if (renderInfo == null) throw (new ArgumentNullException("renderInfo"));
            
                
            if (expressions == null) expressions = new string[0];

            var prefix = renderInfo.Prefix.Trim();
            string partialPrefix = renderInfo.PartialPrefix.Trim();
            

            string toRender = renderInfo.PartialRendering + BasicHtmlHelper.RenderUpdateInfo<M>(htmlHelper, newModel, ref partialPrefix, expressions);
            prefix = htmlHelper.ViewData.TemplateInfo.GetFullHtmlFieldName(partialPrefix);
            object[] args = new object[expressions.Length];
            
            M model = renderInfo.Model;

            if (model != null)
            {
                int index = 0;
                foreach (string exp in expressions)
                {
                    try
                    {
                        args[index] = new PropertyAccessor(model, exp).Value;
                    }
                    catch
                    {
                    }

                    index++;
                }
            }

            newModel.ImportFromModel(model, args, expressions, pars);

            return new RenderInfo<NM>
            {
                Prefix = string.IsNullOrWhiteSpace(prefix) ? "$" : prefix + ".$",
                PartialPrefix = string.IsNullOrWhiteSpace(partialPrefix) ? "$" : prefix + ".$",
                Model = newModel,
                PartialRendering = toRender
            };
        }

        public static MvcHtmlString RenderIn<VM, M>(
            this HtmlHelper<VM> htmlHelper,
            object template,
            RenderInfo<M> renderiNFO)
        {
            if (template == null) throw (new ArgumentNullException("template"));
            if (renderiNFO == null) throw (new ArgumentNullException("renderiNFO"));

            if (template == null) template = typeof(M).Name;

            ViewDataDictionary<M> dataDictionary =
                new ViewDataDictionary<M>(renderiNFO.Model);
                dataDictionary.TemplateInfo.HtmlFieldPrefix = renderiNFO.Prefix;
                BasicHtmlHelper.CopyRelevantErrors(dataDictionary.ModelState, htmlHelper.ViewData.ModelState, dataDictionary.TemplateInfo.HtmlFieldPrefix);    
                return MvcHtmlString.Create(
                    renderiNFO.PartialRendering+
                    new TemplateInvoker<M>(template).Invoke<VM>(htmlHelper, dataDictionary));
        }

        public static HtmlHelper<M> RenderWith<VM, M>(
            this HtmlHelper<VM> htmlHelper,
            RenderInfo<M> renderiNFO)
        {
            
            if (renderiNFO == null) throw (new ArgumentNullException("renderiNFO"));
            htmlHelper.ViewContext.Writer.Write(renderiNFO.PartialRendering);

            ViewDataDictionary<M> dataDictionary =
                new ViewDataDictionary<M>(renderiNFO.Model);
            dataDictionary.TemplateInfo.HtmlFieldPrefix = renderiNFO.Prefix;
             BasicHtmlHelper.CopyRelevantErrors(dataDictionary.ModelState, htmlHelper.ViewData.ModelState, dataDictionary.TemplateInfo.HtmlFieldPrefix);
             return new TemplateInvoker<M>().BuildHelper(htmlHelper, dataDictionary);
        }

        public static MvcHtmlString RenderIn<VM, M, NM>(
            this HtmlHelper<VM> htmlHelper,
            Expression<Func<M, NM>> expression,
            object template,
            RenderInfo<M> renderiNFO)
        {
            if (template == null) throw (new ArgumentNullException("template"));
            if (expression == null) throw (new ArgumentNullException("expression"));
            if (renderiNFO == null) throw (new ArgumentNullException("renderiNFO"));

            if (template == null) template = typeof(M).Name;
            
            NM newModel = default(NM);
            if (renderiNFO.Model != null)
            {
                try
                {
                    newModel = expression.Compile().Invoke(renderiNFO.Model);
                }
                catch { }
            }

            ViewDataDictionary<NM> dataDictionary =
                new ViewDataDictionary<NM>(newModel);

            string prefix = ExpressionHelper.GetExpressionText(expression);
            if (string.IsNullOrWhiteSpace(prefix))
                dataDictionary.TemplateInfo.HtmlFieldPrefix = renderiNFO.Prefix;
            else
                dataDictionary.TemplateInfo.HtmlFieldPrefix = renderiNFO.Prefix+"."+prefix;
            BasicHtmlHelper.CopyRelevantErrors(dataDictionary.ModelState, htmlHelper.ViewData.ModelState, dataDictionary.TemplateInfo.HtmlFieldPrefix);
            return MvcHtmlString.Create(
                renderiNFO.PartialRendering +
                new TemplateInvoker<NM>(template).Invoke<VM>(htmlHelper, dataDictionary));
        }

        public static MvcHtmlString RenderModelEnumerableFor<VM, M>(
            this HtmlHelper<VM> htmlHelper,
            Expression<Func<VM, List<M>>> expression,
            string template,
            bool deletable = false,
            ItemType itemType = ItemType.Simple
            )
        {
            switch (itemType)
            {
                case ItemType.Simple:
                    return RenderEnumerableIn<SimpleEnumerableUpdater<M>, VM, M>
                        (htmlHelper,
                        template,
                         ExtractFromModel(htmlHelper, expression),
                         deletable);
                case ItemType.HandlesDelete:
                    return RenderEnumerableIn<EnumerableUpdater<M>, VM, M>
                        (htmlHelper,
                        template,
                         ExtractFromModel(htmlHelper, expression),
                         deletable);
                default:
                    return RenderEnumerableIn<AutoEnumerableUpdater<M>, VM, M>
                        (htmlHelper,
                        template,
                         ExtractFromModel(htmlHelper, expression),
                         deletable);
            }

        }

        public static  MvcHtmlString RenderAddItemFor<VM, NM, IT>(
            this HtmlHelper<VM> htmlHelper,
            Expression<Func<VM, NM>> expression,
            string template,
            ItemType itemType)
        {
            switch (itemType)
            {
                case ItemType.Simple:
                    return htmlHelper.RenderIn(
                        template,
                        htmlHelper.Extract(
                            t => t.Item,
                            htmlHelper.InvokeUpdateTransform(expression,
                            new SimpleEnumerableUpdater<IT>())));
                case ItemType.AutoDelete:
                    return htmlHelper.RenderIn(
                        template,
                        htmlHelper.Extract(
                            t => t.Item,
                            htmlHelper.InvokeUpdateTransform(expression,
                            new AutoEnumerableUpdater<IT>())));
                default:
                    return htmlHelper.RenderIn(
                       template,
                       htmlHelper.InvokeUpdateTransform(
                           expression,
                           new EnumerableUpdater<IT>()));

            }
        }

        public static MvcHtmlString RenderAddItemFor<VM, NM, IT>(
            this HtmlHelper<VM> htmlHelper,
            RenderInfo<NM> renderInfo,
            string template,
            ItemType itemType)
        {
            switch (itemType)
            {
                case ItemType.Simple:
                    return htmlHelper.RenderIn(
                        template,
                        htmlHelper.Extract(
                            t => t.Item,
                            htmlHelper.InvokeUpdateTransform(renderInfo,
                            new SimpleEnumerableUpdater<IT>())));
                case ItemType.AutoDelete:
                    return htmlHelper.RenderIn(
                        template,
                        htmlHelper.Extract(
                            t => t.Item,
                            htmlHelper.InvokeUpdateTransform(renderInfo,
                            new AutoEnumerableUpdater<IT>())));
                default:
                    return htmlHelper.RenderIn(
                       template,
                       htmlHelper.InvokeUpdateTransform(
                           renderInfo,
                           new EnumerableUpdater<IT>(true)));

            }
        }

        public static MvcHtmlString RenderEnumerableFor<VM, M>(
            this HtmlHelper<VM> htmlHelper,
            RenderInfo<List<M>> renderiNFO,
            string template,
            bool deletable = false,
            ItemType itemType = ItemType.Simple
            )
        {
            switch (itemType)
            {
                case ItemType.Simple:
                    return RenderEnumerableIn<SimpleEnumerableUpdater<M>, VM, M>
                        (htmlHelper,
                        template,
                         renderiNFO,
                         deletable);
                case ItemType.HandlesDelete:
                    return RenderEnumerableIn<EnumerableUpdater<M>, VM, M>
                        (htmlHelper,
                        template,
                         renderiNFO,
                         deletable);
                default:
                    return RenderEnumerableIn<AutoEnumerableUpdater<M>, VM, M>
                        (htmlHelper,
                        template,
                         renderiNFO,
                         deletable);
            }

        }
        
        public static MvcHtmlString RenderEnumerableIn<IM, VM, M>(
            HtmlHelper<VM> htmlHelper,
            string template,
            RenderInfo<List<M>> renderiNFO,
            bool deletable=false)
            
        {
            if (template == null) throw (new ArgumentNullException("template"));
            if (renderiNFO == null) throw (new ArgumentNullException("renderiNFO"));

            bool empty = false;
            IEnumerator enumerator=null;
            if (renderiNFO.Model == null) empty = true;
            else
            {
                enumerator=renderiNFO.Model.GetEnumerator();
                enumerator.Reset();
                empty=!enumerator.MoveNext();
            }
            if(empty)
            {
              return MvcHtmlString.Create(
                renderiNFO.PartialRendering);
            }
            if (template == null) template = typeof(IM).Name;
            if (deletable && typeof(IM).GetInterface("IUpdateModel") == null) 
                throw new NotSupportedException(string.Format(ControlsResources.IUpdateDisplayNotImplemented, "IM"));
            
            

            StringBuilder sb = new StringBuilder();
            sb.Append(renderiNFO.PartialRendering);

            if (deletable)
            {
                ConstructorInfo ci = typeof(IM).GetConstructor(new Type[0]);
                if (ci == null) throw new NotSupportedException(string.Format(Resources.NoConstructor0, typeof(IM).Name));
                int index = 0;
                foreach (object o in renderiNFO.Model)
                {
                    if (o == null) continue;
                    IUpdateModel um = ci.Invoke(new object[0]) as IUpdateModel;
                    um.ImportFromModel(o, null, null, new object[0]);
                    string prefix=renderiNFO.Prefix;
                    string partialPrefix = renderiNFO.PartialPrefix;
                   
                   
                    sb.Append(
                        BasicHtmlHelper.RenderUpdateInfo<M>(htmlHelper, um, ref partialPrefix, new string[0]));

                    prefix = htmlHelper.ViewData.TemplateInfo.GetFullHtmlFieldName(partialPrefix);

                    if (typeof(IM) == typeof(SimpleEnumerableUpdater<M>))
                    {

                        SimpleEnumerableUpdater<M> itemModel = null;
                        if (um != null) itemModel = ((SimpleEnumerableUpdater<M>)um);
                        ViewDataDictionary<M> dataDictionary = new ViewDataDictionary<M>(itemModel.Item);
                        dataDictionary.TemplateInfo.HtmlFieldPrefix = BasicHtmlHelper.AddField(prefix, "$.Item");
                        BasicHtmlHelper.CopyRelevantErrors(dataDictionary.ModelState, htmlHelper.ViewData.ModelState, dataDictionary.TemplateInfo.HtmlFieldPrefix);
                        sb.Append(htmlHelper.Partial(template, dataDictionary));
                    }
                    else if (typeof(IM) == typeof(AutoEnumerableUpdater<M>))
                    {
                        AutoEnumerableUpdater<M> itemModel = null;
                        if (um != null) itemModel = ((AutoEnumerableUpdater<M>)um);
                        ViewDataDictionary<M> dataDictionary = new ViewDataDictionary<M>(itemModel.Item);
                        dataDictionary.TemplateInfo.HtmlFieldPrefix = BasicHtmlHelper.AddField(prefix, "$.Item");
                        BasicHtmlHelper.CopyRelevantErrors(dataDictionary.ModelState, htmlHelper.ViewData.ModelState, dataDictionary.TemplateInfo.HtmlFieldPrefix);
                        sb.Append(htmlHelper.Partial(template, dataDictionary));
                    }
                    else
                    {
                        ViewDataDictionary<IM> dataDictionary = new ViewDataDictionary<IM>((IM)um);
                        dataDictionary.TemplateInfo.HtmlFieldPrefix = BasicHtmlHelper.AddField(prefix, "$.Item");
                        BasicHtmlHelper.CopyRelevantErrors(dataDictionary.ModelState, htmlHelper.ViewData.ModelState, dataDictionary.TemplateInfo.HtmlFieldPrefix);
                        sb.Append(htmlHelper.Partial(template, dataDictionary));
                    }
                    index++;     
                }
            }
            else
            {
                int index=0;
                foreach (object o in renderiNFO.Model)
                {
                    ViewDataDictionary<M> dataDictionary = null;
                    if(o==null)
                        dataDictionary=new ViewDataDictionary<M>(null);
                    else
                        dataDictionary=new ViewDataDictionary<M>((M)o);

                    dataDictionary.TemplateInfo.HtmlFieldPrefix = EnumerableHelper.CreateSubIndexName(renderiNFO.Prefix, index);
                    BasicHtmlHelper.CopyRelevantErrors(dataDictionary.ModelState, htmlHelper.ViewData.ModelState, dataDictionary.TemplateInfo.HtmlFieldPrefix);
                    sb.Append(htmlHelper.Partial(template, dataDictionary));
                    index++;
                }
            }
            

            return MvcHtmlString.Create(
                sb.ToString());
        }

        public static RenderInfo<List<IM>> ConvertToList<VM, NM, IM>(
            this HtmlHelper<VM> htmlHelper,
            Expression<Func<VM, NM>> expression)
        {
            return htmlHelper.Extract(t => t.Items,
                htmlHelper.InvokeTransform(expression, new EnumerableConverter<IM>()));

        }

        public static RenderInfo<List<IM>> ConvertToList<VM, NM, IM>(
            this HtmlHelper<VM> htmlHelper,
            RenderInfo<NM> renderInfo)
        {
            return htmlHelper.Extract(t => t.Items,
                htmlHelper.InvokeTransform(renderInfo, new EnumerableConverter<IM>()));

        }


        public static  RenderInfo<NM> Extract<VM, OM, NM>(
            this HtmlHelper<VM> htmlHelper,
            Expression<Func<OM, NM>> expression,
            RenderInfo<OM> originalModelInfo)
        {
            if (expression == null) throw (new ArgumentNullException("expression"));
            if (originalModelInfo == null) throw (new ArgumentNullException("originalModelInfo"));

            var fullPropertyPath = originalModelInfo.Prefix;
            string partialPath = originalModelInfo.PartialPrefix;
            var expressionName = ExpressionHelper.GetExpressionText(expression);
            if (!string.IsNullOrWhiteSpace(expressionName))
            {
                fullPropertyPath = fullPropertyPath + "." + expressionName;
                partialPath = partialPath + "." + expressionName;
            }
           
            NM finalValue = default(NM);
            try
            {
                finalValue = expression.Compile().Invoke(originalModelInfo.Model);
            }
            catch { }
            return new RenderInfo<NM>
            {
                PartialRendering = originalModelInfo.PartialRendering,

                Prefix = fullPropertyPath,

                PartialPrefix=partialPath,

                Model = finalValue
            };
        }

        public static RenderInfo<NM> ExtractFromModel<VM, NM>(
            this HtmlHelper<VM> htmlHelper,
            Expression<Func<VM, NM>> expression
            )
        {
            if (expression == null) throw (new ArgumentNullException("expression"));
            
            var fullPropertyPath =
                  htmlHelper.ViewContext.ViewData.TemplateInfo.GetFullHtmlFieldName(
                      ExpressionHelper.GetExpressionText(expression));

            var partialPath = ExpressionHelper.GetExpressionText(expression);
            NM finalValue = default(NM);
            try
            {
                finalValue = expression.Compile().Invoke(htmlHelper.ViewData.Model);
            }
            catch { }
            return new RenderInfo<NM>
            {
                PartialRendering = string.Empty,

                Prefix = fullPropertyPath,

                PartialPrefix=partialPath,

                Model = finalValue
            };
        }

        

    }
}
