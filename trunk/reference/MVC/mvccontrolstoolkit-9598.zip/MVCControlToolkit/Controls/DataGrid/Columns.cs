﻿/* ****************************************************************************
 *
 * Copyright (c) Francesco Abbruzzese. All rights reserved.
 * francesco@dotnet-programming.com
 * http://www.dotnet-programming.com/
 * 
 * This software is subject to the the license at http://mvccontrolstoolkit.codeplex.com/license  
 * and included in the license.txt file of this distribution.
 * 
 * You must not remove this notice, or any other, from this software.
 *
 * ***************************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;

namespace MVCControlsToolkit.Controls
{
    public class Columns<T>
    {
        public List<Column> Fields { get; set; }
        public Columns<T> Add<F>
            (Expression<Func<T, F>> field, 
            FieldFeatures features= FieldFeatures.None, 
            object editTemplate=null,
            object displayTemplate=null,
            string overrideName=null){
            if (field == null) throw (new ArgumentException("field"));
            if (Fields == null) Fields = new List<Column>();
            Fields.Add(new Column
            {
                Field=field,
                Features=features,
                EditTemplate = editTemplate,
                DispalyTemplate = displayTemplate,
                ColumnHeader = overrideName

            });
            return this;
        }

    }
}
