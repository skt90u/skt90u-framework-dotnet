﻿/* ****************************************************************************
 *
 * Copyright (c) Francesco Abbruzzese. All rights reserved.
 * francesco@dotnet-programming.com
 * http://www.dotnet-programming.com/
 * 
 * This software is subject to the the license at http://mvccontrolstoolkit.codeplex.com/license  
 * and included in the license.txt file of this distribution.
 * 
 * You must not remove this notice, or any other, from this software.
 *
 * ***************************************************************************/
using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;
using System.Web.Mvc;
using System.Web.Mvc.Html;
using MVCControlsToolkit.Core;
using MVCControlsToolkit.Linq;
using System.Linq.Expressions;
using System.Reflection;
using System.Globalization;


namespace MVCControlsToolkit.Controls
{
    public static class SortableListHelper
    {
        private static string templateSymbol = "QS_23459_86{0}45_ZU";
        private static string startScriptFormat =
        @"
            <script language='javascript' type='text/javascript'>
                var {0}_PermutationUpdateRoot = '{2}';
                $(document).ready(function()
                {{
                    $('#{0}_ItemsContainer' ).sortable({{ {1} update: function(event, ui) {{Update_Permutations(ui.item.attr('id')); }} }});
                    
                }});
            </script>
        ";
        private static string addButtonScript="MvcControlsToolkit_SortableList_AddNew(\"{0}\");";
        private static string stylingScript =
        @"
            <script language='javascript' type='text/javascript'>
                 var {0}_Css = '{1}';
                 var {0}_AltCss = '{2}';
                 $(document).ready(function()
                {{
                    Update_Permutations_Root('{0}');
                }});
            </script>
        ";
        private static string startTemplateScriptFormat =
       @"
            <script language='javascript' type='text/javascript'>
                 var {0}_CanSort = {1};
                 var {0}_ElementsNumber = {2};
                 var {0}_OriginalElementsNumber = {2};
                 var {0}_TemplateSymbol = /{3}/g;
                 var {0}_TemplateSript = null;
                 var {0}_TemplateHtml = null;
                 var {0}_TemplateHidden = '{5}';
                 var {0}_TemplateHiddenHtml = null;
                 var {0}_NamePrefix = '{6}';
                $(document).ready(function()
                {{
                   
                    MvcControlsToolkit_SortableList_PrepareTemplate('{0}', '{4}'); 
                }});
            
            </script>
        ";

        

        public static MvcHtmlString ThemedSortableListFor<M, TItem>(
            this HtmlHelper<M> htmlHelper,
            Expression<Func<M, List<TItem>>> expression,
            SortableListFeatures sortableListFeatures,
            Columns<TItem> fields,
            Expression<Func<M, List<KeyValuePair<LambdaExpression, OrderType>>>> orderExpression = null,
            Expression<Func<M, int>> page = null,
            Expression<Func<M, int>> prevPage = null,
            Expression<Func<M, int>> pageCount = null,
            Expression<Func<M, Expression<Func<TItem, bool>>>> filter = null,
            string title = null,
            string name = "SortableList"
            )
            where TItem : class, new()
        {
            if (expression == null) throw (new ArgumentNullException("(expression"));
            
            if (fields == null || fields.Fields == null || fields.Fields.Count == 0) throw (new ArgumentNullException("fields"));
            string themeName = ThemedControlsStrings.GetTheme();
            htmlHelper.ViewData["ThemeParams"] =
                new SortableListDescription
                {
                    ToShow = expression,
                    ToOrder = orderExpression,
                    Fields = fields.Fields,
                    HtmlHelper = htmlHelper,
                    Features = sortableListFeatures,
                    Title = title,
                    Page = page,
                    PrevPage = prevPage,
                    PageCount = pageCount,
                    Filter = filter
                };
            MvcHtmlString res;
            try
            {
                res = htmlHelper.Partial("Themes/" + themeName + "/" +name, htmlHelper.ViewData);
            }
            finally
            {
                htmlHelper.ViewData["ThemeParams"] = null;
            }
            return res;

        }

        public static MvcHtmlString SortableListAddButton<VM>(
            this HtmlHelper<VM> htmlHelper,
            string textOrUrl,
             ManipulationButtonStyle manipulationButtonStyle = ManipulationButtonStyle.Button,
            IDictionary<string, object> htmlAttributes = null)
        {
            return htmlHelper.ManipulationButton(ManipulationButtonType.Show, textOrUrl,
                                  htmlHelper.PrefixedId("InnerContainer"), null, manipulationButtonStyle, htmlAttributes);
        }
        public static MvcHtmlString SortableListAddButtonFor<VM, T>(
            this HtmlHelper<VM> htmlHelper,
            Expression<Func<VM, List<T>>> expression,
            string textOrUrl,
             ManipulationButtonStyle manipulationButtonStyle = ManipulationButtonStyle.Button,
            IDictionary<string, object> htmlAttributes = null,
            string name = null)
        { 
            if (expression == null) throw (new ArgumentNullException("expression"));
            if (MvcEnvironment.Validation(htmlHelper) == ValidationType.StandardClient) return MvcHtmlString.Create(string.Empty);
            string id = BasicHtmlHelper.IdFromName(htmlHelper.ViewData.TemplateInfo.GetFullHtmlFieldName(ExpressionHelper.GetExpressionText(expression)));
            return htmlHelper.ManipulationButton(ManipulationButtonType.Custom, textOrUrl,
                                  string.Format(addButtonScript, id), name == null ? id + "_AddButton" : name, manipulationButtonStyle, htmlAttributes);
        }
        public static MvcHtmlString SortableListAddButtonFor<VM, TItem>(
            this HtmlHelper<VM> htmlHelper,
            RenderInfo<List<TItem>> renderInfo,
            string textOrUrl,
             ManipulationButtonStyle manipulationButtonStyle = ManipulationButtonStyle.Button,
            IDictionary<string, object> htmlAttributes = null,
            string name=null)
        {
            if (renderInfo == null) throw (new ArgumentNullException("renderInfo"));
            if (MvcEnvironment.Validation(htmlHelper) == ValidationType.StandardClient) return MvcHtmlString.Create(string.Empty);
            string id = BasicHtmlHelper.IdFromName(renderInfo.Prefix);
            return htmlHelper.ManipulationButton(ManipulationButtonType.Custom, textOrUrl,
                string.Format(addButtonScript, id), name == null ? id+"_AddButton" : name, manipulationButtonStyle, htmlAttributes);
        }
        public static MvcHtmlString SortableListCancelButton<VM>(
           this HtmlHelper<VM> htmlHelper,
           string textOrUrl,
            ManipulationButtonStyle manipulationButtonStyle = ManipulationButtonStyle.Button,
           IDictionary<string, object> htmlAttributes = null)
        {
            return htmlHelper.ManipulationButton(ManipulationButtonType.Hide, textOrUrl,
                                  htmlHelper.PrefixedId("InnerContainer"), null, manipulationButtonStyle, htmlAttributes);
        }
        public static MvcHtmlString SortableListDeleteButton<VM>(
           this HtmlHelper<VM> htmlHelper,
           string textOrUrl,
            ManipulationButtonStyle manipulationButtonStyle = ManipulationButtonStyle.Button,
           IDictionary<string, object> htmlAttributes = null)
        {
            return htmlHelper.ManipulationButton(ManipulationButtonType.Remove, textOrUrl,
                                  htmlHelper.PrefixedId("Container"), null, manipulationButtonStyle, htmlAttributes);
        }
        public static string SortableListNewName<VM>(this HtmlHelper<VM> htmlHelper)
        {
            return htmlHelper.PrefixedId("InnerContainer");
        }
        public static MvcHtmlString SortableListFor<VM, TItem>(
            this HtmlHelper<VM> htmlHelper,
            RenderInfo<List<TItem>> renderInfo,
            object template,
            object addElementTemplate = null,
            float opacity = 1,
            bool canSort = true,
            IDictionary<string, object> htmlAttributesContainer = null,
            IDictionary<string, object> htmlAttributesItems = null,
            bool enableMultipleInsert = true,
            ExternalContainerType itemContainer=ExternalContainerType.li,
            ExternalContainerType allItemsContainer=ExternalContainerType.ul,
            object headerTemplate = null,
            object footerTemplate = null,
            string itemCss=null, 
            string altItemCss=null
            )
        {
            if (template == null) throw (new ArgumentNullException("template"));
            if (renderInfo == null) throw (new ArgumentNullException("renderiNFO"));
            if(string.IsNullOrWhiteSpace(itemCss)) itemCss = string.Empty;
            if(string.IsNullOrWhiteSpace(altItemCss)) altItemCss = string.Empty;
            if (canSort)
            {
                itemContainer = ExternalContainerType.li;
                allItemsContainer = ExternalContainerType.ul;
                headerTemplate = null;
                footerTemplate = null;

            }

            StringBuilder sb = new StringBuilder();
            StringBuilder sbInit = new StringBuilder();

            sbInit.Append(renderInfo.PartialRendering);
            if(htmlAttributesContainer == null) htmlAttributesContainer=new Dictionary<string, object>();
            htmlAttributesContainer["id"]=BasicHtmlHelper.IdFromName(renderInfo.Prefix)+"_ItemsContainer";
            string externalOpenTag=null;
            string externalCloseTag = null;
            string itemOpenTag = null;
            string itemCloseTag = null;
            BasicHtmlHelper.GetContainerTags(allItemsContainer, htmlAttributesContainer, out externalOpenTag, out externalCloseTag);
            sb.Append(externalOpenTag);
            if (htmlAttributesItems == null) htmlAttributesItems = new Dictionary<string, object>();

            bool templateEnabled = false;
            switch (MvcEnvironment.Validation(htmlHelper))
            {
                case ValidationType.StandardClient:  break;
                case ValidationType.UnobtrusiveClient:  templateEnabled = true; break;
                default:  templateEnabled = true; break;
            }
            templateEnabled = templateEnabled && enableMultipleInsert;
            int totalCount = 0;
            string javasctiptOpacity = string.Empty;
            string permutationElementPrefix = null;
            if (renderInfo.Model != null)
            {
                if (headerTemplate != null)
                {
                    ViewDataDictionary<TItem> dataDictionary = new ViewDataDictionary<TItem>();
                    dataDictionary.TemplateInfo.HtmlFieldPrefix = renderInfo.Prefix;
                    if (htmlHelper.ViewData.ContainsKey("ThemeParams"))
                    {
                        dataDictionary["ThemeParams"] = htmlHelper.ViewData["ThemeParams"];
                    }
                    BasicHtmlHelper.CopyRelevantErrors(dataDictionary.ModelState, htmlHelper.ViewData.ModelState, dataDictionary.TemplateInfo.HtmlFieldPrefix);
                    htmlAttributesItems["id"] = BasicHtmlHelper.IdFromName(BasicHtmlHelper.AddField(renderInfo.Prefix, "Header")) ;
                    BasicHtmlHelper.GetContainerTags(itemContainer, htmlAttributesItems, out itemOpenTag, out itemCloseTag);
                    sb.Append(itemOpenTag);
                    sb.Append(new TemplateInvoker<TItem>(headerTemplate).Invoke<VM>(htmlHelper, dataDictionary) );
                    sb.Append(itemCloseTag);
                }
                foreach (TItem x in renderInfo.Model)
                {
                    if (x == null) continue;
                    totalCount++;
                    AutoEnumerableUpdater<TItem> um = new AutoEnumerableUpdater<TItem>();
                    um.ImportFromModel(x, null, null, new object[0]);
                    string prefix = renderInfo.Prefix;
                    string partialPrefix = renderInfo.PartialPrefix;
                    sbInit.Append(
                        BasicHtmlHelper.RenderUpdateInfo<TItem>(htmlHelper, um, ref partialPrefix, new string[0]));
                    prefix = htmlHelper.ViewData.TemplateInfo.GetFullHtmlFieldName(partialPrefix);

                    ViewDataDictionary<TItem> dataDictionary = new ViewDataDictionary<TItem>(um.Item);
                    dataDictionary.TemplateInfo.HtmlFieldPrefix = BasicHtmlHelper.AddField(prefix, "$.Item");
                    if (htmlHelper.ViewData.ContainsKey("ThemeParams"))
                    {
                        dataDictionary["ThemeParams"] = htmlHelper.ViewData["ThemeParams"];
                    }
                    BasicHtmlHelper.CopyRelevantErrors(dataDictionary.ModelState, htmlHelper.ViewData.ModelState, dataDictionary.TemplateInfo.HtmlFieldPrefix);
                    htmlAttributesItems["id"] = BasicHtmlHelper.IdFromName(BasicHtmlHelper.AddField(prefix, "$.Item"))+"_Container";
                    BasicHtmlHelper.GetContainerTags(itemContainer, htmlAttributesItems, out itemOpenTag, out itemCloseTag);
                    sb.Append(itemOpenTag);
                    sb.Append(new TemplateInvoker<TItem>(template).Invoke<VM>(htmlHelper, dataDictionary));
                    sb.Append(itemCloseTag);
                }
            }
            if (addElementTemplate != null && !templateEnabled)
            {
                EnumerableUpdater<TItem> um = new EnumerableUpdater<TItem>(true);
                string prefix = renderInfo.Prefix;
                string partialPrefix = renderInfo.PartialPrefix;
                sbInit.Append(
                    BasicHtmlHelper.RenderUpdateInfo<TItem>(htmlHelper, um, ref partialPrefix, new string[0]));
                prefix = htmlHelper.ViewData.TemplateInfo.GetFullHtmlFieldName(partialPrefix);
                sbInit.Append(htmlHelper.GenericInput(InputType.Hidden,
                    BasicHtmlHelper.AddField(partialPrefix, "$.Deleted"), um.Deleted, null));
                ViewDataDictionary<TItem> dataDictionary = new ViewDataDictionary<TItem>(um.Item);
                dataDictionary.TemplateInfo.HtmlFieldPrefix = BasicHtmlHelper.AddField(prefix, "$.Item");
                if (htmlHelper.ViewData.ContainsKey("ThemeParams"))
                {
                    dataDictionary["ThemeParams"] = htmlHelper.ViewData["ThemeParams"];
                }
                BasicHtmlHelper.CopyRelevantErrors(dataDictionary.ModelState, htmlHelper.ViewData.ModelState, dataDictionary.TemplateInfo.HtmlFieldPrefix);
                htmlAttributesItems["id"] = BasicHtmlHelper.IdFromName(BasicHtmlHelper.AddField(prefix, "$.Item")) + "_Container";

                BasicHtmlHelper.GetContainerTags(itemContainer, htmlAttributesItems, out itemOpenTag, out itemCloseTag);
                sb.Append(itemOpenTag);
                sb.Append(new TemplateInvoker<TItem>(addElementTemplate).Invoke<VM>(htmlHelper, dataDictionary));
                sb.Append(itemCloseTag);
            }
            if (canSort)
            {
                PermutationsUpdater<TItem> um = new PermutationsUpdater<TItem>();
                um.ImportFromModel(null, null, null, new object[0]);
                string prefix = renderInfo.Prefix;
                string partialPrefix = renderInfo.PartialPrefix;
                sbInit.Append(
                    BasicHtmlHelper.RenderUpdateInfo<TItem>(htmlHelper, um, ref partialPrefix, new string[0]));
                prefix = htmlHelper.ViewData.TemplateInfo.GetFullHtmlFieldName(partialPrefix);
                sbInit.Append(
                    string.Format("<input type='hidden' id={0} name={1} value=''/>",
                        BasicHtmlHelper.IdFromName(renderInfo.Prefix+"_Permutation"),
                        BasicHtmlHelper.AddField(prefix, "$.Permutation")));
                if (opacity > 1f) opacity = 1f;
                else if (opacity < 0.01f) opacity = 0.01f;
                
                if (opacity < 1f)
                {
                    javasctiptOpacity=string.Format(" opacity: {0}, ", opacity.ToString(CultureInfo.InvariantCulture));
                }
                permutationElementPrefix = prefix;

            }
            if (footerTemplate != null)
            {
                ViewDataDictionary<TItem> dataDictionary = new ViewDataDictionary<TItem>();
                dataDictionary.TemplateInfo.HtmlFieldPrefix = renderInfo.Prefix;
                if (htmlHelper.ViewData.ContainsKey("ThemeParams"))
                {
                    dataDictionary["ThemeParams"] = htmlHelper.ViewData["ThemeParams"];
                }
                BasicHtmlHelper.CopyRelevantErrors(dataDictionary.ModelState, htmlHelper.ViewData.ModelState, dataDictionary.TemplateInfo.HtmlFieldPrefix);
                htmlAttributesItems["id"] = BasicHtmlHelper.IdFromName(BasicHtmlHelper.AddField(renderInfo.Prefix, "Footer"));
                BasicHtmlHelper.GetContainerTags(itemContainer, htmlAttributesItems, out itemOpenTag, out itemCloseTag);
                sb.Append(itemOpenTag);
                sb.Append(new TemplateInvoker<TItem>(footerTemplate).Invoke<VM>(htmlHelper, dataDictionary));
                sb.Append(itemCloseTag);
            }
            if (templateEnabled)
            {
                AutoEnumerableUpdater<TItem> um = new AutoEnumerableUpdater<TItem>();
                string prefix = renderInfo.Prefix;
                string partialPrefix = renderInfo.PartialPrefix;
                string myTemplateSymbol = BasicHtmlHelper.GetUniqueSymbol(htmlHelper, templateSymbol);
                sbInit.Append(
                    BasicHtmlHelper.RenderUpdateInfo<TItem>(htmlHelper, um, ref partialPrefix, new string[0], myTemplateSymbol));
                prefix = htmlHelper.ViewData.TemplateInfo.GetFullHtmlFieldName(partialPrefix);

                ViewDataDictionary<TItem> dataDictionary = new ViewDataDictionary<TItem>(um.Item);
                dataDictionary.TemplateInfo.HtmlFieldPrefix = BasicHtmlHelper.AddField(prefix, "$.Item");
                if (htmlHelper.ViewData.ContainsKey("ThemeParams"))
                {
                    dataDictionary["ThemeParams"] = htmlHelper.ViewData["ThemeParams"];
                }
                BasicHtmlHelper.CopyRelevantErrors(dataDictionary.ModelState, htmlHelper.ViewData.ModelState, dataDictionary.TemplateInfo.HtmlFieldPrefix);
                htmlAttributesItems["id"] = BasicHtmlHelper.IdFromName(BasicHtmlHelper.AddField(prefix, "$.Item")) + "_Container";

                BasicHtmlHelper.GetContainerTags(itemContainer, htmlAttributesItems, out itemOpenTag, out itemCloseTag);
                sb.Append(itemOpenTag);
                sb.Append(new TemplateInvoker<TItem>(template).Invoke<VM>(htmlHelper, dataDictionary));
                sb.Append(itemCloseTag);


                sbInit.Append(string.Format(startTemplateScriptFormat, BasicHtmlHelper.IdFromName(renderInfo.Prefix),
                    canSort ? "true" : "false", totalCount, myTemplateSymbol, htmlAttributesItems["id"],
                    BasicHtmlHelper.IdFromName(prefix), renderInfo.Prefix));
            }
            
            if (canSort) sbInit.Append(string.Format(startScriptFormat, BasicHtmlHelper.IdFromName(renderInfo.Prefix), javasctiptOpacity, BasicHtmlHelper.IdFromName(permutationElementPrefix)));
            string stylingJavaScript = string.Format(stylingScript, BasicHtmlHelper.IdFromName(renderInfo.Prefix), itemCss, altItemCss);
            sbInit.Append(stylingJavaScript);
            sb.Append(externalCloseTag);
            sbInit.Insert(0, sb.ToString());
            return MvcHtmlString.Create(sbInit.ToString());
            
        }
        public static MvcHtmlString SortableListFor<VM, TItem>(
            this HtmlHelper<VM> htmlHelper,
            Expression<Func<VM, List<TItem>>> expression,
            object template,
            object addElementTemplate = null,
            float opacity = 1,
            bool canSort = true,
            IDictionary<string, object> htmlAttributesContainer = null,
            IDictionary<string, object> htmlAttributesItems = null,
            bool enableMultipleInsert = true,
            ExternalContainerType itemContainer = ExternalContainerType.li,
            ExternalContainerType allItemsContainer = ExternalContainerType.ul,
            object headerTemplate = null,
            object footerTemplate = null,
            string itemCss = null,
            string altItemCss = null)
        {
            if (template == null) throw (new ArgumentNullException("template"));
            if (expression == null) throw (new ArgumentNullException("expression"));
            return SortableListFor(
                htmlHelper,
                htmlHelper.ExtractFromModel(expression),
                template,
                addElementTemplate,
                opacity,
                canSort,
                htmlAttributesContainer,
                htmlAttributesItems,
                enableMultipleInsert,
                itemContainer,
                allItemsContainer,
                headerTemplate,
                footerTemplate, 
                itemCss, 
                altItemCss);
        }
            
    }
}
