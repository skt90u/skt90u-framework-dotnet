﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Web.Mvc;
using System.Web.Mvc.Html;
using MVCControlsToolkit.Core;
using System.Globalization;


namespace MVCControlsToolkit.Controls
{
    public enum ContentAlign{Left, Right, Center, None};
    
    public static class TypedTextBoxHelper
    {
        
        private static void applyAlignement(ContentAlign c, ref IDictionary<string, object> attributes)
        {
            
            string align=null;
            switch(c)
            {
                case ContentAlign.Center: align="center"; break;
                case ContentAlign.Left: align="left"; break;
                case ContentAlign.Right: align="right"; break;
                default: return;

            }
            if (attributes == null) attributes = new Dictionary<string, object>();
            BasicHtmlHelper.SetDefaultStyle(attributes, "text-align", align);
        }
        private static void applyAlignement(ContentAlign c, object attributes, out IDictionary<string, object> newAttributes)
        {
            newAttributes = null;
            if (attributes != null) newAttributes = BasicHtmlHelper.AnonymousObjectToDictionary(attributes);
            string align = null;
            switch (c)
            {
                case ContentAlign.Center: align = "center"; break;
                case ContentAlign.Left: align = "left"; break;
                case ContentAlign.Right: align = "right"; break;
                default: return;

            }
            if (newAttributes == null) newAttributes = new Dictionary<string, object>();
            BasicHtmlHelper.SetDefaultStyle(newAttributes, "text-align", align);
        }
        private static int getType(Type TargetType)
        {
            int value = 0;

            if (TargetType == typeof(Int32))
            {
                value = 2;
            }
            else if (TargetType == typeof(Nullable<Int32>))
            {
                value = 2;
            }
            else if (TargetType == typeof(Int16))
            {
                value = 2;
            }
            else if (TargetType == typeof(Nullable<Int16>))
            {
                value = 2;
            }
            else if (TargetType == typeof(Int64))
            {
                value = 2;
            }
            else if (TargetType == typeof(Nullable<Int64>))
            {
                value = 2;
            }
            else if (TargetType == typeof(UInt32))
            {
                value = 1;
            }
            else if (TargetType == typeof(Nullable<UInt32>))
            {
                value = 1;
            }
            else if (TargetType == typeof(UInt16))
            {
                value = 1;
            }
            else if (TargetType == typeof(Nullable<UInt16>))
            {
                value = 1;
            }
            else if (TargetType == typeof(UInt64))
            {
                value = 1;
            }
            else if (TargetType == typeof(Nullable<UInt64>))
            {
                value = 1;
            }
            else if (TargetType == typeof(byte))
            {
                value = 1;
            }
            else if (TargetType == typeof(Nullable<byte>))
            {
                value = 1;
            }
            else if (TargetType == typeof(sbyte))
            {
                value = 2;
            }
            else if (TargetType == typeof(Nullable<sbyte>))
            {
                value = 2;
            }
            else if (TargetType == typeof(decimal))
            {
                value = 3;
            }
            else if (TargetType == typeof(Nullable<decimal>))
            {
                value = 3;
            }
            else if (TargetType == typeof(float))
            {
                value = 3;
            }
            else if (TargetType == typeof(Nullable<float>))
            {
                value = 3;
            }
            else if (TargetType == typeof(double))
            {
                value = 3;
            }
            else if (TargetType == typeof(Nullable<double>))
            {
                value = 3;
            }
            return value;
        }
        private static string script = @"
        <script language='javascript' type='text/javascript'>
                $(document).ready(function()
                {{
                   MvcControlsToolkit_TypedTextBox_Blur('{0}', '{1}', {3}, '{8}', '{9}', '{10}', '{6}', '{7}', '{4}', '{5}',
                           '{11}', '{2}', '{12}');
                   $('#{0}').blur(function(){{
                     MvcControlsToolkit_TypedTextBox_Blur('{0}', '{1}', {3}, '{8}', '{9}', '{10}', '{6}', '{7}', '{4}', '{5}',
                           '{11}', '{2}', '{12}');
                   }});
                   $('#{0}').focus(function(){{
                     MvcControlsToolkit_TypedTextBox_Focus('{0}', '{1}', '{2}');
                   }});
                   $('#{0}').keypress(function(event){{
                     return MvcControlsToolkit_TypedTextBox_Input(event.which, '{0}', '{1}', {3}, '{4}', '{5}', '{6}', '{7}');
                   }});
                   
                }});
        </script>
        "; 
        private static string getScripts<M, T>(
            HtmlHelper<M> htmlHelper,
            string name,
            string watermarkCss,
            string overrideClientFormat,
            string overrideClientPrefix,
            string overrideClientPostfix,
            string overrideWatermark)
        {
            ModelMetadata model = ModelMetadata.FromStringExpression(name, htmlHelper.ViewData);
            if (overrideClientFormat == null)
            {
                object res;
                model.AdditionalValues.TryGetValue("MVCControlsToolkit.ClientFormatString", out res);
                overrideClientFormat = res as string;
            }
            if (string.IsNullOrWhiteSpace(overrideClientFormat)) overrideClientFormat = string.Empty;
            if (overrideClientPrefix == null)
            {
                object res;
                model.AdditionalValues.TryGetValue("MVCControlsToolkit.ClientFormatPrefix", out res);
                overrideClientPrefix = res as string;
            }
            if (string.IsNullOrWhiteSpace(overrideClientPrefix)) overrideClientPrefix = string.Empty;
            if (overrideClientPostfix == null)
            {
                object res;
                model.AdditionalValues.TryGetValue("MVCControlsToolkit.ClientFormatPostfix", out res);
                overrideClientPostfix = res as string;
            }
            if (string.IsNullOrWhiteSpace(overrideClientPostfix)) overrideClientPostfix = string.Empty;
            if (string.IsNullOrWhiteSpace(overrideWatermark))
            {
                overrideWatermark = model.Watermark;
            }
            if (string.IsNullOrWhiteSpace(overrideWatermark)) overrideWatermark = string.Empty;
            int clientType = getType(typeof(T));

            string validationType = null;
            switch (MvcEnvironment.Validation(htmlHelper))
            {
                case ValidationType.StandardClient: validationType = "StandardClient"; break;
                case ValidationType.UnobtrusiveClient: validationType = "UnobtrusiveClient"; break;
                default: validationType = "Server"; break;
            }

            string fieldId = BasicHtmlHelper.IdFromName(htmlHelper.ViewData.TemplateInfo.GetFullHtmlFieldName(name + "_hidden"));
            string companionId = BasicHtmlHelper.IdFromName(htmlHelper.ViewData.TemplateInfo.GetFullHtmlFieldName(name ));
            CultureInfo ci = System.Threading.Thread.CurrentThread.CurrentCulture;
            string decimalSeparator = ci.NumberFormat.NumberDecimalSeparator;
            string digitsSeparator = ci.NumberFormat.NumberGroupSeparator;
            string plus = ci.NumberFormat.PositiveSign;
            string minus = ci.NumberFormat.NegativeSign;

            return string.Format(script, fieldId, companionId, watermarkCss, clientType, decimalSeparator, digitsSeparator,
                plus, minus, overrideClientPrefix, overrideClientPostfix, overrideClientFormat, overrideWatermark, validationType);

        }
        public static MvcHtmlString TypedTextBox<M, T>(this HtmlHelper<M> htmlHelper,
            string name,
            T value,
            IDictionary<string, object> attributes,
            string watermarkCss = null,
            ContentAlign contentAlign = ContentAlign.None,
            string overrideClientFormat = null,
            string overrideClientPrefix = null,
            string overrideClientPostfix = null,
            string overrideWatermark=null)
        {
            if (string.IsNullOrWhiteSpace(name)) throw (new ArgumentNullException("name"));
            if (attributes == null) throw (new ArgumentNullException("attributes"));
            if (watermarkCss == null) watermarkCss = "dummycssstyle";
            applyAlignement(contentAlign, ref attributes);

            return MvcHtmlString.Create(
                htmlHelper.TextBox(name + "_hidden", value, attributes).ToString() +
                (MvcEnvironment.Validation(htmlHelper) == ValidationType.StandardClient ?
                htmlHelper.TextBox(name , value, new { style = "display:none" }).ToString()
                : htmlHelper.Hidden(name, value).ToString()
                ) +
                getScripts<M, T>(
                htmlHelper,
                name,
                watermarkCss,
                overrideClientFormat,
                overrideClientPrefix,
                overrideClientPostfix,
                overrideWatermark));
        }

        public static MvcHtmlString TypedTextBox<M, T>(this HtmlHelper<M> htmlHelper,
            string name,
            T value,
            object attributes,
            string watermarkCss = null,
            ContentAlign contentAlign = ContentAlign.None,
            string overrideClientFormat = null,
            string overrideClientPrefix = null,
            string overrideClientPostfix = null,
            string overrideWatermark = null)
        {
            if (string.IsNullOrWhiteSpace(name)) throw(new ArgumentNullException("name"));
            IDictionary<string, object> newAttributes;
            applyAlignement(contentAlign, attributes, out newAttributes);

            return MvcHtmlString.Create(
                htmlHelper.TextBox(name + "_hidden", value, attributes).ToString() +
                htmlHelper.TextBox(name , value, new { style = "display:none" }).ToString() +
                getScripts<M, T>(
                htmlHelper,
                name,
                watermarkCss,
                overrideClientFormat,
                overrideClientPrefix,
                overrideClientPostfix,
                overrideWatermark));
        }
        public static MvcHtmlString TypedTextBox<M, T>(this HtmlHelper<M> htmlHelper,
            string name,
            T value,
            string watermarkCss = null,
            ContentAlign contentAlign = ContentAlign.None,
            string overrideClientFormat = null,
            string overrideClientPrefix = null,
            string overrideClientPostfix = null,
            string overrideWatermark = null)
        {
            if (string.IsNullOrWhiteSpace(name)) throw (new ArgumentNullException("name"));
            IDictionary<string, object> newAttributes;
            applyAlignement(contentAlign, null, out newAttributes);

            return MvcHtmlString.Create(
                htmlHelper.TextBox(name + "_hidden", value, newAttributes).ToString() +
                htmlHelper.TextBox(name , value, new { style = "display:none" }).ToString() +
                getScripts<M, T>(
                htmlHelper,
                name,
                watermarkCss,
                overrideClientFormat,
                overrideClientPrefix,
                overrideClientPostfix,
                overrideWatermark));
        }
        public static MvcHtmlString TypedTextBoxFor<M, T>(this HtmlHelper<M> htmlHelper,
            Expression<Func<M, T>> expression,
            IDictionary<string, object> attributes,
            string watermarkCss = null,
            ContentAlign contentAlign = ContentAlign.None,
            string overrideClientFormat = null,
            string overrideClientPrefix = null,
            string overrideClientPostfix = null,
            string overrideWatermark = null)
        {
            if (expression==null) throw (new ArgumentNullException("expression"));
            if (attributes == null) throw (new ArgumentNullException("attributes"));
            applyAlignement(contentAlign, ref attributes);
            string name=ExpressionHelper.GetExpressionText(expression);
            object value=null;
            try
            {
                value=expression.Compile().Invoke(htmlHelper.ViewData.Model);
            }
            catch
            {
            }
            return MvcHtmlString.Create(
                htmlHelper.TextBox(name + "_hidden", value, attributes).ToString() +
                htmlHelper.TextBox(name , value, new { style = "display:none" }).ToString() +
                getScripts<M, T>(
                htmlHelper,
                name,
                watermarkCss,
                overrideClientFormat,
                overrideClientPrefix,
                overrideClientPostfix,
                overrideWatermark));
        }

        public static MvcHtmlString TypedTextBoxFor<M, T>(this HtmlHelper<M> htmlHelper,
            Expression<Func<M, T>> expression,
            object attributes,
            string watermarkCss = null,
            ContentAlign contentAlign = ContentAlign.None,
            string overrideClientFormat = null,
            string overrideClientPrefix = null,
            string overrideClientPostfix = null,
            string overrideWatermark = null)
        {
            if (expression == null) throw (new ArgumentNullException("expression"));
            IDictionary<string, object> newAttributes;
            applyAlignement(contentAlign, attributes, out newAttributes);
            string name = ExpressionHelper.GetExpressionText(expression);
            object value = null;
            try
            {
                value = expression.Compile().Invoke(htmlHelper.ViewData.Model);
            }
            catch
            {
            }
            return MvcHtmlString.Create(
                htmlHelper.TextBox(name + "_hidden", value, attributes).ToString() +
                htmlHelper.TextBox(name , value, new { style = "display:none" }).ToString() +
                getScripts<M, T>(
                htmlHelper,
                name,
                watermarkCss,
                overrideClientFormat,
                overrideClientPrefix,
                overrideClientPostfix,
                overrideWatermark));
        }

        public static MvcHtmlString TypedTextBoxFor<M, T>(this HtmlHelper<M> htmlHelper,
            Expression<Func<M, T>> expression,
            string watermarkCss = null,
            ContentAlign contentAlign = ContentAlign.None,
            string overrideClientFormat = null,
            string overrideClientPrefix = null,
            string overrideClientPostfix = null,
            string overrideWatermark = null)
        {
            if (expression == null) throw (new ArgumentNullException("expression"));
            IDictionary<string, object> newAttributes;
            applyAlignement(contentAlign, null, out newAttributes);
            string name = ExpressionHelper.GetExpressionText(expression);
            object value = null;
            try
            {
                value = expression.Compile().Invoke(htmlHelper.ViewData.Model);
            }
            catch
            {
            }
            return MvcHtmlString.Create(
                htmlHelper.TextBox(name + "_hidden", value, newAttributes).ToString() +
                htmlHelper.TextBox(name , value, new { style = "display:none" }).ToString() +
                getScripts<M, T>(
                htmlHelper,
                name,
                watermarkCss,
                overrideClientFormat,
                overrideClientPrefix,
                overrideClientPostfix,
                overrideWatermark));
        }
    }
}
