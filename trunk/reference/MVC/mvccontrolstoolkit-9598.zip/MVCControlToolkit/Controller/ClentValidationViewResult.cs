﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Mvc;
using MVCControlsToolkit.Core;

namespace MVCControlsToolkit.Controller
{
    public class ClentValidationViewResult : ViewResult
    {
        const string DummyFormId = "DummyFormId";
        bool oldClientSetting;
        public ClentValidationViewResult(string viewName, object model)
        {
            ViewName = viewName;
            ViewData = new ViewDataDictionary { Model = model };
        }
 
        public override void ExecuteResult(ControllerContext context)
        {
            var result = base.FindView(context);
            var viewContext = new ViewContext(context, result.View, ViewData, TempData, context.HttpContext.Response.Output);
 
            BeginCapturingValidation(viewContext);
            base.ExecuteResult(context);
            EndCapturingValidation(viewContext);
 
            result.ViewEngine.ReleaseView(context, result.View);
        }
 
        private void BeginCapturingValidation(ViewContext viewContext)
        {

            oldClientSetting = viewContext.ClientValidationEnabled;
            viewContext.ClientValidationEnabled = true;
            viewContext.FormContext = new FormContext { FormId = DummyFormId };
        }
 
        private void EndCapturingValidation(ViewContext viewContext)
        {

            switch (MvcEnvironment.Validation(viewContext))
            {
                case ValidationType.StandardClient:
                    viewContext.OutputClientValidation();
                    break;
                case ValidationType.UnobtrusiveClient: break;
                default: break;
 
            }
            viewContext.ClientValidationEnabled = oldClientSetting;
            
        }
    }
}
