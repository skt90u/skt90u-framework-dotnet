﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel.DataAnnotations;
using MVCControlsToolkit.Core;
using System.Globalization;


namespace MVCControlsToolkit.DataAnnotations
{
    [AttributeUsage(AttributeTargets.Class, AllowMultiple = false, Inherited = true)]
    public class RequiredFieldsAttribute : ValidationAttribute
    {
        public RequiredFieldsAttribute()
            : base()
        {
        }
        public RequiredFieldsAttribute(string message)
            : base(message)
        {
        }
        public string Fields
        {
            get;
            set;
        }
        private string allErrorFieldNames = null;
        public override string FormatErrorMessage(string name)
        {
            return String.Format(CultureInfo.CurrentUICulture, ErrorMessageString,
                allErrorFieldNames);
        }
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            if (value == null) return ValidationResult.Success;
            string[] fields = Fields.Split(',');
            List<string> errorFields=new List<string>();
            StringBuilder sb = new StringBuilder();
            foreach (string x in fields)
            {
                string field=x.Trim();
               
                PropertyAccessor po=new PropertyAccessor(value, field, false);

                object ob = po.Value;
                if (ob == null)
                {
                    errorFields.Add(field);
                    if (sb.Length > 0) sb.Append(", ");
                    sb.Append(po.DisplayName);
                    continue;
                }
                if (!ob.GetType().IsValueType) continue;
                if (ob.Equals(Activator.CreateInstance(ob.GetType())))
                {
                    errorFields.Add(field);
                    if (sb.Length > 0) sb.Append(", ");
                    sb.Append(po.DisplayName);
                }
            }
            if (errorFields.Count == 0) return ValidationResult.Success;
            allErrorFieldNames = sb.ToString();
            return new ValidationResult(null, errorFields);
        }

    }
}
