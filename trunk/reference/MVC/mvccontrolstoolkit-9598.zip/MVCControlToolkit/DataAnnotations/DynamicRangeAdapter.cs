﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;

namespace MVCControlsToolkit.DataAnnotations
{
    public class DynamicRangeAdapter: DataAnnotationsModelValidator<DynamicRangeAttribute> 
    {
        public DynamicRangeAdapter(ModelMetadata metadata, ControllerContext context, DynamicRangeAttribute attribute)
            : base(metadata, context, attribute) {
        }
        
        public override IEnumerable<ModelClientValidationRule> GetClientValidationRules() {
            string errorMessage = ErrorMessage;
            object father = ControllerContext.Controller.ViewData.Model;
            if (Metadata.AdditionalValues.ContainsKey("MVCControlsToolkit.Father"))
            {
                father = Metadata.AdditionalValues["MVCControlsToolkit.Father"];
            }
            string clientMaximum = null;
            string clientMinimum = null;

            object minDelay = null;
            object maxDelay = null;
            var rule = new ModelClientValidationRule
            {
                ErrorMessage = errorMessage,
                ValidationType = Metadata.ModelType == typeof(DateTime) || Metadata.ModelType == typeof(DateTime?) ? "daterange" : "dynamicrange"
            };
            rule.ValidationParameters.Add("min", Attribute.GetGlobalMinimum(father, this.ControllerContext.Controller.ViewData.Model, out clientMinimum, out minDelay));
            rule.ValidationParameters.Add("max", Attribute.GetGlobalMaximum(father, this.ControllerContext.Controller.ViewData.Model, out clientMaximum, out maxDelay));

            if (clientMaximum != null || clientMinimum != null)
            {
                var drule = new ModelClientValidationRule
                {
                    ErrorMessage = errorMessage,
                    ValidationType = Metadata.ModelType == typeof(DateTime) || Metadata.ModelType == typeof(DateTime?) ? "clientdynamicdaterange" : "clientdynamirange"
                };
                drule.ValidationParameters.Add("min", clientMinimum);
                drule.ValidationParameters.Add("max", clientMaximum);
                drule.ValidationParameters.Add("mindelay", minDelay);
                drule.ValidationParameters.Add("maxdelay", maxDelay);
                return new[] { rule, drule };
            }
            else
            {
                return new[] { rule };
            }
        }
    }
}
