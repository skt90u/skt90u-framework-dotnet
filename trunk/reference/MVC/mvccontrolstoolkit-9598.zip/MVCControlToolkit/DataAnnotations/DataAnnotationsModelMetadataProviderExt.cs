﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Web.Mvc;
using System.ComponentModel;
using MVCControlsToolkit.Core;
using MVCControlsToolkit.DataAnnotations;
using System.ComponentModel.DataAnnotations;

namespace MVCControlsToolkit.DataAnnotations
{
    public class DataAnnotationsModelMetadataProviderExt : DataAnnotationsModelMetadataProvider
    {
        
        protected override ModelMetadata CreateMetadata(IEnumerable<Attribute> attributes, Type containerType, Func<object> modelAccessor, Type modelType, string propertyName)
        {
            ModelMetadata res = base.CreateMetadata(attributes, containerType, modelAccessor, modelType, propertyName);

            FormatAttribute formatAttribute = attributes.OfType<FormatAttribute>().FirstOrDefault();
            if (formatAttribute != null)
            {
                string clientFormat;
                string prefix;
                string postfix;
                formatAttribute.GetClientFormat(out prefix, out postfix, out clientFormat);
                res.AdditionalValues.Add("MVCControlsToolkit.ClientFormatString", clientFormat);
                res.AdditionalValues.Add("MVCControlsToolkit.ClientFormatPrefix", prefix);
                res.AdditionalValues.Add("MVCControlsToolkit.ClientFormatPostfix", postfix);
            }
            DisplayAttribute display = attributes.OfType<DisplayAttribute>().FirstOrDefault();
            string name = null;
            if (display != null)
            {
                res.Description = display.GetDescription();
                res.ShortDisplayName = display.GetShortName();
                res.Watermark = display.GetPrompt();
                

                name = display.GetName();
                if (!string.IsNullOrWhiteSpace(name)) res.DisplayName = name;
            }
            if (containerType == null ) return res;
            if (modelAccessor == null) return res;
            System.Reflection.FieldInfo container = modelAccessor.Target.GetType().GetField("container");
            object pathReference = null;
            if (container == null)
            {
                System.Reflection.FieldInfo vdi = modelAccessor.Target.GetType().GetField("vdi");
                if (vdi==null)
                    return res;
                object vdiVal = vdi.GetValue(modelAccessor.Target);
                if (vdiVal == null) return res;
                System.Reflection.PropertyInfo Container = vdiVal.GetType().GetProperty("Container");
                if (Container == null) return res;
                pathReference = Container.GetValue(vdiVal, new object[0]);
                res.AdditionalValues.Add("MVCControlsToolkit.Father", pathReference);
                return res;
            }
            else
            {
                pathReference = container.GetValue(modelAccessor.Target);
            }
            if (pathReference == null) return res;
            if (modelAccessor.Target.GetType().GetField("property") != null)
            {
                res.AdditionalValues.Add("MVCControlsToolkit.Father", pathReference);
                return res;
            }
            System.Reflection.FieldInfo expression = modelAccessor.Target.GetType().GetField("expression");
            if (expression == null)
                return res;
            string path = expression.GetValue(modelAccessor.Target) as string;
            if (path == null)
            {
                LambdaExpression pathExpr = expression.GetValue(modelAccessor.Target) as LambdaExpression;

                if (pathExpr == null || pathReference == null) return res;

                path = ExpressionHelper.GetExpressionText(pathExpr);
            }
            if(string.IsNullOrWhiteSpace(path)) return res;
            
            object father = pathReference;
            if (path.Contains('.'))
            {
                path = path.Substring(0, path.LastIndexOf('.'));
                PropertyAccessor prop = null;
                try
                {
                    prop = new PropertyAccessor(pathReference, path, false);
                }
                catch
                {
                    return res;
                }
                father=prop.Value;
            }
            res.AdditionalValues.Add("MVCControlsToolkit.Father", father);
            return res; 
        }
        
        
    }
}
