﻿/* ****************************************************************************
 *
 * Copyright (c) Francesco Abbruzzese. All rights reserved.
 * francesco@dotnet-programming.com
 * http://www.dotnet-programming.com/
 * 
 * This software is subject to the the license at http://mvccontrolstoolkit.codeplex.com/license  
 * and included in the license.txt file of this distribution.
 * 
 * You must not remove this notice, or any other, from this software.
 *
 * ***************************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using MVCControlsToolkit.Core;

namespace MVCControlsToolkit.Linq
{
    public enum FilterLogicalOperator{And, ExclusiveOr, Or};
    public class FilterBuilder<T>
    {
        private Expression currFilter;
        private ParameterExpression param;
        private FilterLogicalOperator logicalOperator;
        public FilterBuilder (FilterLogicalOperator logicalOperator=FilterLogicalOperator.And)
        {
            this.logicalOperator=logicalOperator;
        }
        private Expression adjustP(Expression exp)
        {

            BinaryExpression expB = exp as BinaryExpression;
            if (expB != null) return expB.Update(adjustP(expB.Left), expB.Conversion, adjustP(expB.Right));
            UnaryExpression expU = exp as UnaryExpression;
            if (expU != null) return expU.Update(adjustP(expU.Operand));
            MemberExpression expM = exp as MemberExpression;
            if (expM != null) return expM.Update(adjustP(expM.Expression));
            MethodCallExpression expC = exp as MethodCallExpression;
            if (expC != null)
            {
                List<Expression> nArgs = new List<Expression>();
                foreach (Expression e in expC.Arguments) nArgs.Add(adjustP(e));
                return expC.Update(adjustP(expC.Object), nArgs);
            }
            if (exp is ParameterExpression) return param;
            return exp;
        }
        public FilterBuilder<T> Add(bool toAdd, Expression<Func<T, bool>> filterClause)
        {
            if (!toAdd) return this;
            if (filterClause.Parameters == null || filterClause.Parameters.Count != 1)
                throw (new ArgumentException(Resources.FilterParameterNumber, "filterClause"));
            if (param == null) param = filterClause.Parameters[0];
            else if (filterClause.Parameters[0].Name != param.Name) 
                throw (new ArgumentException(Resources.FilterParameterName, "filterClause"));

            if (currFilter == null) currFilter = filterClause.Body;
            else
            {
                if(logicalOperator == FilterLogicalOperator.And)
                    currFilter = Expression.And(currFilter, adjustP(filterClause.Body));
                else if (logicalOperator == FilterLogicalOperator.Or) 
                    currFilter = Expression.Or(currFilter, adjustP(filterClause.Body));
                else
                    currFilter = Expression.ExclusiveOr(currFilter, adjustP(filterClause.Body));
            }
            return this;
        }
        public Expression<Func<T, bool>> Get()
        {
            if(currFilter==null) return null;
            return Expression.Lambda<Func<T, bool>>(currFilter, param);
        }
    }
}
