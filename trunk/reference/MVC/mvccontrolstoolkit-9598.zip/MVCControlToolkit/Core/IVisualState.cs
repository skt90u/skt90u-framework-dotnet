﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;

namespace MVCControlsToolkit.Core
{
    public interface IVisualState
    {
        IDictionary Store { set; }
        string ModelName { set; }
    }
}
