﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Mvc;
using System.Web.Mvc.Html;

namespace MVCControlsToolkit.Core
{
    public enum ValidationType {StandardClient, UnobtrusiveClient, Server}
    public static class MvcEnvironment
    {
        public static ValidationType Validation<M>(HtmlHelper<M> htmlHelper)
        {
            if (htmlHelper.ViewContext.ClientValidationEnabled)
            {
                return ValidationType.StandardClient;
            }
            else
            {
                return ValidationType.Server;
            }
        }
        public static ValidationType Validation(ViewContext context)
        {
            if (context.ClientValidationEnabled)
            {
                return ValidationType.StandardClient;
            }
            else
            {
                return ValidationType.Server;
            }
        }
        public static bool UnobtrusiveAjaxOn<M>(HtmlHelper<M> htmlHelper)
        {
            return false;
        }
    }
}
