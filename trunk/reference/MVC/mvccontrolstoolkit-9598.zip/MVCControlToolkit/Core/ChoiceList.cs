﻿/* ****************************************************************************
 *
 * Copyright (c) Francesco Abbruzzese. All rights reserved.
 * francesco@dotnet-programming.com
 * http://www.dotnet-programming.com/
 * 
 * This software is subject to the the license at http://mvccontrolstoolkit.codeplex.com/license  
 * and included in the license.txt file of this distribution.
 * 
 * You must not remove this notice, or any other, from this software.
 *
 * ***************************************************************************/
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;


namespace MVCControlsToolkit.Core
{
    public class ChoiceList<TItem, TValue, TDisplay>
    {
        private IEnumerable<TItem> _items;
        public IEnumerable<TItem> Items
        {
            get
            {
                return _items;
            }
        }
        private Func<TItem, TValue> _valueSelector;

        public Func<TItem, TValue> ValueSelector
        {
            get
            {
                return _valueSelector;
            }
        }

        private Func<TItem, TDisplay> _displaySelector;

        public Func<TItem, TDisplay> DisplaySelector
        {
            get
            {
                return _displaySelector;
            }
        }

        private Func<TItem, object> _labelAttributesSelector;

        public Func<TItem, object> LabelAttributesSelector
        {
            get
            {
                return _labelAttributesSelector;
            }
        }

        private Func<TItem, object> _displayAttributesSelector;

        public Func<TItem, object> DisplayAttributesSelector
        {
            get
            {
                return _displayAttributesSelector;
            }
        }


        public ChoiceList(IEnumerable<TItem> items, 
            Func<TItem, TValue> valueSelector, 
            Func<TItem, TDisplay> displaySelector,
            Func<TItem, object> displayAttributesSelector=null,
            Func<TItem, object> labelAttributesSelector=null)
        {
            _items = items;
            _valueSelector = valueSelector;
            _displaySelector = displaySelector;
            _displayAttributesSelector = displayAttributesSelector;
            _labelAttributesSelector = labelAttributesSelector;
        }
    }
}
