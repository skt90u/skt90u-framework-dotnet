﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Mvc;
using System.Text.RegularExpressions;

namespace MVCControlsToolkit.ActionFilters
{
    public class AcceptViewHintAttribute : ActionFilterAttribute
    {
        public override void OnActionExecuted(ActionExecutedContext filterContext)
        {
            string hint = filterContext.RequestContext.HttpContext.Request.Params["ViewHint"];
            if (hint == null) hint = filterContext.RequestContext.RouteData.Values["ViewHint"] as string;
            if (!string.IsNullOrWhiteSpace(hint) && hint.Length<=100 && new Regex(@"^\w+$").IsMatch(hint) )
            {
                ViewResultBase res = filterContext.Result as ViewResultBase;
                if(res != null) res.ViewName = hint;
            }
            base.OnActionExecuted(filterContext);
        }
    }
}
