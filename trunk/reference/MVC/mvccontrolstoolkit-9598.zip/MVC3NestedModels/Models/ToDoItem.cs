﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using MVCControlsToolkit.DataAnnotations;

namespace MVCNestedModels.Models
{
    public class ToDoItem
    {
       public int Code { get; set; } 

       [Required, CanSort, Display(ShortName = "NAME")]
       public string Name {get;set;}
       
        [CanSort, Display(ShortName = "DESCRIPTION")]
       public string Description { get; set; }
    }
}