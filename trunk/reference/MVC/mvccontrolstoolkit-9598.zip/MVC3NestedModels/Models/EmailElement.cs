﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
namespace MVCNestedModels.Models
{
    public class EmailElement
    {
        public bool IsFolder { get; set; }
        [Required]
        public string Name {get; set;}
        public List<EmailElement> Children { get; set; }
    }
}