Each folder in the archive contains a website with the code examples relative to the corresponding chapter.

Also, a folder may contain additional assemblies provided as Visual Studio projects.

Some examples may require the AdventureWorks database and a valid connection string, depending on your system configuration.

To load an existing website in Visual Studio: File --> Open Web Site --> select website folder.
To load an existing project in Visual Studio: File --> Open Project --> select project file.
