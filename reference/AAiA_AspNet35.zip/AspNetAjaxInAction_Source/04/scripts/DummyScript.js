﻿// No-op.

if(typeof(Sys) !== 'undefined')
    Sys.Application.notifyScriptLoaded();