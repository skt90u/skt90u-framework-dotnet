Type.registerNamespace("Samples");

Samples.AjaxLogin = function(element) {
	Samples.AjaxLogin.initializeBase(this, [element]);
	
	this._userName = null;
	this._password = null;
	this._rememberMe = null;
	this._loginButton = null;
}

Samples.AjaxLogin.prototype = {
	initialize : function() {
		Samples.AjaxLogin.callBaseMethod(this, 'initialize');
		$addHandlers(this._loginButton, {'click':this._onLoginButtonClicked}, this);
	},
	
	dispose : function() {
		$clearHandlers(this._loginButton);
		Samples.AjaxLogin.callBaseMethod(this, 'dispose');
	},
	
	_onLoginButtonClicked : function(e) {
        var validationResult = typeof(Page_ClientValidate) == 'function' && 
								Page_ClientValidate(this._validationGroup) ? true : false;

		if (validationResult) {
			Sys.Services.AuthenticationService.login(
				this._userName.value,
				this._password.value,
				this._rememberMe && this._rememberMe.checked,
				null,
				null,
				Function.createDelegate(this, this._onLoginComplete),
				Function.createDelegate(this, this._onLoginFailed)	
			);		
		}
		e.preventDefault();
	},
	
	_onLoginComplete : function(result) {
		if (result) {
			alert("Login Succeeded");
	    }
		else {
			alert("Login failed");
	    }
	},
	
	_onLoginFailed : function(err) {
		alert(err.get_message());
	},
	
	set_UserName : function(value) {
		this._userName = value;
	},
	
	set_Password : function(value) {
		this._password = value;
	},
		
	set_RememberMe : function(value) {
		this._rememberMe = value;
	},
	
	set_LoginButton : function(value) {
		this._loginButton = value;
	},

	get_UserName : function() {
		return this._userName ;
	},
	
	get_Password : function() {
		return this._password ;
	},
		
	get_RememberMe : function() {
		return this._rememberMe ;
	},
	
	get_LoginButton : function() {
		return this._loginButton ;
	}
	
};
Samples.AjaxLogin.registerClass('Samples.AjaxLogin', Sys.UI.Control);