// (c) Copyright Microsoft Corporation.
// This source is subject to the Microsoft Permissive License.
// See http://www.microsoft.com/resources/sharedsource/licensingbasics/sharedsourcelicenses.mspx.
// All other rights reserved.

using System;
using System.Web.UI.WebControls;
using System.Web.UI;
using System.ComponentModel;
using System.ComponentModel.Design;
using AjaxControlToolkit;

[assembly: System.Web.UI.WebResource("TextChanged.TextChangedBehavior.js", "text/javascript")]

namespace TextChanged
{
    [Designer(typeof(TextChangedDesigner))]
    [ClientScriptResource("TextChanged.TextChangedBehavior", "TextChanged.TextChangedBehavior.js")]
    [TargetControlType(typeof(Control))]
    public class TextChangedExtender : ExtenderControlBase
    {
        [ExtenderControlProperty]
        [DefaultValue(500)]
        [ClientPropertyName("timeout")]
        [RequiredProperty]
        public int Timeout
        {
            get { return GetPropertyValue<int>("Timeout", 500); }
            set { SetPropertyValue<int>("Timeout", value); }
        }

        [ExtenderControlEvent(true)]
        [DefaultValue("")]
        [ClientPropertyName("textChanged")]
        public string OnTextChanged
        {
            get { return GetPropertyValue<string>("OnTextChanged", String.Empty); }
            set { SetPropertyValue<string>("OnTextChanged", value); }
        }
    }
}
