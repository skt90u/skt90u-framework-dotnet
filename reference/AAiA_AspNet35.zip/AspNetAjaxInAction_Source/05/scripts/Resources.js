﻿// JScript File

window.Resources = {
    Login : 'Login',
    Logout : 'Logout',
    LogonFailed : 'Logon Failed',
    LogoutFailed : 'Logout Failed'
};