﻿using System;
using System.Web;
using System.Web.UI;

public partial class SimpleRequest : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
}
