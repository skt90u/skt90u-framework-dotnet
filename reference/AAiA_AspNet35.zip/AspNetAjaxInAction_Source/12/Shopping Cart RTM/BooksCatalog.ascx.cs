using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Collections.Generic;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Samples.ShoppingCart;

public partial class BooksCatalog : System.Web.UI.UserControl, INamingContainer, IScriptControl
{
    private IShoppingCart shoppingCart;
    private object dataSource;

    public IShoppingCart ShoppingCart
    {
        get { return shoppingCart; }
        set { shoppingCart = value; }
    }

    public object DataSource
    {
        get { return dataSource; }
        set { dataSource = value; }
    }

    public override void DataBind()
    {
        listBooks.DataSource = this.dataSource;
        listBooks.DataBind();
    }

    protected void listBooks_ItemCommand(object sender, DataListCommandEventArgs e)
    {
        if (e.CommandName == "AddToCart")
        {
            Button btnAddToCart = e.Item.FindControl("btnAddToCart") as Button;

            // Get book data.
            Book book = BusinessLayer.GetBookById(btnAddToCart.CommandArgument);

            shoppingCart.Add(book);
        }
    }

    protected override void OnPreRender(EventArgs e)
    {
        base.OnPreRender(e);

        if (listBooks.Items.Count > 0)
        {
            ScriptManager sm = ScriptManager.GetCurrent(Page);

            if (sm != null)
            {
                sm.RegisterScriptControl(this);
                sm.RegisterScriptDescriptors(this);
            }
            else
            {
                throw new InvalidOperationException("A ScriptManager control is required on the page.");
            }
        }
    }

    #region IScriptControl Members

    public System.Collections.Generic.IEnumerable<ScriptDescriptor> GetScriptDescriptors()
    {
        List<ScriptBehaviorDescriptor> descriptors = new List<ScriptBehaviorDescriptor>();

        foreach (DataListItem item in listBooks.Items)
        {
            if (item.ItemType == ListItemType.Item || item.ItemType == ListItemType.AlternatingItem)
            {
                Image imgBook = item.FindControl("imgBook") as Image;
                Button btnAddToCart = item.FindControl("btnAddToCart") as Button;

                ScriptBehaviorDescriptor desc = new ScriptBehaviorDescriptor("Samples.BookItem", imgBook.ClientID);
                desc.AddElementProperty("addToCartElement", btnAddToCart.ClientID);
                descriptors.Add(desc);
            }
        }
        return descriptors.ToArray();
    }

    public System.Collections.Generic.IEnumerable<ScriptReference> GetScriptReferences()
    {
        ScriptReference scriptRef = new ScriptReference(Page.ResolveClientUrl("~/ScriptLibrary/BookItem.js"));

        yield return scriptRef;
    }

    #endregion
}
