using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

namespace Samples.ShoppingCart
{
    /// <summary>
    /// Summary description for Book
    /// </summary>
    public class Book : IArticle
    {
        private int quantity;
        private string description;
        private string id;
        private string title;
        private string imageUrl;

        public string ImageUrl
        {
            get { return imageUrl; }
            set { imageUrl = value; }
        }
	
        public string Title
        {
            get { return title; }
            set { title = value; }
        }
	
        public string Id
        {
            get { return id; }
            set { id = value; }
        }
	
        public string Description
        {
            get { return description; }
            set { description = value; }
        }

        public int Quantity
        {
            get { return quantity; }
            set { quantity = value; }
        }
    }
}
