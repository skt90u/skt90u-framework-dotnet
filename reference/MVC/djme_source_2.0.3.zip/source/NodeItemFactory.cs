﻿//  Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Mvc;

namespace DNA.Mvc.jQuery
{
    public abstract class NodeItemFactory<TContainer, TNode, TBuilder, TFactory> : ViewComponentBuilderFactory<TNode>
        where TNode : NodeBase<TContainer, TNode>
        where TBuilder : ViewComponentBuilder<TNode, TBuilder>
    {
        public NodeItemFactory(IComponentItemContainer<TNode> container, AjaxHelper helper) : base(container, helper) { }

        internal TContainer NodeContainer { get; set; }

        protected abstract TNode CreateNodeInstance();

        protected abstract TNode CreateNodeInstance(INavigtable item);

        protected abstract TBuilder CreateBuilder(TNode node);

        public TBuilder Add()
        {
            var n = CreateNodeInstance();
            n.Container = NodeContainer;
            return Add(n);
        }

        public TBuilder Add(INavigtable item)
        {
            var n = CreateNodeInstance(item);
            n.Container = NodeContainer;
            return Add(n);
        }

        public TBuilder Add(TNode item)
        {
            item.Parent = this.Container as TNode;
            this.Container.Items.Add(item);
            this.Container.OnItemAdded(item);
            return CreateBuilder(item);
        }

        public TBuilder Add(string title, string navigateUrl)
        {
            return Add(title, navigateUrl, "");
        }

        public TBuilder Add(string title, string navigateUrl, string imageUrl)
        {
            return Add(title, navigateUrl, imageUrl, "_self");
        }

        public TBuilder Add(string title, string navigateUrl, string imageUrl, string target)
        {
            TNode item = this.CreateNodeInstance();
            item.Title = title;
            item.NavigateUrl = navigateUrl;
            item.ImageUrl = imageUrl;
            item.Target = target;
            item.Container = NodeContainer;
            return Add(item);
        }
    }
}
