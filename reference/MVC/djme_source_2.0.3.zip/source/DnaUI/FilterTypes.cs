﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DNA.Mvc.jQuery
{
    /// <summary>
    /// Defines the FilterTypes that specified which the InputFilter in using.
    /// </summary>
    [Flags]
    public enum FilterTypes
    {
        /// <summary>
        /// Specified the InputFilter using the Numbers text filter ,only number char valid in input.
        /// </summary>
        Numbers = 0,
        /// <summary>
        /// Only lower case charaters can be allows.
        /// </summary>
        LowercaseLetters = 1,
        /// <summary>
        /// Only upper case charaters can be allows.
        /// </summary>
        UppercaseLetters = 2,
        /// <summary>
        /// Using custom filter.
        /// </summary>
        Custom = 3
    }
}
