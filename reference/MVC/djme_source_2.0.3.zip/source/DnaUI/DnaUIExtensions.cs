﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Mvc;

namespace DNA.Mvc.jQuery
{
    /// <summary>
    /// Represents support for Ajax UI  in an application.
    /// </summary>
    public static class DnaUIExtensions
    {
        //public static void FileDialog(this AjaxHelper helper, string triggerID, DomEvents triggerEvent)
        //{
        //}

        #region widgets

        /// <summary>
        /// 
        /// </summary>
        /// <param name="helper"></param>
        /// <param name="targetID"></param>
        public static void Tags(this AjaxHelper helper, string targetID)
        {
            helper.Tags(targetID, null);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="helper"></param>
        /// <param name="targetID"></param>
        /// <param name="options"></param>
        public static void Tags(this AjaxHelper helper, string targetID, TagsOptions options)
        {

            helper.jQuery(targetID, "tags", options);
            if (options != null)
            {
                if (options.IsSortable)
                    helper.Sortable(".ui-tags-nav" + ",#" + targetID, new SortableOptions() { DragOrientation = Orientation.Vertical });
            }
        }

        #endregion

        #region Interaction

        /// <summary>
        /// Returns the html elements of the WaterMark by using the specified Ajax helper,the target id,the watermark text,the watermark css class name and the options of the watermark jQuery plugin. 
        /// </summary>
        /// <param name="helper">The Ajax helper instance that this method extends.</param>
        /// <param name="triggerID">Specified the target element id.</param>
        /// <param name="watermarkText">The watermark text.</param>
        /// <param name="watermarkCssClass">Thae watermark css class name.</param>
        public static void WaterMark(this AjaxHelper helper, string triggerID, string watermarkText, string watermarkCssClass)
        {
            helper.jQuery("#" + triggerID, "watermark", new { waterMark = watermarkText, waterMarkClass = watermarkCssClass });
        }

        /// <summary>
        /// Returns the html elements of the InputFilter by using the specified Ajax helper,the target id  and the options of the InputFilter jQuery plugin. 
        /// </summary>
        /// <param name="helper">The Ajax helper instance that this method extends.</param>
        /// <param name="triggerID">Specified the target element id.</param>
        /// <param name="options">The InputFilterOptions object.</param>
        public static void InputFilter(this AjaxHelper helper, string triggerID, InputFilterOptions options)
        {
            switch (options.FilterType)
            {
                case FilterTypes.Numbers:
                    if (options.DecimalDigits.HasValue)
                        helper.jQuery(triggerID, "inputFilter", new { number = true, decimalDigits = options.DecimalDigits });
                    else
                        helper.jQuery(triggerID, "inputFilter", new { number = true });
                    break;
                case FilterTypes.UppercaseLetters:
                    helper.jQuery(triggerID, "inputFilter", new InputFilterOptions()
                    {
                        FilterMode = FilterModes.ValidChars,
                        ValidChars = "ABCDEFGHIJKLMNOPQRSTUVXYZ1234567890"
                    });
                    break;
                case FilterTypes.LowercaseLetters:
                    helper.jQuery(triggerID, "inputFilter", new InputFilterOptions()
                   {
                       FilterMode = FilterModes.ValidChars,
                       ValidChars = "abcdefghijklmnopqrstuvwyz1234567890"
                   });
                    break;
                case FilterTypes.Custom:
                    helper.jQuery(triggerID, "inputFilter", options);
                    break;
            }


        }

        /// <summary>
        /// Returns the html elements of the Editable by using the specified Ajax helper,the target element id and the options of the editable jQuery plugin. 
        /// </summary>
        /// <param name="helper">The Ajax helper instance that this method extends.</param>
        /// <param name="triggerID">Specified the target element id.</param>
        /// <param name="options">The EditableOptions object.</param>
        public static void Editable(this AjaxHelper helper, string triggerID, EditableOptions options)
        {
            helper.jQuery(triggerID, "editable", options);
        }

        #endregion

    }
}
