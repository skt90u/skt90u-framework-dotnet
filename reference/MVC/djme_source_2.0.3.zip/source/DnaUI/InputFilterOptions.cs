﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DNA.Mvc.jQuery
{
    /// <summary>
    /// Defines a strongly type class of the DJP inputFilter plugin options.
    /// </summary>
    public class InputFilterOptions
    {
        ///// <summary>
        ///// Gets/Sets whether the inputFilter only accept Number characters. 
        ///// </summary>
        //[jQueryOption("number")]
        //public bool? IsNumeric { get; set; }

        /// <summary>
        /// Gets/Sets a the filter mode to apply, either ValidChars (default) or InvalidChars. 
        /// If set to InvalidChars, FilterType must be set to Custom;
        /// if set to ValidChars, FilterType must contain Custom.
        /// </summary>
        [jQueryOption("mode")]
        public FilterModes FilterMode { get; set; }

        /// <summary>
        /// Gets/Sets a the type of filter to apply, as a comma-separated combination of Numbers, 
        /// LowercaseLetters, UppercaseLetters, and Custom. 
        /// If Custom is specified, the ValidChars field will be used in addition to other settings such as Numbers.
        /// </summary>
        [jQueryIgnore]
        public FilterTypes FilterType { get; set; }

        /// <summary>
        /// Gets/Sets the digits of the decimal value.This option only avalidable when FilterModes set to 
        /// Numbers
        /// </summary>
        [jQueryOption("decimalDigits")]
        public int? DecimalDigits { get; set; }

        /// <summary>
        /// Gets/Sets  a string consisting of all characters considered valid for the text field 
        /// </summary>
        [jQueryOption("validChars")]
        public string ValidChars { get; set; }

        /// <summary>
        /// Gets/Sets a string consisting of all characters considered invalid for the text field 
        /// </summary>
        [jQueryOption("invalidChars")]
        public string InvalidChars { get; set; }

        /// <summary>
        /// Gets/Sets the the maximum chars allows in target input.
        /// </summary>
        [jQueryOption("maxlength")]
        public int? MaxChars { get; set; }

    }

}
