﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Mvc;

namespace DNA.Mvc.jQuery
{
    /// <summary>
    /// Represents support for DJP radiobox controls
    /// </summary>
    public static class RadioBoxExtensions
    {
        ///<summary>
        ///Render the radio html element and radio plugin init scripts
        ///</summary>
        ///<param name="name">Specified the name of the checkbox</param>
        ///<param name="text">Specified the radio display text</param>
        ///<returns>radio plugin requires elements.</returns>
        ///<example>
        ///<code language="cs">
        ///  Ajax.RadioBox("myRadio"); 
        ///</code>
        ///</example>
        ///<param name="helper">The Ajax helper object to extends.</param>
        public static MvcHtmlString RadioBox(this AjaxHelper helper, string name, string text)
        {
            return RadioBox(helper, name, text, false);
        }

        ///<summary>Render the radio plugin html element and radio init scripts</summary>
        ///<param name="name">Specified the name of the radio</param>
        ///<param name="text">Specified the radio display text</param>
        ///<param name="value">Specified the radio's value.</param>
        ///<returns>radio plugin requires elements.</returns>
        ///<example>
        ///<code language="cs">
        ///  Ajax.RadioBox("myRadio",true); 
        ///</code>
        ///</example>
        public static MvcHtmlString RadioBox(this AjaxHelper helper, string name, string text, bool value)
        {
            TagBuilder radio = new TagBuilder("input");
            radio.GenerateId(name);
            //radio.Attributes.Add("id", name);
            radio.MergeAttribute("name", name);
            radio.MergeAttribute("type", "hidden");
            radio.MergeAttribute("value", value.ToString().ToLower());

            helper.jQuery("#" + radio.Attributes["id"], "radio", new
            {
                value = value,
                text = text
            });

            return MvcHtmlString.Create(radio.ToString(TagRenderMode.SelfClosing));
        }
    }
}
