﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.Compilation;

namespace DNA.Mvc
{
    /// <summary>
    /// Defines the hierarchical data node provider methods
    /// </summary>
    //public interface IHierarchicalNodeProvider:IHierarchicalNodeProvider<HierarchicalNode>    { }

    /// <summary>
    /// Defines the hierarchical data node provider methods
    /// </summary>
    public interface IHierarchicalNodeProvider
   //     where T : HierarchicalNode
    {
        /// <summary>
        /// Gets the assessable user roles for the specified node.
        /// </summary>
        /// <param name="node">The NavigatableNode instance.</param>
        /// <returns>Role string array</returns>
        string[] GetNodeRoles(HierarchicalNode node);

        /// <summary>
        /// Add the children node to the parent.
        /// </summary>
        /// <param name="parentNode">Specified the target node add to.</param>
        /// <param name="node">Specified the node to add.</param>
        void AddChildren(HierarchicalNode parentNode, HierarchicalNode node);

        /// <summary>
        /// Remove the specified node from provider.
        /// </summary>
        /// <param name="node">Specified the node to remove.</param>
        void RemoveNode(HierarchicalNode node);

        /// <summary>
        /// Get the childnodes of specified node.
        /// </summary>
        /// <param name="node">The NavigatableNode object</param>
        /// <returns></returns>
        IEnumerable<HierarchicalNode> GetChildNodes(HierarchicalNode node);

        /// <summary>
        /// Gets the parent node of specified node.
        /// </summary>
        /// <param name="node">The NavigatableNode object</param>
        /// <returns>Return the parent node instance</returns>
        HierarchicalNode GetParentNode(HierarchicalNode node);

        /// <summary>
        /// Test the user can access the specified node.
        /// </summary>
        /// <param name="context">The httpcontext</param>
        /// <param name="node">Specified th NavigatableNode</param>
        /// <returns></returns>
        bool IsAccessibleToUser(HttpContext context, HierarchicalNode node);

        /// <summary>
        /// Gets the resource key use for node localization.
        /// </summary>
        string ResourceKey { get;}

        /// <summary>
        /// Gets the root node.
        /// </summary>
        HierarchicalNode RootNode { get; }

        /// <summary>
        /// Sets the current node 
        /// </summary>
        HierarchicalNode CurrentNode { get; }

        /// <summary>
        /// Enable the node localization.
        /// </summary>
        bool EnableLocalization { get;}

        /// <summary>
        /// Find the Navigatable for specified key.
        /// </summary>
        /// <param name="key">The key for seach</param>
        /// <returns>The node instance found.</returns>
        HierarchicalNode FindNodeFormKey(string key);
    }
}
