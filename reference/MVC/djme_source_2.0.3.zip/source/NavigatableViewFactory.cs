﻿//  Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Mvc;

namespace DNA.Mvc
{
    public class NavigableViewFactory : NavigableViewFactoryBase<NavigableView, TemplateViewBuilder<NavigableView>>
    {
        public NavigableViewFactory(IComponentItemContainer<NavigableView> container, AjaxHelper helper) : base(container, helper) { }

        protected override TemplateViewBuilder<NavigableView> CreateBuilder(NavigableView component)
        {
            return new TemplateViewBuilder<NavigableView>(component, Helper);
        }
        //public TemplateViewBuilder AddValue(string text)
        //{
        //    return AddValue(text, text);
        //}

        //public TemplateViewBuilder AddValue(string text, string value)
        //{
        //    return Add(new NavigatableNode()
        //    {
        //        Text = text,
        //        Value = value,
        //        NavigateUrl="javascript:void(0);"
        //    });
        //}

        //public TemplateViewBuilder Add(string title, string navigateUrl)
        //{
        //    return Add(title, navigateUrl, "", "");
        //}

        //public TemplateViewBuilder Add(string title, string navigateUrl, string imageUrl)
        //{
        //    return Add(title, navigateUrl, imageUrl, "");
        //}

        //public TemplateViewBuilder Add(string title, string navigateUrl, string imageUrl, string target)
        //{
        //    var component = new NavigableView()
        //     {
        //         Title = title,
        //         NavigateUrl = navigateUrl,
        //         ImageUrl = imageUrl,
        //         Target = target
        //     };
        //    this.Container.Items.Add(component);
        //    return new TemplateViewBuilder(component, Helper);
        //}

        //public TemplateViewBuilder Add(INavigtable node)
        //{
        //    var item = new NavigableView(node);
        //    this.Container.Items.Add(item);
        //    return new TemplateViewBuilder(item, Helper);
        //}
    }

    public abstract class NavigableViewFactoryBase<TComponent, TBuilder> : ViewComponentBuilderFactory<TComponent>
        where TComponent:NavigableView
        where TBuilder : ViewComponentBuilder<TComponent, TBuilder>
    {
        public NavigableViewFactoryBase(IComponentItemContainer<TComponent> container, AjaxHelper helper) : base(container, helper) { }

        protected abstract TBuilder CreateBuilder(TComponent component);

        public TBuilder AddValue(string text)
        {
            return AddValue(text, text);
        }

        public TBuilder AddValue(string text, string value, string imageUrl)
        {
            return Add(new NavigatableNode()
            {
                Text = text,
                Value = value,
                ImageUrl=imageUrl,
                NavigateUrl = "javascript:void(0);"
            });
        }

        public TBuilder AddValue(string text, string value)
        {
            return Add(new NavigatableNode()
            {
                Text = text,
                Value = value,
                NavigateUrl = "javascript:void(0);"
            });
        }

        public TBuilder Add(string title, string navigateUrl)
        {
            return Add(title, navigateUrl, "", "");
        }

        public TBuilder Add(string title, string navigateUrl, string imageUrl)
        {
            return Add(title, navigateUrl, imageUrl, "");
        }

        public TBuilder Add(string title, string navigateUrl, string imageUrl, string target)
        {
            var component = new NavigableView()
            {
                Title = title,
                NavigateUrl = navigateUrl,
                ImageUrl = imageUrl,
                Target = target
            };
            this.Container.Items.Add(component as TComponent);
            this.Container.OnItemAdded(component as TComponent);
            return this.CreateBuilder(component as TComponent);
        }

        public TBuilder Add(INavigtable node)
        {
            var item = new NavigableView(node);
            this.Container.Items.Add(item as TComponent);
            this.Container.OnItemAdded(item as TComponent);
            return this.CreateBuilder(item as TComponent);
        }

    }
}
