﻿//  Copyright (c) 2011 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DNA.Mvc.jQuery
{
    public class ColorPickerOptions
    {
        [jQueryOption("dropdown")]
        public bool? DropDown { get; set; }

        [jQueryOption("showClear")]
        public bool? ShowClearButton { get; set; }

        [jQueryOption("allowInput")]
        public bool? AllowInput { get; set; }

        [jQueryOption("imgUrl")]
        public string IconImageUrl { get; set; }

        [jQueryOption("clientClick", ValueType = JavaScriptTypes.Function, FunctionParams = new string[] { "event", "ui" })]
        public string OnColorSelected { get; set; }
    }
}
