﻿//  Copyright (c) 2011 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Mvc;

namespace DNA.Mvc.jQuery
{
    public class ColorPicker:ViewComponent
    {
        private string color = "#ffffff";

        public string Color
        {
            get { return color; }
            set { color = value; }
        }

        //public override void Render(System.Web.UI.HtmlTextWriter writer)
        //{
        //    var container = new TagBuilder("div");
        //    container.GenerateId(Id);
        //    container.AddCssClass("d-colorpicker");

        //    var palette = new TagBuilder("span");
        //    palette.AddCssClass("d-colorpicker-palette");

        //    var icon = new TagBuilder("span");
        //    icon.AddCssClass("d-colorpicker-icon");

        //    TagBuilder input = new TagBuilder("input");
        //    input.AddCssClass("d-colorpicker-name");
        //    //input.GenerateId(Name);
        //    input.MergeAttribute("name", container.Attributes["id"]);
        //    input.MergeAttribute("value", color);

        //    //input.MergeAttribute("style", "width:50px;padding:3px;font-size:9pt;");
  

        //    TagBuilder picker = new TagBuilder("div");
        //    picker.AddCssClass("farbtastic");
        //    //picker.AddCssClass("ui-widget-content");
        //    //picker.MergeAttribute("style", "display:none");

        //    container.InnerHtml = palette.ToString() + input.ToString(TagRenderMode.SelfClosing)+icon.ToString()+picker.ToString();
        //    //helper.RegisterStartupScript("$('#" + _colorPicker + "').farbtastic('#" + input.Attributes["id"] + "');");
        //    writer.Write(container.ToString());
        //}

        
    }
}
