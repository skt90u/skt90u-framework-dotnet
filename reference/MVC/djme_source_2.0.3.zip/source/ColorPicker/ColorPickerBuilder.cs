﻿//  Copyright (c) 2011 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Mvc;

namespace DNA.Mvc.jQuery
{
    public class ColorPickerBuilder:jQueryComponentBuilder<ColorPickerOptions,ColorPicker, ColorPickerBuilder>
    {
        public ColorPickerBuilder(ColorPicker colorPicker, AjaxHelper helper) : base(colorPicker, helper) { }

        public ColorPickerBuilder Color(string name)
        {
            Component.Color = name;
            return this;
        }

        protected override string jQueryPluginName
        {
            get { return "colorpicker"; }
        }

        public override void Render()
        {
            RenderComponent();
            Helper.jQuery(Component.Name, jQueryPluginName, options);
        }

        //public override void Render()
        //{
        //    base.Render();
        //    //input.Attributes.Add("onfocus", "$(this).siblings('.farbtastic').show().css({'position': 'absolute','z-Index': '2000'});");
        //    //input.Attributes.Add("onblur", "$(this).siblings('.farbtastic').hide();");
        //    Helper.RegisterStartupScript((new StringBuilder() )
        //        .Append("$('#" + Component.Name + "').children('input')")
        //        //.Append(".focus(function(){$(this).siblings('.farbtastic').show().css({'position': 'absolute','z-Index': '2000'});})")
        //        //.Append(".blur(function(){$(this).siblings('.farbtastic').hide();})")
        //        .Append(".bind('DOMAttrModified',function(){$(this).siblings('.d-colorpicker-palette').css('background-color',$(this).val());} );")
        //        //.Append(".change(function(){$(this).siblings('.d-colorpicker-palette').css('background-color',$(this).val());});")
        //        .ToString()
        //        );
        //    Helper.RegisterStartupScript("$('#" + Component.Name + ">.farbtastic').farbtastic('#" +Component.Name+ ">input');");
        //}
    }
}
