﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Mvc;

namespace DNA.Mvc.jQuery
{
    /// <summary>
    /// Represents support for farbtastic jQuery plugin control.
    /// </summary>
    public static class ColorPickerExtensions
    {
        /// <summary>
        /// Returns the html elements and register the jQuery plugin scripts for farbtastic by using the specified 
        /// the Ajax helper and the name of the form field.
        /// </summary>
        /// <param name="helper">The Ajax helper instance that this method extends.</param>
        /// <param name="name">The name of the form field to return.</param>
        /// <param name="color">The initialize color of the picker</param>
        /// <returns>The html elements of the ColorPicker in MvcHtmlString type.</returns>
        public static MvcHtmlString ColorPicker(this AjaxHelper helper, string name, string color)
        {
            TagBuilder input = new TagBuilder("input");
            input.GenerateId(name);
            input.MergeAttribute("name", name);
            var _colorPicker = input.Attributes["id"] + "_colorPicker";

            //input.MergeAttribute("id", name);

            input.MergeAttribute("value", color);
            input.MergeAttribute("type", "text");
            input.MergeAttribute("style", "width:50px;padding:3px;font-size:9pt;");
            input.Attributes.Add("onfocus", "$('#" + _colorPicker + "').show().css({'position': 'absolute','z-Index': '2000'});");
            input.Attributes.Add("onblur", " $('#" + _colorPicker + "').hide();");

            TagBuilder picker = new TagBuilder("div");
            picker.Attributes.Add("id", _colorPicker);
            picker.Attributes.Add("class", "farbtastic ui-widget-content ui-corner-all");
            picker.Attributes.Add("style", "display:none");
            helper.RegisterStartupScript("$('#" + _colorPicker + "').farbtastic('#" + input.Attributes["id"] + "');");
            return MvcHtmlString.Create(input.ToString() + picker.ToString());
        }
    }
}
