﻿//  Copyright (c) 2011 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.UI.WebControls;

namespace DNA.Mvc.jQuery
{
    public class HtmlStyleBuilder
    {
        private IDictionary<string, object> attributes=new Dictionary<string,object>();

        public HtmlStyleBuilder() { }

        public HtmlStyleBuilder Add(string name, string value)
        {
            attributes.Add(name, value);
            return this;
        }

        public HtmlStyleBuilder Width(Unit width)
        {
            return this;
        }

        public HtmlStyleBuilder Height(Unit height)
        {
            return this;
        }

        public HtmlStyleBuilder Valign()
        {
            return this;
        }

        public HtmlStyleBuilder Align()
        {
            return this;
        }

        public HtmlStyleBuilder BackgroundImage()
        {
            return this;
        }

        public HtmlStyleBuilder BackgroundColor()
        {
            return this;
        }

    }
}
