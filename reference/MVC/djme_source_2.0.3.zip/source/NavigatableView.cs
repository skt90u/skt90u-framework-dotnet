﻿//  Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DNA.Mvc
{
    public class NavigableView : TemplateViewComponent, INavigtable
    {
        #region private
         private string _title = "";
        private object _value = "";
        private string imageUrl = "";
        private string tooltip = "";
        private string navigateUrl = "";
        private string target = "";
        //private List<SelectableNode> children;
        //private object properties;
        //private bool selected = false;

        #endregion
        public NavigableView() { }

        public NavigableView(INavigtable node)
        {
            Title = node.Title;
            NavigateUrl = node.NavigateUrl;
            ImageUrl = node.ImageUrl;
            target = node.Target;
            tooltip = node.Description;
            Value = node.Value;
        }

        /// <summary>
        /// Gets/Sets the navigate url of the node.
        /// </summary>
        public string NavigateUrl
        {
            get { return navigateUrl; }
            set { navigateUrl = value; }
        }

        /// <summary>
        /// Gets/Sets the tooltip text of the node.
        /// </summary>
        public string ToolTip
        {
            get { return tooltip; }
            set { tooltip = value; }
        }
        /// <summary>
        /// Gets/Sets the open window target
        /// </summary>
        public string Target
        {
            get { return target; }
            set { target = value; }
        }
        /// <summary>
        /// Gets/Sets the additional value.
        /// </summary>
        public object Value
        {
            get { return this._value; }
            set { this._value = value; }
        }

        /// <summary>
        /// Gets/Sets the image url.
        /// </summary>
        public string ImageUrl
        {
            get { return imageUrl; }
            set { imageUrl = value; }
        }

        /// <summary>
        /// Gets/Sets the node text content.
        /// </summary>
        public string Title
        {
            get { return _title; }
            set { _title = value; }
        }

        #region INavigate members

        string INavigtable.Description
        {
            get { return this.tooltip; }
        }

        string INavigtable.Title
        {
            get { return this.Title; }
        }

        string INavigtable.NavigateUrl
        {
            get { return this.NavigateUrl; }
        }

        string INavigtable.ImageUrl
        {
            get { return this.ImageUrl; }
        }

        string INavigtable.Target
        {
            get { return this.Target; }
        }

        object INavigtable.Value
        {
            get { return this.Value; }
        }

        #endregion

        public override string TagName
        {
            get
            {
                return "li";
            }
        }

        public override void RenderContent(System.Web.UI.HtmlTextWriter writer)
        {
            if (Template == null)
            {
                var builder = new NodeUIBuilder();
                builder.WriteNodeContent(this);
                writer.Write(builder.ToString());
            }
            else
                base.RenderContent(writer);
        }
    }
}
