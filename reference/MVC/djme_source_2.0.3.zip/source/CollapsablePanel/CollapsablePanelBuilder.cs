﻿//  Copyright (c) 2011 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Mvc;

namespace DNA.Mvc.jQuery
{
    public class CollapsablePanelBuilder : jQueryComponentBuilder<CollapseablePanelOptions, CollapsablePanel, CollapsablePanelBuilder>
    {
        private string ajaxUrl;
        protected override string jQueryPluginName
        {
            get { return "togglePanel"; }
        }

        public CollapsablePanelBuilder Title(string text, string collapsedText)
        {
            Component.Title = text;
            Component.CollapseTitle = collapsedText;
            var scripts = new StringBuilder();
            scripts.Append("var _txt=")
                .Append(jQuerySelector + ".find(\".d-panel-header-text\");")
                .Append("if (_txt.length) _txt.text(\"");

            Options(opts =>
            {
                opts.OnCollapsed += scripts.ToString() + collapsedText + "\");";
                opts.OnExpanded += scripts.ToString() + text + "\");";
            });
            return this;
        }

        public CollapsablePanelBuilder Title(string text)
        {
            Component.Title = text;
            return this;
        }

        public CollapsablePanelBuilder ImageUrl(string imageUrl)
        {
            Component.ImageUrl = imageUrl;

            return this;
        }

        public CollapsablePanelBuilder ImageUrl(string imageUrl, string collapsedImageUrl)
        {
            Component.ImageUrl = imageUrl;
            Component.CollapseImageUrl = collapsedImageUrl;
            var scripts = new StringBuilder();
            scripts.Append("var _img=")
                .Append(jQuerySelector + ".find('.d-panel-header-img');")
                .Append("if (_img.length) _img.attr(\"src\",\"");

            Options(opts =>
            {
                opts.OnCollapsed += scripts.ToString() + collapsedImageUrl + "\");";
                opts.OnExpanded += scripts.ToString() + imageUrl + "\");";
            });
            return this;
        }

        public CollapsablePanelBuilder(CollapsablePanel panel, AjaxHelper helper) : base(panel, helper) { }

        public CollapsablePanelBuilder Header(Action value)
        {
            Component.HeaderTemplate = value;
            return this;
        }

        public CollapsablePanelBuilder Body(Action value)
        {
            Component.Template = value;
            return this;
        }

        public CollapsablePanelBuilder Loading(Action value)
        {
            Component.Template = value;
            return this;
        }

        public CollapsablePanelBuilder Load(string url)
        {
            ajaxUrl = url;
            return this;
        }

        public CollapsablePanelBuilder Expand(bool value)
        {
            Component.Expaned = value;
            //Options(opts => { opts. });
            return this;
        }

        private bool isStick=false;

        public CollapsablePanelBuilder Stick()
        {
            return this.Stick(true);
        }

        public CollapsablePanelBuilder Stick(bool value)
        {
            isStick = value;
            return this;
        }

        public override void Render()
        {
            if (options != null)
            {
                if (!string.IsNullOrEmpty(options.HeaderCssClass))
                    Component.HeaderCssClass = options.HeaderCssClass;
                if (!string.IsNullOrEmpty(options.BodyCssClass))
                    Component.BodyCssClass = options.BodyCssClass;
            }

            if (!string.IsNullOrEmpty(ajaxUrl))
            {
                string loadScripts = Helper.GeneratejQueryAjaxScripts(new jQueryAjaxOptions()
                {
                    Url = ajaxUrl,
                    OnSuccess = jQuerySelector + ".find('.d-panel-body').html(data);" + jQuerySelector + ".data(\"loaded\",true);" + jQuerySelector + ".togglePanel(\"setResize\");",
                    OnError = jQuerySelector + ".find('.d-panel-body').html(textStatus);"
                });

                if (Component.Expaned)
                    Helper.RegisterStartupScript(loadScripts);
                else
                    Options(opts =>
                    {
                        opts.OnExpanded = "if (" + jQuerySelector + ".data(\"loaded\")) return;" + loadScripts;
                    });
            }

            if (isStick)
                RenderComponent();
            else
                base.Render();
        }
    }


}
