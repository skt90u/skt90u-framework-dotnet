﻿//  Copyright (c) 2011 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.UI;

namespace DNA.Mvc.jQuery
{
    public class CollapsablePanel : TemplateViewComponent
    {
        public Action HeaderTemplate { get; set; }
        //public Action CollapsedHeaderTemplate { get; set; }
        public string Title { get; set; }
        public string HeaderCssClass { get; set; }

        public string BodyCssClass { get; set; }
        private bool expaned = true;

        public bool Expaned
        {
            get { return expaned; }
            set { expaned = value; }
        }

        public string CollapseTitle { get; set; }

        public string ImageUrl { get; set; }

        public string CollapseImageUrl { get; set; }

        public override void RenderBeginTag(System.Web.UI.HtmlTextWriter writer)
        {
            if (!expaned)
                this.HtmlAttributes.Add("class", "d-panel d-panel-collapsed");
            else
                this.HtmlAttributes.Add("class", "d-panel");

            base.RenderBeginTag(writer);
            writer.WriteBeginTag("div");
            writer.WriteAttribute("class", "d-panel-header");
            writer.Write(HtmlTextWriter.TagRightChar);

            if (HeaderTemplate != null)
                HeaderTemplate.Invoke();
            else
            {
                writer.WriteFullBeginTag("h2");
                if (expaned)
                {
                    if (!string.IsNullOrEmpty(ImageUrl))
                    {
                        writer.WriteBeginTag("img");
                        writer.WriteAttribute("class", "d-panel-header-img");
                        writer.WriteAttribute("src", ImageUrl);
                        writer.Write(HtmlTextWriter.TagRightChar);
                    }
                    //writer.Write(this.Title);
                }
                else
                {
                    if (!string.IsNullOrEmpty(CollapseImageUrl))
                    {
                        writer.WriteBeginTag("img");
                        writer.WriteAttribute("class", "d-panel-header-img");
                        writer.WriteAttribute("src", CollapseImageUrl);
                        writer.Write(HtmlTextWriter.SelfClosingTagEnd);
                    }
                    else
                    {
                        if (!string.IsNullOrEmpty(ImageUrl))
                        {
                            writer.WriteBeginTag("img");
                            writer.WriteAttribute("class", "d-panel-header-img");
                            writer.WriteAttribute("src", ImageUrl);
                            writer.Write(HtmlTextWriter.TagRightChar);
                        }
                    }
                }
                writer.WriteBeginTag("span");
                writer.WriteAttribute("class", "d-panel-header-text");
                writer.Write(HtmlTextWriter.TagRightChar);
                if (!string.IsNullOrEmpty(CollapseTitle))
                    writer.Write(CollapseTitle);
                else
                    writer.Write(this.Title);
                writer.WriteEndTag("span");
                writer.WriteEndTag("h2");
            }

            writer.WriteEndTag("div");
            writer.WriteBeginTag("div");
            writer.WriteAttribute("class", "d-panel-body");
            writer.Write(HtmlTextWriter.TagRightChar);
        }

        //public override void RenderContent(HtmlTextWriter writer)
        //{
        //    //base.RenderContent(writer);
        //    Template.Invoke();
        //}

        public override void RenderEndTag(HtmlTextWriter writer)
        {
            writer.WriteEndTag("div");
            base.RenderEndTag(writer);
        }
    }
}
