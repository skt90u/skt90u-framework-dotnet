﻿//  Copyright (c) 2011 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DNA.Mvc.jQuery
{
    public class CollapseablePanelOptions
    {
        [jQueryOption("resizable")]
        public bool? IsResizable { get; set; }

        [jQueryOption("draggable")]
        public bool? IsDraggable { get; set; }

        [jQueryOption("showEffect")]
        public jQueryEffects ShowEffect { get; set; }

        [jQueryOption("hideEffect")]
        public jQueryEffects HideEffect { get; set; }

        [jQueryOption("droppable")]
        public bool? IsDroppable { get; set; }

        [jQueryOption("duration")]
        public int? Duration { get; set; }

        [jQueryOption("expanded", ValueType = JavaScriptTypes.Function, FunctionParams = new string[] { "event", "ui" })]
        public string OnExpanded { get; set; }

        [jQueryOption("collapsed", ValueType = JavaScriptTypes.Function, FunctionParams = new string[] { "event", "ui" })]
        public string OnCollapsed { get; set; }

        [jQueryIgnore]
        public string HeaderCssClass { get; set; }

        [jQueryIgnore]
        public string BodyCssClass { get; set; }
    }
}
