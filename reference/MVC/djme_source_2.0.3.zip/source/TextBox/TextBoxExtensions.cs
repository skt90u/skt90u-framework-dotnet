﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Mvc;

namespace DNA.Mvc.jQuery
{
    /// <summary>
    /// Represents support for DJP textbox controls
    /// </summary>
    public static class TextBoxExtensions
    {
        /// <summary>
        /// Render the textbox plugin element and textbox plugin init scripts.
        /// </summary>
        /// <param name="helper">The Ajax helper</param>
        /// <param name="name">The name of the textbox</param>
        /// <example>
        /// <code language="cs">
        /// Ajax.TextBox("MyText");
        /// </code>
        /// </example>
        /// <returns>The textbox plugin elements html</returns>
        public static MvcHtmlString TextBox(this AjaxHelper helper, string name)
        {
            return TextBox(helper, name, "", "", null);
        }

        /// <summary>
        /// Render the textbox plugin element and textbox plugin init scripts.
        /// </summary>
        /// <param name="helper">The Ajax helper</param>
        /// <param name="name">The name of the textbox</param>
        /// <param name="iconClass">Specified the icon css class of the textbox this icon will display on the left side in the textbox.</param>
        /// <param name="width">Specified the width of the textbox</param>
        /// <example>
        ///<code language="cs">Ajax.TextBox("UserName","ui-icon ui-icon-person",200);</code>
        ///</example>
        /// <returns>The textbox plugin elements html</returns>
        public static MvcHtmlString TextBox(this AjaxHelper helper, string name, string iconClass, int width)
        {
            return TextBox(helper, name, "", new TextBoxOptions() { Width = width, IconCssClass = iconClass });
        }

        /// <summary>
        /// Render the textbox plugin element and textbox plugin init scripts.
        /// </summary>
        /// <param name="helper">The Ajax helper</param>
        /// <param name="name">The name of the textbox</param>
        /// <param name="value">Specified the init text value of the textbox</param>
        /// <example>
        ///<code language="cs"> Ajax.TextBox("Title","Portal");</code>
        ///</example>
        /// <returns>The textbox plugin elements html</returns>
        public static MvcHtmlString TextBox(this AjaxHelper helper, string name, string value)
        {
            return TextBox(helper, name, value, null, null);
        }

        /// <summary>
        /// Returns the html elements of the textbox by specified the Ajax helper object to extends,the name of the form field,the text content,
        /// the watermark text contet,the watermark css class name and the width of the textbox.
        /// </summary>
        /// <param name="helper">The Ajax helper object to extends.</param>
        /// <param name="name">The name of the form field.</param>
        /// <param name="value">The text content.</param>
        /// <param name="waterMarkText">The watermark text contet.</param>
        /// <param name="waterMarkCssClass">The watermark css class.</param>
        /// <param name="width">The width of textbox.</param>
        /// <returns>The textbox plugin elements html</returns>
        public static MvcHtmlString TextBox(this AjaxHelper helper, string name, string value, string waterMarkText, string waterMarkCssClass, int width)
        {
            return TextBox(helper, name, value, new TextBoxOptions() { WaterMarkCssClass = waterMarkCssClass, WaterMarkText = waterMarkText, Width = width });
        }

        /// <summary>
        /// Returns the html elements of the textbox by specified the Ajax helper object to extends,the name of the form field,
        /// the watermark text contet,the watermark css class name and the width of the textbox.
        /// </summary>
        /// <param name="helper">The Ajax helper object to extends.</param>
        /// <param name="name">The name of the form field.</param>
        /// <param name="waterMarkText">The watermark text contet.</param>
        /// <param name="waterMarkCssClass">The watermark css class.</param>
        /// <param name="width">The width of textbox.</param>
        /// <returns>The textbox plugin elements html</returns>
        public static MvcHtmlString TextBox(this AjaxHelper helper, string name, string waterMarkText, string waterMarkCssClass, int width)
        {
            return TextBox(helper, name, null, new TextBoxOptions() { WaterMarkCssClass = waterMarkCssClass, WaterMarkText = waterMarkText, Width = width });
        }

        /// <summary>
        /// Returns the html elements of the textbox by specified the Ajax helper object to extends,the name of the form field,
        /// the watermark text contet and the watermark css class name. 
        /// </summary>
        /// <param name="helper">The Ajax helper object to extends.</param>
        /// <param name="name">The name of the form field.</param>
        /// <param name="waterMarkText">The watermark text contet.</param>
        /// <param name="waterMarkCssClass">The watermark css class.</param>
        /// <returns>The textbox plugin elements html</returns>
        public static MvcHtmlString TextBox(this AjaxHelper helper, string name, string waterMarkText, string waterMarkCssClass)
        {
            return TextBox(helper, name, null, new TextBoxOptions() { WaterMarkCssClass = waterMarkCssClass, WaterMarkText = waterMarkText });
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="helper">The Ajax helper object to extends.</param>
        /// <param name="name">The name of the form field.</param>
        /// <param name="value">The text content.</param>
        /// <param name="waterMarkText">The watermark text contet.</param>
        /// <param name="waterMarkCssClass">The watermark css class.</param>
        /// <returns>The textbox plugin elements html</returns>
        public static MvcHtmlString TextBox(this AjaxHelper helper, string name, string value, string waterMarkText, string waterMarkCssClass)
        {
            return TextBox(helper, name, value, new TextBoxOptions() { WaterMarkCssClass = waterMarkCssClass, WaterMarkText = waterMarkText });
        }

        /// <summary>
        /// Render the textbox plugin element and textbox plugin init scripts.
        /// </summary>
        /// <param name="helper">The Ajax helper object to extends</param>
        /// <param name="name">The name of the textbox</param>
        /// <param name="value">Specified the init text value of the textbox</param>
        /// <param name="options">Specified the TextBoxObject class to set the parameters of the textbox plugin.</param>
        ///<example>
        ///<code language="cs">
        /// &lt;%:
        ///         Ajax.TextBox("Title","Portal","Input the title of the Portal",
        ///                                new TextBoxOptions(){
        ///                                Clearable=true,
        ///                                TextCssClass="ui-textbox"
        ///                               });
        /// %&gt;                           
        ///</code>
        ///</example>
        /// <returns>The textbox plugin elements html</returns>
        public static MvcHtmlString TextBox(this AjaxHelper helper, string name, string value, TextBoxOptions options)
        {
            TextBoxOptions opts = options;
            if (opts == null)
                opts = new TextBoxOptions();
            string id = "";
            var _inputHtml = Input(name, "text", new { value = string.IsNullOrEmpty(value) ? "" : value }, out id);

            helper.jQuery("#" + id, "textbox", opts);

            return _inputHtml;
        }

        /// <summary>
        ///  Returns the html element and register the jQuery javascript for password jQuery plugin by specified the Ajax helper object to extends and the name of the form field.
        /// </summary>
        /// <param name="helper">The Ajax helper object to extends</param>
        /// <param name="name">The name of the form field.</param>
        /// <returns>The password jQuery plugin elements html</returns>
        public static MvcHtmlString Password(this AjaxHelper helper, string name)
        {
            return Password(helper, name, null, null, null);
        }

        /// <summary>
        /// Returns the html element and register the jQuery javascript for password jQuery plugin by specified the Ajax helper object to extends, the name of the form field,
        /// the icon css class and the width.
        /// </summary>
        /// <param name="helper">The Ajax helper object to extends</param>
        /// <param name="name">The name of the form field.</param>
        /// <param name="iconClass">The icon css class display on left of the password.</param>
        /// <param name="width">The Password width</param>
        /// <returns>The password jQuery plugin elements html</returns>
        public static MvcHtmlString Password(this AjaxHelper helper, string name, string iconClass, int width)
        {
            return Password(helper, name, null, null, new TextBoxOptions() { Width = width, IconCssClass = iconClass });
        }

        /// <summary>
        /// Returns the html element and register the jQuery javascript for password jQuery plugin by specified the Ajax helper object to extends, the name of the form field and value.
        /// </summary>
        /// <param name="helper">The Ajax helper object to extends</param>
        /// <param name="name">The name of the form field.</param>
        /// <param name="value">The text value of the password</param>
        /// <returns>The password jQuery plugin elements html</returns>
        public static MvcHtmlString Password(this AjaxHelper helper, string name, string value)
        {
            return Password(helper, name, value, null, null);
        }

        /// <summary>
        /// Returns the html element and register the jQuery javascript for password jQuery plugin by specified the Ajax helper object to extends, the name of the form field,
        /// the password value and tooltip text and TextboxOptions object.
        /// </summary>
        /// <param name="helper">The Ajax helper object to extends</param>
        /// <param name="name">The name of the form field.</param>
        /// <param name="value">The text value of the password</param>
        /// <param name="tooltip">The tooltip text.</param>
        /// <param name="options"></param>
        /// <returns>The password jQuery plugin elements html</returns>
        public static MvcHtmlString Password(this AjaxHelper helper, string name, string value, string tooltip, TextBoxOptions options)
        {
            TextBoxOptions opts = options;
            if (opts == null)
                opts = new TextBoxOptions();

            if (!string.IsNullOrEmpty(value))
                opts.Value = value;
            string id = "";
            var _inputHtml = Input(name, "password", new { title = tooltip }, out id);
            helper.jQuery("#" + id, "textbox", opts);

            return _inputHtml;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="name">The name of the form field.</param>
        /// <param name="type"></param>
        /// <param name="htmlAttributes"></param>
        /// <param name="id"></param>
        /// <returns></returns>
        private static MvcHtmlString Input(string name, string type, object htmlAttributes, out string id)
        {
            TagBuilder inputTag = new TagBuilder("input");
            //inputTag.Attributes.Add("id", name);
            inputTag.GenerateId(name);
            id = inputTag.Attributes["id"];
            inputTag.MergeAttribute("name", name);
            if (htmlAttributes != null)
                inputTag.MergeAttributes<string, object>(ObjectHelper.ConvertObjectToDictionary(htmlAttributes));
            inputTag.Attributes.Add("type", type);
            return MvcHtmlString.Create(inputTag.ToString(TagRenderMode.SelfClosing));
        }

        /// <summary>
        /// Returns the html element and register the jQuery javascript for number jQuery plugin by specified the Ajax helper object to extends, the name of the form field,
        /// </summary>
        /// <param name="helper">The Ajax helper object to extends</param>
        /// <param name="name">The name of the form field.</param>
        /// <returns>The Number jQuery plugin elements html</returns>
        public static MvcHtmlString Number(this AjaxHelper helper, string name)
        {
            return helper.Number(name, 0, 75);
        }

        /// <summary>
        ///  Returns the html element and register the jQuery javascript for number jQuery plugin by specified the Ajax helper object to extends, the name of the form field and the integer value.
        /// </summary>
        /// <param name="helper">The Ajax helper object to extends</param>
        /// <param name="name">The name of the form field.</param>
        /// <param name="value">The numeric value</param>
        /// <returns>The Number jQuery plugin elements html</returns>
        public static MvcHtmlString Number(this AjaxHelper helper, string name, int value)
        {
            return helper.Number(name, value, 75);
        }

        /// <summary>
        /// Returns the html element and register the jQuery javascript for number jQuery plugin by specified the Ajax helper object to extends, the name of the form field and the float value.
        /// </summary>
        /// <param name="helper">The Ajax helper object to extends</param>
        /// <param name="name">The name of the form field.</param>
        /// <param name="value">The numeric value</param>
        /// <returns>The Number jQuery plugin elements html</returns>
        public static MvcHtmlString Number(this AjaxHelper helper, string name, float value)
        {
            return helper.Number(name, value, 75);
        }

        /// <summary>
        /// Returns the html element and register the jQuery javascript for number jQuery plugin by specified the Ajax helper object to extends, the name of the form field and the decimal value.
        /// </summary>
        /// <param name="helper">The Ajax helper object to extends</param>
        /// <param name="name">The name of the form field.</param>
        /// <param name="value">The numeric value</param>
        /// <returns>The Number jQuery plugin elements html</returns>
        public static MvcHtmlString Number(this AjaxHelper helper, string name, decimal value)
        {
            return helper.Number(name, value, 75);
        }

        /// <summary>
        /// Returns the html element and register the jQuery javascript for number jQuery plugin by specified the Ajax helper object to extends, the name of the form field and the double value.
        /// </summary>
        /// <param name="helper">The Ajax helper object to extends</param>
        /// <param name="name">The name of the form field.</param>
        /// <param name="value">The numeric value</param>
        /// <returns>The Number jQuery plugin elements html</returns>
        public static MvcHtmlString Number(this AjaxHelper helper, string name, double value)
        {
            return helper.Number(name, value, 75);
        }

        /// <summary>
        /// Returns the html element and register the jQuery javascript for number jQuery plugin by specified the Ajax helper object to extends, the name of the form field and the long value.
        /// </summary>
        /// <param name="helper">The Ajax helper object to extends</param>
        /// <param name="name">The name of the form field.</param>
        /// <param name="value">The numeric value</param>
        /// <returns>The Number jQuery plugin elements html</returns>
        public static MvcHtmlString Number(this AjaxHelper helper, string name, long value)
        {
            return helper.Number(name, value, 75);
        }

        /// <summary>
        /// Returns the html element and register the jQuery javascript for number jQuery plugin by specified the Ajax helper object to extends, the name of the form field,the numeric value and the width.
        /// </summary>
        /// <param name="helper">The Ajax helper object to extends</param>
        /// <param name="name">The name of the form field.</param>
        /// <param name="value">The numeric value</param>
        /// <param name="width">The Number width.</param>
        /// <returns>The Number jQuery plugin elements html</returns>
        public static MvcHtmlString Number(this AjaxHelper helper, string name, object value, int width)
        {
            var tagHelper = new TagBuilder("input");
            tagHelper.GenerateId(name);

            helper.jQuery("#" + tagHelper.Attributes["id"], "inputFilter", new
            {
                number = true
            });
            return TextBox(helper, name, value == null ? "0" : value.ToString(), new TextBoxOptions() { Clearable = false, Width = width });
        }
    }
}
