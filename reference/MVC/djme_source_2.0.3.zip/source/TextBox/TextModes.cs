﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DNA.Mvc.jQuery
{
    /// <summary>
    /// Defines the out put text modes of the text box.
    /// </summary>
    public enum TextModes
    {
        /// <summary>
        /// Display the single line text in textbox.
        /// </summary>
        SingleLine,

        /// <summary>
        /// Allows the textbox can display the multi line text.
        /// </summary>
        MultiLine,
        
        /// <summary>
        /// Specify the textbox display the text in "*" format.
        /// </summary>
        Password
    }
}
