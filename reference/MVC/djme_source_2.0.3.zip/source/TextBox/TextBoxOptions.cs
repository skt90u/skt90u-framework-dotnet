﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DNA.Mvc.jQuery
{
    /// <summary>
    /// Represents the options of the jQuery textbox plugin
    /// </summary>
    public class TextBoxOptions
    {
        /// <summary>
        /// Gets/Sets the TextBox's value.
        /// </summary>
        [jQueryOption("value")]
        public string Value { get; set; }

        /// <summary>
        /// Gets/Sets whether the TextBox can be show the clear text button.
        /// </summary>
        [jQueryOption("clearable")]
        public bool? Clearable { get; set; }

        /// <summary>
        /// Gets/Sets the TextBox's width in pixel.
        /// </summary>
        [jQueryOption("width")]
        public int? Width { get; set; }

        /// <summary>
        /// Gets/Sets the TextBox's height in pixel
        /// </summary>
        [jQueryOption("height")]
        public int? Height { get; set; }

        /// <summary>
        /// Gets/Sets the clear text botton's tool tip,if the Clearable property set to false this property will be ignored.
        /// </summary>
        [jQueryOption("clearText")]
        public string ClearButtonToolTipText { get; set; }

        /// <summary>
        /// Gets/Sets the icon css class of the TextBox.If this property sets the icon will show on the left of the TextBox.
        /// </summary>
        [jQueryOption("iconClass")]
        public string IconCssClass { get; set; }
        
        [jQueryOption("iconImg")]
        public string IconImageUrl { get; set; }
        
        /// <summary>
        /// Gets/Sets the TextBox's text class name.
        /// </summary>
        [jQueryOption("textClass")]
        public string TextCssClass { get; set; }

        /// <summary>
        /// Gets/Sets the active css class name of the TextBox this class will be toggle when the TextBox has the focus.
        /// </summary>
        [jQueryOption("activeClass")]
        public string ActiveCssClass { get; set; }

        /// <summary>
        /// Gets/Sets the TextBox container class name.
        /// </summary>
        [jQueryOption("cssClass")]
        public string CssClass { get; set; }

        /// <summary>
        /// Gets/Sets the hover class name of the TextBox
        /// </summary>
        [jQueryOption("highlightClass")]
        public string HoverCssClass { get; set; }

        /// <summary>
        /// Gets/Sets the water mark text shows when the textbox is empty
        /// </summary>
        [jQueryOption("waterMark")]
        public string WaterMarkText { get; set; }

        /// <summary>
        /// Gets/Sets the water mark text's style class.
        /// </summary>
        [jQueryOption("waterMarkClass")]
        public string WaterMarkCssClass { get; set; }

        
        /// <summary>
        /// Getes/Sets the scripts trigger when the text is changed. 
        /// </summary>
        [jQueryOption("change",ValueType=JavaScriptTypes.Function,FunctionParams=new string[]{"event","text"})]
        public string OnChanged { get; set; }

        [jQueryIgnore]
        public TextModes TextMode { get; set; }

        [jQueryIgnore]
        public bool ReadOnly { get; set; }

        [jQueryIgnore]
        public InputFilterOptions InputFilter { get; set; }
    }

}
