﻿//  Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.Mvc;

namespace DNA.Mvc.jQuery
{
    public class TextBox : ViewComponent
    {
        public override string TagName
        {
            get
            {
                return "input";
            }
        }
        
        public string Value { get; set; }

        public bool IsPassword { get; set; }

        public bool IsReadonly { get; set; }

        public override void RenderBeginTag(HtmlTextWriter writer)
        {
            if (this.Width == 0) this.Width = 200;
            if (IsPassword)
                HtmlAttributes.Add("type", "password");
            else
                HtmlAttributes.Add("type", "text");

            if (!string.IsNullOrEmpty(Value))
                HtmlAttributes.Add("value", Value);

            if (IsReadonly)
                HtmlAttributes.Add("readonly","readonly");

            base.RenderBeginTag(writer);
        }

    }
}
