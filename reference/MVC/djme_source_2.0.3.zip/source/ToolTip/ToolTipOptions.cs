﻿//  Copyright (c) 2011 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DNA.Mvc.jQuery
{
    public class ToolTipOptions
    {
        private jQueryEffects hideEffect = jQueryEffects.Slide;
        private jQueryEffects showEffect = jQueryEffects.Slide;

        [jQueryOption("actived", ValueType = JavaScriptTypes.Function, FunctionParams = new string[] { "event", "ui" })]
        public string OnTipActived { get; set; }

        [jQueryIgnore]
        public ToolTipPositions Positions { get; set; }

        [jQueryOption("duration")]
        public int? Duration { get; set; }

        [jQueryOption("opacity")]
        public double? Opacity { get; set; }

        [jQueryOption("hideEffect")]
        public jQueryEffects HideEffect { get { return hideEffect; } set { hideEffect = value; } }

        [jQueryOption("showEffect")]
        public jQueryEffects ShowEffect { get { return showEffect; } set { showEffect = value; } }
    }
}
