﻿//  Copyright (c) 2011 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Mvc;

namespace DNA.Mvc.jQuery
{
    public class ToolTipBuilder : jQueryComponentBuilder<ToolTipOptions, ToolTip, ToolTipBuilder>
    {
        protected override string jQueryPluginName
        {
            get { return "tooltip"; }
        }

        //public ToolTipBuilder ApplyTo(string cssSelector)
        //{
        //    return this;
        //}
        private string _url;
        private string[] keyAttrs;

        public ToolTipBuilder ContentUrl(string url, params string[] keys)
        {
            _url = url;
            keyAttrs = keys;
            return this;
        }

        public ToolTipBuilder(ToolTip toolTip, AjaxHelper helper) : base(toolTip, helper) { }

        public override void Render()
        {
            RenderComponent();
            string name = Component.Name;
            if (string.IsNullOrEmpty(name))
                name = "body";
            else
            {
                if ((!name.Equals("body", StringComparison.OrdinalIgnoreCase)) && (!name.Equals("document", StringComparison.OrdinalIgnoreCase)) &&
                    !name.StartsWith(".") && !name.StartsWith("#"))
                    name = "#" + name;
            }

            var opts = new jQueryScriptBuilder(name, jQueryPluginName);

            if (!string.IsNullOrEmpty(_url))
            {
                if (keyAttrs != null)
                {
                    Options(os =>
                    {
                        os.OnTipActived = Helper.GeneratejQueryAjaxScripts(new jQueryAjaxOptions()
                     {
                         HttpMethod = "GET",
                         Url = _url,
                         OnSuccess = "ui.tip.html(data);"
                     });
                    });
                }
            }

            if (options != null)
            {
                opts.AddOptions(options);
                opts.AddOption("pos", GetPos(options.Positions));
            }

            Helper.RegisterStartupScript(opts.ToString());
            //Helper.jQuery("body", jQueryPluginName, options);
        }

        private string GetPos(ToolTipPositions pos)
        {
            switch (pos)
            {
                case ToolTipPositions.Left: return "\"left\"";
                case ToolTipPositions.Top: return "\"top\"";
                case ToolTipPositions.Right: return "\"right\"";
                case ToolTipPositions.LeftTop: return "\"left top\"";
                case ToolTipPositions.LeftCenter: return "\"left center\"";
                case ToolTipPositions.LeftBottom: return "\"left bottom\"";
                case ToolTipPositions.RightTop: return "\"right top\"";
                case ToolTipPositions.RightBottom: return "\"right bottom\"";
                case ToolTipPositions.RightCenter: return "\"right center\"";
                default:
                    return "\"center\"";
            }
        }
    }

}
