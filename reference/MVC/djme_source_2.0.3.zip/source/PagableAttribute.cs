﻿//  Copyright (c) 2011 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Mvc;

namespace DNA.Mvc.jQuery
{

    [AttributeUsage(AttributeTargets.Method, Inherited = false, AllowMultiple = false)]
    public class PagableAttribute : FilterAttribute, IActionFilter
    {
        public PagableAttribute() { }

        private bool allowJsonget=true;

        public bool AllowJsonGet
        {
            get { return allowJsonget; }
            set { allowJsonget = value; }
        }

        public void OnActionExecuted(ActionExecutedContext filterContext)
        {
            var wrapper = filterContext.Controller.ViewData.Model as IModelWrapper;
            if (wrapper == null) return;



            if ((filterContext.HttpContext.Request.IsAjaxRequest()) && AllowJsonGet)
            {     
                if ((wrapper.Model as IEnumerable<DynamicGroupResult>) != null)
                ((ModelWrapper)wrapper).Model=ModelBinder.ConvertDataResult(wrapper.Model as IEnumerable<DynamicGroupResult>);

                filterContext.Result = new JsonResult()
                {
                    JsonRequestBehavior = JsonRequestBehavior.AllowGet,
                    Data = wrapper
                };
            }
            else
            {
                filterContext.Controller.ViewData["totalRecords"] = wrapper.Total;
                filterContext.Controller.ViewData.Model = wrapper.Model;
            }
        }

        public void OnActionExecuting(ActionExecutingContext filterContext)
        {

        }
    }
}
