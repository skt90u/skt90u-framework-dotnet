﻿/// <reference path="../jquery-1.4.4.js" />
/// <reference path="../jquery-1.4.4-vsdoc.js" />

/*!  
** Copyright (c) 2011 Ray Liang (http://www.dotnetage.com)
** Dual licensed under the MIT and GPL licenses:
** http://www.opensource.org/licenses/mit-license.php
** http://www.gnu.org/licenses/gpl.html
** 
**----------------------------------------------------------------
** title        : DJME ToolTip
** version   : 2.0.0
** modified: 2010-1-28
** depends:
**    jquery.ui.core.js
**    jquery.ui.widget.js
**    jquery.ui.position.js
**----------------------------------------------------------------
*/
(function ($) {
    $.widget("ui.tooltip", {
        options: {
            actived: null,
            pos: "right top",
            showEffect: "blind",
            hideEffect: "blind",
            duration: 100,
            opacity: 0.8
        },
        _create: function () {
            var self = this, eventPrefix = this.widgetEventPrefix, el = this.element
            targetElements = $("[title]", el);
            if (this.options.actived)
                el.bind(eventPrefix + "actived", this.options.actived);

            if (targetElements.length) {
                targetElements.each(function (i, n) {
                    var $t = $(n);
                    if ($t.attr("title")) {
                        $t.mouseover(self._delegate(self, self._onmouseenter))
                           .mouseout(self._delegate(self, self._onmouseleave))
                           .data("title", $t.attr("title"))
                           .removeAttr("title");
                    }
                });
            }
        },
        _delegate: function (context, handler) {
            return function (e) {
                handler.apply(context, [e, this]);
            };
        },
        _triggerEvent: function (eventName, eventArgs) {
            this.element.trigger(this.widgetEventPrefix + eventName, eventArgs);
        },
        _contains: function (parent, child) {
            try {
                return $.contains(parent, child);
            } catch (e) {
                return false;
            }
        },
        _onmouseenter: function (e, element) {
            if (element.holder) {
                if (element.holder.hasClass("d-tooltip-actived")) return;
            }
            this.active(e, element);
        },
        _onmouseleave: function (e, element) {
            if (element.holder) {
                if (element.holder.hasClass("d-tooltip-actived"))
                    this.deactive(e, element);
            }
        },
        active: function (e, element) {
            var self = this, $el = $(element);
            if (element.holder == undefined)
                element.holder = $("<div/>").addClass("d-tooltip")
                                                .html($el.data("title"))
                                                .position({
                                                    my: "left top",
                                                    at: self.options.pos,
                                                    of: element,
                                                    offset: "5 0",
                                                    collision: "flip"
                                                }).appendTo("body");
            clearTimeout($el.data("tipTimer"));

            $el.data("tipTimer", setTimeout(function () {
                self._triggerEvent("actived", { "element": element, "tip": element.holder });
                element.holder.css({
                    "overflow": "auto",
                    "opacity": self.options.opacity
                })
                                .addClass("d-tooltip-actived")
                                .show(self.options.showEffect, {}, self.options.duration);
            }), 100);

            //.stop()
            //.animate(self.options.showfx, self.options.duration);
        },
        deactive: function (e, element) {
            var self = this, $el = $(element);
            if (element.holder) {
                clearTimeout($el.data("tipTimer"));
                $el.data("tipTimer", setTimeout(function () {
                    element.holder.removeClass("d-tooltip-actived")
                .hide(self.options.showEffect, {}, self.options.duration);
                    //.stop().animate(self.options.hidefx, self.options.duration);
                    //.fadeOut("fast");
                }, 100));
            }
        },
        destroy: function () {
            $.Widget.prototype.destroy.call(this);
        }
    });
})(jQuery);   