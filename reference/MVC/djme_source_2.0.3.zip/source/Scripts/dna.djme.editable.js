﻿/// <reference path="../jquery-1.4.4.js" />
/// <reference path="../jquery-1.4.4-vsdoc.js" />

/*!  
** Copyright (c) 2011 Ray Liang (http://www.dotnetage.com)
** Dual licensed under the MIT and GPL licenses:
** http://www.opensource.org/licenses/mit-license.php
** http://www.gnu.org/licenses/gpl.html
** 
**----------------------------------------------------------------
** title        : DJME editable
** version   : 2.0.0
** modified: 2010-1-6
** depends:
**    jquery.ui.core.js
**    jquery.ui.widget.js
**----------------------------------------------------------------
*/

(function ($) {
    $.widget("ui.editable", {
        options: {
            submit: null,
            cancel: null
        },
        _create: function () {
            var self = this, opts = this.options, el = this.element;
            if (opts.submit)
                el.bind("submitchanged", opts.submit);
            if (opts.cancel)
                el.bind("canceledit", opts.cancel);

            el.bind("click", function () {
                self.edit();
            });
        },
        edit: function () {
            var el = this.element, self = this;
            if (el.attr("editing"))
                return;
            el.attr("editing", true);
            //el.data("editing", true);

            var $editbox = $("<input type='text' />");
            $editbox.css({
                "border": "none",
                "background": "none",
                "width": (el.width()) + "px"
                //"dipslay": "inline"
            });
            var _innerText = el.text();
            $editbox.val(_innerText);
            $editbox.css({
                "font-family": el.css("font-family"),
                //"font-size": el.css("font-size"),
                "color": el.css("color")
            });
            el.data("_text", _innerText);
            el[0].innerHTML = "";
            el.append($editbox);


            $editbox.bind("keypress", function (event) {
                if (event.keyCode == 13) self._submitchange();
                if (event.keyCode == 27) self._canceledit();
            });

            $editbox.bind("blur", function () { self._submitchange(); });

            $editbox.focus();
            if ($.browser.msie) {
                var txtRange = $editbox[0].createTextRange();
                txtRange.select();
            }
        },
        _canceledit: function () {
            var el = this.element;
            this._removeEditor();
            this.element.text(el.data("_text"));
            this.element.trigger("canceledit");
            this.element.removeAttr("editing");
        },
        _removeEditor: function () {
            var el = this.element;
            var $input = el.find("input");
            $input.unbind();
            $input.remove();
        },
        _submitchange: function () {
            var el = this.element;
            var $input = el.find("input");
            el.text($input.val());
            el.trigger("submitchanged", $input.val());
            el.removeAttr("editing");
            this._removeEditor();
        },
        destroy: function () {
            this.element.unbind();
            $.Widget.prototype.destroy.call(this);
        }
    });
})(jQuery);   