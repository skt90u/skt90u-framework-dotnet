﻿//  Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DNA.Mvc
{
    public abstract class ContainerViewComponent : ContainerViewComponent<TemplateViewComponent> { }

    /// <summary>
    /// Defines the base class to contain component items.
    /// </summary>
    public abstract class ContainerViewComponent<TComponent> : ViewComponent, IComponentItemContainer<TComponent>
        where TComponent : ViewComponent
    {
        private IList<TComponent> views;

        protected IList<TComponent> InnerItems
        {
            get
            {
                if (views == null)
                    views = new List<TComponent>();
                return views;
            }
            set
            {
                views = value;
            }
        }

        public void AddItem(TComponent item)
        {
            InnerItems.Add(item);
            this.OnItemAdded(item);
        }


        IList<TComponent> IComponentItemContainer<TComponent>.Items
        {
            get { return this.InnerItems; }
        }

        protected virtual void OnItemAdded(TComponent item) { }

        public override void RenderContent(System.Web.UI.HtmlTextWriter writer)
        {
            foreach (var item in InnerItems)
                item.Render(writer);
        }


        void IComponentItemContainer<TComponent>.OnItemAdded(TComponent item)
        {
            this.OnItemAdded(item);
        }
    }


}
