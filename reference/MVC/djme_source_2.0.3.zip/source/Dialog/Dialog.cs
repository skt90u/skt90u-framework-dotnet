﻿//  Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;


namespace DNA.Mvc.jQuery
{
    public class Dialog : TitleView
    {
        private List<DialogButton> buttons;
        private DomEvents triggerEvent = DomEvents.Click;       
 
        public string TriggerID { get; set; }

        public DomEvents TriggerEvent
        {
            get { return triggerEvent; }
            set { triggerEvent = value; }
        }

        public string Title
        {
            get
            {
                if (HtmlAttributes.ContainsKey("Title"))
                    return HtmlAttributes["Title"] as string;
                return "";
            }
            set
            {
                if (HtmlAttributes.ContainsKey("Title"))
                    HtmlAttributes["Title"] = value;
                else
                    HtmlAttributes.Add("Title", value);
            }
        }
        
        public List<DialogButton> Buttons
        {
            get {
                if (buttons == null)
                    buttons = new List<DialogButton>();
                return buttons; 
            }
            set { buttons = value; }
        }

        public string ContentUrl { get; set; }

        //public Action ContentTemplate { get; set; }

        //public string ContentText { get; set; }

        //public override void RenderContent(HtmlTextWriter writer) 
        //{
        //    if (ContentTemplate != null)
        //        ContentTemplate.Invoke();
        //    else
        //        if (!string.IsNullOrEmpty(ContentText))
        //            writer.Write(ContentText);
        //}
    }
}
