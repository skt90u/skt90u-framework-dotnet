﻿//  Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;

namespace DNA.Mvc.jQuery
{
    public class DialogButton
    {
        public string Text { get; set; }

        public string OnClick { get; set; }

        private string httpMethod = "POST";

        public string HttpMethod
        {
            get { return httpMethod; }
            set { httpMethod = value; }
        }

        public string ExecuteRemoteMethod { get; set; }

        public bool IsCloseButton { get; set; }
    }
}
