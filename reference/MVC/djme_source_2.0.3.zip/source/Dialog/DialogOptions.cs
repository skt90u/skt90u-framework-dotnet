﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DNA.Mvc.jQuery
{
    /// <summary>
    /// Defines the jQuery UI Dialog plugin options.
    /// </summary>
    public class DialogOptions
    {
        private jQueryEffects hideEffect = jQueryEffects.Slide;
        private jQueryEffects showEffect = jQueryEffects.Slide;

        /// <summary>
        /// Gets/Sets whether  the dialog will open automatically.
        /// </summary>
        [jQueryOption("autoOpen")]
        public bool? AutoOpen { get; set; }

        /// <summary>
        /// When true, the bgiframe plugin will be used, 
        /// to fix the issue in IE6 where select boxes show on top of other elements, regardless of zIndex. 
        /// </summary>
        /// <remarks>
        /// When dialog detect the current browser is IE6 this property will be set to true.
        /// </remarks>
        [jQueryOption("bgiframe")]
        public bool? bgiFrame { get; set; }

        [jQueryOption("position")]
        public string[] Position { get; set; }

        /// <summary>
        /// Gets/Sets whether the dialog should close when it has focus and the user presses the esacpe (ESC) key.
        /// </summary>
        [jQueryOption("closeOnEscape")]
        public bool? CloseOnEscape { get; set; }

        [jQueryOption("closeText")]
        public string CloseText { get; set; }

        /// <summary>
        /// Gets/Sets the dialog style sheet class.
        /// </summary>
        [jQueryOption("dialogClass")]
        public string CssClass { get; set; }

        /// <summary>
        ///  Gets/Sets whether the dialog can be draggable and set to true it will be draggable by the titlebar.
        /// </summary>
        [jQueryOption("draggable")]
        public bool? IsDraggable { get; set; }

        /// <summary>
        /// Gets/Sets the Dialog's Height
        /// </summary>
        [jQueryOption("height")]
        public int? Height { get; set; }

        /// <summary>
        /// Gets/Sets the effect to be used when the dialog is closed.
        /// </summary>
        [jQueryOption("hide")]
        public jQueryEffects HideEffect { get { return hideEffect; } set { hideEffect = value; } }

        /// <summary>
        /// Gets/Sets the dialog's maximum height to which the dialog can be resized, in pixels.
        /// </summary>
        [jQueryOption("maxHeight")]
        public int? MaxHeight { get; set; }

        /// <summary>
        /// Gets/Sets the maximum width to which the dialog can be resized, in pixels.
        /// </summary>
        [jQueryOption("maxWidth")]
        public int? MaxWidth { get; set; }

        /// <summary>
        /// Gets/Sets the minimum height to which the dialog can be resized, in pixels.
        /// </summary>
        [jQueryOption("minHeight")]
        public int? MinHeight { get; set; }

        /// <summary>
        /// Gets/Sets the minimum width to which the dialog can be resized, in pixels.
        /// </summary>
        [jQueryOption("minWidth")]
        public int? MinWidth { get; set; }

        /// <summary>
        ///  Gets/Sets the title of dialog
        /// </summary>
        [jQueryOption("title")]
        public string Title { get; set; }

        /// <summary>
        /// Gets/Sets the dialog modal behavior; other items on the page will be disabled (i.e. cannot be interacted with). 
        /// Modal dialogs create an overlay below the dialog but above other page elements.
        /// </summary>
        [jQueryOption("modal")]
        public bool? ShowModal { get; set; }

        /// <summary>
        /// Gets/Sets whether the dialog can be resizable
        /// </summary>
        [jQueryOption("resizable")]
        public bool? IsResizable { get; set; }

        /// <summary>
        /// Gets/Sets the effect to be used when the dialog is opened.
        /// </summary>
        [jQueryOption("show")]
        public jQueryEffects ShowEffect
        {
            get { return showEffect; }
            set { showEffect = value; }
        }

        /// <summary>
        /// Gets/Sets whether the dialog will stack on top of other dialogs. 
        /// This will cause the dialog to move to the front of other dialogs when it gains focus.
        /// </summary>
        [jQueryOption("stack")]
        public bool? IsStack { get; set; }

        /// <summary>
        /// Gets/Sets the dialog width
        /// </summary>
        [jQueryOption("width")]
        public int? Width { get; set; }

        /// <summary>
        /// Gets/sets the starting z-index for the dialog.
        /// </summary>
        [jQueryOption("zIndex")]
        public int? ZIndex { get; set; }

        /// <summary>
        /// Gets/Sets the dialog beforeclose event client handler
        /// </summary>
        /// <remarks>
        /// you can write the javascript in jQuery in this property directly if "function" declare not found this property will
        /// generate the function keyword automatic.
        /// this event have two params "event","ui"
        /// </remarks>
        /// <example>
        ///  OnClientBeforeClose=" $(this).dialog('option','autoOpen',true);"
        /// </example>
        [jQueryOption("beforeclose", ValueType = JavaScriptTypes.Function, FunctionParams = new string[] { "event", "ui" })]
        public string OnBeforeClose { get; set; }

        /// <summary>
        /// Gets/Sets the dialog open event client handler
        /// </summary>
        /// <remarks>
        /// you can write the javascript in jQuery in this property directly if "function" declare not found this property will
        /// generate the function keyword automatic.
        /// this event have two params "event","ui"
        /// </remarks>
        /// <example>
        ///  OnClientOpen=" $(this).dialog('option','title','Simaple');"
        /// </example>
        [jQueryOption("open", ValueType = JavaScriptTypes.Function, FunctionParams = new string[] { "event", "ui" })]
        public string OnOpen { get; set; }

        /// <summary>
        /// Gets/Sets the dialog focus event client handler
        /// </summary>
        /// <remarks>
        /// you can write the javascript in jQuery in this property directly if "function" declare not found this property will
        /// generate the function keyword automatic.
        /// this event have two params "event","ui"
        /// </remarks>
        /// <example>
        ///  OnFocus=" $(this).dialog('option','title','Editing');"
        /// </example>
        [jQueryOption("focus", ValueType = JavaScriptTypes.Function, FunctionParams = new string[] { "event", "ui" })]
        public string OnFocus { get; set; }

        /// <summary>
        /// Gets/Sets the dialog dragStart event client handler
        /// </summary>
        /// <remarks>
        /// you can write the javascript in jQuery in this property directly if "function" declare not found this property will
        /// generate the function keyword automatic.
        /// this event have two params "event","ui"
        /// </remarks>
        /// <example>
        ///  OnDragStart="var x=event.screenX;"
        /// </example>
        [jQueryOption("dragStart", ValueType = JavaScriptTypes.Function, FunctionParams = new string[] { "event", "ui" })]
        public string OnDragStart { get; set; }

        /// <summary>
        /// Gets/Sets the dialog dragStop event client event handler
        /// </summary>
        /// <remarks>
        /// you can write the javascript in jQuery in this property directly if "function" declare not found this property will
        /// generate the function keyword automatic.
        /// this event have two params "event","ui"
        /// </remarks>
        /// <example>
        ///  OnDragStop="var x=event.screenX;"
        /// </example>
        [jQueryOption("dragStop", ValueType = JavaScriptTypes.Function, FunctionParams = new string[] { "event", "ui" })]
        public string OnDragStop { get; set; }

        /// <summary>
        /// Gets/Sets the dialog drag event client handler
        /// </summary>
        /// <remarks>
        /// you can write the javascript in jQuery in this property directly if "function" declare not found this property will
        /// generate the function keyword automatic.
        /// this event have two params "event","ui"
        /// </remarks>
        /// <example>
        ///  OnDrag="var x=event.screenX;"
        /// </example>
        [jQueryOption("drag", ValueType = JavaScriptTypes.Function, FunctionParams = new string[] { "event", "ui" })]
        public string OnDrag { get; set; }

        /// <summary>
        /// Gets/Sets the dialog resizeStart event client event handler
        /// </summary>
        /// <remarks>
        /// you can write the javascript in jQuery in this property directly if "function" declare not found this property will
        /// generate the function keyword automatic.
        /// this event have two params "event","ui"
        /// </remarks>
        /// <example>
        ///  OnResizeStart="var x=event.screenX;"
        /// </example>
        [jQueryOption("resizeStart", ValueType = JavaScriptTypes.Function, FunctionParams = new string[] { "event", "ui" })]
        public string OnResizeStart { get; set; }

        /// <summary>
        /// Gets/Sets the dialog resize event client event handler
        /// </summary>
        /// <remarks>
        /// you can write the javascript in jQuery in this property directly if "function" declare not found this property will
        /// generate the function keyword automatic.
        /// this event have two params "event","ui"
        /// </remarks>
        /// <example>
        ///  OnResize="var x=event.screenX;"
        /// </example>
        [jQueryOption("resize", ValueType = JavaScriptTypes.Function, FunctionParams = new string[] { "event", "ui" })]
        public string OnResize { get; set; }

        /// <summary>
        /// Gets/Sets the dialog resizeStop event client event handler
        /// </summary>
        /// <remarks>
        /// you can write the javascript in jQuery in this property directly if "function" declare not found this property will
        /// generate the function keyword automatic.
        /// this event have two params "event","ui"
        /// </remarks>
        /// <example>
        ///  OnResizeStop="var x=event.screenX;"
        /// </example>
        [jQueryOption("resizeStop", ValueType = JavaScriptTypes.Function, FunctionParams = new string[] { "event", "ui" })]
        public string OnResizeStop { get; set; }

        /// <summary>
        /// Gets/Sets the dialog close event client handler
        /// </summary>
        /// <remarks>
        /// you can write the javascript in jQuery in this property directly if "function" declare not found this property will
        /// generate the function keyword automatic.
        /// this event have two params "event","ui"
        /// </remarks>
        [jQueryOption("close", ValueType = JavaScriptTypes.Function, FunctionParams = new string[] { "event", "ui" })]
        public string OnClose { get; set; }

        /// <summary>
        /// Specifies the collection which buttons should be displayed on the dialog. 
        /// </summary>
        [jQueryOption("buttons", ValueType = JavaScriptTypes.JSON)]
        public OptionBuilder Buttons { get; set; }
    }
}
