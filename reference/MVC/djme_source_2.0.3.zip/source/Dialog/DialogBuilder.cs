﻿//  Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.Mvc;

namespace DNA.Mvc.jQuery
{
    public class DialogBuilder : jQueryComponentBuilder<DialogOptions, Dialog, DialogBuilder>
    {
        public DialogBuilder(Dialog component, AjaxHelper helper) : base(component, helper) { }

        public DialogBuilder Body(Action value)
        {
            Component.Template = value;
            return this;
        }

        public DialogBuilder Load(string url)
        {
            Component.ContentUrl = url;
            return this;
        }

        //public DialogBuilder Body(string content)
        //{
        //    Component.HtmlTemplate = content;
        //    return this;
        //}

        public DialogBuilder OpenWith(string triggerID)
        {
            return this.OpenWith(triggerID, DomEvents.Click);
        }

        public DialogBuilder OpenWith(string triggerID, DomEvents openEvent)
        {
            Component.TriggerID = triggerID;
            Component.TriggerEvent = openEvent;
            return this;
        }

        public DialogBuilder Buttons(Action<DialogButtonFactory> value)
        {
            var factory = new DialogButtonFactory(Component.Buttons,Component,Helper);
            value.Invoke(factory);
            return this;
        }

        protected override string jQueryPluginName
        {
            get { return "dialog"; }
        }

        public override void Render()
        {
            if (!string.IsNullOrEmpty(Component.ContentUrl))
            {
                EnsureOptions();
                string ajaxScript = Helper.GeneratejQueryAjaxScripts(new jQueryAjaxOptions()
                {
                    AutoHandlingError=false,
                    Url = Component.ContentUrl,
                    OnSuccess = jQuerySelector + ".html(data);"
                });
                options.OnOpen = ajaxScript;
            }

            if (Component.Buttons.Count > 0)
            {
                EnsureOptions();
                if (options.Buttons == null) options.Buttons = new OptionBuilder();
                foreach (var btn in Component.Buttons)
                {
                    options.Buttons.AddFunctionOption("\""+btn.Text+"\"",btn.OnClick);
                }
            }

            if (!string.IsNullOrEmpty(Component.TriggerID))
            {
                if (string.IsNullOrEmpty(Component.Name))
                    Component.Name = "dialog_" + Guid.NewGuid().ToString().Substring(0, 5);

                Helper.RegisterStartupScript("$(\"#" + Component.TriggerID + "\").bind(\"" + Component.TriggerEvent.ToString().ToLower() + "\",function(){$('#" + Component.Name + "').dialog('open');});");
            }
            base.Render();
        }

        private void EnsureOptions()
        {
            if (options == null) options = new DialogOptions();
        }
    }
}
