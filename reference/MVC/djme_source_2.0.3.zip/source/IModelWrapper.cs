﻿//  Copyright (c) 2011 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Collections;

namespace DNA.Mvc.jQuery
{
    public interface IModelWrapper
    {
        IEnumerable Model { get; }
        int Total { get; }
    }

    [Serializable]
    public class ModelWrapper : IModelWrapper
    {
        public ModelWrapper() { }
        public ModelWrapper(IEnumerable model)
        {
            Model = model;
        }
        public ModelWrapper(IEnumerable model, int total)
            : this(model)
        { Total = total; }

        public IEnumerable Model { get; set; }

        public int Total { get; set; }

        IEnumerable IModelWrapper.Model
        {
            get { return this.Model; }
        }

        int IModelWrapper.Total
        {
            get { return this.Total; }
        }
    }

    [Serializable]
    public class ModelWrapper<T> : IModelWrapper
    {
        public ModelWrapper() { }
        
        public ModelWrapper(IEnumerable<T> model)
        {
            Model = model;
        }

        public ModelWrapper(IEnumerable<T> model, int total)
            : this(model)
        { Total = total; }

        public IEnumerable<T> Model { get; set; }

        public int Total { get; set; }

        IEnumerable IModelWrapper.Model
        {
            get { return this.Model; }
        }

        int IModelWrapper.Total
        {
            get { return this.Total; }
        }
    }


}
