﻿//  Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Mvc;

namespace DNA.Mvc.jQuery
{
    /// <summary>
    /// Represents support for HTML MarkupTextBox controls
    /// </summary>
    public static class MarkupTextBoxExtensions
    {
        /// <summary>
        /// Returns the html elements of the MarkupTextBox by using the specified Ajax helper and the name of the form field.
        /// </summary>
        /// <param name="helper">The HTML helper instance that this method extends.</param>
        /// <param name="name">The name of the form field to return.</param>
        /// <returns>The Html elements and javascripts of the MarkupTextBox</returns>
        public static MvcHtmlString MarkupTextBox(this AjaxHelper helper, string name)
        {
            return MarkupTextBox(helper, name, "", null);
        }

        /// <summary>
        /// Returns the html elements of the MarkupTextBox by using the specified Ajax helper,the name of the form field,and the text content. 
        /// </summary>
        /// <param name="helper">The HTML helper instance that this method extends.</param>
        /// <param name="name">The name of the form field to return.</param>
        /// <param name="value">The text content.</param>
        /// <returns>The Html elements and javascripts of the MarkupTextBox</returns>
        public static MvcHtmlString MarkupTextBox(this AjaxHelper helper, string name, string value)
        {
            return MarkupTextBox(helper, name, value, null);
        }

        /// <summary>
        /// Returns the html elements of the MarkupTextBox by using the specified Ajax helper,the name of the form field, the text content, and the options of the markupable jQuery plugin. 
        /// </summary>
        /// <param name="helper">The HTML helper instance that this method extends.</param>
        /// <param name="name">The name of the form field to return.</param>
        /// <param name="value">The text content.</param>
        /// <param name="options">The options object of the markupText jQuery plugin.</param>
        /// <returns>The Html elements and javascripts of the MarkupTextBox</returns>
        public static MvcHtmlString MarkupTextBox(this AjaxHelper helper, string name, string value, MarkupTextBoxOptions options)
        {
            TagBuilder markupText = new TagBuilder("textarea");
            markupText.GenerateId(name);
            markupText.Attributes.Add("name", name);
            markupText.InnerHtml = value == null ? "" : helper.ViewContext.HttpContext.Server.HtmlEncode(value);
            if (options == null)
                helper.jQuery("#" + markupText.Attributes["id"], "markupable");
            else
                helper.jQuery("#" + markupText.Attributes["id"], "markupable", options);
            return MvcHtmlString.Create(markupText.ToString());
        }
    }
}
