﻿//  Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Mvc;

namespace DNA.Mvc.jQuery
{
    /// <summary>
    /// Defines the properties map to the markupable plugin's options
    /// </summary>
    public class MarkupTextBoxOptions
    {
        /// <summary>
        /// Gets/Sets the heigh of the MTB
        /// </summary>
        [jQueryOption("height")]
        public int? Height { get; set; }

        /// <summary>
        /// Gets/Sets the width of the MTB
        /// </summary>
        [jQueryOption("width")]
        public int? Width { get; set; }

        /// <summary>
        /// Gets/Sets the MTB's background color
        /// </summary>
        [jQueryOption("bgColor")]
        public string BackgroundColor { get; set; }

        /// <summary>
        /// Gets/Sets the parser json file url
        /// </summary>
        [jQueryOption("parserUrl")]
        public string ParserUrl { get; set; }

        /// <summary>
        /// Gets/Sets the image base url
        /// </summary>
        [jQueryOption("imgBaseUrl")]
        public string ImageBaseUrl { get; set; }
    }
}
