﻿//  Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.UI;
using DNA.Mvc.jQuery;

namespace DNA.Mvc
{
    public abstract class jQueryComponentBuilder<TOptions, TComponent, TBuilder> : ViewComponentBuilder<TComponent, TBuilder>
        where TComponent : ViewComponent
        where TBuilder : ViewComponentBuilder<TComponent, TBuilder>
    {
        protected TOptions options;
        
        protected abstract string jQueryPluginName { get; }

        protected string jQuerySelector { get { return "$(\"#"+Component.Id+"\")"; } }

        public jQueryComponentBuilder(TComponent component, AjaxHelper helper) : base(component, helper) { }

        public TBuilder Options(Action<TOptions> value)
        {
            if (options == null)
                options = Activator.CreateInstance<TOptions>();
            value.Invoke(options);
            return this as TBuilder;
        }

        public override void Render()
        {
            if (string.IsNullOrEmpty(jQueryPluginName))
                throw new ArgumentNullException("jQueryPluginName");

            base.Render();
            Helper.jQuery(Component.Id, jQueryPluginName, options);
        }
    }
}