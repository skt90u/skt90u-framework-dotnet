﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DNA.Mvc
{
    /// <summary>
    /// Enumerates the base types of javascript
    /// </summary>
    public enum JavaScriptTypes
    {
        /// <summary>
        /// The string type
        /// </summary>
        String=0,
        /// <summary>
        /// The boolean type.
        /// </summary>
        Boolean=1,
        /// <summary>
        /// The numbers
        /// </summary>
        Number=2,
        /// <summary>
        /// The function object.
        /// </summary>
        Function=3,
        /// <summary>
        /// The array object.
        /// </summary>
        Array=4,
        /// <summary>
        /// object type.
        /// </summary>
        Object=5,
        /// <summary>
        /// The json object
        /// </summary>
        JSON=6,

        jQuerySelector=7
    }
}
