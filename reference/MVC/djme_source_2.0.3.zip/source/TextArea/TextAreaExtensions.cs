﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Mvc;

namespace DNA.Mvc.jQuery
{
    /// <summary>
    ///  Represents support for DJP textarea jQuery plugin control.
    /// </summary>
    public static class TextAreaExtensions
    {
        /// <summary>
        ///  Returns the html elements supports for jQuery textarea by specified  the Ajax helper instance that this method extends and the name of the form field.
        /// </summary>
        /// <param name="helper">The Ajax helper instance that this method extends.</param>
        /// <param name="name">The name of the form field to return.</param>
        /// <returns>The html elements of the TextArea in MvcHtmlString type.</returns>
        public static MvcHtmlString TextArea(this AjaxHelper helper, string name)
        {
            return TextArea(helper, name, null, null);
        }

        /// <summary>
        /// Returns the html elements supports for jQuery textarea by specified  the Ajax helper instance that this method extends ,the name of the form field and the text content.
        /// </summary>
        /// <param name="helper">The Ajax helper instance that this method extends.</param>
        /// <param name="name">The name of the form field to return.</param>
        /// <param name="value">The text content</param>
        /// <returns>The html elements of the TextArea in MvcHtmlString type.</returns>
        public static MvcHtmlString TextArea(this AjaxHelper helper, string name, string value)
        {
            return TextArea(helper, name, value, null);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="helper"></param>
        /// <param name="name"></param>
        /// <param name="value"></param>
        /// <param name="htmlAttributes"></param>
        /// <returns></returns>
        public static MvcHtmlString TextArea(this AjaxHelper helper, string name, string value, object htmlAttributes)
        {
            TagBuilder txtContainer = new TagBuilder("div");
            //txtContainer.AddCssClass("ui-state-default");
            //txtContainer.AddCssClass("ui-corner-all");
            txtContainer.AddCssClass("d-textarea");

            TagBuilder textArea = new TagBuilder("textarea");
            //textArea.Attributes.Add("id", name);
            textArea.GenerateId(name);
            textArea.MergeAttribute("name", name);
            textArea.MergeAttribute("type", "text");
            //textArea.AddCssClass("ui-state-default");
            //textArea.AddCssClass("ui-input");
            textArea.MergeAttribute("rows", "2");
            textArea.MergeAttribute("cols", "20");
            textArea.MergeAttribute("onfocus", "$(this).parent().addClass('d-textarea-active');");
            textArea.MergeAttribute("onblur", "$(this).parent().removeClass('d-textarea-active');");
            //textArea.MergeAttribute("style", "height:100%;width:98%;padding-right:5px;margin:3px;margin-right:0px;");
            textArea.InnerHtml = value;

            if (htmlAttributes != null)
            {
                var _h = ObjectHelper.ConvertObjectToDictionary(htmlAttributes);
                textArea.MergeAttributes<string, object>(_h);
                if (_h.ContainsKey("rows"))
                    textArea.Attributes["rows"] = _h["rows"].ToString();
                if (_h.ContainsKey("cols"))
                    textArea.Attributes["cols"] = _h["cols"].ToString();
            }
            txtContainer.InnerHtml = textArea.ToString();
            return MvcHtmlString.Create(txtContainer.ToString());
        }

    }
}
