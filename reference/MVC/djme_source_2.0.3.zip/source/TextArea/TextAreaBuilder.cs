﻿//  Copyright (c) 2011 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Mvc;

namespace DNA.Mvc.jQuery
{
    public class TextAreaBuilder : ViewComponentBuilder<TextArea, TextAreaBuilder>
    {
        public TextAreaBuilder(TextArea component, AjaxHelper helper) : base(component, helper) { }

        public TextAreaBuilder Value(string value)
        {
            Component.Value = value;
            return this;
        }

        public TextAreaBuilder Value(Action htmlValue)
        {
            Component.HtmlValue = htmlValue;
            return this;
        }

        public TextAreaBuilder ReadOnly()
        {
            Component.IsReadOnly = true;
            return this;
        }

        private bool resizable = false;

        public TextAreaBuilder Resizable()
        {
            resizable = true;
            return this;
        }

        public override void Render()
        {
            base.Render();
            var scripts = new StringBuilder();
            string selector = "$(\"#" + Component.Id + "\")";
            scripts.Append(selector)
                .Append(".focus(function(){$(this).parent().addClass('d-textarea-active');})")
                .Append(".blur(function(){$(this).parent().removeClass('d-textarea-active');});");
            if (resizable)
            {
                Helper.Resizable(Component.Id + "_wrapper", new ResizableOptions()
                {
                    AlsoResize = "#" + Component.Id,
                    AutoHide = true
                });
            }
            Helper.RegisterStartupScript(scripts.ToString());
        }
    }
}
