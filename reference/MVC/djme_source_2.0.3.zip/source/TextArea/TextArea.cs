﻿//  Copyright (c) 2011 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Mvc;

namespace DNA.Mvc.jQuery
{
    public class TextArea : ViewComponent
    {
        public string Value { get; set; }

        public Action HtmlValue { get; set; }
        
        public bool IsReadOnly { get; set; }

        public override string TagName
        {
            get
            {
                return "textarea";
            }
        }

        public override void RenderBeginTag(System.Web.UI.HtmlTextWriter writer)
        {
            TagBuilder txtContainer = new TagBuilder("div");
            txtContainer.Attributes.Add("id", Id + "_wrapper");
            txtContainer.AddCssClass("d-textarea");
            
            if (IsReadOnly)
                MergeAttribute("readonly", "readonly");

            if (Width > 0 || Height > 0)
            {
                string _style = (Width > 0 ? "width:" + Width.ToString() + "px;" : "") + (Height > 0 ? "height:" + Height.ToString() + "px;" : "");
                txtContainer.MergeAttribute("style", _style);
            }
            writer.Write(txtContainer.ToString(TagRenderMode.StartTag));
            base.RenderBeginTag(writer);
        }

        public override void RenderContent(System.Web.UI.HtmlTextWriter writer)
        {
            if (HtmlValue != null)
                HtmlValue.Invoke();
            else
            {
                if (!string.IsNullOrEmpty(Value))
                    writer.Write(Value);
            }
        }

        public override void RenderEndTag(System.Web.UI.HtmlTextWriter writer)
        {
            base.RenderEndTag(writer);
            writer.WriteEndTag("div");
        }
    }
}
