﻿//  Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Web.Mvc;

namespace DNA.Mvc.jQuery
{
    /// <summary>
    /// Represents support for HTML that render a image link list.
    /// </summary>
    public class ImageLinkList
    {
        private ImageLinkCollection links = new ImageLinkCollection();
        private ImageLinkOptions options = new ImageLinkOptions();

        /// <summary>
        /// Add the image link item by specified delegate.
        /// </summary>
        /// <param name="exprs">The Action delegate to add the imagelink items.</param>
        /// <returns>The current ImageLinkList instance.</returns>
        public ImageLinkList Items(Action<ImageLinkCollection> exprs)
        {
            exprs.Invoke(links);
            return this;
        }

        /// <summary>
        /// Set the Options of the ImageLinkList.
        /// </summary>
        /// <param name="exprs">The Action delegate to set the ImageLinkList settings.</param>
        /// <returns>The current ImageLinkList instance.</returns>
        public ImageLinkList Options(Action<ImageLinkOptions> exprs)
        {
            exprs.Invoke(options);
            return this;
        }

        /// <summary>
        /// Receives the Html elements in MvcHtmlString format.
        /// </summary>
        /// <returns></returns>
        public MvcHtmlString Render()
        {
            var builder = new NodeUIBuilder();
            builder.WriteBeginTag("ul", new { Class = options.CssClass, style = options.CssStyleText });

            foreach (var link in links)
            {
                builder.WriteBeginTag("li", new { Class = options.ItemCssClass, style = options.ItemCssStyleText });
                if (!string.IsNullOrEmpty(link.NavigateUrl))
                    builder.WriteBeginLink(link, new { Class = options.LinkCssClass, style = options.LinkCssStyleText });

                if (!string.IsNullOrEmpty(link.ImageUrl))
                    builder.WriteImage(link, new { style = options.ImageCssStyleText, Class = options.LinkCssClass });

                builder.WriteTitle(link, new { style = options.TitleCssStyleText, Class = options.TitleCssClass });

                if (!string.IsNullOrEmpty(link.NavigateUrl))
                    builder.WriteEndTag("a");
                builder.WriteEndTag("li");
            }
            return MvcHtmlString.Create(builder.ToString());
        }

        /// <summary>
        /// The ImageLinkList Optons.
        /// </summary>
        public class ImageLinkOptions
        {
            /// <summary>
            /// Gets/Sets the class attribute of the ImageLinkList.
            /// </summary>
            public string CssClass { get; set; }

            /// <summary>
            /// Gets/Sets the style attribute oft the ImageLinkList
            /// </summary>
            public string CssStyleText { get; set; }
            
            /// <summary>
            /// Gets/Sets the item css class.
            /// </summary>
            public string ItemCssClass { get; set; }
            
            /// <summary>
            /// Gets/Sets the item css text.
            /// </summary>
            public string ItemCssStyleText { get; set; }
            
            /// <summary>
            /// Gets/Sets the link element css class.
            /// </summary>
            public string LinkCssClass { get; set; }
            
            /// <summary>
            /// Gets/Sets the link element css style text.
            /// </summary>
            public string LinkCssStyleText { get; set; }
            
            /// <summary>
            ///  Gets/Sets the image element css class name.
            /// </summary>
            public string ImageCssClass { get; set; }
            
            /// <summary>
            /// Gets/Sets the image element css style text.
            /// </summary>
            public string ImageCssStyleText { get; set; }
            
            /// <summary>
            ///  Gets/Sets the title css class name.
            /// </summary>
            public string TitleCssClass { get; set; }
            
            /// <summary>
            /// Gets/Sets the title css style text.
            /// </summary>
            public string TitleCssStyleText { get; set; }
        }

        /// <summary>
        ///  Defines the collection of the ImageLink item
        /// </summary>
        public class ImageLinkCollection : List<INavigtable>
        {
            /// <summary>
            /// Add the ImageLink item by specified the link text.
            /// </summary>
            /// <param name="text">The link text content.</param>
            public void Add(string text)
            {
                this.Add(text, "", "");
            }

            /// <summary>
            /// Add the ImageLink item by specified the link text and the image url.
            /// </summary>
            /// <param name="text">The link text content</param>
            /// <param name="imageUrl">The image url.</param>
            public void Add(string text, string imageUrl)
            {
                this.Add(text, imageUrl, "");
            }

            /// <summary>
            /// Add the ImageLink item by specified the link text,the image url and the link url.
            /// </summary>
            /// <param name="text">The link text content</param>
            /// <param name="imageUrl">The image url.</param>
            /// <param name="navigateUrl">The link url</param>
            public void Add(string text, string imageUrl, string navigateUrl)
            {
                this.Add(new SelectableNode() { Text = text, ImageUrl = imageUrl, NavigateUrl = navigateUrl, Target = "_self" });
            }
        }
    }

}
