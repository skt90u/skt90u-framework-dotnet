﻿//  Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;

namespace DNA.Mvc.jQuery
{
    /// <summary>
    /// Accordion allows you to provide multiple views and display them one at a time. It is like having several Views where only one can be expanded at a time
    /// </summary>
    public class Accordion : ContainerViewComponent<TitleView>
    {
        public IList<TitleView> Sections
        {
            get { return this.InnerItems; }
            set { this.InnerItems = value; }
        }

        public bool IsSortable { get; set; }

        public override void RenderContent(System.Web.UI.HtmlTextWriter writer)
        {
            foreach (var view in InnerItems)
            {
                if (IsSortable)
                    writer.WriteFullBeginTag("div");

                writer.WriteFullBeginTag("h3");
                writer.WriteBeginTag("a");
                writer.WriteAttribute("herf", "#");
                writer.Write(HtmlTextWriter.TagRightChar);
                writer.Write(view.Title);
                writer.WriteEndTag("a");
                writer.WriteEndTag("h3");
                view.Render(writer);

                if (IsSortable)
                    writer.WriteEndTag("div");
            }
        }
    }
}