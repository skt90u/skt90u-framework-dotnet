﻿//  Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
//using DNA.Mvc.jQuery;
using System.Text;

namespace DNA.Mvc.jQuery
{
    public class AccordionBuilder : jQueryComponentBuilder<AccordionOptions, Accordion, AccordionBuilder>
    {
        public AccordionBuilder(Accordion component, AjaxHelper helper) : base(component, helper) { }

        public AccordionBuilder Sections(Action<TitleViewFactory> value)
        {

            var factory = new TitleViewFactory(Component, Helper);
            value.Invoke(factory);
            return this;
        }

        //private bool isSortable = false;

        public AccordionBuilder Sortable()
        {
            //isSortable = true;
            Component.IsSortable = true;
            Options(opts =>
            {
                opts.Header = ">div>h3";
            });
            return this;
        }

        private string _elementName;
        private ResizableOptions resizeOpts;

        public AccordionBuilder FitTo(string elementName, Action<ResizableOptions> setResizeOptions)
        {
            if (string.IsNullOrEmpty(elementName))
                throw new ArgumentNullException("elementName");

            EnsureResizableOptions();
            setResizeOptions.Invoke(resizeOpts);
            _elementName = elementName;
            return this;
        }
        
        public AccordionBuilder FitTo(string elementName, int minHeight)
        {
            if (string.IsNullOrEmpty(elementName))
                throw new ArgumentNullException("elementName");

            EnsureResizableOptions();
            resizeOpts.MinHeight = minHeight;
            return FitTo(elementName);
        }

        public AccordionBuilder FitTo(string elementName)
        {
            if (string.IsNullOrEmpty(elementName))
                throw new ArgumentNullException("elementName");
            _elementName = elementName;
            return this;
        }

        private void EnsureResizableOptions()
        {
            if (resizeOpts == null)
                resizeOpts = new ResizableOptions();
        }

        protected override string jQueryPluginName
        {
            get { return "accordion"; }
        }

        public override void Render()
        {
            if (!string.IsNullOrEmpty(_elementName))
            {
                Options(opts => {
                    opts.FillSpace = true;
                });
            }


            base.Render();

            if (!string.IsNullOrEmpty(_elementName))
            {
                EnsureResizableOptions();
                resizeOpts.OnResize = "$('#" + Component.Name + "').accordion('resize');";
                Helper.Resizable(_elementName, resizeOpts);
            }

            if (Component.IsSortable)
            {
                var scripts = new StringBuilder();
                var param_stop = Component.Id + "_stop";
                scripts.AppendLine("var " + param_stop + "=false;")
                          .AppendLine("$('#" + Component.Name + " h3').click(function(event){")
                          .AppendLine("if (" + param_stop + ") {")
                          .AppendLine("event.stopImmediatePropagation();")
                          .AppendLine("event.preventDefault();")
                          .AppendLine(param_stop + "=false;}});")
                          .AppendLine("$(\"#" + Component.Id + "\")")
                          .Append(".sortable({axis:'y',handle:'h3',")
                          .Append("stop:function(){")
                          .AppendLine(param_stop + "=true;")
                          .AppendLine("}});");
                Helper.RegisterStartupScript(scripts.ToString());
            }
        }
    }


}