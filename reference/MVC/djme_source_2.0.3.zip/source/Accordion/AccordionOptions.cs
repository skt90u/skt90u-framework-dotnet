﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;

namespace DNA.Mvc.jQuery
{
    /// <summary>
    /// Defines the jQuery UI Accordion plugin options.
    /// </summary>
    public class AccordionOptions
    {
        /// <summary>
        /// Gets/Sets your favorite animation of accrodion In addition to the default,
        /// 'BounceSlide' and 'EaseSlide' are supported
        /// </summary>
        [jQueryOption("animated")]
        public string CollapseAnimation { get; set; }

        /// <summary>
        /// Gets/Sets the clears height and overflow styles after finishing animations. 
        /// This enables accordions to work with dynamic content. Won't work together with AutoHeight.
        /// </summary>
        [jQueryOption("clearStyle")]
        public bool? IsClearStyle { get; set; }

        /// <summary>
        /// Gets/Sets whether all the sections can be closed at once. Allows collapsing the active section by the triggering event (click is the default).
        /// </summary>
        [jQueryOption("collapsible")]
        public bool? AllowCollapseAllSections { get; set; }

        /// <summary>
        /// Gets/Sets the client event on which to trigger the accordion.
        /// </summary>
        [jQueryOption("event")]
        public DomEvents OpenSectionEvent { get; set; }
        /// <summary>
        /// Gets/Sets Accordion looks for the anchor that matches location.href and activates it. 
        /// Great for href-based state-saving. Use navigationFilter to implement your own matcher.
        /// </summary>
        [jQueryOption("navigation")]
        public bool? Navigation { get; set; }

        /// <summary>
        /// Gets/Sets the client function that overwrite the default location.href-matching with your own matcher.(from jquery).
        /// </summary>
        [jQueryOption("navigationFilter", ValueType = JavaScriptTypes.Function)]
        public string NavigationFilter { get; set; }

        /// <summary>
        /// Gets/Sets the client event handler for accordion's changes event
        /// </summary>
        /// <remarks>
        ///   This event's has two params for client function.
        ///   event: jquery object
        ///   ui:jquery object
        /// </remarks>
        [jQueryOption("change", ValueType = JavaScriptTypes.Function, FunctionParams = new string[] { "event", "ui" })]
        public string OnClientViewChange { get; set; }

        /// <summary>
        /// Gets/Sets the active view control's index
        /// </summary>
        [jQueryOption("active")]
        public int? SelectedIndex { get; set; }

        /// <summary>
        /// Gets/Sets the accordion completely fills the height of the parent element
        /// </summary>
        [jQueryOption("fillSpace")]
        public bool? FillSpace { get; set; }

        /// <summary>
        /// Gets/Sets the highest content part used as height reference for all other parts. Provides more consistent animations
        /// </summary>
        [jQueryOption("autoHeight")]
        public bool? AutoHeight { get; set; }

        [jQueryOption("header")]
        public string Header { get; set; }

        /// <summary>
        /// Gets/Sets the icon style of the header icon.
        /// </summary>
        [jQueryOption("icons", ValueType = JavaScriptTypes.Object)]
        public HeaderIconsStyle Icons { get; set; }

        public class HeaderIconsStyle
        {
            /// <summary>
            /// Gets/Sets the header css class name.
            /// </summary>
            [jQueryOption("header")]
            public string HeaderCssClass { get; set; }

            /// <summary>
            /// Gets/Sets the css class name when the header was selected.
            /// </summary>
            [jQueryOption("headerSelected")]
            public string HeaderSelectedIconCssClass { get; set; }
        }
    }
}
