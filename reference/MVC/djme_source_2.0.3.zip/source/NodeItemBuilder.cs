﻿//  Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Mvc;
using System.Web.UI;

namespace DNA.Mvc.jQuery
{
    public abstract class NodeItemBuilder<TContainer, TNode, TFactory, TBuilder> : ViewComponentBuilder<TNode, TBuilder>
        where TNode : NodeBase<TContainer, TNode>
        where TBuilder : ViewComponentBuilder<TNode, TBuilder>
    {
        public NodeItemBuilder(TNode node, AjaxHelper helper) : base(node, helper) { }

        protected abstract TFactory CreateFactory();

        public TBuilder Items(Action<TFactory> items)
        {
            if (items != null)
                items.Invoke(CreateFactory());
            return this as TBuilder;
        }

        public TBuilder Text(string text)
        {
            Component.Title = text;
            return this as TBuilder;
        }

        public TBuilder Image(string imageUrl)
        {
            Component.ImageUrl = imageUrl;
            return this as TBuilder;
        }

        public TBuilder Template(Action value)
        {
            this.Component.Template = value;
            return this as TBuilder;
        }

        //public TBuilder HtmlTemplate(string html)
        //{
        //    this.Component.HtmlTemplate = html;
        //    return this as TBuilder;
        //}
    }
}
