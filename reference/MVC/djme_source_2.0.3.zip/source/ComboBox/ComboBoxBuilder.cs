﻿//  Copyright (c) 2011 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using DNA.Mvc.jQuery;
using System.Web.Mvc;

namespace DNA.Mvc.jQuery
{
    public class ComboBoxBuilder : jQueryNavigableViewBindingBuilder<ComboBoxOptions, ComboBox, ComboBoxBuilder>
    {
        private Action _templ;

        protected override string jQueryPluginName
        {
            get { return "combo"; }
        }

        public ComboBoxBuilder(ComboBox component, AjaxHelper helper) : base(component, helper) { }

        public ComboBoxBuilder DropDownStyle(DropdownStyles style)
        {
            Options(opts => { opts.DropDownStyle = style; });
            return this;
        }

        public ComboBoxBuilder Template(Action templ)
        {
            _templ = templ;
            return this;
        }

        public ComboBoxBuilder Select(string value)
        {
            Options(opts => { opts.SelectedValue = value; });
            return this;
        }

        public override void Render()
        {
            if (options == null) options = new ComboBoxOptions();

            using (var writer = new HtmlTextWriter(Helper.ViewContext.Writer))
            {
                if ((!string.IsNullOrEmpty(remoteUrl)) && (clientTemplate != null))
                {
                    #region Render in Client mode (load on demand)
                    options.ItemTemplateID = Component.Id + "_tmpl";
                    options.ParticalLoad = true;
                    options.Source = string.Empty;
                    var opts = new jQueryScriptBuilder("#" + Component.Name, jQueryPluginName);
                    opts.AddOptions(options);
                    opts.AddOption("source", remoteUrl, true);
                    Component.Render(writer);
                    RenderClientTemplate(writer);
                    Helper.RegisterStartupScript(opts.ToString());
                    #endregion
                }
                else
                {
                    #region Render Server mode
                    options.Source = "$('#" + Component.Id + "_menu')";
                    Component.Render(writer);

                    if (_templ != null)
                        writer.WriteBeginTag("div");
                    else
                        writer.WriteBeginTag("ul");

                    writer.WriteAttribute("id", Component.Id + "_menu");
                    writer.WriteAttribute("unselectable", "on");
                    writer.WriteAttribute("style", "display:none");
                    writer.Write(HtmlTextWriter.TagRightChar);

                    if (_templ != null)
                    {
                        _templ();
                    }
                    else
                    {
                        foreach (var item in Component.Items)
                        {
                            if (item.Template != null)
                            {
                                writer.WriteBeginTag("li");
                                writer.WriteAttribute("unselectable", "on");
                                writer.Write(Html32TextWriter.TagRightChar);

                                writer.WriteBeginTag("input");
                                writer.WriteAttribute("type", "hidden");
                                writer.WriteAttribute("value", item.Value != null ? item.Value.ToString() : "");
                                writer.Write(HtmlTextWriter.SelfClosingTagEnd);
                                item.Template();
                                writer.WriteEndTag("li");
                                continue;
                            }

                            if (Component.ItemDataBoundTemplate != null)
                            {
                                writer.WriteBeginTag("li");
                                writer.WriteAttribute("unselectable", "on");
                                writer.Write(Html32TextWriter.TagRightChar);
                                writer.WriteBeginTag("input");
                                writer.WriteAttribute("type", "hidden");
                                writer.WriteAttribute("value", item.Value != null ? item.Value.ToString() : "");
                                writer.Write(HtmlTextWriter.SelfClosingTagEnd);
                                Component.ItemDataBoundTemplate.Invoke(item);
                                writer.WriteEndTag("li");
                                continue;
                            }

                            var builder = new NodeUIBuilder();
                            builder.WriteNode(item);
                            writer.Write(builder.ToString());
                        }
                    }
                    if (_templ != null)
                        writer.WriteEndTag("div");
                    else
                        writer.WriteEndTag("ul");
                    #endregion
                    Helper.jQuery(Component.Id, jQueryPluginName, options);
                }
            }


        }
    }
}
