﻿//  Copyright (c) 2011 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DNA.Mvc.jQuery
{
    public class ComboBoxOptions
    {
        [jQueryOption("dropdownStyle")]
        public DropdownStyles DropDownStyle { get; set; }

        [jQueryOption("source", ValueType = JavaScriptTypes.jQuerySelector)]
        public string Source { get; set; }

        [jQueryOption("filterMode")]
        public bool? AllowFilter { get; set; }

        [jQueryOption("particalLoad")]
        public bool? ParticalLoad { get; set; }

        [jQueryOption("dataTextField")]
        public string DataTextField { get; set; }

        [jQueryOption("dataValueField")]
        public string DataValueField { get; set; }

        [jQueryOption("itemClass")]
        public string ItemCssClass { get; set; }

        [jQueryOption("itemHoverClass")]
        public string ItemHoverCssClass { get; set; }

        [jQueryOption("itemSelectedClass")]
        public string ItemSelectedCssClass { get; set; }
        
        [jQueryOption("itemTemplate")]
        public string ItemTemplateID { get; set; }

        [jQueryOption("selectedValue")]
        public string SelectedValue { get; set; }

        [jQueryOption("autofit")]
        public bool? AutoFitWith { get; set; }

        [jQueryOption("selected", ValueType = JavaScriptTypes.Function, FunctionParams = new string[] { "event", "ui" })]
        public string OnItemSelected { get; set; }
    }
}
