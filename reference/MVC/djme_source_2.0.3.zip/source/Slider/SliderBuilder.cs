﻿//  Copyright (c) 2011 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Mvc;
using System.Web.UI;

namespace DNA.Mvc.jQuery
{
    public class SliderBuilder : jQueryComponentBuilder<SliderOptions, Slider, SliderBuilder>
    {
        public SliderBuilder(Slider slider, AjaxHelper helper)
            : base(slider, helper) { }

        protected override string jQueryPluginName
        {
            get { return "slider"; }
        }

        public SliderBuilder Values(int minValue, int maxValue)
        {
            Options(opts =>
            {
                opts.Value = null;
                opts.Values = new int[] { minValue, maxValue };
            });
            return this;
        }

        public SliderBuilder Value(int value)
        {
            Options(opts =>
            {
                opts.Value = value;
            });

            return this;
        }

        public SliderBuilder Minimum(int minValue)
        {
            Options(opts =>
            {
                opts.Minimum = minValue;
            });
            return this;
        }

        public SliderBuilder Maximum(int maxValue)
        {
            Options(opts =>
            {
                opts.Maximum = maxValue;
            });
            return this;
        }

        private bool rangeSlider=false;
        public SliderBuilder Range(int minValue,int maxValue)
        {
            //Values(minValue, maxValue);
            Maximum(maxValue);
            Minimum(minValue);
            rangeSlider = true;
            return this;
        }
        
        private string txtStartSelector, txtEndSelector, valStartSelect, valEndSelector;

        public SliderBuilder FillTextTo(string selector)
        {
            Options(opts =>
            {
                opts.FillTextTo = selector;
            });
            return this;
        }

        public SliderBuilder FillTextTo(string startSelector, string endSelector)
        {
            txtStartSelector = startSelector;
            txtEndSelector = endSelector;
            return this;
        }

        public SliderBuilder FillValueTo(string selector)
        {
            Options(opts =>
            {
                opts.FillValueTo = selector;
            });

            return this;
        }

        public SliderBuilder FillValueTo(string startSelector, string endSelector)
        {
            valStartSelect = startSelector;
            valEndSelector = endSelector;
            return this;
        }

        public SliderBuilder Orientation(Orientation orientation)
        {
            Options(opts =>
            {
                opts.Orientation = orientation;
            });
            return this;
        }

        public override void Render()
        {
            using (var writer = new HtmlTextWriter(Helper.ViewContext.Writer))
            {
                Component.Render(writer);
            }

            if (options != null)
            {
                options.EnabledAnimate = true;
                if (options.Range == Ranges.Notset)
                    options.Range = Ranges.Min;

                if (rangeSlider) 
                {
                    if (!string.IsNullOrEmpty(valStartSelect))
                        options.OnSliding = options.OnSliding + "$(\"#" + valStartSelect + "\").val(ui.values[0]);";

                    if (!string.IsNullOrEmpty(valEndSelector))
                        options.OnSliding = options.OnSliding + "$(\"#" + valEndSelector + "\").val(ui.values[1]);";

                    if (!string.IsNullOrEmpty(txtStartSelector))
                        options.OnSliding = options.OnSliding + "$(\"#" +txtStartSelector+ "\").text(ui.values[0]);";

                    if (!string.IsNullOrEmpty(txtEndSelector))
                        options.OnSliding = options.OnSliding + "$(\"#" + txtEndSelector + "\").text(ui.values[1]);";

                    options.OnSliding = options.OnSliding + "$(\"#" + Component.Id + "\").val(ui.values[0].toString()+','+ui.values[1].toString());";

                }
                else
                {
                    if (!string.IsNullOrEmpty(options.FillValueTo))
                        options.OnSliding = options.OnSliding + "$(\"#" + options.FillValueTo + "\").val(ui.value);";
                    if (!string.IsNullOrEmpty(options.FillTextTo))
                        options.OnSliding = options.OnSliding + "$(\"#" + options.FillTextTo + "\").text(ui.value);";
                    options.OnSliding = options.OnSliding + "$(\"#" + Component.Id + "\").val(ui.value);";
                }

                var jscripts = new jQueryScriptBuilder("#" + Component.Id+"_slider", "slider");

                jscripts.AddOptions(options);

                if (options.Orientation != DNA.Mvc.jQuery.Orientation.Notset)
                    jscripts.AddOption("orientation", options.Orientation.ToString().ToLower(), true);

                if (rangeSlider)
                {
                    jscripts.AddOption("range", true);
                }
                else
                {
                    if (options.Range != Ranges.Notset)
                        jscripts.AddOption("range", options.Range.ToString().ToLower(), true);
                }
                Helper.RegisterStartupScript(jscripts.ToString());
            }
            else
                Helper.jQuery("#" + Component.Id + "_slider", "slider");
        }
    }
}
