﻿//  Copyright (c) 2011 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Mvc;

namespace DNA.Mvc.jQuery
{
    public class Slider : ViewComponent
    {

        public override void Render(System.Web.UI.HtmlTextWriter writer)
        {
            TagBuilder hidden = new TagBuilder("input");
            hidden.GenerateId(Name);
            hidden.MergeAttribute("name", Name);
            string sliderName = hidden.Attributes["id"] + "_slider";
            TagBuilder sliderContainer = new TagBuilder("div");
            sliderContainer.Attributes.Add("id", sliderName);
            if (HtmlAttributes!=null)
            sliderContainer.MergeAttributes<string, object>(this.HtmlAttributes);
            hidden.MergeAttribute("value", "0");
            hidden.MergeAttribute("type", "hidden");
            sliderContainer.InnerHtml = hidden.ToString();
            writer.Write(sliderContainer.ToString());
        }

    }
}
