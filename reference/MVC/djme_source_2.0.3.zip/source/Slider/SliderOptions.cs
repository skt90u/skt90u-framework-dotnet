﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DNA.Mvc.jQuery
{
    /// <summary>
    /// Defines a strongly type class of the DJP slider plugin options.
    /// </summary>
    public class SliderOptions
    {
        /// <summary>
        ///  Gets/Sets whether to slide handle smoothly when user click outside handle on the bar.
        /// </summary>
        [jQueryOption("animate")]
        public bool? EnabledAnimate { get; set; }

        /// <summary>
        /// Gets/Sets the maximum value of the slider.
        /// </summary>
        [jQueryOption("max")]
        public int? Maximum { get; set; }


        /// <summary>
        /// Gets/Sets the minimum value of the slider.
        /// </summary>
        [jQueryOption("min")]
        public int? Minimum { get; set; }

        /// <summary>
        /// Gets/Sets the Silder's Orientaion
        /// </summary>
        //[jQueryOption("orientation")]
        [jQueryIgnore]
        public Orientation Orientation { get; set; }

        /// <summary>
        /// Gets/Sets the size or amount of each interval or step the slider takes between min and max. 
        /// </summary>
        /// <remarks>
        /// The full specified value range of the slider (max - min) needs to be evenly divisible by the step.
        /// </remarks>
        [jQueryOption("step")]
        public int? Step { get; set; }

        /// <summary>
        ///  Gets/Sets the slider's range,if this property set the slider will detect if you have two handles and 
        ///  create a stylable  range element between these two. Two other possible values are 'Min' and 'Max'.
        ///  A Min range goes from the slider Min to one handle. A max range goes from one handle to the 
        ///  slider max.
        /// </summary>
        // [jQueryOption("range")]
        [jQueryIgnore]
        public Ranges Range { get; set; }

        /// <summary>
        /// Gets/Sets the slider width.
        /// </summary>
        [jQueryIgnore]
        public int? Width { get; set; }

        /// <summary>
        /// Gets/Sets the slider height.
        /// </summary>
        [jQueryIgnore]
        public int? Height { get; set; }

        /// <summary>
        /// Gets/Sets the input element id that fill the value to.
        /// </summary>
        [jQueryIgnore]
        public string FillValueTo { get; set; }

        /// <summary>
        /// Gets/Sets the element id that fill the value to element as text.
        /// </summary>
        [jQueryIgnore]
        public string FillTextTo { get; set; }

        /// <summary>
        /// Gets/Sets the value of the slider, if there's only one handle. 
        /// If there is more than one handle, determines the value of the first handle.
        /// </summary>
        [jQueryOption("value")]
        public int? Value { get; set; }

        [jQueryOption("values")]
        public int[] Values { get; set; }

        /// <summary>
        /// Gets/Sets the start client event handler.
        /// </summary>
        /// <remarks>This event is triggered when the user starts sliding</remarks>
        [jQueryOption("start", ValueType = JavaScriptTypes.Function, FunctionParams = new string[] { "event", "ui" })]
        public string OnStartSliding { get; set; }

        /// <summary>
        /// Gets/Sets the slide client event handler.
        /// </summary>
        [jQueryOption("slide", ValueType = JavaScriptTypes.Function, FunctionParams = new string[] { "event", "ui" })]
        public string OnSliding { get; set; }

        /// <summary>
        /// Gets/Sets the change client event handler.
        /// </summary>
        [jQueryOption("change", ValueType = JavaScriptTypes.Function, FunctionParams = new string[] { "event", "ui" })]
        public string OnValueChanged { get; set; }

        /// <summary>
        /// Gets/Sets the stop client event handler.
        /// </summary>
        [jQueryOption("stop", ValueType = JavaScriptTypes.Function, FunctionParams = new string[] { "event", "ui" })]
        public string OnStopSliding { get; set; }

    }

}
