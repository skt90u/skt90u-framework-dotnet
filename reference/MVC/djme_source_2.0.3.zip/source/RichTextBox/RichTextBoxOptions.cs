﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
//using DNA.Text;

namespace DNA.Mvc.jQuery
{
    /// <summary>
    /// Defines the properties map to the richtextbox's options
    /// </summary>
    public class RichTextBoxOptions
    {
        ///// <summary>
        ///// Gets/Sets the heigh of the RTB
        ///// </summary>
        //[jQueryOption("height")]
        //public int? Height { get; set; }

        ///// <summary>
        ///// Gets/Sets the width of the RTB
        ///// </summary>
        //[jQueryOption("width")]
        //public int? Width { get; set; }

        /// <summary>
        /// Gets/Sets the init mode of the RTB
        /// </summary>
        /// <remarks>
        /// It can accept two options 
        ///    "editor" - show the editor mode
        ///    "source"  -show as the source code mode.
        /// </remarks>
        [jQueryOption("mode")]
        public string Mode { get; set; }

        /// <summary>
        /// Gets/Sets the RTB's background color
        /// </summary>
        [jQueryOption("bgColor")]
        public string BackgroundColor { get; set; }

        ///// <summary>
        ///// Gets/Sets the image base url
        ///// </summary>
        //[jQueryOption("imgBaseUrl")]
        //public string ImageBaseUrl { get; set; }
        
        /// <summary>
        /// Gets/Sets the font size in editor
        /// </summary>
        [jQueryOption("textFontSize")]
        public int? FontSize { get; set; }

        /// <summary>
        /// Gets/Sets the font name of the editor
        /// </summary>
        [jQueryOption("textFont")]
        public string FontFamily { get; set; }

        [jQueryOption("documentStyle")]
        public bool? UseDocumentStyle { get; set; }

        [jQueryOption("normalized", ValueType = JavaScriptTypes.Function, FunctionParams = new string[] { "event", "sender" })]
        public string OnDOMNodeNormalized { get; set; }
    }
}
