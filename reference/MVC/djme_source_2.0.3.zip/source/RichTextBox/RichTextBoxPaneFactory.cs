﻿//  Copyright (c) 2011 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Mvc;

namespace DNA.Mvc.jQuery
{
    public class RichTextBoxPaneFactory : ViewComponentBuilderFactory<RichTextBoxToolPane>
    {
        public RichTextBoxPaneFactory(RichTextBox container, AjaxHelper helper) : base(container, helper) { }

        public RichTextBoxPaneBuilder Add()
        {
            var pane = new RichTextBoxToolPane();
            Container.Items.Add(pane);
            Container.OnItemAdded(pane);
            var builder = new RichTextBoxPaneBuilder(pane, Helper).GenerateId();
            return builder;
        }

       
        public void Clear()
        {
            Container.Items.Clear();
        }
    }
}
