﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Mvc;

namespace DNA.Mvc.jQuery
{
    /// <summary>
    /// Represents support for DJP richtextbox jQuery plugin control.
    /// </summary>
    public static class RichTextBoxExtensions
    {
        /// <summary>
        /// Returns the html and register the jQuery plugin scripts for richtextbox jQuery plugin control by using the specified 
        /// the Ajax helper and the name of the form field.
        /// </summary>
        /// <param name="helper">The Ajax helper instance that this method extends.</param>
        /// <param name="name">The name of the form field to return.</param>
        /// <returns>The html elements of the richtextbox</returns>
        public static MvcHtmlString RichTextBox(this AjaxHelper helper, string name)
        {
            return RichTextBox(helper, name, "", null);
        }

        /// <summary>
        /// Returns the html and register the jQuery plugin scripts for richtextbox jQuery plugin control by using the specified 
        /// the Ajax helper ,the name of the form field and the html text content.
        /// </summary>
        /// <param name="helper">The Ajax helper instance that this method extends.</param>
        /// <param name="name">The name of the form field to return.</param>
        /// <param name="value">The html text content.</param>
        /// <returns>The html elements of the richtextbox</returns>
        public static MvcHtmlString RichTextBox(this AjaxHelper helper, string name, string value)
        {
            return RichTextBox(helper, name, value, null);
        }

        /// <summary>
        /// Returns the html and register the jQuery plugin scripts for richtextbox jQuery plugin control by using the specified 
        /// the Ajax helper ,the name of the form field , the html text content and the RichTextBoxOptions instance that use to setting the richtextbox.
        /// </summary>
        /// <param name="helper">The Ajax helper instance that this method extends.</param>
        /// <param name="name">The name of the form field to return.</param>
        /// <param name="value">The html text content.</param>
        /// <param name="options">The RichTextBoxOptions instance that setting the richtextbox options.</param>
        /// <returns>The html elements of the richtextbox</returns>
        public static MvcHtmlString RichTextBox(this AjaxHelper helper, string name, string value, RichTextBoxOptions options)
        {
            TagBuilder richtext = new TagBuilder("textarea");
            richtext.GenerateId(name);
            //richtext.Attributes.Add("id", name);
            richtext.Attributes.Add("name", name);
            richtext.InnerHtml = value == null ? "" : helper.ViewContext.HttpContext.Server.HtmlEncode(value);
            if (options == null)
                helper.jQuery("#" + richtext.Attributes["id"], "richtextbox");
            else
                helper.jQuery("#" + richtext.Attributes["id"], "richtextbox", options);
            return MvcHtmlString.Create(richtext.ToString());
        }
    }
}
