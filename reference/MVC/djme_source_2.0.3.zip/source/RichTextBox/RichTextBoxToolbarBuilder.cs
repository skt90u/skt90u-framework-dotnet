﻿//  Copyright (c) 2011 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Mvc;

namespace DNA.Mvc.jQuery
{
    public class RichTextBoxToolbarBuilder : ViewComponentBuilder<RichTextBoxToolbar, RichTextBoxToolbarBuilder>
    {
        public RichTextBoxToolbarBuilder(RichTextBoxToolbar component, AjaxHelper helper) : base(component, helper) { }

        private ToolbarButtonFactory buttonFactory;

        public RichTextBoxToolbarBuilder Buttons(Action<ToolbarButtonFactory> buttons)
        {
            var fac = new ToolbarButtonFactory(Component, Helper);
            buttons.Invoke(fac);
            return this;
        }

        private ToolbarButtonFactory ButtonFactory
        {
            get
            {
                if (buttonFactory == null)
                    buttonFactory = new ToolbarButtonFactory(Component, Helper);
                return buttonFactory;
            }
        }

        public RichTextBoxToolbarBuilder AddTemplateTool(Action tmpl)
        {

            var tmplButton = ButtonFactory.Add();
            tmplButton.Template(tmpl);
            return this;
        }

        public RichTextBoxToolbarBuilder AddText(string text, string onclick, bool? isPushed = false, bool? isChecked = false)
        {
            var txtButton = ButtonFactory.AddButton(text, onclick);
            if (isPushed.Value)
                txtButton.Settings(settings =>
                {
                    settings.ChangeType(ButtonTypes.ToggleButton)
                               .States(states =>
                               {
                                   states.Add()
                                       .Select(!isChecked.Value)
                                       .ToggleClass("d-rte-icon-button")
                                       .SetValue(false);
                                   states.Add()
                                       .Select(isChecked.Value)
                                       .ToggleClass("d-rte-icon-button-push")
                                       .SetValue(true);
                               });
                });
            return this;
        }

        public RichTextBoxToolbarBuilder AddImage(string imageUrl, string text, string onclick, string toolTip, bool? isPushed = false, bool? isChecked = false)
        {
            var imgButton = ButtonFactory.AddImageButton(imageUrl, onclick);
            if (!string.IsNullOrEmpty(text))
                imgButton.Text(text);
            if (!string.IsNullOrEmpty(toolTip))
                imgButton.ToolTip(toolTip);
            if (isPushed.Value)
                imgButton.Settings(settings =>
                {
                    settings.ChangeType(ButtonTypes.ToggleButton)
                               .States(states =>
                               {
                                   states.Add()
                                       .ImageIcons(imageUrl)
                                       .Select(!isChecked.Value)
                                       .ToggleClass("d-rte-icon-button")
                                       .SetValue(false);
                                   states.Add()
                                       .ImageIcons(imageUrl)
                                       .Select(isChecked.Value)
                                       .ToggleClass("d-rte-icon-button-push")
                                       .SetValue(true);
                               });
                });
            return this;
        }

        public RichTextBoxToolbarBuilder AddImage(string imageUrl, string onclick, string toolTip, bool? isPushed = false, bool? isChecked = false)
        {
            return this.AddImage(imageUrl, null, onclick, toolTip, isPushed, isChecked);
        }

        public RichTextBoxToolbarBuilder AddIcon(string cssClass, string onclick, string text, string toolTip,Action<string> onNormalized, bool? isPushed = false, bool? isChecked = false)
        {
            var iconButton = ButtonFactory.AddIconButton(cssClass, onclick);
            if (!string.IsNullOrEmpty(text))
                iconButton.Text(text);
            if (!string.IsNullOrEmpty(toolTip))
                iconButton.ToolTip(toolTip);
            if (isPushed.Value)
                iconButton.Settings(settings =>
                {
                    settings.ChangeType(ButtonTypes.ToggleButton)
                               .States(states =>
                               {
                                   states.Add()
                                       .Icons(cssClass)
                                       .Select(!isChecked.Value)
                                       .ToggleClass("d-rte-icon-button")
                                       .SetValue(false);
                                   states.Add()
                                       .Icons(cssClass)
                                       .Select(isChecked.Value)
                                       .ToggleClass("d-rte-icon-button-push")
                                       .SetValue(true);
                               });
                });
            if (onNormalized != null)
                onNormalized.Invoke(iconButton.Component.Id);
            //if (!string.IsNullOrEmpty(onNormalized))
            //    this.Component.EditBox.OnNormalized.AppendLine("var self"+onNormalized);

            return this;
        }

        public RichTextBoxToolbarBuilder AddIcon(string cssClass, string onclick, string toolTip, bool? isPushed = false, bool? isChecked = false)
        {
            return this.AddIcon(cssClass, onclick, null, toolTip,null, isPushed, isChecked);
        }

        public RichTextBoxToolbarBuilder AddPush(string cssClass, string onclick, string toolTip, string group, Action<ButtonStateFactory> states)
        {
            return this.AddPush(cssClass,onclick,toolTip,group,states,null);
        }

        public RichTextBoxToolbarBuilder AddPush(string cssClass, string onclick, string toolTip, string group, Action<ButtonStateFactory> states, Action<string> onNormalized)
        {
            var pushButton = ButtonFactory.AddIconButton(cssClass, onclick)
            .Settings(settings =>
            {
                settings.ChangeType(ButtonTypes.RadioBox)
                    .Group(group, Component.Name)
                    .States(s => { states.Invoke(s); });
            });
            if (!string.IsNullOrEmpty(toolTip))
                pushButton.ToolTip(toolTip);
            if (onNormalized != null)
                onNormalized.Invoke(pushButton.Component.Id);
            return this;
        }


        public RichTextBoxToolbarBuilder AddColorPicker(string cssClass,string onselect)
        {
            var builder = ButtonFactory.AddButton("")
                     .Icons(cssClass);

                      string id = builder.Component.Id;
            string colorId = id + "_foreColorPicker";

            builder.Settings(settings =>
                     {
                         settings.ChangeType(ButtonTypes.LinkButton)
                         .Options(opts =>
                         {
                             opts.OnCommand = onselect; //"$(\"#" + Component.EditBox.Id + "\").richtextbox(\"runCmd\",\"forecolor\",cmd);";
                         })
                         .ShowSplitButton("$('#" + colorId + "').dropdownable('open');");
                     });

           
            
            builder.Component.AfterComponentRender += new ViewComponentRenderDelegate((writer) =>
            {
                Helper.Dna().ColorPicker(colorId).Render();
                var scripts = new DNA.Mvc.jQuery.jQueryScriptBuilder("#" + colorId, "dropdownable");

                scripts.AddOption("target", "#"+id, true)
                    .AddFunctionOption("closed", "var _val=$(\"#"+colorId+"\").colorpicker(\"option\",\"value\"); $(\"#"+
                   id+"\").find(\".d-button-primary-icon\"). css({\"margin\":\"0px\",\"border-bottom\":\"3px solid \"+_val}); $(\"#"+id
                   +"\").buttonex(\"option\",\"cmd\",_val);$(\"#"+id+"\").click();");

                Helper.RegisterStartupScript(scripts.ToString());
            });

            return this;
        }

        public RichTextBoxToolbarBuilder AddCombo(Action<ComboBoxBuilder> combo)
        {
            return this.AddCombo(combo, null);
        }

        public RichTextBoxToolbarBuilder AddCombo(Action<ComboBoxBuilder> combo, Action<string> onNormalized)
        {
            if (combo != null)
            {
                var comboBuilder = ButtonFactory.AddCombo();
                combo.Invoke(comboBuilder);
                if (onNormalized != null)

                    onNormalized.Invoke(comboBuilder.Component.Id);
            }
            return this;
        }

        public RichTextBoxToolbarBuilder AddCombo(Enum _enum, string onselection)
        {
            ButtonFactory.AddCombo()
                .Options(opts => { opts.OnItemSelected = onselection; })
                .Bind(_enum);
            return this;
        }

        public RichTextBoxToolbarBuilder AddCombo<T>(IEnumerable<T> collection, string onselection)
            where T : NavigableView
        {
            ButtonFactory.AddCombo()
                .Options(opts => { opts.OnItemSelected = onselection; })
                .Bind<T>(collection);
            return this;
        }

        public RichTextBoxToolbarBuilder AddCombo<T>(IEnumerable<T> collection, string onselection, string dataTextField, string dataValueField)
        {
            ButtonFactory.AddCombo()
       .Options(opts => { opts.OnItemSelected = onselection; })
       .Bind<T>(collection, dataTextField, dataValueField);
            return this;
        }

        public RichTextBoxToolbarBuilder AddSeparator()
        {
            ButtonFactory.AddSpliter();
            return this;
        }


    }
}
