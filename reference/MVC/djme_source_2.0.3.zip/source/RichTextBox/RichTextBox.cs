﻿//  Copyright (c) 2011 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.UI;

namespace DNA.Mvc.jQuery
{
    public class RichTextBox : ContainerViewComponent<RichTextBoxToolPane>
    {
        public IList<RichTextBoxToolPane> Panes
        {
            set { InnerItems = value; }
            get { return InnerItems; }
        }
        private bool allowEditSource = true;

        public bool AllowEditSource
        {
            get { return allowEditSource; }
            set { allowEditSource = value; }
        }

        public Action StatusBar { get; set; }

        private StringBuilder onNormalized = new StringBuilder();

        internal StringBuilder OnNormalized
        {
            get { return onNormalized; }
        }

        public override string TagName
        {
            get
            {
                return "textarea";
            }
        }

        protected override void OnItemAdded(RichTextBoxToolPane item)
        {
            item.Parent = this;
            base.OnItemAdded(item);
        }

        public override void RenderBeginTag(HtmlTextWriter writer)
        {
            var attrs = new Dictionary<string, object>();
            MergeAttribute("class", "d-rte", true);


            foreach (var key in HtmlAttributes.Keys)
            {
                if (key.Equals("id", StringComparison.OrdinalIgnoreCase) || key.Equals("name", StringComparison.OrdinalIgnoreCase)) continue;
                attrs.Add(key, HtmlAttributes[key]);
            }

            if (Width > 0)
            {
                if (attrs.ContainsKey("style"))
                    attrs["style"] = attrs["style"].ToString() + "width:" + Width.ToString() + "px";
                else
                    attrs.Add("style", "width:" + Width.ToString() + "px;");
            }

            attrs.Add("id", Id + "_container");
            this.RenderBeginTagToWriter(writer, "div", attrs);

            //if (Height > 0)
            //    MergeAttribute("style", "height:" + Height.ToString() + "px;");


            //ToolPane
            this.RenderBeginTagToWriter(writer, "div", new { @class = "d-rte-toolpanes" });
            writer.WriteBeginTag("ul");
            writer.WriteAttribute("id", Id + "_panes");
            writer.Write(HtmlTextWriter.TagRightChar);

            foreach (var pane in Panes)
                pane.Render(writer);

            writer.WriteEndTag("ul");
            writer.WriteEndTag("div");

            this.RenderBeginTagToWriter(writer, "div", new { @class = "d-rte-editor" ,style=Height>0 ? "height:"+Height.ToString()+"px;":"height:200px;"});
            this.RenderBeginTagToWriter(writer, TagName, new { id = Id, name = Name });
        }

        public override void RenderEndTag(HtmlTextWriter writer)
        {
            base.RenderEndTag(writer);
            writer.WriteEndTag("div");

            this.RenderBeginTagToWriter(writer, "div", new { @class = "d-rte-statusbar" });
            if (this.StatusBar != null)
                this.StatusBar.Invoke();
            writer.WriteEndTag("div");
            writer.WriteEndTag("div");
        }

        private void RenderBeginTagToWriter(HtmlTextWriter writer, string tagName, object htmlAttributes)
        {
            writer.WriteBeginTag(tagName);
            if (htmlAttributes != null)
                this.RenderHtmlAttributesToWriter(writer, ObjectHelper.ConvertObjectToDictionary(htmlAttributes));
            writer.Write(HtmlTextWriter.TagRightChar);
        }

        private void RenderHtmlAttributesToWriter(HtmlTextWriter writer)
        {
            this.RenderHtmlAttributesToWriter(writer, HtmlAttributes);
        }

        private void RenderHtmlAttributesToWriter(HtmlTextWriter writer, IDictionary<string, object> htmlAttributes)
        {
            if (htmlAttributes != null)
            {
                foreach (var key in htmlAttributes.Keys)
                {
                    if (!string.IsNullOrEmpty(htmlAttributes[key] as string))
                    {
                        if (htmlAttributes[key] is bool)
                            writer.WriteAttribute(key, htmlAttributes[key].ToString().ToLower());
                        else
                            writer.WriteAttribute(key, htmlAttributes[key].ToString());
                    }
                }
            }
        }

        public override void RenderContent(HtmlTextWriter writer) { }
    }
}
