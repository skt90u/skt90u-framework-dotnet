﻿//  Copyright (c) 2011 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Mvc;
using System.Web.UI;

namespace DNA.Mvc.jQuery
{
    public class RichTextBoxBuilder : jQueryComponentBuilder<RichTextBoxOptions, RichTextBox, RichTextBoxBuilder>
    {
        public RichTextBoxBuilder(RichTextBox rte, AjaxHelper helper)
            : base(rte, helper)
        {
            ToolPanes(panes =>
            {
                panes.Add().AddFontTools();
                panes.Add().AddParagraphTools().AddFormatTools().AddClipboardTools();
            });
        }
        //private bool showStatusbar = true;
        private bool resizable = false;

        //public bool ShowStatusbar
        //{
        //    get { return showStatusbar; }
        //    set { showStatusbar = value; }
        //}

        protected override string jQueryPluginName
        {
            get { return "richtextbox"; }
        }

        public RichTextBoxBuilder HtmlValue(Action value)
        {
            Component.BeforeContentRender += new ViewComponentRenderDelegate((writer) =>
            {
                value.Invoke();
            });
            return this;
        }

        public RichTextBoxBuilder ToolPanes(Action<RichTextBoxPaneFactory> panes)
        {
            var factory = new RichTextBoxPaneFactory(this.Component, Helper);
            panes.Invoke(factory);
            return this;
        }

        public RichTextBoxBuilder Resizable()
        {
            resizable = true;
            return this;
        }

        public RichTextBoxBuilder AllowHTMLEditing(bool value)
        {
            Component.AllowEditSource = value;
            return this;
        }

        public override void Render()
        {
            if (Component.OnNormalized.Length > 0)
                this.Options(opts =>
                {
                    opts.OnDOMNodeNormalized += Component.OnNormalized;
                });

            if (Component.AllowEditSource)
            {
                Component.StatusBar = new Action(() =>
                {
                    Helper.Dna().Button(Component.Id + "_toggleButton")
                        .Click(jQuerySelector + ".richtextbox(\"toggleview\");")
                        .Icons("d-rte-icon d-rte-design")
                        .States(states =>
                        {
                            states.Add("Design")

                                .Icons("d-rte-icon d-rte-design");

                            states.Add("HTML").Select(true)
                                .Icons("d-rte-icon d-rte-html");
                        })
                        .Render();
                });
            }

            //Component.Panes.Count>0

            base.Render();

            // Helper.RegisterStartupScript(jQuerySelector+".richtextbox(\"resize\");");

            if (resizable)
                Helper.Resizable("#" + Component.Id + "_container", new ResizableOptions()
                {
                    AlsoResize = "#" + Component.Id + "_container .d-rte-editor",
                    OnResize = this.jQuerySelector + ".richtextbox(\"resize\");"
                });

            //if (Component.Panes.Count >1)
            //{
                Helper.Sortable("#" + Component.Id + "_panes>li", new SortableOptions()
                {
                    DragHandler = ".d-toolbar-draghandler",
                    ConnectWith = "#" + Component.Id + "_panes>li",
                    DragHelper = Helpers.Clone,
                    ForceHelperSize = true,
                    ForcePlaceholderSize = true,
                    PlaceHolderCssClass = "ui-widget-placeholder"
                });

                Helper.Droppable("#" + Component.Id + "_panes>li", new DroppableOptions()
                {
                    Accept = ".d-toolbar",
                    ActiveCssClass = "ui-state-default",
                    HoverCssClass = "ui-state-highlight"
                });
            //}
        }
    }
}
