﻿//  Copyright (c) 2011 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DNA.Mvc.jQuery
{
    public class RichTextBoxToolPane:ContainerViewComponent<RichTextBoxToolbar>
    {
        private RichTextBox parent;

        public RichTextBox Parent
        {
            get { return parent; }
            internal set { parent = value; }
        }

        public IList<RichTextBoxToolbar> Tools 
        {
            get { return this.InnerItems; }
            set { this.InnerItems = value; }
        }

        protected override void OnItemAdded(RichTextBoxToolbar item)
        {
            item.EditBox = this.parent;
            item.Pane = this;
            base.OnItemAdded(item);
        }

        public override string TagName
        {
            get
            {
                return "li";
            }
        }

        public override void RenderBeginTag(System.Web.UI.HtmlTextWriter writer)
        {
            MergeAttribute("class", "d-rte-pane", true);
            base.RenderBeginTag(writer);
        }

        public override void RenderContent(System.Web.UI.HtmlTextWriter writer)
        {
            foreach (var toolbar in Tools)
            {
                toolbar.Render(writer);
            }
        }
    }
}
