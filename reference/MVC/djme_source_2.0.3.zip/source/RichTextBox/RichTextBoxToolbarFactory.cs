﻿//  Copyright (c) 2011 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Mvc;

namespace DNA.Mvc.jQuery
{
    public class RichTextBoxToolbarFactory : ViewComponentBuilderFactory<RichTextBoxToolbar>
    {
        public RichTextBoxToolbarFactory(RichTextBoxToolPane container, AjaxHelper helper) : base(container, helper) { }

        public RichTextBoxToolbarBuilder Add()
        {
            var pane = new RichTextBoxToolbar();
            pane.ShowDragHandler=true;
            Container.Items.Add(pane);
            Container.OnItemAdded(pane);
            var builder = new RichTextBoxToolbarBuilder(pane, Helper).GenerateId().Name(pane.EditBox.Name+"_"+pane.Name);
            return builder;
        }

        public void Clear()
        {
            Container.Items.Clear();
        }
    }
}
