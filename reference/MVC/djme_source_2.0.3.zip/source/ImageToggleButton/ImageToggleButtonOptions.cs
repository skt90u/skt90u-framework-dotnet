﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Mvc;

namespace DNA.Mvc.jQuery
{
    /// <summary>
    /// Defines the properties of the ImageToggleButton options.
    /// </summary>
    public class ImageToggleButtonOptions
    {
        /// <summary>
        /// Gets/Sets the link css class.
        /// </summary>
        public string CssClass { get; set; }
        
        /// <summary>
        /// Gets/Sets the style text of the 
        /// </summary>
        public string StyleText { get; set; }

        /// <summary>
        /// Gets/Sets the css style name of the Text.
        /// </summary>
        public string TextCssClass { get; set; }

        /// <summary>
        /// Gets/Sets the css style text of the Text element.
        /// </summary>
        public string TextStyleText { get; set; }

        /// <summary>
        /// Gets/Sets the image css class.
        /// </summary>
        public string ImageCssClass { get; set; }
        
        /// <summary>
        /// Gets/Sets the image style text.
        /// </summary>
        public string ImageStyleText { get; set; }
        
        /// <summary>
        /// Gets/Sets the image url.
        /// </summary>
        public string ImageUrl { get; set; }
        
        /// <summary>
        /// Gets/Sets the text of the button.
        /// </summary>
        public string Text { get; set; }
        
        /// <summary>
        /// Gets/Sets the first client click scripts
        /// </summary>
        public string OnClientClick { get; set; }
        
        /// <summary>
        /// Gets/Sets the toggle image url.after the OnClientClick execute this image will be display.
        /// </summary>
        public string ToggleImageUrl { get; set; }

        /// <summary>
        /// Gets/Sets the toggle text of the button.After the OnClientClick executed this text will be display.
        /// </summary>
        public string ToggleText { get; set; }

        /// <summary>
        /// Gets/Sets the toggle client click scripts.
        /// </summary>
        public string OnClientToggleClick { get; set; }
    }
}
