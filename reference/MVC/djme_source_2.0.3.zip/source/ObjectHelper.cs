﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System.Collections.Generic;
using System.Reflection;
using System;

namespace DNA.Mvc
{
    /// <summary>
    /// The ObjectHelper use to convert the object instance 's properties into a IDictionary object.
    /// </summary>
    public static class ObjectHelper
    {
        /// <summary>
        /// Convert to unknow type object's property names and values into a Dictionary object.
        /// </summary>
        /// <param name="data">The object to be converted.</param>
        /// <returns>A Dictionary object contains the converted object's property names and values.</returns>
        public static IDictionary<string, object> ConvertObjectToDictionary(object data)
        {
            if (data is IDictionary<string,object>)
                return data as IDictionary<string, object>;

            var attr = BindingFlags.Public | BindingFlags.Instance;
            var dict = new Dictionary<string, object>();
            foreach (var property in data.GetType().GetProperties(attr))
            {
                if (property.CanRead)
                {
                    dict.Add(property.Name, property.GetValue(data, null));
                }
            }
            return dict;
        }
    }
}
