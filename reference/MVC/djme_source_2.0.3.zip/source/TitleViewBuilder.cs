﻿//  Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using DNA.Mvc.jQuery;
using System.Text;

namespace DNA.Mvc.jQuery
{
    public class TitleViewBuilder : ViewComponentBuilder<TitleView, TitleViewBuilder>
    {
        public TitleViewBuilder(TitleView component, AjaxHelper helper) : base(component, helper) { }

        public TitleViewBuilder Template(Action value)
        {
            this.Component.Template = value;
            return this;
        }
    }

    public class TitleViewFactory : ViewComponentBuilderFactory<TitleView>
    {
        public TitleViewFactory(IComponentItemContainer<TitleView> container, AjaxHelper helper) : base(container, helper) { }

        public TitleViewBuilder Add(string title)
        {
            var item = new TitleView() { Title = title };
            Container.Items.Add(item);
            Container.OnItemAdded(item);
            return new TitleViewBuilder(item, Helper);
        }
    }
}
