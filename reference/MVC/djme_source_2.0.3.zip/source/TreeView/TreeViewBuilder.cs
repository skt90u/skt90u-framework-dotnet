﻿//  Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Mvc;
using System.Web;
using System.Web.UI;
using System.Xml;

namespace DNA.Mvc.jQuery
{
    public class TreeViewBuilder : jQueryDataBindableComponentBuilder<TreeOptions,TreeView, TreeNode, TreeNodeFactory, TreeViewBuilder>
    {
        private string _key;
        private string _val;
        private string _url;
        private Action _jQueryTmpl;
        private string _httpMethod = "POST";

        protected override string jQueryPluginName
        {
            get { return "dtree"; }
        }

        public TreeViewBuilder(TreeView treeview, AjaxHelper helper) : base(treeview, helper) { }

        protected override TreeNodeFactory CreateNodeItemFactory()
        {
            return new TreeNodeFactory(Component, Helper) { NodeContainer = Component };
        }

        protected override HierarchialBindingFactory<TreeNode, TreeView> CreateBindingFactory()
        {
            return new HierarchialBindingFactory<TreeNode, TreeView>(Component, (item) =>
            {
                return new TreeNode(item) { Container = this.Component };
            });
        }
        
        private void EnsureOptions() {
            if (options == null)
                options = new TreeOptions();
        }

        public TreeViewBuilder DragAndDrop(bool enableDragAndDrop)
        {
            return this.DragAndDrop(enableDragAndDrop, string.Empty);
        }

        public TreeViewBuilder SinglePathExpand(bool selectSingle)
        {
            EnsureOptions();
            options.SinglePathExpand = selectSingle;
            return this;
        }

        public TreeViewBuilder DragAndDrop(bool enableDragAndDrop,string dropTargets)
        {
            EnsureOptions();
            options.EnableDropAndDrag = enableDragAndDrop;
            if (!string.IsNullOrEmpty(dropTargets))
                options.DropTargets = dropTargets;
            return this;
        }

        public TreeViewBuilder ShowCheckboxs(bool checkboxs)
        {
            EnsureOptions();
            options.AllowCheckNodes=checkboxs;
            return this;
        }

        public TreeViewBuilder ClientBind(string url)
        {
            return this.ClientBind(url, _httpMethod);
        }

        public TreeViewBuilder ClientBind(string url,string httpMethod)
        {
            _httpMethod = httpMethod;
            Options(opts => {
                opts.OnNodePopulate = (new StringBuilder())
                                           .Append("var $n = $(node);")
                                           .Append("$n.addClass(\"d-treenode-loading\");")
                                           .Append("var url = $(\">.d-treenode-content\", $n).find(\".d-treenode-value\").val();")
                                           .Append("$(\"#"+Component.Id+"\").dtree(\"loadNodes\", url, \""+_httpMethod+"\", {}, $n);")
                                           .Append("$n.removeClass(\"d-treenode-hasChildren\");")
                                           .ToString();
                opts.OnNodeLoaded = "if (node) {$(node).removeClass(\"d-treenode-loading\");}";
            });
            return this.ClientBind(url,_httpMethod,()=>{
                using (var writer = new HtmlTextWriter(Helper.ViewContext.Writer))
                { 
                    writer.WriteBeginTag("li");
                    writer.Write(" {{if Value}} class=\"d-treenode-hasChildren\" {{/if}} ");
                    writer.WriteAttribute("class","d-treenode-hasChildren");
                    writer.Write(HtmlTextWriter.TagRightChar);
                    writer.WriteBeginTag("a");
                    writer.WriteAttribute("href","${NavigateUrl}");
                    writer.WriteAttribute("title", "${ToolTip}");
                    writer.Write(" {{if Target}} target=\"${Target}\" {{/if}}");
                    writer.Write(HtmlTextWriter.TagRightChar);
                    writer.Write(" {{if ImageUrl}} ");
                    writer.WriteBeginTag("img");
                    writer.WriteAttribute("src","${ImageUrl}");
                    writer.WriteAttribute("class","d-treenode-img");
                    writer.WriteAttribute("alt","${Text}");
                    writer.Write(HtmlTextWriter.SelfClosingTagEnd);
                    writer.Write(" {{/if}}");
                    writer.Write("{{if Value}} <input type=\"hidden\" class=\"d-treenode-value\" value=\"${Value}\" /> {{/if}}");
                    writer.WriteBeginTag("span");
                    writer.WriteAttribute("class", "d-treenode-text");
                    writer.Write(HtmlTextWriter.TagRightChar);
                    writer.Write("${Text}");
                    writer.WriteEndTag("span");
                    writer.WriteEndTag("a");
                    writer.WriteEndTag("li");
                }
            });
        }

        public TreeViewBuilder ClientBind(string url, Action clientTemplate)
        {
            return this.ClientBind(url, null, clientTemplate);
        }

        public TreeViewBuilder ClientBind(string url,string httpMethod, Action clientTemplate)
        {
            _url = url;
            if (!string.IsNullOrEmpty(httpMethod))
            _httpMethod = httpMethod;
            _jQueryTmpl = clientTemplate;
            return this;
        }

        public TreeViewBuilder ExpandedLevel(int level)
        {
            Component.ExpandedLevel = level;
            return this;
        }

        public TreeViewBuilder SelectNode(string key, string value)
        {
            _key = key;
            _val = value;
            return this;
        }

        protected void RenderClientTemplate(HtmlTextWriter writer)
        {
            writer.WriteBeginTag("script");
            writer.WriteAttribute("id", Component.Id + "_tmpl");
            writer.WriteAttribute("type", "text/x-jquery-tmpl");
            writer.Write(HtmlTextWriter.TagRightChar);
            _jQueryTmpl.Invoke();
            writer.WriteEndTag("script");
        }

        //private bool XmlMapper(XmlNode xmlNode, HierarchicalNode node)
        //{
        //    for (int i = 0; i < xmlNode.Attributes.Count; i++)
        //    {
        //        //attrs.Item()
        //        var attr = xmlNode.Attributes[i];
        //        if (attr.LocalName.Equals("Title", StringComparison.OrdinalIgnoreCase)) { node.Title = attr.Value; continue; }
        //        if (attr.LocalName.Equals("Target", StringComparison.OrdinalIgnoreCase)) { node.Target = attr.Value; continue; }
        //        if (attr.LocalName.Equals("Description", StringComparison.OrdinalIgnoreCase)) { node.Description = attr.Value; continue; }
        //        if (attr.LocalName.Equals("ResourceKey", StringComparison.OrdinalIgnoreCase)) { node.ResourceKey = attr.Value; continue; }
                
        //        //if (attr.LocalName.Equals("ResourceKey", StringComparison.OrdinalIgnoreCase)) { node. = attr.Value; continue; }

        //        if (attr.LocalName.Equals("NavigateUrl", StringComparison.OrdinalIgnoreCase))
        //        {
        //            node.NavigateUrl = attr.Value;
        //            if (VirtualPathUtility.IsAppRelative(node.NavigateUrl))
        //                node.NavigateUrl = VirtualPathUtility.ToAbsolute(node.NavigateUrl);
        //            continue;
        //        }

        //        if (attr.LocalName.Equals("ImageUrl", StringComparison.OrdinalIgnoreCase))
        //        {
        //            node.ImageUrl = attr.Value;
        //            if (VirtualPathUtility.IsAppRelative(node.ImageUrl))
        //                node.ImageUrl = VirtualPathUtility.ToAbsolute(node.ImageUrl);
        //            continue;
        //        }
        //        if (attr.LocalName.Equals("Key", StringComparison.OrdinalIgnoreCase)) { node.Key = attr.Value; continue; }
        //        node.Attributes.Add(attr.LocalName, attr.Value);
        //    }


        //    if (string.IsNullOrEmpty(node.Target))
        //    {
        //        if ((xmlNode.ParentNode != null) && (xmlNode.ParentNode.Attributes != null))
        //        {
        //            if (xmlNode.ParentNode.Attributes["target"] != null)
        //                g_target = xmlNode.ParentNode.Attributes["target"].Value;
        //        }
        //        node.Target = g_target;
        //    }

        //    if (string.IsNullOrEmpty(node.ImageUrl))
        //    { 

        //    }
        //    node.Item = node.Attributes;
        //    return true;
        //}
        string g_target = "";

        public override void Render()
        {
            if ((!string.IsNullOrEmpty(_url)) && (_jQueryTmpl != null))
            {
                using (var writer = new HtmlTextWriter(Helper.ViewContext.Writer))
                {
                    var firstLoad = new StringBuilder();
                    firstLoad.Append(jQuerySelector + ".dtree(\"loadNodes\",\"")
                        .Append(_url)
                        .Append("\",\"")
                        .Append(_httpMethod)
                        .Append("\",{});");

                    Options(opts => {
                        opts.NodeTemplate = Component.Id + "_tmpl";
                    });

                    Component.Render(writer);
                    RenderClientTemplate(writer);
                   
                    Helper.jQuery(Component.Name, jQueryPluginName, options);
                    Helper.RegisterStartupScript(firstLoad.ToString());
                }
            }
            else
                base.Render();
        }
    }

}
