﻿//  Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Mvc;
using System.Web;
using System.Web.UI;
using System.Xml;

namespace DNA.Mvc.jQuery
{
    public class TreeNodeBuilder : NodeItemBuilder<TreeView, TreeNode, TreeNodeFactory, TreeNodeBuilder>
    {
        public TreeNodeBuilder(TreeNode node, AjaxHelper helper) : base(node, helper) { }

        protected override TreeNodeFactory CreateFactory()
        {
            return new TreeNodeFactory(this.Component, Helper);
        }

        public TreeNodeBuilder Expanded(bool expanded)
        {
            Component.Expanded = expanded;
            return this;
        }
    }
}
