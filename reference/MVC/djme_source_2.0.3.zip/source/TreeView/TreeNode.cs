﻿//  Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Mvc;
using System.Web;
using System.Web.UI;
using System.Xml;

namespace DNA.Mvc.jQuery
{
    public class TreeNode : NodeBase<TreeView, TreeNode>, ISelectable
    {
        private bool expanded = true;
        private bool _checked = false;
        private bool selected = false;
        private bool enabled = true;

        public TreeNode() { }

        public TreeNode(INavigtable node)
            : base(node)
        {
            if (node.Value != null)
            {
                //Binding to the XmlNode 
                ///Refactory:This code is not so smart!
                #region Xml Node binding

                if (node.Value is XmlNode)
                {
                    var _node = (XmlNode)node.Value;
                    if (_node.Attributes != null)
                    {
                        for (int i = 0; i < _node.Attributes.Count; i++)
                        {
                            //attrs.Item()
                            var attr = _node.Attributes[i];
                            if (attr.LocalName.Equals("Title", StringComparison.OrdinalIgnoreCase)) continue;
                            if (attr.LocalName.Equals("Target", StringComparison.OrdinalIgnoreCase)) continue;
                            if (attr.LocalName.Equals("Description", StringComparison.OrdinalIgnoreCase)) continue;
                            if (attr.LocalName.Equals("NavigateUrl", StringComparison.OrdinalIgnoreCase)) continue;
                            if (attr.LocalName.Equals("ImageUrl", StringComparison.OrdinalIgnoreCase)) continue;

                            if (attr.LocalName.Equals("Selected", StringComparison.OrdinalIgnoreCase))
                            {
                                bool.TryParse(attr.Value, out this.selected);
                                continue;
                            }

                            if (attr.LocalName.Equals("Checked", StringComparison.OrdinalIgnoreCase))
                            {
                                bool.TryParse(attr.Value, out this._checked);
                                continue;
                            }

                            if (attr.LocalName.Equals("Expanded", StringComparison.OrdinalIgnoreCase))
                            {
                                bool.TryParse(attr.Value, out this.expanded);
                                continue;
                            }

                            if (attr.LocalName.Equals("Enabled", StringComparison.OrdinalIgnoreCase))
                            {
                                bool.TryParse(attr.Value, out this.enabled);
                                continue;
                            }
                            this.MergeAttribute(attr.LocalName.ToLower(), attr.Value);
                        }
                    }
                }
                #endregion
            }
        }

        public bool Enabled
        {
            get { return enabled; }
            set { enabled = value; }
        }

        public bool Selected
        {
            get { return selected; }
            set { selected = value; }
        }

        public bool Checked
        {
            get { return _checked; }
            set { _checked = value; }
        }

        public bool Expanded
        {
            get { return expanded; }
            set { expanded = value; }
        }

        protected override string NodeContainerCssClass
        {
            get
            {
                return "";
            }
        }

        public override void RenderBeginTag(HtmlTextWriter writer)
        {
            var classes = new List<string>();

            if (selected)
                classes.Add("d-treenode-selected");

            if ((Children.Count > 0) && expanded)
            {
                if (Container.ExpandedLevel > -1)
                {
                    if (this.Level < Container.ExpandedLevel)
                        classes.Add("d-treenode-expanded");
                    else
                        classes.Add("d-treenode-collapsed");
                }
                else
                    classes.Add("d-treenode-expanded");
            }

            if ((Children.Count > 0) && (expanded == false))
                classes.Add("d-treenode-collapsed");

            if (!enabled)
                classes.Add("d-treenode-disabled");

            //if (Container.ExpandedLevel)

            if (classes.Count > 0)
                this.MergeAttribute("class", string.Join(" ", classes.ToArray()));
           // if (!string.IsNullOrEmpty(this.ToolTip))
              //  this.MergeAttribute("title",this.ToolTip);
            base.RenderBeginTag(writer);
        }

        public override void RenderNodeContent(HtmlTextWriter writer)
        {
            var builder = new NodeUIBuilder();

            if ((!string.IsNullOrEmpty(this.NavigateUrl) && this.Enabled))
                builder.WriteBeginLink(this, new { @class = "d-treenode-link" });

            if (!string.IsNullOrEmpty(this.ImageUrl))
                builder.WriteImage(this, new { @class = "d-treenode-img" });

            builder.WriteTitle(this, new { @class = "d-treenode-text" });

            if ((!string.IsNullOrEmpty(this.NavigateUrl) && this.Enabled))
                builder.WriteEndTag("a");

            writer.Write(builder.ToString());
        }
    }
}
