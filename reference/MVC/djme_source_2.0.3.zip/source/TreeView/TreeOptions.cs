﻿//  Copyright (c) 2011 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DNA.Mvc.jQuery
{
    public class TreeOptions
    {
        private jQueryEffects hideEffect = jQueryEffects.Blind;
        private jQueryEffects showEffect = jQueryEffects.Blind;

        [jQueryOption("nodeTemplate")]
        public string NodeTemplate { get; set; }

        [jQueryOption("enableDropAndDrag")]
        public bool? EnableDropAndDrag { get; set; }

        [jQueryOption("singlePathExpand")]
        public bool? SinglePathExpand { get; set; }

        [jQueryOption("checkboxes")]
        public bool? AllowCheckNodes { get; set; }

        [jQueryOption("nodeClass")]
        public string NodeCssClass { get; set; }

        [jQueryOption("selectedClass")]
        public string NodeSelectedCssClass { get; set; }

        [jQueryOption("hoverClass")]
        public string NodeHoverCssClass { get; set; }

        [jQueryOption("disableClass")]
        public string NodeDisableCssClass { get; set; }

        [jQueryOption("duration")]
        public int? Duration { get; set; }

        [jQueryOption("hideEffect")]
        public jQueryEffects HideEffect { get { return hideEffect; } set { hideEffect = value; } }

        [jQueryOption("showEffect")]
        public jQueryEffects ShowEffect { get { return showEffect; } set { showEffect = value; } }

        [jQueryOption("dropTargets")]
        public string DropTargets { get; set; }

        [jQueryOption("drag", ValueType = JavaScriptTypes.Function, FunctionParams = new string[] { "event", "node" })]
        public string OnNodeDragged { get; set; }

        [jQueryOption("dragstart", ValueType = JavaScriptTypes.Function, FunctionParams = new string[] { "event", "node" })]
        public string OnNodeDragStart { get; set; }

        [jQueryOption("dragstop", ValueType = JavaScriptTypes.Function, FunctionParams = new string[] { "event", "node" })]
        public string OnNodeDragStop { get; set; }

        [jQueryOption("dropped", ValueType = JavaScriptTypes.Function, FunctionParams = new string[] { "event", "ui" })]
        public string OnNodeDropped { get; set; }

        [jQueryOption("dropout", ValueType = JavaScriptTypes.Function, FunctionParams = new string[] { "event", "ui" })]
        public string OnNodeDropOut { get; set; }

        [jQueryOption("dropover", ValueType = JavaScriptTypes.Function, FunctionParams = new string[] { "event", "ui" })]
        public string OnNodeDropOver { get; set; }

        [jQueryOption("selected", ValueType = JavaScriptTypes.Function, FunctionParams = new string[] { "event", "node" })]
        public string OnNodeSelected { get; set; }

        [jQueryOption("checked", ValueType = JavaScriptTypes.Function, FunctionParams = new string[] { "event", "ui" })]
        public string OnNodeChecked { get; set; }

        [jQueryOption("collapsed", ValueType = JavaScriptTypes.Function, FunctionParams = new string[] { "event", "ui" })]
        public string OnNodeCollapsed { get; set; }

        [jQueryOption("expanded", ValueType = JavaScriptTypes.Function, FunctionParams = new string[] { "event", "ui" })]
        public string OnNodeExpanded { get; set; }

        [jQueryOption("popupNodes", ValueType = JavaScriptTypes.Function, FunctionParams = new string[] { "event", "node" })]
        public string OnNodePopulate { get; set; }

        [jQueryOption("nodeLoaded", ValueType = JavaScriptTypes.Function, FunctionParams = new string[] { "event", "node" })]
        public string OnNodeLoaded { get; set; }

        [jQueryOption("nodeLoadError", ValueType = JavaScriptTypes.Function, FunctionParams = new string[] { "event", "ui" })]
        public string OnLoadNodeError { get; set; }

    }
}
