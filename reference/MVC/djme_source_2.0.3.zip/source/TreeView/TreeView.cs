﻿//  Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Mvc;
using System.Web;
using System.Web.UI;
using System.Xml;


namespace DNA.Mvc.jQuery
{
    public class TreeView : DataBindableComponent<TreeNode>
    {
        public List<TreeNode> Nodes
        {
            get { return InnerItems.Select(item => { return (TreeNode)item; }).ToList(); }
            set { InnerItems = value; }
        }

        private int expandLevel = -1;

        [jQueryIgnore]
        public int ExpandedLevel
        {
            get { return expandLevel; }
            set { expandLevel = value; }
        }
        public override string TagName
        {
            get
            {
                return "ul";
            }
        }
    }
}
