﻿//  Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Mvc;
using System.Web;
using System.Web.UI;
using System.Xml;

namespace DNA.Mvc.jQuery
{
    public class TreeNodeFactory : NodeItemFactory<TreeView, TreeNode, TreeNodeBuilder, TreeNodeFactory>
    {
        public TreeNodeFactory(IComponentItemContainer<TreeNode> node, AjaxHelper helper) : base(node, helper) { }

        protected override TreeNode CreateNodeInstance()
        {
            return new TreeNode();
        }

        protected override TreeNode CreateNodeInstance(INavigtable node)
        {
            return new TreeNode(node);
        }

        protected override TreeNodeBuilder CreateBuilder(TreeNode node)
        {
            return new TreeNodeBuilder(node, Helper);
        }
    }
}
