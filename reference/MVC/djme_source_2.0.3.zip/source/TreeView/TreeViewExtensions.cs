﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Mvc;

namespace DNA.Mvc.jQuery
{
    /// <summary>
    /// Provides the helper methods to build the html elements and treeview jQuery script.
    /// </summary>
    public static class TreeViewExtensions
    {
        /// <summary>
        /// Genernate the html elemens and jQuery script for treeview plugin
        /// </summary>
        /// <param name="helper">The ajax helper object</param>
        /// <param name="name">Specified the name of treeview</param>
        /// <param name="nodes">Specified the treeivew root nodes</param>
        /// <returns>the html elements for treeivew</returns>
        public static MvcHtmlString TreeView(this AjaxHelper helper, string name, IEnumerable<HierarchicalNode> nodes)
        {
            return helper.TreeView(name, nodes, null, null);
        }

        /// <summary>
        /// Genernate the html elemens and jQuery script for treeview plugin
        /// </summary>
        /// <param name="helper">The ajax helper object</param>
        /// <param name="name">Specified the name of treeview</param>
        /// <param name="nodes">Specified the treeivew root nodes</param>
        /// <param name="options">The options for treeivew</param>
        /// <returns>the html elements for treeivew</returns>
        public static MvcHtmlString TreeView(this AjaxHelper helper, string name, IEnumerable<HierarchicalNode> nodes, TreeViewOptions options)
        {
            return helper.TreeView(name, nodes, options, null);
        }

        /// <summary>
        /// Genernate the html elemens and jQuery script for treeview plugin
        /// </summary>
        /// <param name="helper">The ajax helper object</param>
        /// <param name="name">Specified the name of treeview</param>
        /// <param name="nodes">Specified the treeivew root nodes</param>
        /// <param name="options">The options for treeivew</param>
        /// <param name="htmlAttributes"></param>
        /// <returns>the html elements for treeivew</returns>
        public static MvcHtmlString TreeView(this AjaxHelper helper, string name,IEnumerable<HierarchicalNode> nodes, TreeViewOptions options, object htmlAttributes)
        {
            TagBuilder treeview = new TagBuilder("div");
            treeview.Attributes.Add("id", name);
            if (htmlAttributes != null)
                treeview.MergeAttributes<string, object>(ObjectHelper.ConvertObjectToDictionary(htmlAttributes));
            treeview.AddCssClass("ui-helper-reset");
            TreeViewOptions opts = options == null ? new TreeViewOptions() : options;
            if (string.IsNullOrEmpty(opts.ApplyCssClassTo))
            {
                opts.ApplyCssClassTo = "span";
                opts.SelectedNodeCssClass = "ui-node-text-selected";
            }

            var builder = new HierarchicalNodeUIBuilder();
            builder.WriteNodesRecursiveWithAllAttributes(nodes);
            treeview.InnerHtml = builder.ToString();
            helper.jQuery("#" + name, "treeview", options);
            return MvcHtmlString.Create(treeview.ToString());
        }

        /// <summary>
        /// Genernate the html elemens and jQuery script for treeview plugin
        /// </summary>
        /// <param name="helper">The ajax helper object</param>
        /// <param name="name">Specified the name of treeview</param>
        /// <param name="root">Specified the treeivew root node which the treeview build from</param>
        /// <param name="options">The options for treeivew</param>
        /// <returns>the html elements for treeivew</returns>
        public static MvcHtmlString TreeView(this AjaxHelper helper, string name, HierarchicalNode root, TreeViewOptions options)
        {
            return helper.TreeView(name, root, options, null);
        }

        /// <summary>
        /// Genernate the html elemens and jQuery script for treeview plugin
        /// </summary>
        /// <param name="helper">The ajax helper object</param>
        /// <param name="name">Specified the name of treeview</param>
        /// <param name="root">Specified the treeivew root node which the treeview build from</param>
        /// <returns>the html elements for treeivew</returns>
        public static MvcHtmlString TreeView(this AjaxHelper helper, string name, HierarchicalNode root)
        {
            return helper.TreeView(name, root, null, null);
        }

        /// <summary>
        /// Genernate the html elemens and jQuery script for treeview plugin
        /// </summary>
        /// <param name="helper">The ajax helper object</param>
        /// <param name="name">Specified the name of treeview</param>
        /// <param name="root">Specified the treeivew root node which the treeview build from</param>
        /// <param name="options">The options for treeivew</param>
        /// <param name="htmlAttributes"></param>
        /// <returns>the html elements for treeivew</returns>
        public static MvcHtmlString TreeView(this AjaxHelper helper, string name,HierarchicalNode root, TreeViewOptions options, object htmlAttributes)
        {
            TagBuilder treeview = new TagBuilder("ul");
            treeview.Attributes.Add("id", name);
            if (htmlAttributes != null)
                treeview.MergeAttributes<string, object>(ObjectHelper.ConvertObjectToDictionary(htmlAttributes));
            treeview.AddCssClass("ui-helper-reset");
            TreeViewOptions opts = options == null ? new TreeViewOptions() : options;
            if (string.IsNullOrEmpty(opts.ApplyCssClassTo))
            {
                opts.ApplyCssClassTo = "span";
                opts.SelectedNodeCssClass = "ui-node-text-selected";
            }
            var builder = new HierarchicalNodeUIBuilder();
            builder.WriteNodeRecursiveWithAllAttributes(root);
            treeview.InnerHtml = builder.ToString();
            helper.jQuery("#" + name, "treeview", options);
            return MvcHtmlString.Create(treeview.ToString());
        }

        /// <summary>
        /// Genernate the html elemens and jQuery script for treeview plugin
        /// </summary>
        /// <param name="helper">The ajax helper object</param>
        /// <param name="name">Specified the name of treeview</param>
        /// <param name="provider">The provider use to get the node data that impletement the IHierarchicalNodeProvider</param>
        /// <param name="options">The options for treeivew</param>
        /// <returns>the html elements for treeivew</returns>
        public static MvcHtmlString TreeView(this AjaxHelper helper, string name, IHierarchicalNodeProvider provider, TreeViewOptions options)
        {
            return helper.TreeView(name, provider, options, null);
        }

        /// <summary>
        /// Genernate the html elemens and jQuery script for treeview plugin
        /// </summary>
        /// <param name="helper">The ajax helper object</param>
        /// <param name="name">Specified the name of treeview</param>
        /// <param name="provider">The provider use to get the node data that impletement the IHierarchicalNodeProvider</param>
        /// <returns>the html elements for treeivew</returns>
        public static MvcHtmlString TreeView(this AjaxHelper helper, string name, IHierarchicalNodeProvider provider)
        {
            return helper.TreeView(name, provider, null, null);
        }

        /// <summary>
        /// Genernate the html elemens and jQuery script for treeview plugin
        /// </summary>
        /// <param name="helper">The ajax helper object</param>
        /// <param name="name">Specified the name of treeview</param>
        /// <param name="provider">The provider use to get the node data that impletement the IHierarchicalNodeProvider</param>
        /// <param name="options">The options for treeivew</param>
        /// <param name="htmlAttributes"></param>
        /// <returns>the html elements for treeivew</returns>
        public static MvcHtmlString TreeView(this AjaxHelper helper, string name,IHierarchicalNodeProvider provider, TreeViewOptions options, object htmlAttributes)
        {
            return helper.TreeView(name, provider.RootNode, options, htmlAttributes);
        }

        public static MvcHtmlString TreeView(this AjaxHelper helper, string name, string action)
        {
            return helper.TreeView(name, action, string.Empty, null, null, null);
        }
        
        public static MvcHtmlString TreeView(this AjaxHelper helper, string name, string action, string controller)
        {
            return helper.TreeView(name, action, controller, null, null, null);
        }
        
        public static MvcHtmlString TreeView(this AjaxHelper helper, string name, string action, string controller, object routeData)
        {
            return helper.TreeView(name, action, controller, routeData, null, null);
        }

        public static MvcHtmlString TreeView(this AjaxHelper helper, string name, string action, string controller, object routeData, TreeViewOptions options)
        {
            return helper.TreeView(name, action, controller, routeData, options, null);
        }

        public static MvcHtmlString TreeView(this AjaxHelper helper, string name, string action, string controller, object routeData,TreeViewOptions options, object htmlAttributes)
        {
            TagBuilder treeview = new TagBuilder("div");
            treeview.Attributes.Add("id", name);
            if (htmlAttributes != null)
                treeview.MergeAttributes<string, object>(ObjectHelper.ConvertObjectToDictionary(htmlAttributes));
            treeview.AddCssClass("ui-helper-reset");
            TreeViewOptions opts = options == null ? new TreeViewOptions() : options;
            if (string.IsNullOrEmpty(opts.ApplyCssClassTo))
            {
                opts.ApplyCssClassTo = "span";
                opts.SelectedNodeCssClass = "ui-node-text-selected";
            }

            string defaultController = string.IsNullOrEmpty(controller) ? helper.ViewContext.RouteData.Values["controller"].ToString() : controller;
            UrlHelper Url = new UrlHelper(helper.ViewContext.RequestContext);
            options.DataSourceUrl = routeData == null ? Url.Action(action, defaultController) : Url.Action(action, defaultController, routeData);

            helper.jQuery("#" + name, "treeview", options);
            return MvcHtmlString.Create(treeview.ToString());
        }

    }
}
