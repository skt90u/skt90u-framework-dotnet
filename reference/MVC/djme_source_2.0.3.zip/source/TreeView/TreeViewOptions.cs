﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DNA.Mvc.jQuery
{
    /// <summary>
    /// Represents the options of the jQuery treeview plugin
    /// </summary>
    public class TreeViewOptions
    {
        private string baseImageUrl = "/content/images/treeview/";
        /// <summary>
        /// Gets/Sets the script that handling the event when the treenode is selected.
        /// </summary>
        /// <remarks>
        /// The node paramter is a treenode() plugin object.
        /// </remarks>
        [jQueryOption("select", ValueType = JavaScriptTypes.Function, FunctionParams = new string[] { "event", "node" })]
        public string OnNodeSelected { get; set; }

        /// <summary>
        /// Gets/Sets the script that handling the event when the treenode is dropped.
        /// </summary>
        /// <remarks>
        /// In order to trigger this event the EnableDragAndDrop must be set to ture.
        /// The ui object has two object property
        ///  ui.node :the node that dropped.
        ///  ui.parentNode : the new parent node.
        ///  ui.position:The new position of the node.
        /// </remarks>
        [jQueryOption("dropped", ValueType = JavaScriptTypes.Function, FunctionParams = new string[] { "event", "ui" })]
        public string OnNodeDropped { get; set; }

        /// <summary>
        /// Gets/Sets the bool value that enabling the node drag and drop.
        /// </summary>
        [jQueryOption("enableDropAndDrag")]
        public bool? EnableDragAndDrop { get; set; }

        /// <summary>
        /// Gets/Sets the disable the node linke to prevent the link defualt behavior.
        /// </summary>
        [jQueryOption("disableLinks")]
        public bool? DisableNodeLinks { get; set; }

        /// <summary>
        /// Gets/Sets the tree node data source url
        /// </summary>
        [jQueryOption("url")]
        public string DataSourceUrl { get; set; }

        /// <summary>
        /// Gets/Sets the treeview node images folder url
        /// </summary>
        [jQueryOption("baseImageUrl")]
        public string BaseImageUrl { get { return baseImageUrl; } set { baseImageUrl = value; } }

        /// <summary>
        /// Gets/sets the css class name of the selected node.
        /// </summary>
        [jQueryOption("selectedClass")]
        public string SelectedNodeCssClass { get; set; }

        /// <summary>
        /// Gets/Sets the jQuery selector for selected node content.
        /// </summary>
        [jQueryOption("applyClassTo")]
        public string ApplyCssClassTo { get; set; }

        /// <summary>
        /// Gets/Sets the key value of the node to be selected on init.
        /// </summary>
        [jQueryOption("selectedKey")]
        public string SelectedKey { get; set; }
    }
}
