﻿//  Copyright (c) 2011 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Mvc;
using System.Web.UI.WebControls;

namespace DNA.Mvc.jQuery
{
    public class GridColumnBuilder : ViewComponentBuilder<GridColumn, GridColumnBuilder>
    {
        public GridColumnBuilder(GridColumn component, AjaxHelper helper) : base(component, helper) { }

        public GridColumnBuilder Title(string text)
        {
            Component.Title = text;
            return this;
        }

        public GridColumnBuilder Template(Action<object> tmpl)
        {
            Component.CellTemplate = tmpl;
            return this;
        }

        public GridColumnBuilder TextAlign(HorizontalAlign align)
        {
            Component.TextAlign = align;
            return this;
        }

        public GridColumnBuilder Template(Action tmpl)
        {
            Component.ClientCellTemplate = tmpl;
            return this;
        }
    }

    public class GridColumnBuilder<TModel, TValue> : ViewComponentBuilder<GridColumn<TModel, TValue>, GridColumnBuilder<TModel, TValue>>
    {
        public GridColumnBuilder(GridColumn<TModel, TValue> component, AjaxHelper helper) : base(component, helper) { }

        public GridColumnBuilder<TModel, TValue> TextAlign(HorizontalAlign align)
        {
            Component.TextAlign = align;
            return this;
        }

        public GridColumnBuilder<TModel, TValue> Title(string text)
        {
            Component.Title = text;
            return this;
        }

        public GridColumnBuilder<TModel, TValue> Template(Action<TModel> tmpl)
        {
            this.Component.CellTemplate = tmpl;
            return this;
        }

        public GridColumnBuilder<TModel, TValue> Template(Action tmpl)
        {
            Component.ClientCellTemplate = tmpl;
            return this;
        }

        public GridColumnBuilder<TModel, TValue> Format(string format)
        {
            Component.FormatString = format;
            return this;
        }
    }
}
