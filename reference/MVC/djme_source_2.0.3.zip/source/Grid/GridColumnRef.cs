﻿//  Copyright (c) 2011 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Linq.Expressions;

namespace DNA.Mvc.jQuery
{
    public class GridColumnRef
    {
        private Grid parent;

        public Grid Parent
        {
            get { return parent; }
            protected set { parent = value; }
        }

        public string Name { get; set; }

        public virtual GridColumn Column
        {
            get
            {
                return parent.Columns.FirstOrDefault(c => c.DataField.Equals(Name, StringComparison.OrdinalIgnoreCase));
            }
        }

        public GridColumnRef(Grid grid, string name)
        {
            parent = grid;
            Name = name;
        }
    }

    public class GridColumnRef<TModel, TValue> : GridColumnRef
          where TModel : class
    {
        public new GridColumn<TModel, TValue> Column
        {
            get
            {
                return (GridColumn<TModel, TValue>)base.Column;
            }
        }

        public GridColumnRef(Grid grid, string name) : base(grid, name) { }
    }


}
