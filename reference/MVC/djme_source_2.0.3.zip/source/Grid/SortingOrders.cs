﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DNA.Mvc.jQuery
{
    public enum SortingOrders
    {
        NotSet,
        Asc,
        Desc
    }
}
