﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Linq.Expressions;
using System.Web.Mvc;

namespace DNA.Mvc.jQuery
{
    public class GridOrderedColumnRefFactory
    {
        private Grid _grid;

        public GridOrderedColumnRefFactory(Grid grid)
        {
            _grid = grid;
        }

        public void Add(string name)
        {
            this.Add(name, SortingOrders.Asc);
        }

        public void Add(string name, SortingOrders order)
        {
            if (string.IsNullOrEmpty(name))
                throw new ArgumentNullException("name");

            _grid.OrderedColumns.Add(new GridOrderedColumnRef(_grid, name) { Order = order });
        }
    }

    public class GridOrderedColumnRefFactory<TModel>
      where TModel : class
    {
        private Grid _grid;

        public GridOrderedColumnRefFactory(Grid grid)
        {
            _grid = grid;
        }

        public void Add(string name)
        {
            this.Add(name, SortingOrders.Asc);
        }

        public void Add(string name, SortingOrders order)
        {
            _grid.OrderedColumns.Add(new GridOrderedColumnRef(_grid, name) { Order=order });
        }

        public void Add<TValue>(Expression<Func<TModel, TValue>> expression)
        {
            this.Add(expression, SortingOrders.Asc);
        }

        public void Add<TValue>(Expression<Func<TModel, TValue>> expression, SortingOrders order)
        {
            ModelMetadata modelMeta = ModelMetadata.FromLambdaExpression<TModel, TValue>(expression, new ViewDataDictionary<TModel>());
            _grid.OrderedColumns.Add(new GridOrderedColumnRef(_grid, modelMeta.PropertyName) { Order = order });
        }

    }
}
