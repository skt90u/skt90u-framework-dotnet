﻿//  Copyright (c) 2011 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Linq.Expressions;
using System.Web.Mvc;

namespace DNA.Mvc.jQuery
{
    public class GridColumnRefFactory
    {
        private Grid _grid;

        public GridColumnRefFactory(Grid grid)
        {
            _grid = grid;
        }

        public void Add(string name)
        {
            if (string.IsNullOrEmpty(name))
                throw new ArgumentNullException("name");
            _grid.GroupColumns.Add(new GridColumnRef(_grid,name));
        }
    }

    public class GridColumnRefFactory<TModel>
          where TModel : class
    {
        private Grid _grid;

        public GridColumnRefFactory(Grid grid)
        {
            _grid = grid;
        }

        public void Add<TValue>(Expression<Func<TModel, TValue>> expression)
        {
            ModelMetadata modelMeta = ModelMetadata.FromLambdaExpression<TModel, TValue>(expression, new ViewDataDictionary<TModel>());
            _grid.GroupColumns.Add(new GridColumnRef<TModel, TValue>(_grid, modelMeta.PropertyName));
        }

        public void Add(string name)
        {
            if (string.IsNullOrEmpty(name))
                throw new ArgumentNullException("name");
            _grid.GroupColumns.Add(new GridColumnRef(_grid, name));
        }
    }
}
