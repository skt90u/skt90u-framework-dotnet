﻿//  Copyright (c) 2011 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DNA.Mvc.jQuery
{
    public class GridOptions
    {
        [jQueryOption("sortable")]
        public bool? Sortable { get; set; }

        [jQueryOption("showScroll")]
        public bool? ShowScrollBar { get; set; }

        [jQueryOption("columnClick", ValueType = JavaScriptTypes.Function, FunctionParams = new string[] { "event", "ui" })]
        public string OnColumnClick { get; set; }

        [jQueryOption("sort", ValueType = JavaScriptTypes.Function, FunctionParams = new string[] { "event", "ui" })]
        public string OnSort { get; set; }

        [jQueryOption("rowSelected", ValueType = JavaScriptTypes.Function, FunctionParams = new string[] { "event", "ui" })]
        public string OnRowSelected { get; set; }

        [jQueryOption("addGroup", ValueType = JavaScriptTypes.Function, FunctionParams = new string[] { "event", "ui" })]
        public string OnAddGroup { get; set; }

        [jQueryOption("delGroup", ValueType = JavaScriptTypes.Function, FunctionParams = new string[] { "event", "ui" })]
        public string OnRemoveGroup { get; set; }

         [jQueryOption("filterChanged", ValueType = JavaScriptTypes.Function, FunctionParams = new string[] { "event", "ui" })]
        public string OnFilterChanged { get; set; }
    }
}
