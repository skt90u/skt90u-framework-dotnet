﻿//  Copyright (c) 2011 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Mvc;
using System.Linq.Expressions;

namespace DNA.Mvc.jQuery
{
    public class GridColumnBuilderFactory : ViewComponentBuilderFactory<GridColumn>
    {
        public GridColumnBuilderFactory(Grid container, AjaxHelper helper) : base(container, helper) { }

        public GridColumnBuilder Add(string title, string dataField)
        {
            var column = new GridColumn() { Title = title, DataField = dataField };
            
            Container.Items.Add(column);
            Container.OnItemAdded(column);
            return new GridColumnBuilder(column, Helper);
        }
    }

    public class GridColumnBuilderFactory<TModel> : ViewComponentBuilderFactory<GridColumn>
        where TModel : class
    {
        public GridColumnBuilderFactory(Grid container, AjaxHelper helper) : base(container, helper) { }

        public GridColumnBuilder<TModel, TValue> Bound<TValue>(Expression<Func<TModel, TValue>> expression)
        {
            ModelMetadata modelMeta = ModelMetadata.FromLambdaExpression<TModel, TValue>(expression, new ViewDataDictionary<TModel>());
            var column = new GridColumn<TModel, TValue>(modelMeta);
            Container.Items.Add(column);
            Container.OnItemAdded(column);
            return new GridColumnBuilder<TModel, TValue>(column, Helper);
        }
    }


}
