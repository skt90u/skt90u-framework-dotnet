﻿//  Copyright (c) 2011 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DNA.Mvc.jQuery
{
    public class GridOrderedColumnRef:GridColumnRef
    {
        public GridOrderedColumnRef(Grid grid, string name) : base(grid, name) { }

        private SortingOrders order = SortingOrders.Asc;

        public SortingOrders Order
        {
            get { return order; }
            set { order = value; }
        }

    }

    public class GridOrderedColumnRef<TModel, TValue> : GridColumnRef<TModel, TValue>
          where TModel : class
    {
        public GridOrderedColumnRef(Grid grid, string name) : base(grid, name) { }

        private SortingOrders order = SortingOrders.Asc;

        public SortingOrders Order
        {
            get { return order; }
            set { order = value; }
        }
    }
}
