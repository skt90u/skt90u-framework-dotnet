﻿//  Copyright (c) 2011 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DNA.Mvc.jQuery
{
    public static class jQueryScriptHelper
    {
        public static string GetSelectorName(string name)
        {
            if ((name.StartsWith("#") || name.StartsWith(".") || name.StartsWith(">") || name.StartsWith("~") || name.StartsWith(":") || name.Equals("document", StringComparison.OrdinalIgnoreCase) || name.Equals("body", StringComparison.OrdinalIgnoreCase)))
                return name;
            return "#"+name;
        }

        public static string GetjQuerySelector(string name)
        {
            return "$(\""+GetSelectorName(name)+"\")";
        }
    }
}
