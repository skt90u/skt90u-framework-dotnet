﻿//  Copyright (c) 2011 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Mvc;

namespace DNA.Mvc.jQuery
{
    public class DatePicker : ViewComponent
    {
        private DatePickerDisplayModes displayMode = DatePickerDisplayModes.Picker;

        public DatePickerDisplayModes DisplayMode
        {
            get { return displayMode; }
            set { displayMode = value; }
        }

        private DateTime date;

        public DateTime Value
        {
            get { return date; }
            set { date = value; }
        }

        public override void Render(System.Web.UI.HtmlTextWriter writer)
        {
            var tags = new TagBuilder(TagName);

            if (displayMode == DatePickerDisplayModes.Picker)
            {
                tags.AddCssClass("d-datepicker");
                if (HtmlAttributes != null)
                    tags.MergeAttributes<string, object>(HtmlAttributes);
                var input = new TagBuilder("input");
                input.AddCssClass("d-datepicker-input");
                input.MergeAttribute("type", "text");
                input.MergeAttribute("id", this.Id);
                input.MergeAttribute("name", this.Name);
                var btn = new TagBuilder("span");
                btn.AddCssClass("d-datepicker-button");
                tags.InnerHtml = input.ToString(TagRenderMode.SelfClosing) + btn.ToString();
                writer.Write(tags.ToString());
            }
            else
            {
                var calendar = new TagBuilder("div");
                calendar.Attributes.Add("id", Id);
                calendar.InnerHtml = "<input type='hidden' value='' name='" + Name + "' />";
                writer.Write(calendar.ToString());
            }
        }
    }
}
