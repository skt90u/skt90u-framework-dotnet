﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DNA.Mvc.jQuery
{
    /// <summary>
    /// Defines the jQuery UI DatePicker options.
    /// </summary>
    public class DatePickerOptions
    {
        /// <summary>
        ///  Gets/Sets the text to display after each date field, e.g. to show the required format.
        /// </summary>
        [jQueryOption("appendText")]
        public string AppendText { get; set; }

        /// <summary>
        /// Gets/Sets the URL for the popup button image. If set, button text becomes the alt value and is not directly displayed.
        /// </summary>
        [jQueryIgnore]
        public string ButtonImageUrl { get; set; }

        /// <summary>
        /// Set to true to place an image after the field to use as the trigger without it appearing on a button.
        /// </summary>
        [jQueryIgnore]
        public bool ShowButtonImageOnly { get; set; }

        ///// <summary>
        ///// Gets/Sets whether show the datepicker's button's image
        ///// </summary>
        //[jQueryIgnore]
        //public bool ShowDefaultButtonImage { get; set; }

        /// <summary>
        /// Gets/Sets the dateFormat to be used for the altField option. This allows one date format to be shown to the user for selection purposes, while a different format is actually sent behind the scenes. For a full list of the possible formats see the formatDate function
        /// </summary>
        [jQueryIgnore]
        public string AnotherFormatString { get; set; }

        /// <summary>
        /// Gets/Sets the jQuery server side selector for another field that is to be updated with the selected date from the datepicker. Use the altFormat setting below to change the format of the date within this field. Leave as blank for no alternate field.
        /// </summary>
        [jQueryOption("altField")]
        public string AnotherField { get; set; }

        /// <summary>
        /// Gets/Sets the text to display on the trigger button.
        /// </summary>
        [jQueryOption("buttonText")]
        public string ButtonText { get; set; }

        /// <summary>
        /// Gets/Sets whether the DatePicker allows you to change the month by selecting from a drop-down list. You can enable this feature by setting the property to true.
        /// </summary>
        [jQueryOption("changeMonth")]
        public bool? AllowChangeMonth { get; set; }

        /// <summary>
        /// Gets/Sets whether the DatePicker allows you to change the year by selecting from a drop-down list. You can enable this feature by setting the attribute to true.
        /// </summary>
        [jQueryOption("changeYear")]
        public bool? AllowChangeYear { get; set; }

        /// <summary>
        /// Gets/Sets The text to display for the close link. This attribute is one of the regionalisation attributes. Use the ShowButtonPanel to display this button.
        /// </summary>
        [jQueryOption("closeText")]
        public string CloseButtonText { get; set; }

        /// <summary>
        /// True if the input field is constrained to the current date format.
        /// </summary>
        [jQueryOption("constrainInput")]
        public bool? ConstrainInput { get; set; }

        /// <summary>
        /// Gets/Sets the text to display for the current day link. This attribute is one of the regionalisation attributes. Use the ShowButtonPanel to display this button.
        /// </summary>
        [jQueryOption("currentText")]
        public string TextForToday { get; set; }

        /// <summary>
        /// Gets/Sets the region id for the datepicker
        /// </summary>
        [jQueryIgnore]
        public string LocID { get; set; }

        /// <summary>
        /// Gets/Sets the format for parsed and displayed dates. 
        /// </summary>
        /// <remarks>
        ///  DatePicker Web Control not use jQuery's dateFormat,you can using the DateFormat in .Net.
        /// </remarks>
        [jQueryIgnore]
        public string DateFormatString { get; set; }

        /// <summary>
        /// Gets the collection of long day names, starting from Sunday, for use as requested via the dateFormat setting. 
        /// They also appear as popup hints when hovering over the corresponding column headings. 
        /// This attribute is one of the regionalisation attributes.
        /// </summary>
        /// <remarks>
        /// 	<para>The DayNames default value is below</para>
        /// 	<para>'Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday',
        ///     'Saturday'</para>
        /// </remarks>
        [jQueryOption("dayNames", ValueType = JavaScriptTypes.Array)]
        public string[] DayNames { get; set; }

        /// <summary>
        /// Gets the colleciton of abbreviated day names, starting from Sunday, for use as requested via the 
        /// dateFormat setting. This attribute is one of the regionalisation attributes.
        /// </summary>
        /// <remarks><para>default value:'Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'</para></remarks>
        [jQueryOption("dayNamesShort", ValueType = JavaScriptTypes.Array)]
        public string[] ShortDayNames { get; set; }

        /// <summary>
        ///Gets the collection of minimised day names, starting from Sunday, for use as column headers within the datepicker. 
        ///This attribute is one of the regionalisation attributes.
        /// </summary>
        /// <remarks>
        /// Default value:'Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'
        /// </remarks>
        [jQueryOption("dayNamesMin", ValueType = JavaScriptTypes.Array)]
        public string[] MinDayNames { get; set; }

        /// <summary>
        /// Gets/Sets the date to highlight on first opening if the field is blank. 
        /// </summary>
        /// <remarks>
        /// Specify either an actual date via a Date object, or a number of days from today 
        /// (e.g. +7) or a string of values and periods ('y' for years, 'm' for months, 'w' for weeks, 'd' for days, 
        /// e.g. '+1m +7d'), or null for today.
        /// </remarks>
        [jQueryOption("defaultDate")]
        public string DefaultDateString { get; set; }

        /// <summary>
        /// Control the speed at which the datepicker appears, it may be a time in milliseconds
        /// </summary>
        [jQueryOption("duration")]
        public int? Duration { get; set; }

        /// <summary>
        /// Gets/Sets the first day of the week: 
        /// </summary>
        /// <remarks>
        /// Sunday is 0, Monday is 1, ... This property is one of the regionalisation properties.
        /// </remarks>
        [jQueryOption("firstDay")]
        public int? FirstDayOfWeek { get; set; }

        /// <summary>
        /// Gets/Sets whether the current day link moves to the currently selected date instead of today.
        /// </summary>
        [jQueryOption("gotoCurrent")]
        public bool? MoveToSelectedDate { get; set; }

        /// <summary>
        /// Gets/Sets normally the previous and next links are disabled when not applicable (see minDate/maxDate). 
        /// You can hide them altogether by setting this attribute to true.
        /// </summary>
        [jQueryOption("hideIfNoPrevNext")]
        public bool? HideIfNoPrevNext { get; set; }

        /// <summary>
        ///Gets/Sets a maximum selectable date via a Date object, or a number of days from today (e.g. +7) or a string
        ///of values and periods ('y' for years, 'm' for months, 'w' for weeks, 'd' for days, e.g. '+1m +1w'), or null 
        ///for no limit.
        /// </summary>
        [jQueryOption("maxDate")]
        public string MaxDateFormat { get; set; }

        [jQueryIgnore]
        public DateTime? MaxDateValue { get; set; }

        [jQueryIgnore]
        public DateTime? MinDateValue { get; set; }

        /// <summary>
        /// Gets/Sets a minimum selectable date via a Date object, or a number of days from today (e.g. +7) or a string of values and periods ('y' for years, 'm' for months, 'w' for weeks, 'd' for days, e.g. '-1y -1m'), or null for no limit.
        /// </summary>
        [jQueryOption("minDate")]
        public string MinDateFormat { get; set; }

        /// <summary>
        /// Gets the collection of full month names, as used in the month header on each datepicker and as requested via the dateFormat setting. This attribute is one of the regionalisation attributes.
        /// </summary>
        /// <remarks>
        /// Default value:'January', 'February', 'March', 'April', 'May', 'June', 'July',
        /// 'August', 'September', 'October', 'November', 'December'
        /// </remarks>
        [jQueryOption("monthNames", ValueType = JavaScriptTypes.Array)]
        public string[] MonthNames { get; set; }

        /// <summary>
        /// Gets the collection of abbreviated month names, for use as requested via the dateFormat setting. This attribute is one of the regionalisation attributes.
        /// </summary>
        /// <remarks>
        /// Default value:'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'
        /// </remarks>
        [jQueryOption("monthNamesShort",ValueType=JavaScriptTypes.Array)]
        public string[] MonthShortNames { get; set; }

        /// <summary>
        /// Gets/sets the formatDate function is applied to the prevText, nextText, 
        /// and currentText values before display, allowing them to display the target month names for example.
        /// </summary>
        [jQueryOption("navigationAsDateFormat")]
        public bool? NavigationAsDateFormat { get; set; }

        /// <summary>
        ///  Gets/Sets the text to display for the next month link. This attribute is one of the regionalisation attributes.
        ///  With the standard ThemeRoller styling, this value is replaced by an icon.
        /// </summary>
        [jQueryOption("nextText")]
        public string NextMonthText { get; set; }

        ///<summary>
        ///Gets/Sets how many months to show at once. The value can be a straight integer, or can be 
        ///a two-element array to define the number of rows and columns to display.
        ///</summary>
        [jQueryOption("numberOfMonths")]
        public int? NumberOfMonths { get; set; }

        /// <summary>
        /// Gets/Sets the text to display for the previous month link. 
        /// </summary>
        [jQueryOption("prevText")]
        public string PrevMonthText { get; set; }

        /// <summary>
        /// Gets/Sets the cutoff year for determining the century for a date (used in conjunction with dateFormat 'y').
        /// If a numeric value (0-99) is provided then this value is used directly. If a string value is provided then 
        /// it is converted to a number and added to the current year. Once the cutoff year is calculated, any dates
        /// entered with a year value less than or equal to it are considered to be in the current century, while those
        /// greater than it are deemed to be in the previous century.
        /// </summary>
        [jQueryOption("shortYearCutoff")]
        public int? ShortYearCutOff { get; set; }

        /// <summary>
        /// Gets/Sets the name of the animation used to show/hide the datepicker.
        /// </summary>
        /// <remarks>
        ///  Use 'show' (the default), 'slideDown', 'fadeIn', or any of the show/hide jQuery UI effects.
        /// </remarks>
        [jQueryOption("showAnim")]
        public string AnimationOnShow { get; set; }

        /// <summary>
        /// Gets/Sets whether to show the button panel.
        /// </summary>
        [jQueryOption("showButtonPanel")]
        public bool? ShowButtonPanel { get; set; }

        /// <summary>
        /// Gets/Sets where in a multi-month display the current month shows, starting from 0 at the top/left.
        /// </summary>
        [jQueryOption("showCurrentAtPos")]
        public int? ShowCurrentAtPos { get; set; }

        /// <summary>
        /// Gets/Sets whether to show the month after the year in the header.
        /// </summary>
        [jQueryOption("showMonthAfterYear")]
        public bool? ShowMonthAfterYear { get; set; }

        /// <summary>
        /// Gets/Sets the datepicker appear automatically when the field receives focus ('focus'), appear only when a button is clicked ('button'), or appear when either event takes place ('both').
        /// </summary>
        [jQueryOption("showOn")]
        public DateIconShowModes ShowIconMode { get; set; }

        /// <summary>
        /// Gets/Sets  if using one of the jQuery UI effects for AnimationOnShow, you can provide additional settings for that animation via this option.
        /// </summary>
        [jQueryOption("showOptions")]
        public string ShowOptions { get; set; }

        /// <summary>
        /// Gets/Sets display dates in other months (non-selectable) at the start or end of the current month.
        /// </summary>
        [jQueryOption("showOtherMonths")]
        public bool? ShowOtherMonths { get; set; }

        /// <summary>
        /// Gets/Sets how many months to move when clicking the Previous/Next links.
        /// </summary>
        [jQueryOption("stepMonths")]
        public int? StepMonths { get; set; }

        /// <summary>
        /// Gets/Sets control the range of years displayed in the year drop-down: either relative to current year (-nn:+nn) or absolute (nnnn:nnnn).
        /// </summary>
        [jQueryOption("yearRange")]
        public string YearRange { get; set; }

        /// <summary>
        /// Gets/Sets the DatePicker's DisplayMode
        /// </summary>
        [jQueryIgnore]
        public DatePickerDisplayModes DisplayMode { get; set; }

        /// <summary>
        /// Gets/Sets whether the current language is drawn from right to left. 
        /// </summary>
        [jQueryOption("isRTL")]
        public bool? IsRightToLeft { get; set; }

        /// <summary>
        /// Gets/Sets the DatePicker 's select value
        /// </summary>
        [jQueryIgnore]
        public DateTime? Value { get; set; }

        /// <summary>
        /// Can be a function that takes an input field and current datepicker instance and returns an 
        /// options object to update the datepicker with. It is called just before the datepicker is displayed.
        /// </summary>
        [jQueryOption("beforeShow", ValueType = JavaScriptTypes.Function, FunctionParams = new string[] { "input" })]
        public string OnBeforeShow { get; set; }

        /// <summary>
        /// The function takes a date as a parameter and must return an array with [0] equal to 
        /// true/false indicating whether or not this date is selectable, [1] equal to a CSS class name(s) or 
        /// '' for the default presentation and [2] an optional popup tooltip for this date. It is called for each 
        /// day in the datepicker before is it displayed.
        /// </summary>
        [jQueryOption("beforeShowDay", ValueType = JavaScriptTypes.Function, FunctionParams = new string[] { "date" })]
        public string OnBeforeShowDay { get; set; }

        /// <summary>
        /// Allows you to define your own event when the datepicker moves to a new month and/or year. 
        /// The function receives the selected year, month and the datepicker instance as parameters. this refers
        /// to the associated input field.
        /// </summary>
        [jQueryOption("onChangeMonthYear", ValueType = JavaScriptTypes.Function, FunctionParams = new string[] { "date" })]
        public string OnChangeMonthYear { get; set; }

        /// <summary>
        /// Allows you to define your own event when the datepicker is closed, whether or not a date is selected.
        /// The function receives the selected date as a Date and the datepicker instance as parameters. 
        /// this refers to the associated input field.
        /// </summary>
        [jQueryOption("onClose", ValueType = JavaScriptTypes.Function, FunctionParams = new string[] { "date" })]
        public string OnClose { get; set; }

        /// <summary>
        /// Allows you to define your own event when the datepicker is selected. 
        /// The function receives the selected date(s) as text and the datepicker instance as parameters. 
        /// this refers to the associated input field.
        /// </summary>
        [jQueryOption("onSelect", ValueType = JavaScriptTypes.Function, FunctionParams = new string[] { "dateText" })]
        public string OnSelect { get; set; }

    }

    public enum DateIconShowModes
    {
        Focus,
        Button,
        Both
    }

    public enum DatePickerDisplayModes
    {
        Picker,
        Calendar
    }
}
