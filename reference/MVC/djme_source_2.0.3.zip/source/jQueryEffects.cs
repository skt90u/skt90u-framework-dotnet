﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DNA.Mvc.jQuery
{
    /// <summary>
    /// Defines values that specifty the effects of jQuery effect plugin.
    /// </summary>
    public enum jQueryEffects
    {
        /// <summary>
        /// Specified blind effect
        /// </summary>
        Blind,
        
        /// <summary>
        /// Specified bounce effect
        /// </summary>
        Bounce,
        
        /// <summary>
        /// Sepcified clip effect
        /// </summary>
        Clip,
        
        /// <summary>
        /// Specified drop effect.
        /// </summary>
        Drop,

        /// <summary>
        /// Specified explode effect.
        /// </summary>
        Explode,

        /// <summary>
        /// Specified fold effect.
        /// </summary>
        Fold,

        /// <summary>
        /// Specified highlight effect.
        /// </summary>
        Highlight,
        
        /// <summary>
        /// Specified pulsate effect.
        /// </summary>
        Pulsate,
        
        /// <summary>
        /// Specified scale effect.
        /// </summary>
        Scale,
        
        /// <summary>
        /// Specified shake effect.
        /// </summary>
        Shake,
        
        /// <summary>
        /// Specified slide effect.
        /// </summary>
        Slide,
        
        /// <summary>
        /// Specified transfer effect.
        /// </summary>
        Transfer
    }
}
