﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DNA.Mvc.jQuery
{
    /// <summary>
    /// Defines a strongly type class of the jQuery.ui selectable plugin options.
    /// </summary>
    public class SelectableOptions
    {
        /// <summary>
        /// This determines whether to refresh (recalculate) the position and size of each selectee at the beginning 
        /// of each select operation. If you have many many items, you may want to set this to false and call the
        /// refresh method manually.
        /// </summary>
        [jQueryOption("autoRefresh")]
        public bool? AutoRefresh { get; set; }

        /// <summary>
        /// Prevents selecting if you start on elements matching the selector.
        /// </summary>
        [jQueryOption("cancel")]
        public string DisableElements { get; set; }

        /// <summary>
        /// Time in milliseconds to define when the selecting should start. It helps preventing unwanted selections
        /// when clicking on an element.
        /// </summary>
        [jQueryOption("delay")]
        public int? Delay { get; set; }

        /// <summary>
        /// Tolerance, in pixels, for when selecting should start. If specified, selecting will not start until after mouse is dragged beyond distance.
        /// </summary>
        [jQueryOption("distance")]
        public int? Distance { get; set; }

        /// <summary>
        /// The matching child elements will be made selectees (able to be selected).
        /// </summary>
        [jQueryOption("filter")]
        public string Filter { get; set; }

        /// <summary>
        /// Possible values: 'touch', 'fit'.
       ///  * fit: draggable overlaps the droppable entirely
       ///  * touch: draggable overlaps the droppable any amount
        /// </summary>
        [jQueryOption("tolerance")]
        public Tolerances Tolerance { get; set; }

        /// <summary>
        /// This event is triggered at the end of the select operation, on each element added to the selection.
        /// </summary>
        [jQueryOption("selected", ValueType = JavaScriptTypes.Function, FunctionParams = new string[] { "event", "ui" })]
        public string OnSelected { get; set; }

        /// <summary>
       ///This event is triggered during the select operation, on each element added to the selection.
        /// </summary>
        [jQueryOption("selecting", ValueType = JavaScriptTypes.Function, FunctionParams = new string[] { "event", "ui" })]
        public string OnSelecting { get; set; }

        /// <summary>
        ///  This event is triggered at the beginning of the select operation
        /// </summary>
        [jQueryOption("start", ValueType = JavaScriptTypes.Function, FunctionParams = new string[] { "event", "ui" })]
        public string OnStart { get; set; }

        /// <summary>
        ///This event is triggered at the end of the select operation.
        /// </summary>
        [jQueryOption("stop", ValueType = JavaScriptTypes.Function, FunctionParams = new string[] { "event", "ui" })]
        public string OnStop { get; set; }

        /// <summary>
        ///  This event is triggered at the end of the select operation, on each element removed from the selection.
        /// </summary>
        [jQueryOption("unselected", ValueType = JavaScriptTypes.Function, FunctionParams = new string[] { "event", "ui" })]
        public string OnUnselected { get; set; }

        /// <summary>
        /// This event is triggered during the select operation, on each element removed from the selection.
        /// </summary>
        [jQueryOption("unselecting", ValueType = JavaScriptTypes.Function, FunctionParams = new string[] { "event", "ui" })]
        public string OnUnselecting { get; set; }
    }
}
