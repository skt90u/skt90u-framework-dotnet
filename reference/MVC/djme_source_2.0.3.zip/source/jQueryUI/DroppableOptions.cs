﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DNA.Mvc.jQuery
{
    /// <summary>
    /// Defines the jQuery UI droppable options.
    /// </summary>
    public class DroppableOptions
    {
        /// <summary>
        /// Gets/Sets all draggables that match the selector will be accepted. 
        /// </summary>
        [jQueryOption("accept")]
        public string Accept { get; set; }

        /// <summary>
        /// Gets/Sets the class will be added to the droppable while an acceptable draggable is being dragged.
        /// </summary>
        [jQueryOption("activeClass")]
        public string ActiveCssClass { get; set; }

        /// <summary>
        /// Gets/Sets whether prevent the ui-droppable class from being added. 
        /// </summary>
        /// <remarks>
        /// This may be desired as a performance optimization when calling .droppable() init on many hundreds of elements.
        /// </remarks>
        [jQueryOption("addClasses")]
        public bool? AllowAddClasses { get; set; }

        /// <summary>
        /// Gets/Sets whether prevent event propagation on nested droppables.
        /// </summary>
        [jQueryOption("greedy")]
        public bool? Greedy { get; set; }

        /// <summary>
        /// Gets/Sets the class will be added to the droppable while an acceptable draggable is being hovered.
        /// </summary>
        [jQueryOption("hoverClass")]
        public string HoverCssClass { get; set; }

        /// <summary>
        /// Gets/Sets the group sets of draggable and droppable items, in addition to droppable's Accept Property. 
        /// </summary>
        [jQueryOption("scope")]
        public string GroupName { get; set; }

        /// <summary>
        /// Gets/Sets which mode to use for testing whether a draggable is 'over' a droppable. Possible values: 'fit', 'intersect', 'pointer', 'touch'.
        /// </summary>
        [jQueryOption("tolerance")]
        public Tolerances Tolerance { get; set; }

        /// <summary>
        /// This event is triggered any time an accepted draggable starts dragging. This can be useful if you want to make the droppable 'light up' when it can be dropped on
        /// </summary>
        [jQueryOption("activate", ValueType = JavaScriptTypes.Function, FunctionParams = new string[] { "event", "ui" })]
        public string OnDragActive { get; set; }

        /// <summary>
        /// This event is triggered any time an accepted draggable stops dragging
        /// </summary>
        [jQueryOption("deactivate", ValueType = JavaScriptTypes.Function, FunctionParams = new string[] { "event", "ui" })]
        public string OnDragDeactive { get; set; }

        /// <summary>
        /// This event is triggered as an accepted draggable is dragged 'over' (within the tolerance of) this droppable
        /// </summary>
        [jQueryOption("over", ValueType = JavaScriptTypes.Function, FunctionParams = new string[] { "event", "ui" })]
        public string OnDragOver { get; set; }

        /// <summary>
        /// This event is triggered when an accepted draggable is dragged out (within the tolerance of) this droppable
        /// </summary>
        [jQueryOption("out", ValueType = JavaScriptTypes.Function, FunctionParams = new string[] { "event", "ui" })]
        public string OnDragOut { get; set; }

        /// <summary>
        /// This event is triggered when an accepted draggable is dropped 'over'
        /// (within the tolerance of) this droppable. In the callback, $(this) represents 
        /// the droppable the draggable is dropped on. ui.draggable represents the draggable
        /// </summary>
        [jQueryOption("drop", ValueType = JavaScriptTypes.Function, FunctionParams = new string[] { "event", "ui" })]
        public string OnDrop { get; set; }
    }
}
