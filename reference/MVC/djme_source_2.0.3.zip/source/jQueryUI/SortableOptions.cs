﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DNA.Mvc.jQuery
{
    /// <summary>
    /// Defines the sortable option object.
    /// </summary>
    public class SortableOptions
    {
        /// <summary>
        /// Defines where the helper that moves with the mouse is being appended to during the
        /// drag (for example, to resolve overlap/zIndex issues).
        /// </summary>
        [jQueryOption("appendTo")]
        public string AppendTo { get; set; }
        
        /// <summary>
        /// Gets/Sets time in milliseconds after mousedown until dragging should start.
        /// </summary>
        /// <remarks>
        /// This Property can be used to prevent unwanted drags when clicking on an element.
        /// </remarks>
        [jQueryOption("delay")]
        public int DragStartDelay { get; set; }

        /// <summary>
        /// Gets/Sets DragDistance in pixels after mousedown the mouse must move before dragging should start. 
        /// </summary>
        ///<remarks>
        /// This Property can be used to prevent unwanted drags when clicking on an element.
        /// </remarks>
        [jQueryOption("distance")]
        public int? DragStartDistance { get; set; }

        /// <summary>
        /// Specifies which items inside the element should be sortable.
        /// </summary>
        [jQueryOption("items")]
        public string SortableItems { get; set; }

        /// <summary>
        /// Specified which items jQuery selector that disable sortable.
        /// </summary>
        [jQueryOption("cancel")]
        public string UnsortableItems { get; set; }

        /// <summary>
        /// Takes a jQuery selector with items that also have sortables applied. 
        /// If used, the sortable is now connected to the other one-way, so you can drag from 
        /// this sortable to the other.
        /// </summary>
        [jQueryOption("connectWith")]
        public string ConnectWith { get; set; }

        /// <summary>
        /// Gets/Sets whether empty allows for an item to be dropped from a linked selectable.
        /// </summary>
        [jQueryOption("dropOnEmpty")]
        public bool? AllowDropOnEmpty { get; set; }

        /// <summary>
        /// Gets/Sets whether forces the helper to have a size.
        /// </summary>
        [jQueryOption("forceHelperSize")]
        public bool? ForceHelperSize { get; set; }

        /// <summary>
        /// Gets/Sets forces the placeholder to have a size.
        /// </summary>
        [jQueryOption("forcePlaceholderSize")]
        public bool? ForcePlaceholderSize { get; set; }

        /// <summary>
        /// Gets/Sets css class that gets applied to the otherwise white space.
        /// </summary>
        [jQueryOption("placeholder")]
        public string PlaceHolderCssClass { get; set; }

        /// <summary>
        /// The css cursor during the drag operation.
        /// </summary>
        [jQueryOption("cursor")]
        public string Cursor { get; set; }

        /// <summary>
        /// Moves the dragging helper so the cursor always appears to drag from the same position. 
        /// Coordinates can be given as a hash using a combination of one or two keys: { Top, Left, Right, Bottom }.
        /// </summary>
        [jQueryOption("cursorAt", ValueType = JavaScriptTypes.Object)]
        public Position CursorPosition { get; set; }

        /// <summary>
        /// Gets/Sets whether the item will be reverted to its new DOM position with a smooth animation.
        /// </summary>
        [jQueryOption("revert")]
        public bool? Revert { get; set; }

        //[jQueryOption("containment")]
        //public string Containment { get; set; }

        [jQueryIgnore]
        public Containers ContainsIn { get; set; }

        /// <summary>
        /// Gets/Sets the id of  the container.
        /// </summary>
        [jQueryIgnore]
        public string Container { get; set; }

        [jQueryIgnore]
        public Orientation DragOrientation { get; set; }

        /// <summary>
        ///  Gets/Sets restricts drag start click to the specified Controls/Elements
        /// </summary>
        [jQueryOption("handle")]
        public string DragHandler { get; set; }

        /// <summary>
        /// This is the way the reordering behaves during drag. Possible values: 'Intersect', 'Pointer'. 
        /// In some setups, 'Pointer' is more natural.
        /// </summary>
        [jQueryOption("tolerance")]
        public Tolerances Tolerance { get; set; }

        //[jQueryOption("axis")]
        //public string Axis { get; set; }
        
        [jQueryOption("grid")]
        public int[] Grid { get; set; }

        [jQueryOption("helper")]
        public Helpers DragHelper { get; set; }

        /// <summary>
        /// Gets/Sets the custom helper html
        /// </summary>
        [jQueryIgnore]
        public string CustomHelper { get; set; }

        /// <summary>
        /// Gets/Sets opacity for the helper while being dragged.
        /// </summary>
        [jQueryOption("opacity")]
        public float? DragHelperOpacity { get; set; }

        /// <summary>
        /// Gets/Sets whether container auto-scrolls while dragging.
        /// </summary>
        [jQueryOption("scroll")]
        public bool? AutoScroll { get; set; }

        /// <summary>
        /// Gets/Sets distance in pixels from the edge of the viewport after which the viewport should scroll. 
        /// Distance is relative to pointer, not the draggable.
        /// </summary>
        [jQueryOption("scrollSensitivity")]
        public int? ScrollSensitivity { get; set; }

        /// <summary>
        /// Gets/Sets the speed at which the window should scroll once the mouse pointer gets within the 
        /// scrollSensitivity distance.
        /// </summary>
        [jQueryOption("scrollSpeed")]
        public int? ScrollSpeed { get; set; }

        /// <summary>
        /// This event is triggered when sorting starts.
        /// </summary>
        [jQueryOption("start", ValueType = JavaScriptTypes.Function, FunctionParams = new string[] { "event", "ui" })]
        public string OnSortStart { get; set; }

        /// <summary>
        /// This event is triggered during sorting.
        /// </summary>
        [jQueryOption("sort", ValueType = JavaScriptTypes.Function, FunctionParams = new string[] { "event", "ui" })]
        public string OnSort { get; set; }

        /// <summary>
        /// This event is triggered during sorting, but only when the DOM position has changed.
        /// </summary>
        [jQueryOption("change", ValueType = JavaScriptTypes.Function, FunctionParams = new string[] { "event", "ui" })]
        public string OnSortChange { get; set; }

        /// <summary>
        /// This event is triggered when sorting stops, but when the placeholder/helper is still available.
        /// </summary>
        [jQueryOption("beforeStop", ValueType = JavaScriptTypes.Function, FunctionParams = new string[] { "event", "ui" })]
        public string OnSortBeforeStop { get; set; }


        /// <summary>
        /// This event is triggered when sorting has stopped.
        /// </summary>
        [jQueryOption("stop", ValueType = JavaScriptTypes.Function, FunctionParams = new string[] { "event", "ui" })]
        public string OnSortStop { get; set; }

        /// <summary>
        /// This event is triggered when the user stopped sorting and the DOM position has changed.
        /// </summary>
        [jQueryOption("update", ValueType = JavaScriptTypes.Function, FunctionParams = new string[] { "event", "ui" })]
        public string OnSortUpdate { get; set; }

        /// <summary>
        /// This event is triggered when a connected sortable list has received an item from another list
        /// </summary>
        [jQueryOption("receive", ValueType = JavaScriptTypes.Function, FunctionParams = new string[] { "event", "ui" })]
        public string OnSortReceive { get; set; }

        /// <summary>
        /// This event is triggered when a sortable item has been dragged out from the list and into another
        /// </summary>
        [jQueryOption("remove", ValueType = JavaScriptTypes.Function, FunctionParams = new string[] { "event", "ui" })]
        public string OnSortRemove { get; set; }

        /// <summary>
        /// This event is triggered when a sortable item is moved into a connected list
        /// </summary>
        [jQueryOption("over", ValueType = JavaScriptTypes.Function, FunctionParams = new string[] { "event", "ui" })]
        public string OnSortOver { get; set; }

        /// <summary>
        /// This event is triggered when a sortable item is moved away from a connected list
        /// </summary>
        [jQueryOption("out", ValueType = JavaScriptTypes.Function, FunctionParams = new string[] { "event", "ui" })]
        public string OnSortOut { get; set; }

        /// <summary>
        /// This event is triggered when using connected lists, every connected list on drag start receives it
        /// </summary>
        [jQueryOption("activate", ValueType = JavaScriptTypes.Function, FunctionParams = new string[] { "event", "ui" })]
        public string OnSortActivate { get; set; }

        /// <summary>
        /// This event is triggered when sorting was stopped, is propagated to all possible connected lists
        /// </summary>
        [jQueryOption("deactivate", ValueType = JavaScriptTypes.Function, FunctionParams = new string[] { "event", "ui" })]
        public string OnSortDeactivate { get; set; }
    }
}
