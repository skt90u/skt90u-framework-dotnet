﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DNA.Mvc.jQuery
{
    /// <summary>
    /// 
    /// </summary>
    public enum Orientation
    {
        /// <summary>
        /// 
        /// </summary>
        Notset,
        /// <summary>
        /// 
        /// </summary>
        Vertical,
        /// <summary>
        /// 
        /// </summary>
        Horizontal
    }

    /// <summary>
    /// Enumerates  the revert modes
    /// </summary>
    public enum RevertModes
    {
        /// <summary>
        /// Specified not using revert mode
        /// </summary>
        NotSet,
        /// <summary>
        /// Specified using the original revert mode.
        /// </summary>
        Original,
        /// <summary>
        /// 
        /// </summary>
        Valid,
        /// <summary>
        /// 
        /// </summary>
        Invalid
    }

    /// <summary>
    /// 
    /// </summary>
    public enum Helpers
    {
        NotSet,
        /// <summary>
        /// 
        /// </summary>
        Clone,
        /// <summary>
        /// 
        /// </summary>
        Original
    }

    /// <summary>
    /// 
    /// </summary>
    public enum SnapModes
    {
        /// <summary>
        /// 
        /// </summary>
        Both,
        /// <summary>
        /// 
        /// </summary>
        Inner,
        /// <summary>
        /// 
        /// </summary>
        Outer
    }

    /// <summary>
    /// 
    /// </summary>
    public enum Containers
    {
        /// <summary>
        /// 
        /// </summary>
        NotSet,
        /// <summary>
        /// 
        /// </summary>
        Parent,
        /// <summary>
        /// 
        /// </summary>
        Document,
        /// <summary>
        /// 
        /// </summary>
        Window,
        /// <summary>
        /// 
        /// </summary>
        Customize
    }

    /// <summary>
    /// 
    /// </summary>
    public enum Tolerances
    {
        /// <summary>
        /// draggable overlaps the droppable at least 50%
        /// </summary>
        Intersect, 
        /// <summary>
        /// mouse pointer overlaps the droppable
        /// </summary>
        Pointer,
        /// <summary>
        /// draggable overlaps the droppable entirely
        /// </summary>
        Fit,
        /// <summary>
        /// draggable overlaps the droppable any amount
        /// </summary>
        Touch
    }


    public enum Ranges
    {
        Notset,
        Max,
        Min
    }
}


