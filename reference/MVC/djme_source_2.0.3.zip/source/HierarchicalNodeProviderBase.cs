﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;

namespace DNA.Mvc
{
    /// <summary>
    /// The base class of the IHierarchicalNodeProvider
    /// </summary>
    public abstract class HierarchicalNodeProviderBase:IHierarchicalNodeProvider
    {
        private bool _enableLocalization = false;
        private string _resourceKey = "";

        /// <summary>
        /// Gets user roles of the current node
        /// </summary>
        /// <param name="node">Specified the node object.</param>
        /// <returns>The role string array of the specified node.</returns>
        public virtual string[] GetNodeRoles(HierarchicalNode node)
        {
            return new string[0];
        }

        /// <summary>
        /// Receives the child node collection by specified node.
        /// </summary>
        /// <param name="node">Specified the node object.</param>
        /// <returns>A collection of the children nodes.</returns>
        public abstract IEnumerable<HierarchicalNode> GetChildNodes(HierarchicalNode node);

        /// <summary>
        /// Receive the parent node of the specified node.
        /// </summary>
        /// <param name="node">Specified the node instance.</param>
        /// <returns>The parent node instance.</returns>
        public abstract HierarchicalNode GetParentNode(HierarchicalNode node);

        /// <summary>
        /// Receives wheather current user can access this node.
        /// </summary>
        /// <param name="context">The httpContext object.</param>
        /// <param name="node">The node object.</param>
        /// <returns>The bool value.</returns>
        public virtual bool IsAccessibleToUser(HttpContext context, HierarchicalNode node)
        {
            return true;
        }

        /// <summary>
        /// Gets/Sets the resource key of this node.
        /// </summary>
        public virtual string ResourceKey
        {
            get
            {
                return _resourceKey;
            }
            set
            {
                _resourceKey = value;
            }
        }

        /// <summary>
        /// Gets/Sets the root node.
        /// </summary>
        public abstract HierarchicalNode RootNode { get; set; }

        /// <summary>
        /// Gets/Sets the current node.
        /// </summary>
        public virtual HierarchicalNode CurrentNode
        {
            get { return null; }
        }

        /// <summary>
        /// Enabling the node localization.
        /// </summary>
        public virtual bool EnableLocalization
        {
            get
            {
                return _enableLocalization;
            }
            set
            {
                _enableLocalization = value;
            }
        }

        /// <summary>
        /// Find the node instance by specified the node key.
        /// </summary>
        /// <param name="key">The key value of the node.</param>
        /// <returns>If the node not found the null value will be return.</returns>
        public abstract HierarchicalNode FindNodeFormKey(string key);

        /// <summary>
        /// Add the children node to the specified node.
        /// </summary>
        /// <param name="parentNode">Specified the parent node to add the children.</param>
        /// <param name="node">Specified the child node to add.</param>
        public virtual void AddChildren(HierarchicalNode parentNode, HierarchicalNode node) { }

        /// <summary>
        /// Remove the specified node.
        /// </summary>
        /// <param name="node">The node to remove.</param>
        public virtual void RemoveNode(HierarchicalNode node) { }

        #region IHierarchicalNodeProvider<HierarchicalNode> 成员

        void IHierarchicalNodeProvider.AddChildren(HierarchicalNode parentNode, HierarchicalNode node)
        {
            this.AddChildren(parentNode, node);
        }

        void IHierarchicalNodeProvider.RemoveNode(HierarchicalNode node)
        {
            this.RemoveNode(node);
        }

        string[] IHierarchicalNodeProvider.GetNodeRoles(HierarchicalNode node)
        {
            return this.GetNodeRoles(node);
        }

        IEnumerable<HierarchicalNode> IHierarchicalNodeProvider.GetChildNodes(HierarchicalNode node)
        {
            return this.GetChildNodes(node);
        }

        HierarchicalNode IHierarchicalNodeProvider.GetParentNode(HierarchicalNode node)
        {
            return this.GetParentNode(node);
        }

        bool IHierarchicalNodeProvider.IsAccessibleToUser(System.Web.HttpContext context, HierarchicalNode node)
        {
            return this.IsAccessibleToUser(context, node);
        }

        string IHierarchicalNodeProvider.ResourceKey
        {
            get
            {
                return this._resourceKey;
            }
        }

        HierarchicalNode IHierarchicalNodeProvider.RootNode
        {
            get { return this.RootNode; }
        }

        HierarchicalNode IHierarchicalNodeProvider.CurrentNode
        {
            get { return this.CurrentNode; }
        }

        bool IHierarchicalNodeProvider.EnableLocalization
        {
            get
            {
                return this._enableLocalization;
            }
         }

        HierarchicalNode IHierarchicalNodeProvider.FindNodeFormKey(string key)
        {
            return this.FindNodeFormKey(key);
        }

        #endregion
    }

    //public abstract class HierarchicalNodeProviderBase : HierarchicalNodeProviderBase<HierarchicalNode> { }
}
