﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Text;
using System.Reflection;
using System.Web.Script.Serialization;
using System.Web.UI.WebControls;

namespace DNA.Mvc.jQuery
{
    /// <summary>
    /// Defines the methods to build the jQuery java scripts.
    /// </summary>
    public class jQueryScriptBuilder : OptionBuilder
    {
        private string _selector;
        private string _name;

        /// <summary>
        /// Initialize the jQueryScriptBuilder by specified jQuery selector and plugin name.
        /// </summary>
        /// <param name="selector">The jQuery selector.</param>
        /// <param name="plugin">The plugin name.</param>
        public jQueryScriptBuilder(string selector, string plugin)
        {
            _selector = selector;
            _name = plugin;
        }

        /// <summary>
        /// Initialize the jQueryScriptBuilder by specifed jQuery selector ,plugin name and jQuery options object.
        /// </summary>
        /// <param name="selector">The jQuery selector.</param>
        /// <param name="plugin">The plugin name.</param>
        /// <param name="options">The jQuery options object instance.</param>
        public jQueryScriptBuilder(string selector, string plugin, object options)
        {
            _selector = selector;
            _name = plugin;
            if (options != null)
                AddOptions(options);
        }

        /// <summary>
        /// Receives the results of the jQuery script.
        /// </summary>
        /// <returns></returns>
        public override string ToString()
        {
            StringBuilder builder = new StringBuilder();
            if ((_selector == "$") || (string.IsNullOrEmpty(_selector)))
                builder.Append("$.");
            else
                builder.Append("$('" + _selector + "').");

            builder.Append(_name + "(");
            builder.Append(base.ToString());
            builder.Append(");");
            return builder.ToString();
        }
    }
}
