﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Mvc;

namespace DNA.Mvc.jQuery
{
    public static class PagerExtensions
    {
        public static MvcHtmlString Pager(this AjaxHelper helper, string name, int totalRecords)
        {
            return Pager(helper, name, 1, 20, totalRecords, null);
        }

        public static MvcHtmlString Pager(this AjaxHelper helper, string name, int pageIndex, int pageSize, int totalRecords)
        {
            return Pager(helper, name, pageIndex, pageSize, totalRecords, null);
        }

        public static MvcHtmlString Pager(this AjaxHelper helper, string name, int pageIndex, int pageSize, int totalRecords, object htmlAttributes)
        {
            return Pager(helper, name, new PagerOptions() { PageIndex = pageIndex, PageSize = pageSize, TotalRecords = totalRecords }, htmlAttributes);
        }

        public static MvcHtmlString Pager(this AjaxHelper helper, string name, PagerOptions options, object htmlAttributes)
        {
            TagBuilder pager = new TagBuilder("div");
            pager.GenerateId(name);
            //pager.Attributes.Add("id", name);
            if (htmlAttributes != null)
                pager.MergeAttributes<string, object>(ObjectHelper.ConvertObjectToDictionary(htmlAttributes));
            helper.jQuery("#" + pager.Attributes["id"], "pager", options);
            return MvcHtmlString.Create(pager.ToString());
        }
    }
}
