﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Mvc;

namespace DNA.Mvc.jQuery
{
    /// <summary>
    /// Defines the properties of the PagerOptions.
    /// </summary>
    public class PagerOptions
    {
        /// <summary>
        /// Gets/Sets the TotalRecords.
        /// </summary>
        [jQueryOption("totalrecords")]
        public int? TotalRecords { get; set; }

        /// <summary>
        /// Gets/Sets the current page index value.
        /// </summary>
        [jQueryOption("pageindex")]
        public int? PageIndex { get; set; }

        /// <summary>
        /// Gets/Sets the page size.
        /// </summary>
        [jQueryOption("pagesize")]
        public int? PageSize { get; set; }

        /// <summary>
        /// Gets/Sets the client scripts handling pageIndexChanged event.
        /// </summary>
        [jQueryOption("changed", ValueType = JavaScriptTypes.Function, FunctionParams = new string[] { "event", "ui" })]
        public string OnPageIndexChanged { get; set; }
    }
}
