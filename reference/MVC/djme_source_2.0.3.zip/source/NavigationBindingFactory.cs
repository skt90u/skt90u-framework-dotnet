﻿//  Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DNA.Mvc.jQuery
{
    public class NavigationBindingFactory<TComponent, TContainer>
        where TComponent : NavigableView, IComponentItemContainer<TComponent>
        where TContainer : IComponentItemContainer<TComponent>
    {
        protected IComponentItemContainer<TComponent> Container;
        protected Func<INavigtable, TComponent> creator;

        public NavigationBindingFactory(IComponentItemContainer<TComponent> container, Func<INavigtable, TComponent> factoryMethod)
        {
            Container = container;
            creator = factoryMethod;
        }

        public void Bind<T>(IEnumerable<T> collection)
            where T : INavigtable
        {
            this.Bind(collection, null);
        }

        public void Bind<T>(IEnumerable<T> collection, MapAction<T, INavigtable> mapper)
            where T : INavigtable
        {
            foreach (var item in collection)
            {
                var navItem = creator.Invoke(item as INavigtable);
                if (mapper != null)
                {
                    if (mapper.Invoke(item, navItem) == false)
                        continue;
                }
                Container.Items.Add(navItem);
                Container.OnItemAdded(navItem);
            }
        }
    }
}
