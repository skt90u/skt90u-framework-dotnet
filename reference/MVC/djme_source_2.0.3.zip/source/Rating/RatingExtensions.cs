﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Mvc;

namespace DNA.Mvc.jQuery
{
    public static class RatingExtensions
    {
        public static MvcHtmlString Rating(this AjaxHelper helper, string name, double value)
        {
            return Rating(helper, name, value, null, null, null, new RatingOptions() { ReadOnly = true });
        }

        public static MvcHtmlString Rating(this AjaxHelper helper, string name, double value, string action)
        {
            return Rating(helper, name, value, null, action, null, null);
        }

        public static MvcHtmlString Rating(this AjaxHelper helper, string name, double value, string action, object routeData)
        {
            return Rating(helper, name, value, null, action, routeData, null);
        }

        public static MvcHtmlString Rating(this AjaxHelper helper, string name, double value, string action, string controller)
        {
            return helper.Rating(name, value, action, controller, null, null);
        }

        public static MvcHtmlString Rating(this AjaxHelper helper, string name, double value, string action, string controller, object routeData, RatingOptions options)
        {
            TagBuilder div = new TagBuilder("div");
            div.GenerateId(name);
            //div.Attributes.Add("id", name);
            RatingOptions opts = options == null ? new RatingOptions() : options;
            opts.Value = value;
            if (!string.IsNullOrEmpty(action))
            {
                string ctrl = !string.IsNullOrEmpty(controller) ? controller : helper.ViewContext.RouteData.Values["controller"].ToString();
                UrlHelper Url = new UrlHelper(helper.ViewContext.RequestContext);
                string actionUrl = Url.Action(action, ctrl);
                StringBuilder scripts = new StringBuilder();

                if (routeData != null)
                {
                    OptionBuilder _route = new OptionBuilder();
                    _route.AddOptions(routeData);
                    scripts.Append("var _d=");
                    scripts.Append(_route.ToString());
                    scripts.Append(";");
                }
                else
                    scripts.Append("var _d={};");

                scripts.Append("_d.value=value;");
                scripts.Append("$.post(\"");
                scripts.Append(actionUrl);
                scripts.Append("\",_d");
                scripts.Append(",function(v){ if (v){$('#" + name + "').rating('setValue',v);}} ");
                scripts.Append(")");

                if (!string.IsNullOrEmpty(opts.OnChanged))
                    opts.OnChanged += scripts.ToString();
                else
                    opts.OnChanged = scripts.ToString();
            }


            helper.jQuery("#" + div.Attributes["id"], "rating", opts);
            return MvcHtmlString.Create(div.ToString());
        }

        public static MvcHtmlString Rating(this AjaxHelper helper, string name, RatingOptions options)
        {
            TagBuilder div = new TagBuilder("div");
            div.GenerateId(name);
            //div.Attributes.Add("id", name);
            helper.jQuery("#" + div.Attributes["id"], "rating", options);
            return MvcHtmlString.Create(div.ToString());
        }
    }
}
