﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Mvc;

namespace DNA.Mvc.jQuery
{
    /// <summary>
    /// Defines the Rating plugin options.
    /// </summary>
    public class RatingOptions
    {
        /// <summary>
        /// Gets/Sets the initialize value of the rating.
        /// </summary>
        [jQueryOption("value")]
        public double? Value { get; set; }

        /// <summary>
        /// Gets/Sets how many stars shows in rating plugin.
        /// </summary>
        [jQueryOption("maxrating")]
        public int? MaxRating{get;set;}

        /// <summary>
        /// Gets/Sets whether allows the users post the rating value to server.
        /// </summary>
        [jQueryOption("readOnly")]
        public bool? ReadOnly { get; set; }

        /// <summary>
        /// Gets/Sets the star icon css class.
        /// </summary>
        [jQueryOption("starIcon")]
        public string StarIconCssClass { get; set; }

        /// <summary>
        /// Gets/Sets the rating element css class.
        /// </summary>
        [jQueryOption("cssClass")]
        public string CssClass { get; set; }

        /// <summary>
        /// Gets/Sets the css class when the mouse hove the star.
        /// </summary>
        [jQueryOption("hoverClass")]
        public string HoverCssClass { get; set; }

        /// <summary>
        /// Gets/Sets the client event scripts when the rating value is changed.
        /// </summary>
        [jQueryOption("change", ValueType = JavaScriptTypes.Function, FunctionParams = new string[] { "event", "value" })]
        public string OnChanged { get; set; }
    }
}
