﻿//  Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DNA.Mvc
{
    /// <summary>
    /// Defines the template delegate or template text that makes the component temlpatable.
    /// </summary>
    public class TemplateViewComponent : ViewComponent
    {
        // public string Title { get; set; }

        /// <summary>
        /// Gets/Sets a delegate method allows developers inject the template code at runtime.
        /// </summary>
        public Action Template { get; set; }

        ///// <summary>
        ///// Gets/Sets the html template plain text.
        ///// </summary>
        //public Action HtmlTemplate { get; set; }

        /// <summary>
        /// Redner the Template to ViewContent
        /// </summary>
        public override void RenderContent(System.Web.UI.HtmlTextWriter writer)
        {
            //if (HtmlTemplate != null)
            //{
            //    writer.WriteBeginTag("")
            //    //writer.Write(HtmlTemplate);
            //}
            //else
            //{
            if (Template != null)
                Template.Invoke();
            //}
        }
        //public override void RenderEndTag(System.Web.UI.HtmlTextWriter writer)
        //{
        //    base.RenderEndTag(writer);

        //}
    }
}
