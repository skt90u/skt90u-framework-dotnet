﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Mvc;

namespace DNA.Mvc.jQuery
{
    /// <summary>
    /// Defines the jQueryActionLinkOptons for jQuery plugin
    /// </summary>
    public class jQueryActionLinkOptions
    {
        /// <summary>
        /// Gets/Sets the jQueryActionLink Text
        /// </summary>
        [jQueryOption("text")]
        public string Text { get; set; }

        /// <summary>
        /// Gets/Sets the icon css class name display on the left of the actionlink
        /// </summary>
        [jQueryOption("icon")]
        public string IconCssClass { get; set; }

        /// <summary>
        /// Gets/Sets the client click scripts
        /// </summary>
        /// <remarks>
        /// if this property sets the jQueryActionLink will ignore the link behavior 
        /// </remarks>
        [jQueryOption("click", ValueType = JavaScriptTypes.Function, FunctionParams = new string[] { "event"})]
        public string OnClick { get; set; }

        /// <summary>
        /// Gets/Sets the css class name of the actionlink
        /// </summary>
        [jQueryOption("cssClass")]
        public string CssClass { get; set; }

        /// <summary>
        /// Gets/Sets the hover css class name of actionlink
        /// </summary>
        [jQueryOption("hoverClass")]
        public string HoverCssClass { get; set; }
    }
}
