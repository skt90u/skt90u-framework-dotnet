﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Mvc;

namespace DNA.Mvc.jQuery
{
    /// <summary>
    /// Define the jQueryActionLink extension methods
    /// </summary>
    public static class ActionLinkExtensions
    {
        public static MvcHtmlString jQueryActionLink(this AjaxHelper helper, string text, string cssClass, string action)
        {
            return helper.jQueryActionLink(text, cssClass, action, "");
        }

        public static MvcHtmlString jQueryActionLink(this AjaxHelper helper, string text, string cssClass, StringBuilder scripts)
        {
            return helper.jQueryActionLink(text, cssClass, scripts, null);
        }

        public static MvcHtmlString jQueryActionLink(this AjaxHelper helper, string text, string cssClass, StringBuilder scripts, object htmlAttributes)
        {
            if (scripts == null)
                throw new ArgumentNullException("The client script is null!");

            return helper.jQueryActionLink(new jQueryActionLinkOptions() { Text = text, IconCssClass = cssClass, OnClick = scripts.ToString() }, htmlAttributes);
        }

        public static MvcHtmlString jQueryActionLink(this AjaxHelper helper, string text, string cssClass, string action, string controller)
        {
            return helper.jQueryActionLink(text, cssClass, action, controller, null);
        }

        public static MvcHtmlString jQueryActionLink(this AjaxHelper helper, string text, string cssClass, string action, string controller, object routeData)
        {
            return helper.jQueryActionLink(action, controller, routeData, new jQueryActionLinkOptions() { Text = text, IconCssClass = cssClass }, null);
        }

        public static MvcHtmlString jQueryActionLink(this AjaxHelper helper, string text, string cssClass, string action, string controller, object routeData, object htmlAttributes)
        {
            return helper.jQueryActionLink(action, controller, routeData, new jQueryActionLinkOptions() { Text = text, IconCssClass = cssClass }, htmlAttributes);
        }

        public static MvcHtmlString jQueryActionLink(this AjaxHelper helper, jQueryActionLinkOptions options, object htmlAttributes)
        {
            return helper.jQueryActionLink("", "", null, options, htmlAttributes);
        }

        public static MvcHtmlString jQueryActionLink(this AjaxHelper helper, string action, string controller, object routeData, jQueryActionLinkOptions options, object htmlAttributes)
        {
            string defaultController = string.IsNullOrEmpty(controller) ? helper.ViewContext.RouteData.Values["controller"].ToString() : controller;
            string btnID = Guid.NewGuid().ToString().Substring(0, 5);
            var opts = options != null ? options : new jQueryActionLinkOptions();

            TagBuilder a = new TagBuilder("a");
            a.Attributes.Add("id", btnID);

            if (string.IsNullOrEmpty(opts.OnClick))
            {
                UrlHelper Url = new UrlHelper(helper.ViewContext.RequestContext);
                string url = routeData == null ? Url.Action(action, defaultController) : url = Url.Action(action, defaultController, routeData);
                a.Attributes.Add("href", url);
            }

            if (htmlAttributes != null)
                a.MergeAttributes<string, object>(ObjectHelper.ConvertObjectToDictionary(htmlAttributes));

            helper.jQuery("#" + btnID, "actionLink", opts);
            return MvcHtmlString.Create(a.ToString());
        }

        public static MvcHtmlString jQueryActionLink(this AjaxHelper helper, string text, string icon, string action, string controller, object routeData, jQueryAjaxOptions options, object htmlAttributes)
        {
            if (string.IsNullOrEmpty(action))
                throw new ArgumentNullException("The action counld not be empty");
            if (options == null)
                throw new ArgumentNullException("The options could not be null");
            string defaultController = string.IsNullOrEmpty(controller) ? helper.ViewContext.RouteData.Values["controller"].ToString() : controller;
            UrlHelper Url = new UrlHelper(helper.ViewContext.RequestContext);
            options.Url = routeData == null ? Url.Action(action, defaultController) : Url.Action(action, defaultController, routeData);
            string clientClick = helper.GeneratejQueryAjaxScripts(options);
            return helper.jQueryActionLink(action, controller, routeData, new jQueryActionLinkOptions() { Text = text, IconCssClass = icon, OnClick = clientClick }, htmlAttributes);
        }

        public static MvcHtmlString jQueryActionLink(this AjaxHelper helper, string text, string iconCssClass, string routeName, string action, string controller, System.Web.Routing.RouteValueDictionary values, jQueryActionLinkOptions options, object htmlAttributes)
        {
            string url = UrlHelper.GenerateUrl(routeName,
                                                                 action,
                                                                 controller,
                                                                 values,
                                                                 System.Web.Routing.RouteTable.Routes,
                                                                 helper.ViewContext.RequestContext, 
                                                                 true
                                                                );

            string btnID = Guid.NewGuid().ToString().Substring(0, 5);
            var opts = options != null ? options : new jQueryActionLinkOptions();

            if (!string.IsNullOrEmpty(iconCssClass))
                opts.IconCssClass = iconCssClass;

            TagBuilder a = new TagBuilder("a");
            a.Attributes.Add("id", btnID);
            a.Attributes.Add("href", url);

            if (htmlAttributes != null)
                a.MergeAttributes<string, object>(ObjectHelper.ConvertObjectToDictionary(htmlAttributes));
            if (!string.IsNullOrEmpty(text))
                opts.Text = text;

            helper.jQuery("#" + btnID, "actionLink", opts);
            return MvcHtmlString.Create(a.ToString());
        }
    }
}
