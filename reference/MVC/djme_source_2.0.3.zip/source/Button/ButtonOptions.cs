﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DNA.Mvc.jQuery
{
    /// <summary>
    /// Define the button options
    /// </summary>
    public class ButtonOptions
    {
        /// <summary>
        /// Gets/Sets whether to show any text - 
        /// when set to false (display no text), icons (see icons option) must be enabled, otherwise it'll be ignored.
        /// </summary>
        [jQueryOption("text")]
        public bool? ShowText { get; set; }

        /// <summary>
        /// Gets/Sets disables (true) or enables (false) the button. Can be set when initialising (first creating) the button.
        /// </summary>
        [jQueryOption("icons",ValueType=JavaScriptTypes.Object)]
        public ButtonIcons Icons { get; set; }

        /// <summary>
        /// Gets/Sets the css class of the button.
        /// </summary>
        [jQueryOption("disabled")]
        public bool? Disabled { get; set; }

        /// <summary>
        /// Gets/Sets the the text to show on the button.
        /// </summary>
        [jQueryOption("label")]
        public string Text { get; set; }

        /// <summary>
        /// Gets/Sets the click event handle scripts.
        /// </summary>
        [jQueryIgnore]
         public string OnClick { get; set; }

        /// <summary>
        /// Define the button icon styles
        /// </summary>
        public class ButtonIcons 
        {
            /// <summary>
            /// Gets/Sets the primary icon class name that show on the left of the button.
            /// </summary>
            [jQueryOption("primary")]
            public string PrimaryIconCssClass { get; set; }

            /// <summary>
            /// Gets/Sets the secondary icon class name that show on the right of the button
            /// </summary>
            [jQueryOption("secondary")]
            public string SecondaryIconCssClass { get; set; }
        }
    }
}
