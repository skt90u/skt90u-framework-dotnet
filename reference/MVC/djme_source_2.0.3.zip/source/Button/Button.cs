﻿//  Copyright (c) 2011 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.UI;
using System.Web.Mvc;

namespace DNA.Mvc.jQuery
{
    public class Button : ViewComponent
    {
        private List<ButtonState> states = new List<ButtonState>();

        private string text = "";

        public string Text
        {
            get { return text; }
            set { text = value; }
        }

        public bool HasValue { get; set; }

        public string Value { get; set; }

        public List<ButtonState> States
        {
            get { return states; }
            set { states = value; }
        }

        public override void RenderBeginTag(HtmlTextWriter writer)
        {
            TagBuilder _tag = new TagBuilder(TagName);
            _tag.MergeAttribute("id", Id);

            if (this.HtmlAttributes != null)
                _tag.MergeAttributes<string, object>(HtmlAttributes);
            writer.Write(_tag.ToString(TagRenderMode.StartTag));

            if (HasValue)
            {
                var _input = new TagBuilder("input");
                _input.AddCssClass("d-button-value");
                _input.MergeAttribute("type", "hidden");
                _input.MergeAttribute("name", Name);
                _input.MergeAttribute("value", Value);
                writer.Write(_input.ToString(TagRenderMode.SelfClosing));
            }
        }

        public override void RenderContent(HtmlTextWriter writer)
        {
                writer.Write(text);
        }

        
    }
}
