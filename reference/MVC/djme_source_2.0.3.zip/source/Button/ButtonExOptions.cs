﻿//  Copyright (c) 2011 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DNA.Mvc.jQuery
{
    public class ButtonExOptions
    {
        private ButtonTypes buttonType = ButtonTypes.Standard;
        [jQueryOption("type")]
        public ButtonTypes ButtonType 
        {
            get { return buttonType; }
            set {
                buttonType = value;
                if (value == ButtonTypes.RadioBox)
                    IsRadio = true;
            }
        }

        [jQueryIgnore]
        public bool IsSubmitButton { get; set; }

        [jQueryOption("isbg")]
        public bool? IsBackgroundImage { get; set; }

        [jQueryOption("clientClick", ValueType = JavaScriptTypes.Function, FunctionParams = new string[] { "event" })]
        public string OnClick { get; set; }

        [jQueryOption("stateChanged", ValueType = JavaScriptTypes.Function, FunctionParams = new string[] { "event","value" })]
        public string OnStateChanged { get; set; }

        [jQueryOption("hoverClass")]
        public string HoverCssClass { get; set; }

        [jQueryOption("hoverImage")]
        public string HoverImageUrl { get; set; }

        [jQueryOption("downImage")]
        public string MouseDownImageUrl { get; set; }

        [jQueryOption("target")]
        public string Target { get; set; }

        [jQueryOption("linkUrl")]
        public string NavigateUrl { get; set; }

        [jQueryOption("imageUrl")]
        public string ImageUrl { get; set; }

        [jQueryOption("primaryIconImage")]
        public string PrimaryIconImageUrl { get; set; }

        [jQueryOption("primaryIcon")]
        public string PrimaryIconCssClass { get; set; }

        [jQueryOption("secondaryIcon")]
        public string SecondaryIconCssClass { get; set; }

        [jQueryOption("secondaryIconImage")]
        public string SecondaryIconImageUrl { get; set; }

        [jQueryOption("group")]
        public string GroupName { get; set; }

        [jQueryOption("radio")]
        public bool? IsRadio { get; set; }

        [jQueryIgnore]
        public object Value { get; set; }

        private string groupContainer = null;

        [jQueryOption("containment")]
        public string GroupContainer 
        {
            get { return groupContainer; }
            set 
            {
                if ((!value.StartsWith("#")) || (!value.StartsWith(".")))
                    groupContainer="#"+value;
                else
                    groupContainer=value;
            }
        }

        [jQueryOption("splitButton")]
        public bool? ShowSplitButton { get; set; }

        [jQueryOption("spliterClick", ValueType = JavaScriptTypes.Function, FunctionParams = new string[] { "event", "sender" })]
        public string OnSplitButtonClick { get; set; }

        [jQueryOption("oncommand", ValueType = JavaScriptTypes.Function, FunctionParams = new string[] { "event", "cmd" })]
        public string OnCommand { get; set; }
    }
}
