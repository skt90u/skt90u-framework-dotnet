﻿//  Copyright (c) 2011 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DNA.Mvc.jQuery
{
    public class ButtonStateFactory
    {
        private List<ButtonState> states = new List<ButtonState>();

        internal List<ButtonState> States { get { return states; } }
        
        public ButtonState Add() 
        {
            var state = new ButtonState();
            states.Add(state);
            return state;
        }

        public ButtonState Add(string text)
        {
            return this.Add(text, null, null);
        }

        public ButtonState Add(string text, object value)
        {
            return this.Add(text, value, null);
        }

        public ButtonState Add(string text, object value, string imageUrl)
        {
            var state = new ButtonState()
            {
                Text = text,
                Value = value,
                ImageUrl = imageUrl,
            };
            states.Add(state);
            return state;
        }
    }
}
