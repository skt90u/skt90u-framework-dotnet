﻿//  Copyright (c) 2011 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DNA.Mvc.jQuery
{
    public class ButtonState
    {
        public string Text { get; set; }

        public string ImageUrl { get; set; }

        public string PrimaryIconImageUrl { get; set; }

        public string PrimaryIconCssCass { get; set; }

        public string SecondaryIconCssClass { get; set; }

        public string SecondaryIconImageUrl { get; set; }

        public string CssClass { get; set; }

        public object Value { get; set; }

        public bool Selected { get; set; }

        public ButtonState ToggleClass(string cssClass)
        {
            CssClass= cssClass;
            return this;
        }

        public ButtonState ImageIcons(string primary)
        {
            return this.ImageIcons(primary, null);
        }

        public ButtonState ImageIcons(string primary, string secondary)
        {
            this.PrimaryIconImageUrl = primary;
            this.SecondaryIconImageUrl = secondary;
            return this;
        }

        public ButtonState ButtonImageUrl(string imgUrl)
        {
            ImageUrl = imgUrl;
            return this;
        }

        public ButtonState Icons(string primary, string secondary)
        {
            this.PrimaryIconCssCass = primary;
            this.SecondaryIconCssClass = secondary;
            return this;
        }

        public ButtonState Icons(string primary)
        {
            return this.Icons(primary, null);
        }

        public ButtonState ButtonText(string text)
        {
            this.Text = text;
            return this;
        }
        
        public ButtonState SetValue(object value)
        {
            Value = value;
            return this;
        }

        public ButtonState Select(bool value)
        {
            Selected = value;
            return this;
        }
    }
}
