﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Mvc;
using System.Web.Mvc.Ajax;
using System.Web;

namespace DNA.Mvc.jQuery
{
    /// <summary>
    /// Represents support for jQuery  button plugin controls in an application.
    /// </summary>
    public static class ButtonExtensions
    {
        /// <summary>
        /// Render the button Html and register the button plugin script
        /// </summary>
        /// <param name="helper">The Ajax helper</param>
        /// <param name="text">Specifity the button text</param>
        /// <param name="onClick">Specifity the client script to handle the button click event.</param>
        /// <returns>Retuns the button html</returns>
        public static MvcHtmlString Button(this AjaxHelper helper, string text, string onClick)
        {
            return helper.Button(text, "", onClick);
        }

        /// <summary>
        ///  Render the button Html and register the button plugin script
        /// </summary>
        /// <param name="helper">The Ajax helper</param>
        /// <param name="text">Specifity the button text</param>
        /// <param name="iconCssClass">the icon css class name display on the left of the button</param>
        /// <param name="onClick">Specifity the client script to handle the button click event.</param>
        /// <returns>Retuns the button html</returns>
        public static MvcHtmlString Button(this AjaxHelper helper, string text, string iconCssClass, string onClick)
        {
            return helper.Button("",
                new ButtonOptions()
                {
                    Text = text,
                    Icons = new ButtonOptions.ButtonIcons() { PrimaryIconCssClass = iconCssClass },
                    OnClick = onClick
                }, null);
        }

        public static MvcHtmlString Button(this AjaxHelper helper, ButtonOptions options, object htmlAttributes)
        {
            return helper.Button(string.Empty,options, htmlAttributes);
        }

        /// <summary>
        /// Render the button Html and register the button plugin script
        /// </summary>
        /// <param name="helper">The Ajax helper</param>
        /// <param name="name">specified the name of the button</param>
        /// <param name="options">The ButtonOptions instance</param>
        /// <param name="htmlAttributes"></param>
        /// <returns>Retuns the button html</returns>
        public static MvcHtmlString Button(this AjaxHelper helper, string name, ButtonOptions options, object htmlAttributes)
        {
            TagBuilder buttonLink = new TagBuilder("button");
            var n = string.IsNullOrEmpty(name) ? Guid.NewGuid().ToString().Substring(0, 5) : name;
            //buttonLink.GenerateId(n);
            buttonLink.Attributes.Add("id", n);
            //buttonLink.Attributes.Add("type", "button");
            if (htmlAttributes != null)
                buttonLink.MergeAttributes<string, object>(ObjectHelper.ConvertObjectToDictionary(htmlAttributes));
            if (options != null)
                helper.jQuery("#" + n, "button", options);
            else
                helper.jQuery("#" + n, "button");
            if (!string.IsNullOrEmpty(options.OnClick))
            {
                helper.RegisterStartupScript("$('#" + n + "').click(function(event){event.preventDefault();" + options.OnClick + "});");
            }

            return MvcHtmlString.Create(buttonLink.ToString());
        }

        /// <summary>
        /// Render the submit button Html and register the button plugin script
        /// </summary>
        /// <param name="helper">The Ajax helper</param>
        /// <param name="text">Specifity the button text</param>
        /// <param name="iconCssClass">the icon css class name display on the left of the button</param>
        /// <param name="htmlAttributes"></param>
        /// <returns>Retuns the submit html</returns>
        public static MvcHtmlString Submit(this AjaxHelper helper, string text, string iconCssClass, object htmlAttributes)
        {
            TagBuilder submit = new TagBuilder("input");
            submit.Attributes.Add("type", "submit");
            if (htmlAttributes != null)
                submit.MergeAttributes<string, object>(ObjectHelper.ConvertObjectToDictionary(htmlAttributes));
            submit.Attributes.Add("id", Guid.NewGuid().ToString().Substring(0, 5));

            helper.jQuery("#" + submit.Attributes["id"], "button", new ButtonOptions()
            {
                Text = text,
                Icons = new ButtonOptions.ButtonIcons() { PrimaryIconCssClass = iconCssClass }
            });
            return MvcHtmlString.Create(submit.ToString());
        }

        public static MvcHtmlString Submit(this AjaxHelper helper, string text, string iconCssClass)
        {
            return helper.Submit(text, iconCssClass, null);
        }

        /// <summary>
        /// Render the submit button Html and register the button plugin script
        /// </summary>
        /// <param name="helper">The Ajax helper</param>
        /// <param name="text">Specifity the button text</param>
        /// <returns>Retuns the submit html</returns>
        public static MvcHtmlString Submit(this AjaxHelper helper, string text)
        {
            return helper.Submit(text, "", null);
        }

        public static MvcHtmlString ActionButton(this AjaxHelper helper, string text, string iconCssClass, string action, string controller, jQueryAjaxOptions options)
        {
            return helper.ActionButton(text, iconCssClass, action, controller, options, null, null);
        }


        public static MvcHtmlString ActionButton(this AjaxHelper helper, string text, string iconCssClass, string action, string controller, jQueryAjaxOptions options, object routeData)
        {
            return helper.ActionButton(text, iconCssClass, action, controller, options, routeData, null);
        }

        public static MvcHtmlString ActionButton(this AjaxHelper helper, string text, string iconCssClass, string action, string controller, jQueryAjaxOptions options, object routeData, object htmlAttributes)
        {
            if (string.IsNullOrEmpty(action))
                throw new ArgumentNullException("The action counld not be empty");
            if (options == null)
                throw new ArgumentNullException("The options could not be null");
            string defaultController = string.IsNullOrEmpty(controller) ? helper.ViewContext.RouteData.Values["controller"].ToString() : controller;
            UrlHelper Url = new UrlHelper(helper.ViewContext.RequestContext);
            options.Url = routeData == null ? Url.Action(action, defaultController) : Url.Action(action, defaultController, routeData);

            string clientClick = helper.GeneratejQueryAjaxScripts(options);

            return helper.Button(new ButtonOptions()
            {
                Text = text,
                ShowText = !string.IsNullOrEmpty(text),
                Icons = new ButtonOptions.ButtonIcons() { PrimaryIconCssClass = iconCssClass },
                OnClick = clientClick
            }, htmlAttributes);
        }
    }
}
