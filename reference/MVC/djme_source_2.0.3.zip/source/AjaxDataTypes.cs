﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DNA.Mvc.jQuery
{
    /// <summary>
    /// The type of data that you're expecting back from the server. 
    /// </summary>
    public enum AjaxDataTypes
    {
        /// <summary>
        /// Returns HTML as plain text; included script tags are evaluated when inserted in the DOM. 
        /// </summary>
        Html,
        /// <summary>
        /// Returns a XML document that can be processed via jQuery
        /// </summary>
        Xml,
        /// <summary>
        /// Evaluates the response as JavaScript and returns it as plain text. Disables caching unless option "cache" is used. Note: This will turn POSTs into GETs for remote-domain requests.
        /// </summary>
        Script,
        /// <summary>
        ///  Evaluates the response as JSON and returns a JavaScript Object.
        /// </summary>
        Json,
        /// <summary>
        /// Loads in a JSON block using JSONP. Will add an extra "?callback=?" to the end of your URL to specify the callback. (Added in jQuery 1.2) 
        /// </summary>
        Jsonp,
        /// <summary>
        /// A plain text string
        /// </summary>
        Text
    }
}
