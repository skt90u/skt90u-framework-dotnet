﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Mvc;
using System.Collections;

namespace DNA.Mvc.jQuery
{
    /// <summary>
    ///  Represents support for DJP dropdown jQuery plugin control.
    /// </summary>
    public static class DropDownExtensions
    {
        /// <summary>
        ///  Render the jQuery dropdown plugin Html elements and dropdown init script
        /// </summary>
        /// <param name="helper">The Ajax Helper</param>
        /// <param name="name">The name of the dropdown.</param>
        /// <param name="nodes">The SelectableNode list that render as dropdown items.</param>
        /// <example>
        /// <code language="cs">
        ///<![CDATA[List<SelectableNode> nodes=new List<SelectableNode>();
        ///nodes.Add(new Selectable("Item1"));
        ///nodes.Add(new Selectable("Item2"));
        ///nodes.Add(new Selectable("Item3"));
        ///Ajax.DropDown("myDropDown",nodes); ]]>
        /// </code>
        ///</example>
        /// <returns>The dropdown plugin required html elements.</returns>
        public static MvcHtmlString DropDown(this AjaxHelper helper, string name, List<SelectableNode> nodes)
        {
            return DropDown<NodeUIBuilder>(helper, name, nodes, null);
        }

        /// <summary>
        /// Render the jQuery dropdown plugin Html elements and dropdown init script
        /// </summary>
        /// <param name="helper">The Ajax Helper</param>
        /// <param name="name">The name of the dropdown.</param>
        /// <param name="nodes">The SelectableNode list that render as dropdown items.</param>
        /// <param name="options">The dropdown plugin option class.</param>
        ///  <example>
        ///<code>
        ///<![CDATA[List<SelectableNode> nodes=new List<SelectableNode>();
        ///nodes.Add(new Selectable("Item1"));
        ///nodes.Add(new Selectable("Item2"));
        ///nodes.Add(new Selectable("Item3"));
        ///Ajax.DropDown<MyUIBuilder>("myDropDown",nodes,
        ///     new DropDownOptions(){
        ///                                            Editable=true
        ///                                          }
        ///); ]]>
        /// </code>
        /// </example>
        /// <returns>The dropdown plugin required html elements.</returns>
        public static MvcHtmlString DropDown(this AjaxHelper helper, string name, List<SelectableNode> nodes, DropDownOptions options)
        {
            return DropDown<NodeUIBuilder>(helper, name, nodes, options);
        }


        /// <summary>
        /// Render the jQuery dropdown plugin Html elements and dropdown init script
        /// </summary>
        /// <typeparam name="UIBuilder">The NodeUIBuilder class which controls the SelectableNodes rendering as html elements. </typeparam>
        /// <param name="helper">The Ajax Helper</param>
        /// <param name="name">The name of the dropdown.</param>
        /// <param name="nodes">The SelectableNode list that render as dropdown items.</param>
        /// <param name="options">The dropdown plugin option class.</param>
        /// <returns>The dropdown plugin required html elements.</returns>
        public static MvcHtmlString DropDown<UIBuilder>(this AjaxHelper helper, string name, List<SelectableNode> nodes, DropDownOptions options)
            where UIBuilder : NodeUIBuilder
        {
            TagBuilder inputTag = new TagBuilder("input");
            inputTag.MergeAttribute("name", name);
            inputTag.MergeAttribute("type", "hidden");

            TagBuilder div = new TagBuilder("div");
            div.GenerateId(name);
            UIBuilder builder = Activator.CreateInstance<UIBuilder>();
            builder.WriteNodes(nodes.Cast<INavigtable>());
            div.InnerHtml = inputTag.ToString(TagRenderMode.SelfClosing) + builder.ToString();
            helper.jQuery("#" + div.Attributes["id"], "dropdown", options);
            return MvcHtmlString.Create(div.ToString());
        }

    }
}
