﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DNA.Mvc.jQuery
{
    /// <summary>
    /// Represents the options of the jQuery dropdown plugin
    /// </summary>
    public class DropDownOptions
    {
        /// <summary>
        /// Gets/Sets wheather can auto size the dropdown pane.
        /// </summary>
        [jQueryOption("autosize")]
        public bool? AutoSize { get; set; }
        
        [jQueryOption("source",ValueType=JavaScriptTypes.jQuerySelector)]
        public string Source { get; set; }

        /// <summary>
        /// Gets/Sets the dropdown item's class
        /// </summary>
        [jQueryOption("itemClass")]
        public string ItemCssClass { get; set; }

        /// <summary>
        /// Gets/Sets the dropdown item's hover class
        /// </summary>
        [jQueryOption("hoverClass")]
        public string ItemHoverCssClass { get; set; }

        /// <summary>
        /// Gets/Sets the dropdown icon class which display on the right of the dropdown
        /// </summary>
        [jQueryOption("iconClass")]
        public string DropDownIconCssClass { get; set; }

        /// <summary>
        /// Gets/Sets the dropdown 's class 
        /// </summary>
        [jQueryOption("cssClass")]
        public string CssClass { get; set; }

        /// <summary>
        /// Gets/Sets the class which item is selected 
        /// </summary>
        [jQueryOption("selectedClass")]
        public string ItemSelectedCssClass { get; set; }

        /// <summary>
        /// Gets/Sets the hover class of the dropdown
        /// </summary>
        [jQueryOption("highlightClass")]
        public string DropDownHoverCssClass { get; set; }

        /// <summary>
        /// Gets/Sets the append text of the dropdown.If this property set when item is selected the dropdown
        /// will display the PrefixText and item text inline.
        /// </summary>
        [jQueryOption("appendText")]
        public string PrefixText { get; set; }

        /// <summary>
        /// Gets/Sets the text that when dropdown does not select any item.
        /// </summary>
        [jQueryOption("defaultText")]
        public string EmptyText { get; set; }

        /// <summary>
        /// Gets/Sets the dropdown 's height  in pixel
        /// </summary>
        [jQueryOption("height")]
        public int? Height { get; set; }

        /// <summary>
        /// Gets/Sets the dropdown's width in pixel
        /// </summary>
        [jQueryOption("width")]
        public int? Width { get; set; }

        /// <summary>
        /// Gets/Sets the dropdown container's min height.
        /// </summary>
        [jQueryOption("minHeight")]
        public int? MinListHeight { get; set; }

        /// <summary>
        /// Gets/Sets the jQuery selector used to select the text element.
        /// </summary>
        [jQueryOption("textField")]
        public string TextFieldSelector { get; set; }

        /// <summary>
        /// Gets/Sets the jQuery selector used to select the value element.
        /// </summary>
        [jQueryOption("valueField")]
        public string ValueFieldSelector { get; set; }

        /// <summary>
        /// Gets/Sets the jQuery selector that used to select the dropdown items container element.
        /// </summary>
        [jQueryOption("container")]
        public string DropDownContainerSelector { get; set; }

        /// <summary>
        /// Gets/Sets the jQuery selector that used to select the dropdown items.
        /// </summary>
        [jQueryOption("items")]
        public string ItemSelector { get; set; }

        /// <summary>
        /// Gets/Sets the index which item should be select.
        /// </summary>
        [jQueryOption("selectedIndex")]
        public int? SelectedIndex { get; set; }

        /// <summary>
        /// Gets/Sets the value which item should be select.
        /// </summary>
        [jQueryOption("selectedValue")]
        public string SelectedValue { get; set; }

        /// <summary>
        /// Gets/Sets whether the dropdown container can be resize.
        /// </summary>
        [jQueryOption("resizable")]
        public bool? Resizable { get; set; }

        /// <summary>
        /// Gets/Sets whether the dropdown can accept use input.
        /// </summary>
        [jQueryOption("editable")]
        public bool? Editable { get; set; }

        [jQueryOption("selectWholeItem")]
        public bool? SelectWholeItem { get; set; }

        /// <summary>
        /// Gets/Sets the client event handler script to handle dropdown 's selectedChanged event.
        /// </summary>
        [jQueryOption("selectedChanged", ValueType = JavaScriptTypes.Function,FunctionParams=new string[]{"event","ui"})]
        public string OnClientSelectedChanged { get; set; }

        /// <summary>
        /// Gets/Sets the client event handler script to handle dropdown 's  open event.
        /// </summary>
        [jQueryOption("beforeOpen", ValueType = JavaScriptTypes.Function)]
        public string OnClientBeforeOpen { get; set; }

        /// <summary>
        /// Gets/Sets the client event handler script to handle after dropdown 's  open event.
        /// </summary>
        [jQueryOption("afterOpen", ValueType = JavaScriptTypes.Function)]
        public string OnClientAfterOpen { get; set; }

        /// <summary>
        /// Gets/Sets the client event handler script to handle before dropdown 's close event.
        /// </summary>
        [jQueryOption("beforeClose", ValueType = JavaScriptTypes.Function)]
        public string OnClientBeforeClose { get; set; }

        /// <summary>
        /// Gets/Sets the client event handler script to handle after dropdown 's close event.
        /// </summary>
        [jQueryOption("afterClose", ValueType = JavaScriptTypes.Function)]
        public string OnAfterClose { get; set; }
    }
}
