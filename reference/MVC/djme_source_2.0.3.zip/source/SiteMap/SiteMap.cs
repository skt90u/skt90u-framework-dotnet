﻿//  Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Mvc;
using System.Web;
using System.Web.UI;
using System.Xml;

namespace DNA.Mvc.jQuery
{
    public class SiteMap : DataBindableComponent<SiteMapNode>
    {        
        private int columnCount = 2;
        private int displayLevels = 2;
        private DNA.Mvc.jQuery.Orientation orientation = Orientation.Horizontal;

        public DNA.Mvc.jQuery.Orientation RepeatDirection
        {
            get { return orientation; }
            set { orientation = value; }
        }

        public List<SiteMapNode> SiteMapNodes
        {
            get { return InnerItems.Select(item => { return (SiteMapNode)item; }).ToList(); }
            set { InnerItems = value; }
        }

        public override string TagName
        {
            get
            {
                return "div";
            }
        }

        public int ColumnCount
        {
            get { return columnCount; }
            set { columnCount = value; }
        }

        public int DisplayLevels
        {
            get { return displayLevels; }
            set { displayLevels = value; }
        }

        public override void RenderContent(HtmlTextWriter writer)
        {
            //base.RenderContent(writer);
            if (columnCount<=0) columnCount=1;
            int maxColumns =(this.columnCount<=InnerItems.Count ) ? this.columnCount : InnerItems.Count;
            var presentWidth = ((double)1 / (double)maxColumns) * 100;
            int index=0;
            int colRows =Convert.ToInt16(Math.Round((double)InnerItems.Count / (double)maxColumns));

            for (int cols = 0; cols < maxColumns; cols++) //Top level node loop controlling layouts
            {
                writer.WriteBeginTag("ul");
                writer.WriteAttribute("class", "ui-helper-reset d-sitemap-column");
                writer.WriteAttribute("style", "float:left;width:" + presentWidth.ToString() + "%");
                writer.Write(HtmlTextWriter.TagRightChar);
                //Lv2 rendering
                for (int step = 0; step < colRows; step++)
                {
                    if (index == InnerItems.Count)
                        break;
                    var n = InnerItems[index];
                    n.MergeAttribute("class", "d-sitemap-top-node");
                    n.Render(writer);
                    index++;
                }
                writer.WriteEndTag("ul");
            }
        }

        public override void RenderEndTag(HtmlTextWriter writer)
        {
            writer.WriteBeginTag("div");
            writer.WriteAttribute("style", "clear:left;width:0px;height:0px;");
            writer.Write(HtmlTextWriter.TagRightChar);
            writer.WriteEndTag("div");
            base.RenderEndTag(writer);
        }
    }

}
