﻿//  Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Mvc;
using System.Web;
using System.Web.UI;
using System.Xml;

namespace DNA.Mvc.jQuery
{
    public class SiteMapNodeFactory : NodeItemFactory<SiteMap, SiteMapNode, SiteMapNodeBuilder, SiteMapNodeFactory>
    {
        public SiteMapNodeFactory(IComponentItemContainer<SiteMapNode> container, AjaxHelper helper) : base(container, helper) { }

        protected override SiteMapNode CreateNodeInstance()
        {
            return new SiteMapNode();
        }

        protected override SiteMapNode CreateNodeInstance(INavigtable node)
        {
            return new SiteMapNode(node);
        }

        protected override SiteMapNodeBuilder CreateBuilder(SiteMapNode node)
        {
            return new SiteMapNodeBuilder(node, Helper);
        }
    }
}
