﻿//  Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Mvc;
using System.Web;
using System.Web.UI;
using System.Xml;

namespace DNA.Mvc.jQuery
{
    public class SiteMapBuilder : DataBindableComponentBuilder<SiteMap, SiteMapNode, SiteMapNodeFactory, SiteMapBuilder>
    {
        public SiteMapBuilder(SiteMap sitemap, AjaxHelper helper) : base(sitemap, helper) { }

        protected override SiteMapNodeFactory CreateNodeItemFactory()
        {
            return new SiteMapNodeFactory(Component, Helper) { NodeContainer = Component };
        }

        protected override HierarchialBindingFactory<SiteMapNode, SiteMap> CreateBindingFactory()
        {
            return new HierarchialBindingFactory<SiteMapNode, SiteMap>(Component, (item) =>
            {
                return new SiteMapNode(item) { Container = this.Component };
            });
        }

        public SiteMapBuilder Columns(int count)
        {
            if (count > 0)
                Component.ColumnCount = count;
            return this;
        }

        public SiteMapBuilder Levels(int levels)
        {
            if (levels > 0)
                Component.DisplayLevels = levels;
            return this;
        }

        public SiteMapBuilder Direction(DNA.Mvc.jQuery.Orientation direction)
        {
            Component.RepeatDirection = direction;
            return this;
        }
    }
}
