﻿//  Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.UI;


namespace DNA.Mvc.jQuery
{
    public class SiteMapNode : NodeBase<SiteMap, SiteMapNode>
    {
        public SiteMapNode() { }

        public SiteMapNode(INavigtable node) : base(node) { }

        public int ColumnCount
        {
            get { return columnCount; }
            set { columnCount = value; }
        }

        private int columnCount = 2;

        public override void RenderBeginTag(HtmlTextWriter writer)
        {
            //this.MergeAttribute("class", "d-sitemap-node");
            this.MergeAttribute("style", "overflow:hidden;");
            base.RenderBeginTag(writer);
        }

        public override void RenderContent(System.Web.UI.HtmlTextWriter writer)
        {
            if (Template != null)
                base.RenderContent(writer);
            else
                RenderNodeContent(writer);

            if (Children.Count > 0)
            {
                if ((Container.DisplayLevels <= 0) || ( this.Level<Container.DisplayLevels ))
                {
                    writer.WriteBeginTag("div");
                    writer.WriteAttribute("style", "clear:left;overflow:auto;");
                    writer.WriteAttribute("class", "d-sitemap-container");
                    writer.Write(HtmlTextWriter.TagRightChar);
                    if (columnCount <= 0) columnCount = 1;

                    int maxColumns = (this.columnCount <= Children.Count) ? this.columnCount : Children.Count;

                    var presentWidth = ((double)1 / (double)maxColumns) * 100;
                    int index = 0;
                    int colRows = Convert.ToInt16(Math.Round((double)Children.Count / (double)maxColumns));

                    for (int cols = 0; cols < maxColumns; cols++) //Top level node loop controlling layouts
                    {
                        writer.WriteBeginTag("ul");
                        writer.WriteAttribute("class", "ui-helper-reset");
                        writer.WriteAttribute("style", "float:left;width:" + presentWidth.ToString() + "%");
                        writer.Write(HtmlTextWriter.TagRightChar);
                        //Lv2 rendering
                        for (int step = 0; step < colRows; step++)
                        {
                            ///UNDONE:这里有错，奇数列会缺少最后一行
                            Children[index].MergeAttribute("class", "d-sitemap-node");
                            Children[index].Render(writer);
                            index++;
                            if (index == Children.Count)
                                break;
                        }
                        writer.WriteEndTag("ul");
                    }

                    writer.WriteEndTag("div");
                }
            }
        }

        public virtual void RenderNodeContent(System.Web.UI.HtmlTextWriter writer)
        {
            var builder = new NodeUIBuilder();

            if (!string.IsNullOrEmpty(this.NavigateUrl))
                builder.WriteBeginLink(this, new { @class="d-sitemap-node-link"});


            if (!string.IsNullOrEmpty(this.ImageUrl))
                builder.WriteImage(this, new { @class = "d-sitemap-node-img" });

            builder.WriteTitle(this, new { @class = "d-sitemap-node-text",style = "padding:2px;cursor:default;display:inline-block;" });

            if (!string.IsNullOrEmpty(this.NavigateUrl))
                builder.WriteEndTag("a");

            writer.Write(builder.ToString());
        }
    }
}
