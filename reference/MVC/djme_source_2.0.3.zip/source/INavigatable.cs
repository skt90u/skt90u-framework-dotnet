﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DNA.Mvc
{
    /// <summary>
    /// Defines properties of a navigable object.
    /// </summary>
    public interface INavigtable
    {
        /// <summary>
        /// Retrieves the display title 
        /// </summary>
        string Title { get; }

        /// <summary>
        /// Gets the description to show as tooltip.
        /// </summary>
        string Description { get; }

        /// <summary>
        /// Gets the target uri of the navigable object.
        /// </summary>
        string NavigateUrl { get; }

        /// <summary>
        /// Gets the image url that use to display the icon.
        /// </summary>
        string ImageUrl { get; }

        /// <summary>
        /// Gets the open target mode this value maybe sets window's name,"_blank","_parent","_self","_top"
        /// </summary>
        string Target { get; }

        /// <summary>
        /// Gets the additational object in the navigatable object.
        /// </summary>
        object Value { get; }
    }

}
