﻿//  Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Mvc;
using System.Web.UI;
using System.Xml;

namespace DNA.Mvc.jQuery
{
    public class MenuBuilder : jQueryDataBindableComponentBuilder<MenuOptions, Menu, MenuItem, MenuItemFactory, MenuBuilder>
    {
        public MenuBuilder(Menu menu, AjaxHelper helper) : base(menu, helper) { }

        protected override string jQueryPluginName
        {
            get { return "dnamenu"; }
        }

        public MenuBuilder DropIcons(Action<SubMenuIcons> value)
        {
            if (value != null)
                value.Invoke(Component.SubMenuDropIcons);
            return this;
        }

        public MenuBuilder ChangeType(MenuTypes type)
        {
            Options(opts => {
                opts.MenuType = type;
            });

            return this;
        }

        public MenuBuilder DefaultStyle()
        {
            if (options == null)
                options = new MenuOptions();

            DropIcons(icons =>
            {
                if (options.MenuType == MenuTypes.Horizontal)
                    icons.TopIconCssClass = "ui-icon ui-icon-triangle-1-s";
                else
                    icons.TopIconCssClass = "ui-icon ui-icon-triangle-1-e";
                icons.IconCssClass = "ui-icon ui-icon-triangle-1-e";
            });

            options.TopMenuCssClass = "d-top-menu-container";
            options.TopItemCssClass = "d-top-menu-item";
            options.TopItemHoverCssClass = "d-top-menu-item-hover";
            options.TopItemSelectedCssClass = "d-top-menu-item-selected";

            //options.SubMenuCssClass = "d-top-menu-container";
            options.SubMenuItemCssClass = "d-sub-menu-item";
            options.SubMenuItemHoverCssClass = "d-sub-menu-item-hover";
            return this;
        }

        public MenuBuilder DropdownTarget(string name)
        {
            if (!string.IsNullOrEmpty(name))
            {
                Options(opts => { opts.MenuType=MenuTypes.Context; });
                var ondropdown = new StringBuilder();
                ondropdown.Append(jQueryScriptHelper.GetjQuerySelector(name))
                    .Append(".bind(\"click\",function(){")
                    .Append(jQuerySelector)
                    .Append(".dnamenu(\"dropdown\",this);")
                    .Append("});");
                Helper.RegisterStartupScript(ondropdown.ToString());
            }
            return this;
        }

         public MenuBuilder ContextMenuTarget(string name)
        {
            if (!string.IsNullOrEmpty(name))
            {
                Options(opts => {
                    opts.MenuType = MenuTypes.Context;
                });
                var contextHandler = new StringBuilder();
                contextHandler.Append(jQueryScriptHelper.GetjQuerySelector(name))
                    .Append(".bind(\"contextmenu\",function(event){")
                    .AppendLine("event.preventDefault();")
                    .Append(jQuerySelector)
                    .AppendLine(".dnamenu(\"showMenu\",event.clientX,event.clientY); ")
                    .Append(jQuerySelector)
                    .AppendLine(".dnamenu(\"option\",\"contextElement\",this);")
                    .AppendLine("});");
                    //.Append(jQueryScriptHelper.GetjQuerySelector("document"))
                    //.AppendLine(".bind(\"contextmenu\",function(event){")
                    //.AppendLine(" event.preventDefault();")
                    //.AppendLine("});");


                Helper.RegisterStartupScript(contextHandler.ToString());
            }

            return this;
        }      
        
        public override void Render()
        {
            if (options != null)
            {
                Component.TopMenuCssClass = options.TopMenuCssClass;
                Component.TopItemSelectedCssClass = options.TopItemSelectedCssClass;
            }

            base.Render();
        }

        //public override void Render()
        //{
        //    using (var writer = new HtmlTextWriter(Helper.ViewContext.Writer))
        //    {
        //        Component.Options = options != null ? options : new MenuOptions();
        //        Component.Render(writer);
        //    }
        //    Helper.jQuery(Component.Name + "_c", jQueryPluginName, options);
        //}

        protected override MenuItemFactory CreateNodeItemFactory()
        {
            return new MenuItemFactory(Component, Helper) { Menu = Component };
        }

        protected override HierarchialBindingFactory<MenuItem, Menu> CreateBindingFactory()
        {
            return new HierarchialBindingFactory<MenuItem, Menu>(Component, (item) =>
            {
                return new MenuItem(item) { Menu = this.Component };
            });
        }
    }

}
