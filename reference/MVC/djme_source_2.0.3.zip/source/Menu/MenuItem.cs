﻿//  Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.UI;

namespace DNA.Mvc.jQuery
{
    /// <summary>
    /// Defines the methods for MenuItem node.
    /// </summary>
    public class MenuItem : NavigableView, IComponentItemContainer<MenuItem>, ISelectable
    {
        #region

        ///// <summary>
        /////  Initializes a new instance of the MenuItem
        ///// </summary>
        ///// <param name="provider">The provider contains the menu items.</param>
        //public MenuItem(MenuItemProvider provider) : base(provider) { }

        ///// <summary>
        /////  Gets/Sets the client script handling the menu click event.
        ///// </summary>
        //public string OnClientClick
        //{
        //    get
        //    {
        //        if (Attributes.ContainsKey("onclick"))
        //            return Attributes["onclick"] as string;
        //        return "";
        //    }
        //    set
        //    {
        //        if (Attributes.ContainsKey("onclick"))
        //            Attributes.Add("onclick", value);
        //        else
        //            Attributes["onclick"] = value;
        //    }
        //}

        ///// <summary>
        ///// Add the menu item by using Lamda expression
        ///// </summary>
        ///// <param name="expr">The Action delegate to  adding the menu item.</param>
        ///// <example>
        ///// <code language="cs">
        /////    &lt;%:
        /////    Ajax.Menu("MySamleMenu")
        /////    .Options(options =>
        /////    {
        /////         options.TargetID = "sitetoolsmenu";
        /////         options.DropdownEvent = DomEvents.MouseOver;
        /////         options.MenuType = MenuStyles.Dropdown;
        /////         options.TopMenuCssClass = "ui-sitetools-menu";
        /////         options.TopItemCssClass = "ui-sitetools-menuitem";
        /////         options.TopItemHoverCssClass = "ui-sitetools-menuitem-hover";
        /////     })
        /////     .Items(root =>
        /////     {
        /////          root.AddMenuItem(item =>
        /////          {
        /////              item.Title ="MenuItem1";
        /////               item.NavigateUrl = "javascript:void(0);";
        /////               item.OnClientClick ="alert('The menu click')";
        /////               item.ImageUrl = Url.Content("~/Content/Images/add_content.gif");
        /////           });
        /////     });
        /////     %&gt;
        ///// </code>
        ///// </example>
        ///// <returns>The current MenuItem instance</returns>
        //public MenuItem AddMenuItem(Action<MenuItem> expr)
        //{
        //    var subItem = new MenuItem(this.Provider as MenuItemProvider);
        //    expr.Invoke(subItem);
        //    AddChildren(subItem);
        //    return subItem;
        //}

        ///// <summary>
        ///// Add the menu item by specified the menu title and navigate url.
        ///// </summary>
        ///// <param name="title">The title display on the menu item.</param>
        ///// <param name="navigateUrl">The menu navigation url</param>
        ///// <returns>The current MenuItem instance</returns>
        //public MenuItem AddMenuItem(string title, string navigateUrl)
        //{
        //    var subItem = new MenuItem(this.Provider as MenuItemProvider)
        //    {
        //        Title = title,
        //        NavigateUrl = navigateUrl
        //    };
        //    AddChildren(subItem);
        //    return subItem;
        //}
        #endregion

        public Menu Menu { get; internal set; }

        public MenuItem Parent { get; internal set; }

        public MenuItem() { }

        public MenuItem(INavigtable navItem) : base(navItem) { }

        private IList<MenuItem> items;

        public IList<MenuItem> Items
        {
            get
            {
                if (items == null)
                    items = new List<MenuItem>();
                return items;
            }
            set
            {
                items = value;
            }

        }

        IList<MenuItem> IComponentItemContainer<MenuItem>.Items
        {
            get { return this.Items; }
        }

        public override void Render(HtmlTextWriter writer)
        {
            string cssClass = "d-menu-item";
            if (!enabled) cssClass += " d-state-disabled";

            if ((isSelected) && (!string.IsNullOrEmpty(Menu.TopItemSelectedCssClass)) && (this.Parent == null))
                cssClass += " " + Menu.TopItemSelectedCssClass;

            if (this.HtmlAttributes.ContainsKey("class"))
                this.HtmlAttributes["class"] += " " + cssClass;
            else
                this.HtmlAttributes["class"] = cssClass;

            base.Render(writer);
        }

        public override void RenderContent(System.Web.UI.HtmlTextWriter writer)
        {
            if (Template != null)
                base.RenderContent(writer);
            else
            {
                var builder = new NodeUIBuilder();
                if (!string.IsNullOrEmpty(this.NavigateUrl))
                    builder.WriteBeginLink(this, new { style = "display:block;", @class = "d-menu-item-link" });

                if (!string.IsNullOrEmpty(this.ImageUrl))
                    builder.WriteImage(this, new { @class = "d-menu-item-img" });

                builder.WriteTitle(this, new { @class = "d-menu-item-text" });
                //builder.Write(this.Title);

                if (Items.Count > 0)
                {
                    if (Parent == null) //top item
                    {
                        if (!string.IsNullOrEmpty(Menu.SubMenuDropIcons.TopIconUrl))
                            builder.Write("<img src=\"" + Menu.SubMenuDropIcons.TopIconUrl + "\" />");
                        else
                        {
                            if (!string.IsNullOrEmpty(Menu.SubMenuDropIcons.TopIconCssClass))
                            {
                                builder.WriteBeginTag("span", new { @class = Menu.SubMenuDropIcons.TopIconCssClass });
                                builder.WriteEndTag("span");
                            }
                        }
                    }
                    else
                    {
                        if (!string.IsNullOrEmpty(Menu.SubMenuDropIcons.IconIconUrl))
                            builder.Write("<img src=\"" + Menu.SubMenuDropIcons.IconIconUrl + "\" />");
                        else
                        {
                            if (!string.IsNullOrEmpty(Menu.SubMenuDropIcons.IconCssClass))
                            {
                                builder.WriteBeginTag("span", new { @class = Menu.SubMenuDropIcons.IconCssClass });
                                builder.WriteEndTag("span");
                            }
                        }
                    }
                }

                if (!string.IsNullOrEmpty(this.NavigateUrl))
                    builder.WriteEndTag("a");
                writer.Write(builder.ToString());
            }

            if (Items.Count > 0)
            {
                writer.WriteBeginTag("ul");
                writer.WriteAttribute("class", "ui-helper-reset d-menu-container");
                writer.Write(HtmlTextWriter.TagRightChar);

                foreach (var item in items)
                    item.Render(writer);
                writer.WriteEndTag("ul");
            }
        }

        public override string TagName
        {
            get
            {
                return "li";
            }
        }

        private bool isSelected = false;
        private bool enabled = true;

        public bool Enabled
        {
            get { return enabled; }
            set { enabled = value; }
        }

        public bool Selected
        {
            get
            {
                return isSelected;
            }
            set
            {
                isSelected = true;
            }
        }

        void IComponentItemContainer<MenuItem>.OnItemAdded(MenuItem item) { item.Parent = this; }
    }


}
