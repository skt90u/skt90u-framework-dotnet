﻿//  Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DNA.Mvc.jQuery
{
    /// <summary>
    /// Defines the class in using for Hierarchical data binding.
    /// </summary>
    public class MenuItemProvider : HierarchicalNodeProviderBase
    {
        private HierarchicalNode root;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="node"></param>
        /// <param name="children"></param>
        public override void AddChildren(HierarchicalNode node, HierarchicalNode children)
        {
            var _parent = node;
            if (node == null)
                _parent = RootNode;

            children.ParentNode = _parent;
            if (_parent.ChildNodes == null)
                _parent.ChildNodes = new List<HierarchicalNode>();
            _parent.ChildNodes.Add(children);
        }

        /// <summary>
        /// Gets the root menu item node instance.
        /// </summary>
        public override HierarchicalNode RootNode
        {
            get
            {
                if (root == null)
                    root = new MenuItem(this)
                    {
                        Key = "0",
                        Title = "Menu",
                        Item = "0",
                        ChildNodes = new List<HierarchicalNode>()
                    };
                return root;
            }
            set
            {
                root = value;
            }
        }

        /// <summary>
        /// Gets the children menu item nodes by specified menu item node.
        /// </summary>
        /// <param name="node">Specified the menu item node.</param>
        /// <returns>A collection contains the children menu item nodes.</returns>
        public override IEnumerable<HierarchicalNode> GetChildNodes(HierarchicalNode node)
        {
            return null;
        }

        /// <summary>
        /// Gets the parent node instance of the specified menu item node.
        /// </summary>
        /// <param name="node">The menu item node.</param>
        /// <returns>The parent HierarchicalNode instance.</returns>
        public override HierarchicalNode GetParentNode(HierarchicalNode node)
        {
            return null;
        }

        /// <summary>
        /// Find the menu item instance by specified menu item key.
        /// </summary>
        /// <param name="key">The key of menu item.</param>
        /// <returns>Node instance of the menu item.</returns>
        public override HierarchicalNode FindNodeFormKey(string key)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Remove the specified menu item.
        /// </summary>
        /// <param name="node">The menu item node.</param>
        public override void RemoveNode(HierarchicalNode node)
        {
            throw new NotImplementedException();
        }
    }
}
