﻿//  Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Mvc;
using System.Web;

namespace DNA.Mvc.jQuery
{
    public class MenuItemBuilder : ViewComponentBuilder<MenuItem, MenuItemBuilder>
    {
        public MenuItemBuilder(MenuItem item, AjaxHelper helper) : base(item, helper) { }

        public MenuItemBuilder Items(Action<MenuItemFactory> items)
        {
            if (items != null)
            {
                var factory = new MenuItemFactory(Component, Helper) { Menu = Component.Menu };
                items.Invoke(factory);
            }
            return this;
        }

        public MenuItemBuilder Text(string text)
        {
            Component.Title = text;
            return this;
        }

        public MenuItemBuilder Image(string imageUrl)
        {
            Component.ImageUrl = imageUrl;
            return this;
        }

        public MenuItemBuilder Template(Action value)
        {
            this.Component.Template = value;
            return this;
        }

        //public MenuItemBuilder HtmlTemplate(string html)
        //{
        //    this.Component.HtmlTemplate = html;
        //    return this;
        //}

        public MenuItemBuilder Select(bool value)
        {
            if (this.Component.Parent == null)
                this.Component.Selected = value;
            return this;
        }

        public MenuItemBuilder Enabled(bool value)
        {
            this.Component.Enabled = value;
            return this;
        }


    }
}
