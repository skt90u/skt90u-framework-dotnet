﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Mvc;

namespace DNA.Mvc.jQuery
{
    /// <summary>
    /// Provides the helper methods to build menu elements and register the menu jQuery plugin scripts.
    /// </summary>
    public static class MenuExtensions
    {
        /// <summary>
        ///  Returns the html elements fo the jQuery menu control and register the jQuery javascript to page startup event.
        /// </summary>
        /// <param name="helper">The Ajax helper instance that this method extends.</param>
        /// <param name="name">The name of the form field to return.</param>
        /// <param name="provider">The menu item provider</param>
        /// <param name="options">Specified the options of the menu.</param>
        /// <param name="htmlAttributes"></param>
        /// <returns>The html elements of the menu control</returns>
        public static MvcHtmlString Menu(this AjaxHelper helper, string name, IHierarchicalNodeProvider provider, MenuOptions options, object htmlAttributes)
        {
            TagBuilder _menu = new TagBuilder("div");
            _menu.Attributes.Add("id", name);
            if (htmlAttributes != null)
                _menu.MergeAttributes<string, object>(ObjectHelper.ConvertObjectToDictionary(htmlAttributes));

            var opts = options != null ? options : new MenuOptions();
            var _uibuilder = new HierarchicalNodeUIBuilder();
            _uibuilder.WriteNodesRecursiveWithAllAttributes(provider.RootNode.ChildNodes);
            _menu.InnerHtml += _uibuilder.ToString();

            //if (!string.IsNullOrEmpty(opts.TargetID))
            //{
            //    if (!opts.TargetID.StartsWith("#"))
            //        opts.TargetID = "#" + opts.TargetID;
            //}

            helper.jQuery("#" + name + ">ul", "dnamenu", opts);
            return MvcHtmlString.Create(_menu.ToString());
        }

        /// <summary>
        /// Returns the html elements fo the jQuery menu control and register the jQuery javascript to page startup event.
        /// </summary>
        /// <param name="helper">The Ajax helper instance that this method extends.</param>
        /// <param name="name">The name of the form field to return.</param>
        /// <returns>The html elements of the menu control</returns>
        public static Menu Menu(this AjaxHelper helper, string name)
        {
            //return new Menu() { Name = name, Helper = helper };
            return null;
        }
    }
}
