﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DNA.Mvc.jQuery
{
    /// <summary>
    /// Defines the menu type styles
    /// </summary>
    public enum MenuTypes
    {
        /// <summary>
        /// Specified the menu plugin to build as Horizontal Main menu.
        /// </summary>
        Horizontal,
        /// <summary>
        /// Specified the menu plugin to build as Vertical menu.
        /// </summary>
        Vertical,
        /// <summary>
        /// Specified the menu plugin to build the dropdown menu to the target element.
        /// </summary>
        Dropdown,
        /// <summary>
        /// Specified the menu plugin as the context menu to target element.
        /// </summary>
        Context
    }
}
