﻿//  Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Mvc;
using System.Web.UI;

namespace DNA.Mvc.jQuery
{
    public class MenuItemFactory : ViewComponentBuilderFactory<MenuItem>
    {
        internal Menu Menu { get; set; }

        public MenuItemFactory(IComponentItemContainer<MenuItem> container, AjaxHelper helper)
            : base(container, helper)
        { }

        public MenuItemBuilder Add()
        {
            return Add(new MenuItem() { Menu = Menu });
        }

        public MenuItemBuilder Add(INavigtable item)
        {
            return Add(new MenuItem(item) { Menu = Menu });
        }

        public MenuItemBuilder Add(MenuItem item)
        {
            item.Parent = this.Container as MenuItem;
            this.Container.Items.Add(item);
            this.Container.OnItemAdded(item);
            return new MenuItemBuilder(item, Helper);
        }

        public MenuItemBuilder Add(string title, string navigateUrl)
        {
            return Add(title, navigateUrl, "");
        }

        public MenuItemBuilder Add(string title, string navigateUrl, string imageUrl)
        {
            return Add(title, navigateUrl, imageUrl, "_self");
        }

        public MenuItemBuilder Add(string title, string navigateUrl, string imageUrl, string target)
        {
            var item = new MenuItem()
            {
                Title = title,
                NavigateUrl = navigateUrl,
                ImageUrl = imageUrl,
                Target = target,
                Menu = Menu
            };
            return Add(item);
        }

    }


}
