﻿//  Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Mvc;
using System.Web;
using System.Web.UI;
using System.Xml;

namespace DNA.Mvc.jQuery
{
    /// <summary>
    /// Represents support for rendering HTML and jQuery scripts for menu jQuery plugin control.
    /// </summary>
    public class Menu : DataBindableComponent<MenuItem>
    {
         //public MenuOptions Options { get; set; }

        public List<MenuItem> MenuItems
        {
            get { return InnerItems.Select(item => { return (MenuItem)item; }).ToList(); }
            set { InnerItems = value; }
        }
        private SubMenuIcons subMenuDropIcons;

        public SubMenuIcons SubMenuDropIcons
        {
            get
            {
                if (subMenuDropIcons == null)
                    subMenuDropIcons = new SubMenuIcons();
                return subMenuDropIcons;
            }
            set { subMenuDropIcons = value; }
        }

        public string TopMenuCssClass { get; set; }

        public string TopItemSelectedCssClass { get; set; }

        public override void RenderContent(System.Web.UI.HtmlTextWriter writer)
        {
            writer.WriteBeginTag("ul");
            if (!string.IsNullOrEmpty(TopMenuCssClass))
                writer.WriteAttribute("class", TopMenuCssClass);
            //writer.WriteAttribute("id", Name + "_c");
            writer.Write(HtmlTextWriter.TagRightChar);
            base.RenderContent(writer);
            writer.WriteEndTag("ul");
        }
    }

    public delegate bool MapAction<S, T>(S source, T target);
  
}
