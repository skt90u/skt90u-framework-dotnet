﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DNA.Mvc.jQuery
{
    /// <summary>
    /// Represents the options of the jQuery menu plugin
    /// </summary>
    public class MenuOptions
    {
        private int duration = 100;
        private jQueryEffects hideEffect = jQueryEffects.Slide;
        private jQueryEffects showEffect = jQueryEffects.Slide;
        //private Orientation orentation = Orientation.Horizontal;
        private MenuTypes menutype = MenuTypes.Horizontal;

        /// <summary>
        /// Idendifiy the menu type.
        /// </summary>
        [jQueryOption("type")]
        public MenuTypes MenuType
        {
            get { return menutype; }
            set { menutype = value; }
        }

        ///// <summary>
        ///// Idendifiy the menu type.
        ///// </summary>
        //[jQueryOption("type")]
        //public Orientation Orientation
        //{
        //    get { return orentation; }
        //    set { orentation = value; }
        //}

        ///// <summary>
        ///// Specify the target element id for dropdown/context menu.
        ///// </summary>
        ///// <remarks>Initialize the menu with the target option specified.</remarks>
        //[jQueryOption("target")]
        //public string TargetID { get; set; }

        ///// <summary>
        ///// Specified the the target element open menu's event.
        ///// </summary>
        //[jQueryOption("dropdownEvent")]
        //public DomEvents DropdownEvent { get; set; }

        /// <summary>
        ///Specify the top menu css class of the menu.
        /// </summary>
        [jQueryOption("topMenuClass")]
        public string TopMenuCssClass { get; set; }

        /// <summary>
        /// Specify the top menu item css class of the menu.
        /// </summary>
        [jQueryOption("topItemClass")]
        public string TopItemCssClass { get; set; }

        /// <summary>
        /// Specify the top menu item hover css class of the menu.
        /// </summary>
        [jQueryOption("topItemHoverClass")]
        public string TopItemHoverCssClass { get; set; }

        /// <summary>
        /// Specify the top menu item selected css class of the menu.
        /// </summary>
        [jQueryOption("topItemSelectedClass")]
        public string TopItemSelectedCssClass { get; set; }

        /// <summary>
        /// Specify the sub menu css class of the menu.
        /// </summary>
        [jQueryOption("subMenuClass")]
        public string SubMenuCssClass { get; set; }

        /// <summary>
        /// Specify the sub item css class of the menu.
        /// </summary>
        [jQueryOption("subMenuItemClass")]
        public string SubMenuItemCssClass { get; set; }

        /// <summary>
        /// Specify the sub item hover css class of the menu.
        /// </summary>
        [jQueryOption("subMenuItemHoverClass")]
        public string SubMenuItemHoverCssClass { get; set; }

        [jQueryOption("skateBoard")]
        public bool? ShowSkateBoard { get; set; }

         [jQueryOption("skateBoardClass")]
        public string SkateBoardCssClass { get; set; }
        ///// <summary>
        /////  Gets/Sets whether the spliter show between the top menu items.
        ///// </summary>
        //[jQueryIgnore]
        //public bool ShowSpliter { get; set; }

        ///// <summary>
        ///// Gets/Sets the spliter icon css class of the top menu items.
        ///// </summary>
        //[jQueryIgnore]
        //public string SpliterIconCssClass { get; set; }

        ///// <summary>
        ///// This event is raise before the menu open
        ///// </summary>
        //[jQueryOption("beforeOpen", ValueType = JavaScriptTypes.Function,FunctionParams=new string[]{"event","ui"})]
        //public string OnBeforeMenuOpen { get; set; }

        /// <summary>
        /// This event is raise after the menu open.
        /// </summary>
        [jQueryOption("open", ValueType = JavaScriptTypes.Function, FunctionParams = new string[] { "event", "ui" })]
        public string OnMenuOpen { get; set; }

        ///// <summary>
        ///// This event is raise before the menu close
        ///// </summary>
        //[jQueryOption("beforeClose", ValueType = JavaScriptTypes.Function, FunctionParams = new string[] { "event", "ui" })]
        //public string OnBeforeMenuClose { get; set; }

        /// <summary>
        /// This event is raise after the menu is closed.
        /// </summary>
        [jQueryOption("close", ValueType = JavaScriptTypes.Function, FunctionParams = new string[] { "event", "ui" })]
        public string OnMenuClose { get; set; }

        [jQueryOption("opacity")]
        public double? Opacity { get; set; }

        [jQueryOption("delay")]
        public int Duration { get { return duration; } set { duration = value; } }
        
        [jQueryOption("hideEffect")]
        public jQueryEffects HideEffect { get { return hideEffect; } set { hideEffect = value; } }

        [jQueryOption("showEffect")]
        public jQueryEffects ShowEffect { get { return showEffect; } set { showEffect = value; } }
    }
}
