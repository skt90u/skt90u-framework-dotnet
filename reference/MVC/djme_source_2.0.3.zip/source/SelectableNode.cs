﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Text;
using DNA.Mvc.jQuery;

namespace DNA.Mvc
{
    /// <summary>
    /// Represents a node in the hierarchical structure such as "ul","li"
    /// </summary>
    public class SelectableNode : NavigatableNode, ISelectable
    {
        #region private
        private object properties;
        private bool selected = false;
        #endregion

        /// <summary>
        /// Gets/Sets wheather the node is selected.
        /// </summary>
        public bool Selected
        {
            get { return selected; }
            set { selected = value; }
        }

        /// <summary>
        /// Gets/Sets the addition properties.
        /// </summary>
        public object Properties
        {
            get { return properties; }
            set { properties = value; }
        }

        /// <summary>
        /// Initizialize the SelectableNode.
        /// </summary>
        public SelectableNode() { }

        /// <summary>
        /// Initizialize the SelectableNode by specified the node text.
        /// </summary>
        /// <param name="text"></param>
        public SelectableNode(string text) : base(text) { }

        /// <summary>
        /// Initizialize the SelectableNode by specified the node text and node value.
        /// </summary>
        /// <param name="text">The text content of the node.</param>
        /// <param name="value">The value of the node.</param>
        public SelectableNode(string text, string value) : base(text, value) { }

        /// <summary>
        /// Recevies the Json object of the node.
        /// </summary>
        /// <returns>The Json string.</returns>
        public string Json()
        {
            return Json(this);
        }

        /// <summary>
        /// Receives the Json string of the specified node collection.
        /// </summary>
        /// <param name="nodes"></param>
        /// <returns>The Json string.</returns>
        public static string Json(List<SelectableNode> nodes)
        {
            string[] _ns = new string[nodes.Count];
            for (int i = 0; i < nodes.Count; i++)
                _ns[i] = nodes[i].Json();
            return "[" + string.Join(",", _ns) + "]";
        }

        private string Json(SelectableNode node)
        {
            OptionBuilder jsonNode = new OptionBuilder();

            if (!string.IsNullOrEmpty(node.Text))
                jsonNode.AddOption("text", node.Text, true);

            if (!string.IsNullOrEmpty(node.Value.ToString()))
                jsonNode.AddOption("value", node.Value.ToString(), true);

            if (!string.IsNullOrEmpty(node.ImageUrl))
                jsonNode.AddOption("imgUrl", node.ImageUrl, true);

            if (!string.IsNullOrEmpty(node.ToolTip))
                jsonNode.AddOption("title", node.ToolTip, true);

            if (!string.IsNullOrEmpty(node.NavigateUrl))
                jsonNode.AddOption("url", node.NavigateUrl, true);

            if (node.Properties != null)
                jsonNode.AddOptions(node.properties);

            //if (node.Children.Count > 0)
            //{
            //    //StringBuilder childbuilder=new StringBuilder();
            //    string[] childJson = new string[node.Children.Count];
            //    for (int i = 0; i < node.Children.Count; i++)
            //        childJson[i] = Json(node.Children[i]);
            //    jsonNode.AddOption("children", "[" + String.Join(",", childJson) + "]", false);
            //}
            return jsonNode.ToString();
        }
    }

    public class NavigatableNode : INavigtable
    {
        private string _title = "";
        private object _value = "";
        private string imageUrl = "";
        private string tooltip = "";
        private string navigateUrl = "";
        private string target = "";

        public NavigatableNode() { }

        /// <summary>
        /// Initizialize the SelectableNode by specified the node text.
        /// </summary>
        /// <param name="text"></param>
        public NavigatableNode(string text) : this(text, "") { }

        /// <summary>
        /// Initizialize the SelectableNode by specified the node text and node value.
        /// </summary>
        /// <param name="text">The text content of the node.</param>
        /// <param name="value">The value of the node.</param>
        public NavigatableNode(string text, string value)
        {
            _title = text;
            _value = value;
        }

        /// <summary>
        /// Gets/Sets the open window target
        /// </summary>
        public string Target
        {
            get { return target; }
            set { target = value; }
        }

        /// <summary>
        /// Gets/Sets the navigate url of the node.
        /// </summary>
        public string NavigateUrl
        {
            get { return navigateUrl; }
            set { navigateUrl = value; }
        }

        /// <summary>
        /// Gets/Sets the tooltip text of the node.
        /// </summary>
        public string ToolTip
        {
            get { return tooltip; }
            set { tooltip = value; }
        }

        /// <summary>
        /// Gets/Sets the additional value.
        /// </summary>
        public object Value
        {
            get { return this._value; }
            set { this._value = value; }
        }

        /// <summary>
        /// Gets/Sets the image url.
        /// </summary>
        public string ImageUrl
        {
            get { return imageUrl; }
            set { imageUrl = value; }
        }

        /// <summary>
        /// Gets/Sets the node text content.
        /// </summary>
        public string Text
        {
            get { return _title; }
            set { _title = value; }
        }
        #region INavigate members

        string INavigtable.Description
        {
            get { return this.tooltip; }
        }

        string INavigtable.Title
        {
            get { return this.Text; }
        }

        string INavigtable.NavigateUrl
        {
            get { return this.NavigateUrl; }
        }

        string INavigtable.ImageUrl
        {
            get { return this.ImageUrl; }
        }

        string INavigtable.Target
        {
            get { return this.Target; }
        }

        object INavigtable.Value
        {
            get { return this.Value; }
        }

        #endregion
    }
}
