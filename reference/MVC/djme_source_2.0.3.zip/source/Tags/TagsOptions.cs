﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DNA.Mvc.jQuery
{
    /// <summary>
    /// Defines the tags plugin options.
    /// </summary>
    public class TagsOptions
    {
        /// <summary>
        /// Gets/Sets Zero-based index of the tag to be selected on initialization. To set all tags to unselected pass -1 as value. 
        /// </summary>
        [jQueryOption("selectedIndex")]
        public int? SelectedIndex { get; set; }

        /// <summary>
        /// Gets/Sets the tags layout position.properby value"left","right" 
        /// </summary>
        [jQueryOption("pos")]
        public TagsLayouts Layout { get; set; }

        /// <summary>
        /// Gets/Sets the tags selected event.
        /// </summary>
        [jQueryOption("event")]
        public DomEvents TriggerEvent { get; set; }

        /// <summary>
        /// Gets/Sets the scripts when clicking a tag. 
        /// </summary>
        [jQueryOption("select", ValueType = JavaScriptTypes.Function, FunctionParams = new string[] { "index", "tag", "panel" })]
        public string OnSelect { get; set; }

        /// <summary>
        /// Gets/Sets the scripts when the tag shown
        /// </summary>
        [jQueryOption("select", ValueType = JavaScriptTypes.Function, FunctionParams = new string[] { "index", "tag", "panel" })]
        public string OnShow { get; set; }

        /// <summary>
        /// Gets/Sets whether the tags can be sortable.
        /// </summary>
        [jQueryIgnore]
        public bool IsSortable { get; set; }
    }

    /// <summary>
    /// Defines the Tags layout mode.
    /// </summary>
    public enum TagsLayouts
    {
        /// <summary>
        /// Specified the Tags shows on the left side.
        /// </summary>
        Left,
        /// <summary>
        /// Specified the Tags shows on the right side.
        /// </summary>
        Right
    }
}
