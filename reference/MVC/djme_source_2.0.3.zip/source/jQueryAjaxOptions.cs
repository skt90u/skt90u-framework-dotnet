﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Mvc;

namespace DNA.Mvc.jQuery
{
    /// <summary>
    /// Defines the jQuery Ajax options object.
    /// </summary>
    public class jQueryAjaxOptions
    {
        private DomEvents triggerEvent = DomEvents.Click;
        private bool autoBlocking = false;
        private bool autoHandlingError = true;

        /// <summary>
        /// Gets/Sets whether the system will handing erro when progress Http Request.
        /// </summary>
        [jQueryIgnore]
        public bool AutoHandlingError
        {
            get { return autoHandlingError; }
            set { autoHandlingError = value; }
        }

        /// <summary>
        /// Gets/Sets whether shows the default loader when progress Http Request.
        /// </summary>
        [jQueryIgnore]
        public bool AutoBlocking
        {
            get { return autoBlocking; }
            set { autoBlocking = value; }
        }

        /// <summary>
        /// Gets/Sets the trigger event type of the element to invoke the Http Request
        /// </summary>
        [jQueryIgnore]
        public DomEvents TriggerEvent
        {
            get { return triggerEvent; }
            set { triggerEvent = value; }
        }

        /// <summary>
        /// Gets/Sets the element id to trigger the Http Request
        /// </summary>
        [jQueryIgnore]
        public string TriggerID { get; set; }

        /// <summary>
        /// Gets/Sets the element id to display the Http Response
        /// </summary>
        [jQueryIgnore]
        public string UpdateTargetID { get; set; }

        /// <summary>
        /// Gets or sets the loading element id.
        /// </summary>
        [jQueryIgnore]
        public string LoadingElementID { get; set; }

        /// <summary>
        /// Gets or sets the insertion mode.
        /// </summary>
        [jQueryIgnore]
        public System.Web.Mvc.Ajax.InsertionMode InsertionMode { get; set; }

        /// <summary>
        /// Gets/Sets whether auto binding the element's value as parameters to send to the specified url.
        /// </summary>
        [jQueryIgnore]
        public bool AutoBindingParameterElement { get; set; }

        /// <summary>
        /// Gets or sets the junction to call for a confirmation.
        /// </summary>
        [jQueryIgnore]
        public string Confirm { get; set; }

        ///// <summary>
        ///// Gets/Sets the Dialog title of the confirm message.
        ///// </summary>
        //[jQueryIgnore]
        //public string ConfirmDialogTitle { get; set; }

        /// <summary>
        /// A function to be called if the request fails. 
        /// </summary>
        /// <remarks>
        /// he function is passed three arguments: The XMLHttpRequest object, a string describing the type of error that occurred and an optional exception object, if one occurred. Possible values for the second argument (besides null) are "timeout", "error", "notmodified" and "parsererror". 
        /// </remarks>
        [jQueryOption("error", AllowNull = true, ValueType = JavaScriptTypes.Function, FunctionParams = new string[] { "XMLHttpRequest", "textStatus", "errorThrown" })]
        public string OnError { get; set; }

        /// <summary>
        /// A pre-callback to modify the XMLHttpRequest object before it is sent. 
        /// Use this to set custom headers etc. The XMLHttpRequest is passed as the only argument. 
        /// This is an Ajax Event. You may return false in function to cancel the request. 
        /// </summary>
        [jQueryOption("beforeSend", AllowNull = true, ValueType = JavaScriptTypes.Function, FunctionParams = new string[] { "XMLHttpRequest" })]
        public string OnBeforeSend { get; set; }

        /// <summary>
        /// A function to be called when the request finishes (after success and error callbacks are executed). 
        /// The function gets passed two arguments: The XMLHttpRequest object and a string describing the type of success of the request.
        /// </summary>
        [jQueryOption("complete", AllowNull = true, ValueType = JavaScriptTypes.Function, FunctionParams = new string[] { "XMLHttpRequest", "textStatus" })]
        public string OnComplete { get; set; }

        /// <summary>
        /// A function to be called if the request success. T
        /// </summary>
        /// <remarks>he function gets passed two arguments: The data returned from the server, formatted according to the 'dataType' parameter, and a string describing the status.</remarks>
        [jQueryOption("success", AllowNull = true, ValueType = JavaScriptTypes.Function, FunctionParams = new string[] { "data", "textStatus" })]
        public string OnSuccess { get; set; }

        /// <summary>
        /// Gets or sets the HTTP method.
        /// </summary>
        [jQueryOption("type")]
        public string HttpMethod { get; set; }

        /// <summary>
        /// The URL to request. This *must* be a string (e.g., document.location.href) 
        /// and not a Location object (e.g., document.location)
        /// </summary>
        [jQueryOption("url")]
        public string Url { get; set; }

        /// <summary>
        /// Data to be sent to the server. It is converted to a query string, if not already a string. 
        /// </summary>
        /// <remarks>
        /// It's appended to the url for GET-requests. See processData option to prevent this automatic processing. 
        /// Object must be Key/Value pairs. If value is an Array, jQuery serializes multiple values with same key i.e. {foo:["bar1", "bar2"]} becomes '&amp;foo=bar1&amp;foo=bar2'.
        /// </remarks>
        [jQueryOption("data", ValueType = JavaScriptTypes.JSON)]
        public object Data { get; set; }

        /// <summary>
        /// The type of data that you're expecting back from the server. If none is specified, jQuery will intelligently pass either responseXML or responseText to your success callback, based on the MIME type of the response. The available types (and the result passed as the first argument to your success callback) are: 
        /// </summary>
        [jQueryOption("dataType")]
        public AjaxDataTypes DataType { get; set; }

        /// <summary>
        /// By default, all requests are sent asynchronous (i.e. this is set to true by default).
        /// If you need synchronous requests, set this option to false. 
        /// Note that synchronous requests may temporarily lock the browser,
        /// disabling any actions while the request is active.
        /// </summary>
        [jQueryOption("async")]
        public bool? AsyncMode { get; set; }

        /// <summary>
        /// Added in jQuery 1.2, if set to false it will force the pages that you request to not be cached by the browser.
        /// </summary>
        [jQueryOption("cache")]
        public bool? EnableCache { get; set; }

        /// <summary>
        /// When sending data to the server, use this content-type. Default is "application/x-www-form-urlencoded", which is fine for most cases.
        /// </summary>
        [jQueryOption("contentType")]
        public string ContentType { get; set; }

        /// <summary>
        /// Whether to trigger global AJAX event handlers for this request. The default is true. Set to false to prevent the global handlers like ajaxStart or ajaxStop from being triggered. This can be used to control various Ajax Events.
        /// </summary>
        [jQueryOption("global")]
        public bool? TriggerGlobalAjaxEvent { get; set; }

        /// <summary>
        /// Allow the request to be successful only if the response has changed since the last request. This is done by checking the Last-Modified header. Default value is false, ignoring the header.
        /// </summary>
        [jQueryOption("ifModified")]
        public bool? IfModified { get; set; }

        /// <summary>
        /// Override the callback function name in a jsonp request. This value will be used instead of 'callback' in the 'callback=?' part of the query string in the url for a GET or the data for a POST. So {jsonp:'onJsonPLoad'} would result in 'onJsonPLoad=?' passed to the server.
        /// </summary>
        [jQueryOption("jsonp")]
        public string Jsonp { get; set; }

        /// <summary>
        /// A username to be used in response to an HTTP access authentication request.
        /// </summary>
        [jQueryOption("username")]
        public string Username { get; set; }

        /// <summary>
        /// A password to be used in response to an HTTP access authentication request.
        /// </summary>
        [jQueryOption("password")]
        public string Password { get; set; }

        /// <summary>
        /// By default, data passed in to the data option as an object (technically, anything other than a string) will be processed and transformed into a query string, fitting to the default content-type "application/x-www-form-urlencoded". If you want to send DOMDocuments, or other non-processed data, set this option to false.
        /// </summary>
        [jQueryOption("processData")]
        public bool? ProcessData { get; set; }

        /// <summary>
        /// Only for requests with 'jsonp' or 'script' dataType and GET type. Forces the request to be interpreted as a certain charset. Only needed for charset differences between the remote and local content.
        /// </summary>
        [jQueryOption("scriptCharset")]
        public string ScriptCharset { get; set; }

        /// <summary>
        /// Set a local timeout (in milliseconds) for the request. This will override the global timeout, if one is set via $.ajaxSetup. For example, you could use this property to give a single request a longer timeout than all other requests that you've set to time out in one second. 
        /// </summary>
        [jQueryOption("timeout")]
        public int? RequestTimeout { get; set; }

        /// <summary>
        /// A function to be used to handle the raw responsed data of XMLHttpRequest.This is a pre-filtering function to sanitize the response.You should return the sanitized data.The function gets passed two arguments: The raw data returned from the server, and the 'dataType' parameter. 
        /// </summary>
        [jQueryOption("dataFilter", AllowNull = true, ValueType = JavaScriptTypes.Function, FunctionParams = new string[] { "data","type" })]
        public string DataFilter { get; set; }
    }
}
