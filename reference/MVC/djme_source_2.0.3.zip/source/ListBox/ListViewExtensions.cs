﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Mvc;

namespace DNA.Mvc.jQuery
{
    public static class ListViewExtensions
    {

        public static string ListView<UIBuilder>(this AjaxHelper helper, string name, List<SelectableNode> listItems, object htmlAttributes)
        where UIBuilder : NodeUIBuilder
        {
            TagBuilder tag = new TagBuilder("div");
            //tag.GenerateId(name);
            tag.Attributes.Add("id", name);
            if (htmlAttributes != null)
                tag.MergeAttributes<string, object>(ObjectHelper.ConvertObjectToDictionary(htmlAttributes));
            UIBuilder nodeBuilder = Activator.CreateInstance<UIBuilder>();
            nodeBuilder.WriteNodes(listItems.Cast<INavigtable>());
            tag.InnerHtml = nodeBuilder.ToString();
            helper.jQuery("#" + name, "listview");
            return tag.ToString();
        }

        //public static string ListView(this AjaxHelper helper, string name, List<SelectableNode> listItems, object htmlAttributes)
        //{
        //    return ListView<ListViewNodeUIBuilder>(helper, name, listItems, htmlAttributes);
        //}
    }
}
