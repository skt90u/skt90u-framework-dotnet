﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Mvc;

namespace DNA.Mvc.jQuery
{
    /// <summary>
    /// Defines the properies of the DJP listview plugin.
    /// </summary>
    public class ListViewOptions
    {
        /// <summary>
        /// Gets/Sets wheather the listview item can editable.
        /// </summary>
        [jQueryOption("itemEditable")]
        public bool? EnableEditable { get; set; }
        
        /// <summary>
        /// Gets/Sets the item field element jQuery selector.
        /// </summary>
        [jQueryOption("items")]
        public string ItemField { get; set; }
        
        /// <summary>
        /// Gets/Sets the item text field element jQuery selector.
        /// </summary>
        [jQueryOption("itemText")]
        public string ItemTextField { get; set; }

        /// <summary>
        /// Gets/Sets the item image field element jQuery selector.
        /// </summary>
        [jQueryOption("itemImg")]
        public string ItemImageField { get; set; }

        /// <summary>
        /// Gets/Sets the listview item height.
        /// </summary>
        [jQueryOption("itemHeight")]
        public int? ItemHeight { get; set; }

        /// <summary>
        /// Gets/Sets the listview item width.
        /// </summary>
        [jQueryOption("itemWidth")]
        public int? ItemWidth { get; set; }

        /// <summary>
        /// Gets/Sets the item value field element jQuery selector.
        /// </summary>
        [jQueryOption("itemValue")]
        public string ItemValueField { get; set; }

        /// <summary>
        /// Gets/Sets the item css class name.
        /// </summary>
        [jQueryOption("itemClass")]
        public string ItemCssClass { get; set; }

        /// <summary>
        /// Gets/Sets the item css class name when item hover.
        /// </summary>
        [jQueryOption("hoverClass")]
        public string ItemHoverCssClass { get; set; }

        /// <summary>
        /// Gets/Sets the item css class name when item selected.
        /// </summary>
        [jQueryOption("selectedClass")]
        public string ItemSelectedCssClass { get; set; }

        /// <summary>
        /// Gets/Sets the current selected value.
        /// </summary>
        [jQueryOption("selectedValue")]
        public string SelectedValue { get; set; }

        /// <summary>
        /// Gets/Sets the client scripts to handling the listview item click event.
        /// </summary>
        [jQueryOption("itemClick", ValueType = JavaScriptTypes.Function, FunctionParams = new string[] { "event", "ui" })]
        public string OnItemClick { get; set; }
    }
}
