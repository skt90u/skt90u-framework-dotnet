﻿//  Copyright (c) 2011 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Mvc;
using System.Web.UI;
using System.Linq.Expressions;

namespace DNA.Mvc.jQuery
{
    public class ListBoxBuilder : jQueryNavigableViewBindingBuilder<ListBoxOptions, ListBox, ListBoxBuilder>
    {
        public ListBoxBuilder(ListBox component, AjaxHelper helper) : base(component, helper) { }

        protected override string jQueryPluginName
        {
            get { return "listbox"; }
        }

        public ListBoxBuilder ConnectTo(string selector)
        {
            Options(opts =>
            {
                opts.IsDroppable = true;
                opts.DropTargets = (((!selector.StartsWith(".")) && (!selector.StartsWith("#"))) ? "#" + selector : selector) + ">.d-list-items-holder";
            });
            return this;
        }

        public override void Render()
        {
            if ((clientTemplate != null) && (!string.IsNullOrEmpty(base.remoteUrl)))
            {
                var startHandler = new StringBuilder();
                startHandler.Append(jQuerySelector)
                .Append(".listbox(\"loadJson\",\"")
                .Append(remoteUrl)
                .Append("\",{index:1,size:20},\"")
                .Append(Component.Id).Append("_tmpl\",function(e,data){")
                .Append("e.element.data(\"routeValues\",{index:2,size:20,count:data.Total,total:Math.round(data.Total/20)});")
                .Append("},\"")
                .Append(httpMethod)
                .Append("\");");

                var scrollHandler = new StringBuilder();
                scrollHandler.Append("var _routeValues=")
                    .Append(jQuerySelector)
                     .Append(".data(\"routeValues\");_routeValues.index++; if (_routeValues.total >= _routeValues.index) ")
                     .Append(jQuerySelector)
                .Append(".listbox(\"loadJson\",\"")
                .Append(remoteUrl)
                .Append("\",_routeValues,\"")
                .Append(Component.Id).Append("_tmpl\",function(e,data){")
                .Append("e.element.data(\"routeValues\",_routeValues);")
                 .Append("},\"")
                .Append(httpMethod)
                .Append("\");");

                //Partical load
                Options(opts =>
                {
                    opts.OnScrollToEnd = scrollHandler.ToString();
                });
                base.Render();
                //First load
                Helper.RegisterStartupScript(startHandler.ToString());
            }
            else
                base.Render();
        }

        public ListBoxBuilder Select(string value)
        {
            Component.Value=value;
            return this;
        }

        public ListBoxBuilder Select(string[] values)
        {
            Component.Value=string.Join(",",values);
            return this;
        }
    }

    public class ListBoxBuilder<TModel,TValue> : ListBoxBuilder
        where TModel:class
    {
        private Action<TModel> itemTmpl;
        private IEnumerable<TModel> _model;
        private Func<TModel, TValue> fieldSelector;

        public ListBoxBuilder(IEnumerable<TModel> model,Expression<Func<TModel, TValue>> expression, ListBox component, AjaxHelper helper) : base(component, helper) 
        {
            _model = model;
            fieldSelector = expression.Compile();
        }

        public ListBoxBuilder<TModel, TValue> ItemTemplate(Action<TModel> itemTemplate)
        {
            itemTmpl = itemTemplate;
            return this;
        }

        public new ListBoxBuilder<TModel, TValue> Height(int height)
        {
            base.Height(height);
            return this;
        }

        public new ListBoxBuilder<TModel, TValue> Width(int width)
        {
            base.Width(width);
            return this;
        }

        public new ListBoxBuilder<TModel, TValue> AddClass(string className)
        {
            base.AddClass(className);
            return this;
        }

        public new ListBoxBuilder<TModel, TValue> HtmlAttributes(object htmlAttributes)
        {
            base.HtmlAttributes(htmlAttributes);
            return this;
        }

        public override void Render()
        {
            GenerateId();
            
             using (var writer = new HtmlTextWriter(Helper.ViewContext.Writer))
            {
                Component.RenderBeginTag(writer);
                Component.RenderContent(writer);

                writer.WriteBeginTag("ul");
                RenderItemHolderAttributes(writer);
                writer.Write(HtmlTextWriter.TagRightChar);

                foreach (var item in _model)
                {
                    writer.WriteFullBeginTag("li");
                    writer.WriteBeginTag("input");
                    writer.WriteAttribute("type", "hidden");
                    var _value=fieldSelector.Invoke(item) as string;
                    writer.WriteAttribute("value",string.IsNullOrEmpty(_value) ? "" : _value);
                    writer.Write(HtmlTextWriter.SelfClosingTagEnd);
                    itemTmpl.Invoke(item);
                    writer.WriteEndTag("li");
                }
                writer.WriteEndTag("ul");
                Component.RenderEndTag(writer);
            }

            Helper.jQuery(Component.Id, jQueryPluginName, options);
        
        }
    }
}
