﻿//  Copyright (c) 2011 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DNA.Mvc.jQuery
{
    public class ListBoxOptions
    {
        [jQueryOption("editable")]
        public bool? AllowItemTitleEditing { get; set; }

        [jQueryOption("checkboxs")]
        public bool? ShowCheckbox { get; set; }
        
        [jQueryOption("multiselection")]
        public bool? AllowMultiSelection { get; set; }

        [jQueryOption("inline")]
        public bool? IsInlineMode { get; set; }

        [jQueryOption("sortable")]
        public bool? IsSortable { get; set; }

        [jQueryOption("droppable")]
        public bool? IsDroppable { get; set; }

        [jQueryOption("droptargets")]
        public string DropTargets { get; set; }

        [jQueryOption("dataTextField")]
        public string DataTextField { get; set; }

        [jQueryOption("dataValueField")]
        public string DataValueField { get; set; }

        [jQueryOption("itemClass")]
        public string ItemCssClass { get; set; }

        [jQueryOption("itemHoverClass")]
        public string ItemHoverCssClass { get; set; }

        [jQueryOption("itemSelectedClass")]
        public string ItemSelectedCssClass { get; set; }

        [jQueryOption("changed", ValueType = JavaScriptTypes.Function, FunctionParams = new string[] { "event", "ui" })]
        public string OnPositionChanged { get; set; }

        [jQueryOption("edited", ValueType = JavaScriptTypes.Function, FunctionParams = new string[] { "event", "ui" })]
        public string OnItemEdited { get; set; }

        [jQueryOption("dropped", ValueType = JavaScriptTypes.Function, FunctionParams = new string[] { "event", "ui" })]
        public string OnItemDropped { get; set; }

        [jQueryOption("dropout", ValueType = JavaScriptTypes.Function, FunctionParams = new string[] { "event", "ui" })]
        public string OnItemDropOut { get; set; }

        [jQueryOption("dropover", ValueType = JavaScriptTypes.Function, FunctionParams = new string[] { "event", "ui" })]
        public string OnItemDropOver { get; set; }

        [jQueryOption("selected", ValueType = JavaScriptTypes.Function, FunctionParams = new string[] { "event", "ui" })]
        public string OnItemSelected { get; set; }

        [jQueryOption("scrollEnd", ValueType = JavaScriptTypes.Function, FunctionParams = new string[] { "event"})]
        public string OnScrollToEnd { get; set; }
    }
}
