﻿//  Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.Mvc;

namespace DNA.Mvc.jQuery
{
    public class ListBox : DataBindableComponent<NavigableView>
    {
        public IList<NavigableView> Items
        {
            get
            {
                return InnerItems;
            }
            set
            {
                InnerItems = value;
            }
        }

        public string Value{get;set;}

        public override void RenderBeginTag(HtmlTextWriter writer)
        {
            base.RenderBeginTag(writer);
            var input = new TagBuilder("input");
            input.AddCssClass("d-listbox-values");
            input.MergeAttribute("type", "hidden");
            input.MergeAttribute("name", this.Name);
            if (!string.IsNullOrEmpty(Value))
                input.MergeAttribute("value", Value);

            writer.Write(input.ToString(TagRenderMode.SelfClosing));
        }

        public override void RenderContent(HtmlTextWriter writer)
        {
        }

        public override void RenderEndTag(HtmlTextWriter writer)
        {
            writer.WriteEndTag("div");
        }
    }
}
