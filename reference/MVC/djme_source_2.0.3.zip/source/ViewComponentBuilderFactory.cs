﻿//  Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace DNA.Mvc
{
    public class ViewComponentBuilderFactory<TComponent>
        where TComponent:ViewComponent
      //  where TBuilder:ViewComponentBuilder<TComponent,TBuilder>
    {
        private IComponentItemContainer<TComponent> _container;
        private AjaxHelper _helper;

        protected IComponentItemContainer<TComponent> Container
        {
            get { return _container; }
            private set { _container = value; }
        }

        protected AjaxHelper Helper
        {
            get { return _helper; }
            private set { _helper = value; }
        }

        public ViewComponentBuilderFactory(IComponentItemContainer<TComponent> container, AjaxHelper helper)
        {
            this._container = container;
            this._helper = helper;
        }
    }
}
