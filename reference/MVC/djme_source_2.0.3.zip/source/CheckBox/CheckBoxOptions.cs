﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DNA.Mvc.jQuery
{
    /// <summary>
    /// Represents the options of the checkbox plugin
    /// </summary>
    public class CheckBoxOptions
    {
        private string text =string.Empty;

        /// <summary>
        /// Gets/Sets the checkbox value.
        /// </summary>
        [jQueryOption("value")]
        public bool? Value { get; set; }

        /// <summary>
        /// Gets/Sets the text shows on the rightside of the checkbox.
        /// </summary>
        [jQueryOption("text")]
        public string Text
        {
            get 
            {
                if (!string.IsNullOrEmpty(text))
                    return HttpContext.Current.Server.HtmlEncode(text);
                return text;
            }
            set { text = value; }
        }

        /// <summary>
        /// Gets/Sets the css class name of the checkbox
        /// </summary>
        [jQueryOption("checkboxClass")]
        public string CssClass { get; set; }

        /// <summary>
        /// Gets/Sets the css class name of the checkbox when the value is true.
        /// </summary>
        [jQueryOption("selectedClass")]
        public string CheckedCssClass { get; set; }

        /// <summary>
        /// Gets/Sets the css class name of the checkbox when the value is set to false.
        /// </summary>
        [jQueryOption("unselectedClass")]
        public string UncheckCssClass { get; set; }

        [jQueryOption("changed", ValueType = JavaScriptTypes.Function, FunctionParams = new string[] { "event", "value" })]
        public string OnCheckedChanged { get; set; }
    }
}
