﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Mvc;

namespace DNA.Mvc.jQuery
{
    /// <summary>
    /// Represents support for DJP checkbox controls
    /// </summary>
    public static class CheckBoxExtensions
    {

        ///<summary>Render the checkbox html element and checkbox jQuery scripts</summary>
        ///<param name="helper">The Ajax helper object to extends.</param>
        ///<param name="name">Specified the name of the checkbox</param>
        ///<param name="text">Specified the checkbox display text</param>
        ///<returns>checkbox plugin requires elements.</returns>
        ///<example>
        ///<code>
        ///<![CDATA[ Ajax.CheckBox("myCheckbox"); ]]>
        ///</code>
        ///</example>
        public static MvcHtmlString CheckBox(this AjaxHelper helper, string name, string text)
        {
            return helper.CheckBox(name, text, false);
        }

        ///<summary>Render the checkbox html element and checkbox jQuery scripts</summary>
        ///<param name="helper">The Ajax helper object to extends.</param>
        ///<param name="name">Specified the name of the checkbox</param>
        ///<param name="text">Specified the checkbox display text</param>
        ///<param name="value">Specified the checkbox's value.</param>
        ///<returns>checkbox plugin requires elements.</returns>
        ///<example>
        ///<code>
        ///<![CDATA[ Ajax.CheckBox("myCheckbox",true); ]]>
        ///</code>
        ///</example>
        public static MvcHtmlString CheckBox(this AjaxHelper helper, string name, string text, bool value)
        {
            return helper.CheckBox(name, new CheckBoxOptions() { Text = text, Value = value });
        }

        /// <summary>
        /// Render the checkbox html element and checkbox jQuery scripts
        /// </summary>
        /// <param name="helper">The Ajax helper object to extends.</param>
        /// <param name="name">Specified the name of the checkbox</param>
        /// <param name="options">The CheckBoxOption instance.</param>
        /// <returns></returns>
        public static MvcHtmlString CheckBox(this AjaxHelper helper, string name, CheckBoxOptions options)
        {
            TagBuilder checkbox = new TagBuilder("input");
            checkbox.GenerateId(name);
            
            if (!checkbox.Attributes.Keys.Contains("id"))
                checkbox.Attributes.Add("id",name);

            checkbox.Attributes.Add("type", "hidden");

            checkbox.Attributes.Add("name", name);
            checkbox.Attributes.Add("value", options.Value.HasValue ? options.Value.ToString().ToLower() : "false");

            helper.jQuery("#" + checkbox.Attributes["id"], "checkbox", options);
            return MvcHtmlString.Create(checkbox.ToString(TagRenderMode.SelfClosing));
        }
    }
}
