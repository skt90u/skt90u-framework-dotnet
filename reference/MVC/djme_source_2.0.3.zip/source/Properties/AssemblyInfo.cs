﻿//  Copyright (c) 2011 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("DJME2")]
[assembly: AssemblyDescription("The DotNetAge Mvc Extensions for jQuery ")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("http://www.DotNetAge.com")]
[assembly: AssemblyProduct("DotNetAge jQuery Mvc Extensions (DJME)")]
[assembly: AssemblyCopyright("Copyright ©  2009 - 2011 Ray Liang (http://www.dotnetage.com)")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: Guid("cec41a33-81db-4b38-aeef-89e79391d28b")]
[assembly: AssemblyVersion("2.0.3.*")]
[assembly: AssemblyFileVersion("2.0.3")]
