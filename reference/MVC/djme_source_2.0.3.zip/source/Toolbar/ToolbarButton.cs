﻿//  Copyright (c) 2011 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Mvc;
using System.Web.UI;

namespace DNA.Mvc.jQuery
{
    public class ToolbarButton : TemplateViewComponent
    {
        public string Text { get; set; }

        public string NavigateUrl { get; set; }

        public string OnClick { get; set; }

        public string PrimaryIconImageUrl { get; set; }

        public string PrimaryIconCssClass { get; set; }

        public string SecondaryIconCssClass { get; set; }

        public string SecondaryIconImageUrl { get; set; }

        public override string TagName
        {
            get
            {
                return "td";
            }
        }

        public override void RenderBeginTag(HtmlTextWriter writer)
        {
            writer.WriteBeginTag(TagName);
            writer.WriteAttribute("class", "d-toolbar-button");
            writer.WriteAttribute("valign", "middle");
            writer.Write(Html32TextWriter.TagRightChar);
        }

    }
}
