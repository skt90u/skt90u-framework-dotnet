﻿//  Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Mvc;
using System.Web.UI;

namespace DNA.Mvc.jQuery
{
    /// <summary>
    /// The spliter toolbar item
    /// </summary>
    public class ToolbarSpliter : ViewComponent
    {
        public override string TagName
        {
            get
            {
                return "td";
            }
        }

        public override void RenderBeginTag(HtmlTextWriter writer)
        {
            writer.WriteBeginTag(TagName);
            writer.WriteAttribute("class", "d-toolbar-spliter");
            writer.WriteAttribute("valign", "middle");
            writer.Write(Html32TextWriter.TagRightChar);
        }

        public override void RenderContent(System.Web.UI.HtmlTextWriter writer)
        {
            writer.WriteFullBeginTag("div");
            writer.WriteEndTag("div");
        }
    }
}
