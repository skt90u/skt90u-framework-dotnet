﻿//  Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Mvc;

namespace DNA.Mvc.jQuery
{

    /// <summary>
    /// Define the toolbar button that just display as icon
    /// </summary>
    public class ToolbarIconButton : ToolbarItem
    {
        internal ToolbarIconButton(ToolPane parent) { this._parent = parent; }

        /// <summary>
        /// Gets/Sets the icon css class name of the toolbar button.
        /// </summary>
        public string IconCssClass { get; set; }

        /// <summary>
        /// Gets/Sets the client click scripts of the toolbar button.
        /// </summary>
        public string OnClick { get; set; }

        /// <summary>
        ///  Receives the string of the Toolbar object in json format.
        /// </summary>
        /// <returns>The Json format string.</returns>
        public override string ToJson()
        {
            return "{icon:'" + IconCssClass + "',exec:function(){" + OnClick + "}}";
        }
    }

}
