﻿//  Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Mvc;

namespace DNA.Mvc.jQuery
{
    /// <summary>
    /// Define the pane to contains the toolbar buttons.Use the ToolPane to grouping the ToolBarItems.
    /// </summary>
    public class ToolPane
    {
        private List<ToolbarItem> _items;
        private Toolbar _parent;

        /// <summary>
        /// Receives the ToolbarItems for this ToolPane.
        /// </summary>
        public List<ToolbarItem> Items
        {
            get
            {
                if (_items == null)
                    _items = new List<ToolbarItem>();
                return _items;
            }
        }

        /// <summary>
        /// Initialize the ToolPane by specified the parent Toolbar object.
        /// </summary>
        /// <param name="parent">The parent Toolbar object instance.</param>
        public ToolPane(Toolbar parent) { this._parent = parent; }

        /// <summary>
        /// Gets the parent Toolbar of this ToolPane.
        /// </summary>
        public Toolbar Parent { get { return _parent; } }

        /// <summary>
        /// Add a spliter Toolbar item.
        /// </summary>
        /// <example>
        /// <code language="cs">
        /// &lt;%:
        ///  Ajax.Toolbar("SampleToolbar")
        ///        .ToolPane(pane =>
        ///          {
        ///              pane.AddSpliter();
        ///          });
        ///   %&gt;         
        /// </code>
        /// </example>
        /// <returns>The current ToolPane instance.</returns>
        public ToolPane AddSpliter()
        {
            Items.Add(new ToolbarSpliter(this));
            return this;
        }

        /// <summary>
        /// Add a dropdown toolbar item by specifed item list and client select event handler scripts.
        /// </summary>
        /// <param name="list">The dropdown item list.</param>
        /// <param name="onSelected">The client select event handler.</param>
         /// <returns>The current ToolPane instance.</returns>
        public ToolPane AddDropDown(SelectList list, string onSelected)
        {
            Items.Add(new ToolbarDropdown(this) { Items = list, OnSelected = onSelected });
            return this;
        }

        /// <summary>
        /// Add a text label toolbar item by specified the text content.
        /// </summary>
        /// <param name="text">The text of the label</param>
        /// <code language="cs">
        /// &lt;%:
        ///  Ajax.Toolbar("SampleToolbar")
        ///        .ToolPane(pane =>
        ///          {
        ///              pane.AddLabel("Item1");
        ///              pane.AddSpliter();
        ///              pane.AddLabel("Item2");
        ///          });
        ///   %&gt;         
        /// </code>
        /// <returns>The current ToolPane instance.</returns>
        public ToolPane AddLabel(string text)
        {
            Items.Add(new ToolbarLabel(this) { Text = text });
            return this;
        }

        /// <summary>
        /// Add a icon button toolbar item by specified the text content,icon class and jQuery ajax options.
        /// </summary>
        /// <param name="text">The text of the button</param>
        /// <param name="iconCssClass">The icon css class.</param>
        /// <param name="options">The jQuery ajax option instance.</param>
        /// <returns>The current ToolPane instance.</returns>
        public ToolPane AddIconTextButton(string text, string iconCssClass,jQueryAjaxOptions options)
        {
            return this.AddIconTextButton(text,iconCssClass,Parent.Helper.GeneratejQueryAjaxScripts(options));
        }

        /// <summary>
        ///  Add a button toolbar item by specified the text content ,icon css class and client click scripts.
        /// </summary>
        /// <param name="text">The text of the button</param>
        /// <param name="iconCssClass">The icon css class.</param>
        /// <param name="onClickClick">The client click scripts.</param>
        /// <returns>The current ToolPane instance.</returns>
        public ToolPane AddIconTextButton(string text, string iconCssClass, string onClickClick)
        {
            Items.Add(new ToolbarTextButton(this) { Text = text, IconCssClass = iconCssClass, OnClick = onClickClick });
            return this;
        }

        /// <summary>
        /// Add a icon button toolbar item by specified icon css class and jQuery ajax options.
        /// </summary>
        /// <param name="iconCssClass">The icon css class.</param>
        /// <param name="options">The jQuery ajax option instance.</param>
        /// <returns>The current ToolPane instance.</returns>
        public ToolPane AddIconButton(string iconCssClass, jQueryAjaxOptions options)
        {
            return this.AddIconButton(iconCssClass,Parent.Helper.GeneratejQueryAjaxScripts(options));
        }

        /// <summary>
        /// Add a icon button toolbar item by specified icon css class and client click scripts.
        /// </summary>
        /// <param name="iconCssClass">The icon css class.</param>
        /// <param name="onClientClick">The client click scripts.</param>
        /// <returns>The current ToolPane instance.</returns>
        public ToolPane AddIconButton(string iconCssClass, string onClientClick)
        {
            var icon = new ToolbarIconButton(this) { IconCssClass = iconCssClass, OnClick = onClientClick };
            Items.Add(icon);
            return this;
        }
    }
}
