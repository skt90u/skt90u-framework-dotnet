﻿//  Copyright (c) 2011 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Mvc;

namespace DNA.Mvc.jQuery
{
    public class ToolbarButtonBuilder : ToolbarButtonBuilder<ToolbarButtonBuilder> 
    {
        public ToolbarButtonBuilder(ToolbarButton component, AjaxHelper helper) : base(component, helper) { }
    }

    public class ToolbarButtonBuilder<TBuilder> : TemplateViewBuilder<ToolbarButton>
        where TBuilder:ToolbarButtonBuilder<TBuilder>
    {
        public ToolbarButtonBuilder(ToolbarButton component, AjaxHelper helper) : base(component, helper) { }
        private ButtonBuilder button;

        protected virtual ButtonBuilder Button
        {
            get
            {
                if (button == null)
                {
                    button = new ButtonBuilder(new Button() { Name =Component.Id }, Helper);
                    Component.Template = new Action(() =>
                    {
                        button.ChangeType(ButtonTypes.LinkButton).Render();
                    });
                }
                return button;
            }
        }

        public override TemplateViewBuilder<ToolbarButton> Name(string name)
        {
            button.Name(name);
            return this as TBuilder;
            //return base.Name(name);
        }

        public TBuilder Settings(Action<ButtonBuilder> settings)
        {
            settings.Invoke(Button);
            return this as TBuilder;
        }

        public TBuilder Text(string text)
        {
            Component.Text = text;
            Button.Text(text);
            return this as TBuilder;
        }

        public TBuilder Icons(string primaryIcon)
        {
            return this.Icons(primaryIcon, null);
        }

        public TBuilder Icons(string primaryIcon, string secondaryIcon)
        {
            Component.PrimaryIconCssClass = primaryIcon;
            Component.SecondaryIconCssClass = secondaryIcon;
            Button.Icons(primaryIcon, secondaryIcon);
            return this as TBuilder;
        }

        public TBuilder ImageIcons(string primaryIconUrl)
        {
            return this.ImageIcons(primaryIconUrl, null);
        }

        public TBuilder ImageIcons(string primaryIconUrl, string secondaryIconUrl)
        {
            Component.PrimaryIconImageUrl = primaryIconUrl;
            Component.SecondaryIconImageUrl = secondaryIconUrl;
            Button.ImageIcons(primaryIconUrl, secondaryIconUrl);
            return this as TBuilder;
        }

        public TBuilder NavigateUrl(string url)
        {
            Component.NavigateUrl = url;
            Button.NavigateUrl(url);
            return this as TBuilder;
        }

        public TBuilder Click(string scripts)
        {
            Component.OnClick = scripts;
            Button.Click(scripts);
            return this as TBuilder;
        }

        public TBuilder Click(StringBuilder scripts)
        {
            return this.Click(scripts.ToString());
        }

        public override void Render()
        {
            Template(() =>
            {
                Button.Render();
            });
            base.Render();
        }

    }
}
