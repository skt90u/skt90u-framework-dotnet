﻿//  Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Mvc;

namespace DNA.Mvc.jQuery
{
    /// <summary>
    /// The extension methods to create the toolbar
    /// </summary>
    public static class ToolbarExtensions
    {
        /// <summary>
        /// The extension method to create the toolbar
        /// </summary>
        /// <param name="helper">The helper object</param>
        /// <param name="name">Specified the name for the toolbar</param>
        /// <returns>The toolbar instance</returns>
        public static Toolbar Toolbar(this AjaxHelper helper,string name)
        {
            var _tb = new Toolbar() { Name = name };
            _tb.Helper = helper;
            return _tb;
        }
    }
}
