﻿//  Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Web.Mvc;
using System.Web.UI;

namespace DNA.Mvc.jQuery
{
    /// <summary>
    /// Represents support for rendering HTML and jQuery scripts for toolbar jQuery plugin control.
    /// </summary>
    public class Toolbar : ContainerViewComponent<ViewComponent>
    {
        //private List<ToolPane> toolPanes = new List<ToolPane>();
        //private string _name;
        //internal AjaxHelper Helper { get; set; }
        //private bool _enableDragAndDrop = false;

        ///// <summary>
        /////  Enable the toolbar items drag and drop supports.
        ///// </summary>
        ///// <param name="value"></param>
        ///// <returns>The current Toolbar instance.</returns>
        //public Toolbar EnableDragAndDrop(bool value)
        //{
        //    _enableDragAndDrop = value;
        //    return this;
        //}

        ///// <summary>
        ///// Gets/Sets the toolbar name
        ///// </summary>
        //public string Name
        //{
        //    get { return _name; }
        //    set { _name = value; }
        //}

        ///// <summary>
        ///// Gets the ToolPane collection of the toolbar
        ///// </summary>
        //public List<ToolPane> ToolPanes { get { return toolPanes; } }

        ///// <summary>
        ///// The helper method to allows user add the toolpane and items though lamda expression
        ///// </summary>
        ///// <param name="expr">The lamda expression that add toolpane and toolbar items to toolbar</param>
        ///// <returns>The current Toolbar instance.</returns>
        //public Toolbar ToolPane(Action<ToolPane> expr)
        //{
        //    var pane = new ToolPane(this);
        //    expr.Invoke(pane);
        //    this.ToolPanes.Add(pane);
        //    return this;
        //}

        ///// <summary>
        ///// Output the toolbar html and register the toolbar scripts.
        ///// </summary>
        ///// <returns>The html reparents the toolbar.</returns>
        //public MvcHtmlString Render()
        //{
        //    return this.Render(null);
        //}

        ///// <summary>
        ///// Output the toolbar html and register the toolbar scripts.
        ///// </summary>
        ///// <param name="htmlAttributes">The html attributes of the toolbar container element.</param>
        ///// <returns>The html reparents the toolbar.</returns>
        //public MvcHtmlString Render(object htmlAttributes)
        //{
        //    TagBuilder tag = new TagBuilder("div");
        //    tag.Attributes.Add("id", Name);
        //    if (htmlAttributes != null)
        //        tag.MergeAttributes<string, object>(ObjectHelper.ConvertObjectToDictionary(htmlAttributes));
        //    StringBuilder scripts = new StringBuilder();
        //    if (_enableDragAndDrop)
        //    {
        //        scripts.Append("sortable:true,");
        //    }

        //    scripts.Append("toolpanes:[");
        //    int i = 0;
        //    foreach (var pane in toolPanes)
        //    {
        //        if (i > 0)
        //            scripts.Append(",");
        //        scripts.Append("{commands:[");
        //        var j = 0;
        //        foreach (var item in pane.Items)
        //        {
        //            if (j > 0)
        //                scripts.Append(",");
        //            scripts.Append(item.ToJson());
        //            j++;
        //        }
        //        scripts.Append("]}");
        //        i++;
        //    }
        //    scripts.Append("]");
        //    Helper.RegisterStartupScript("$(\"#" + Name+"\").toolbar({"+scripts.ToString()+"})");
        //    return MvcHtmlString.Create(tag.ToString());
        //}

        private bool showDragHandler = false;

        public bool ShowDragHandler
        {
            get { return showDragHandler; }
            set { showDragHandler = value; }
        }

        public IList<ViewComponent> ToolbarButtons
        {
            get { return InnerItems; }
            set { InnerItems = value; }
        }

        public override string TagName
        {
            get
            {
                return "table";
            }
        }

        public override void RenderBeginTag(HtmlTextWriter writer)
        {
            if (this.HtmlAttributes.ContainsKey("class"))
                this.HtmlAttributes["class"] = "d-toolbar " + this.HtmlAttributes["class"].ToString();
            else
                this.MergeAttribute("class", "d-toolbar");

            base.RenderBeginTag(writer);
        }

        public override void RenderContent(HtmlTextWriter writer)
        {
            writer.WriteFullBeginTag("tr");

            if (showDragHandler)
            {
                writer.WriteBeginTag("td");
                writer.WriteAttribute("valign", "middle");
                writer.Write(HtmlTextWriter.TagRightChar);
                writer.WriteBeginTag("span");
                writer.WriteAttribute("class", "d-toolbar-draghandler");
                writer.Write(HtmlTextWriter.TagRightChar);
                writer.Write("&nbsp;");
                writer.WriteEndTag("span");
                writer.WriteEndTag("td");
            }

            base.RenderContent(writer);
            writer.WriteEndTag("tr");
        }
    }
}

