﻿//  Copyright (c) 2011 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Mvc;

namespace DNA.Mvc.jQuery
{
    public class ToolbarButtonFactory : ViewComponentBuilderFactory<ViewComponent>
    {
        public ToolbarButtonFactory(Toolbar container, AjaxHelper helper) : base(container, helper) { }
        private int btnIndex = 0;
        private int comboIndex = 0;

        public ToolbarButtonBuilder Add()
        {
            btnIndex++;
            var button = new ToolbarButton() { Name = ((ViewComponent)Container).Id +"button"+ btnIndex.ToString() };
            this.AddItem(button);
            var builder = new ToolbarButtonBuilder(button, Helper);
            return builder;
        }

        public ToolbarButtonBuilder AddButton(string text)
        {
            return Add().Text(text);
        }

        public ToolbarButtonBuilder AddButton(string text, string onclick)
        {
            return Add().Text(text).Click(onclick);
        }

        public ToolbarButtonBuilder AddImageButton(string imageUrl, string onclick)
        {
            return this.Add().ImageIcons(imageUrl).Click(onclick);
        }
        
        public ToolbarButtonBuilder AddIconButton(string cssClass, string onclick)
        {
            return this.Add().Icons(cssClass).Click(onclick);
        }

        public ToolbarDropdownBuilder AddDropdown(string text)
        {
            btnIndex++;
            var button = new ToolbarButton() { Name = ((ViewComponent)Container).Id + "button" + btnIndex.ToString() };
            this.AddItem(button);
            var builder = new ToolbarDropdownBuilder(button, Helper);
            builder.Text(text);

            return builder;
        }

        public ToolbarButtonBuilder AddLink(string text, string navigateUrl)
        {
            return Add().Text(text).NavigateUrl(navigateUrl);
        }

        private void AddItem(ViewComponent item)
        {
            Container.Items.Add(item);
            Container.OnItemAdded(item);
        }

        public void AddLabel(string text)
        {
            this.AddItem(new ToolbarLabel() { Text = text });
        }

        public void AddSpliter()
        {
            var spliter = new ToolbarSpliter();
            this.AddItem(spliter);
        }

        public ComboBoxBuilder AddCombo()
        {
            comboIndex++;
            var combo = Helper.Dna().ComboBox(((ViewComponent)Container).Id + "combo" + comboIndex.ToString());
            this.Add().Template(() =>
            {
                combo.Render();
            });
            return combo;
        }
    }

}
