﻿//  Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Mvc;

namespace DNA.Mvc.jQuery
{
    /// <summary>
    /// Define a ToolbarItem that contains a dropdown list
    /// </summary>
    public class ToolbarDropdownBuilder : ToolbarButtonBuilder<ToolbarDropdownBuilder>
    {
        public ToolbarDropdownBuilder(ToolbarButton component, AjaxHelper helper) : base(component, helper) { }

        public ToolbarDropdownBuilder SplitButtonClick(string onClick)
        {
            Button.ShowSplitButton(onClick);
            return this;
        }

        public ToolbarDropdownBuilder MenuItems(Action<MenuItemFactory> items)
        {
            var contextMenu = new Menu() { Name = Component.Id + "_contextmenu" };
            var menuBuilder = new MenuBuilder(contextMenu, Helper);
            var factory = new MenuItemFactory(contextMenu, Helper);
            items.Invoke(factory);

            Component.Template = new Action(() =>
            {
                Button.ChangeType(ButtonTypes.LinkButton)
                    .ShowSplitButton("$(\"#" + Component.Id + "_contextmenu\").dnamenu(\"dropdown\",this);")
                    .Render();

                menuBuilder.ChangeType(MenuTypes.Context)
                    .DefaultStyle()
                    .Render();
            });

            return this;
        }
    }
}
