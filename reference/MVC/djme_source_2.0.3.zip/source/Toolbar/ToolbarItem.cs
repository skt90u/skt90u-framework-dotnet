﻿//  Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Mvc;

namespace DNA.Mvc.jQuery
{
    /// <summary>
    /// The base class of the toolbar items
    /// </summary>
    public abstract class ToolbarItem:ViewComponent
    {
        ///// <summary>
        ///// Gets the parent toolbar
        ///// </summary>
        //protected ToolPane _parent;

        ///// <summary>
        ///// Gets/Sets the parent toolpane that contains this ToolbarItem
        ///// </summary>
        //public ToolPane Parent { get { return _parent; } }

        ///// <summary>
        ///// Gets/Sets the name of the ToolbarItem
        ///// </summary>
        //public string Name { get; set; }

        //public abstract string ToJson();
    }

}
