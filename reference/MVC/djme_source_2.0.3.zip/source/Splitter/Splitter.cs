﻿//  Copyright (c) 2011 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.UI;

namespace DNA.Mvc.jQuery
{
    public class Splitter : ViewComponent
    {
        private Orientation orientation = Orientation.Horizontal;

        public Orientation Orientation
        {
            get { return orientation; }
            set { orientation = value; }
        }

        public Action PanelA { get; set; }

        public Action PanelB { get; set; }

        public override string TagName
        {
            get
            {
                return "div";
            }
        }

        public override void RenderBeginTag(HtmlTextWriter writer)
        {
            if (Orientation == Orientation.Vertical)
                MergeAttribute("class", "d-splitter d-splitter-vertical");
            else
                MergeAttribute("class", "d-splitter d-splitter-horizontal");
            //if (Width > 0 || Height > 0)
            //    MergeAttribute("style", (Width > 0 ? "width:" + Width.ToString() + "px;" : "") + (Height > 0 ? "height:" + Height.ToString() + "px;" : ""));

            base.RenderBeginTag(writer);
        }
        public override void RenderContent(HtmlTextWriter writer)
        {
            writer.WriteBeginTag("table");
            if (this.Height > 0)
                writer.WriteAttribute("style", "height:" + Height.ToString() + "px");
            writer.WriteAttribute("cellspacing","0");
            writer.Write(HtmlTextWriter.TagRightChar);

            if (orientation == Orientation.Horizontal)
            {
                writer.WriteFullBeginTag("tr");

                writer.WriteBeginTag("td");
                writer.WriteAttribute("class", "d-splitter-panel");
                writer.WriteAttribute("id", Id + "_paneA");
                writer.WriteAttribute("valign", "top");
                writer.Write(HtmlTextWriter.TagRightChar);

                if (PanelA != null)
                    PanelA.Invoke();
                writer.WriteEndTag("td");

                writer.WriteBeginTag("td");
                writer.WriteAttribute("class", "d-splitter-helper");

                writer.Write(HtmlTextWriter.TagRightChar);
                writer.WriteEndTag("td");

                writer.WriteBeginTag("td");
                writer.WriteAttribute("class", "d-splitter-panel");
                writer.WriteAttribute("id", Id + "_paneB");
                writer.WriteAttribute("valign", "top");
                writer.Write(HtmlTextWriter.TagRightChar);

                if (PanelB != null)
                    PanelB.Invoke();

                writer.WriteEndTag("td");
                writer.WriteEndTag("tr");
            }
            else
            {
                writer.WriteFullBeginTag("tr");
                writer.WriteBeginTag("td");
                writer.WriteAttribute("valign", "top");
                writer.WriteAttribute("class", "d-splitter-panel");
                writer.Write(HtmlTextWriter.TagRightChar);
                if (PanelA != null)
                    PanelA.Invoke();
                writer.WriteEndTag("td");
                writer.WriteEndTag("tr");

                writer.WriteFullBeginTag("tr");
                writer.WriteBeginTag("td");
                writer.WriteAttribute("valign", "top");
                writer.WriteAttribute("class", "d-splitter-panel");
                writer.Write(HtmlTextWriter.TagRightChar);
                if (PanelB != null)
                    PanelB.Invoke();

                writer.WriteEndTag("td");
                writer.WriteEndTag("tr");

            }
            writer.WriteEndTag("table");
        }
    }
}
