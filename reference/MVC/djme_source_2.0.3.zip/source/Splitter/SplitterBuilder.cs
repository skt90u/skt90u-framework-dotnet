﻿//  Copyright (c) 2011 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Mvc;

namespace DNA.Mvc.jQuery
{
    public class SplitterBuilder : jQueryComponentBuilder<SplitterOptions, Splitter,SplitterBuilder>
    {
        public SplitterBuilder(Splitter component, AjaxHelper helper) : base(component, helper) { }

        protected override string jQueryPluginName
        {
            get { return "splitter"; }
        }
        
        public SplitterBuilder PanelA(Action panel)
        {
            Component.PanelA = panel;
            return this;
        }

        public SplitterBuilder PanelB(Action panel)
        {
            Component.PanelB = panel;
            return this;
        }

        public override void Render()
        {
            Options(opts => {
                opts.PaneA ="#"+ Component.Id + "_paneA";
                opts.PaneB = "#"+Component.Id + "_paneB";
            });
            base.Render();
        }
    }

    public class SplitterOptions
    {
        private Orientation orientation = Orientation.Vertical;
        
        [jQueryOption("paneA")]
        public string PaneA { get; set; }
        
        [jQueryOption("paneB")]
        public string PaneB { get; set; }

        [jQueryOption("orientation")]
        public Orientation Orientation
        {
            get { return orientation; }
            set { orientation = value; }
        }
    }
}
