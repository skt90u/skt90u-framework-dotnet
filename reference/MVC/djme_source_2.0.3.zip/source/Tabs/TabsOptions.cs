﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DNA.Mvc.jQuery
{
    /// <summary>
    /// Defines a strongly type class of the jQuery.ui tabs plugin Options.
    /// </summary>
    ///<remarks>
    /// jQuery method will genernate the json object for the tabs plugin in javascript.
    /// </remarks>
    /// <example>
    ///  You can put this code on your Mvc View in order to output the tabs plugin in server side syntax.
    ///  <code>
    ///       &lt;% 
    ///       Ajax.jQuery("#tagname",new TabsOptions(){
    ///          SelectedIndex=1,
    ///          EnabledContentCache=true
    ///       });
    ///      %&gt;
    ///  </code>
    /// </example>
    public class TabsOptions
    {
        /// <summary>
        /// Gets/Sets Whether or not to cache remote tabs content.
        /// </summary>
        /// <remarks>
        /// e.g. load only once or with every click. 
        /// Cached content is being lazy loaded, e.g once and only once for the first click. 
        /// Note that to prevent the actual Ajax requests from being cached by the browser you need 
        /// to provide an extra cache: false flag to ajaxOptions.
        /// </remarks>
        [jQueryOption("cache")]
        public bool? EnabledContentCache { get; set; }

        /// <summary>
        /// Gets/Sets whether tabs allow an already selected tab to become unselected again upon reselection.
        /// </summary>
        [jQueryOption("collapsible")]
        public bool? Collapsible { get; set; }

        [jQueryIgnore]
        public bool IsSortable { get; set; }
        /// <summary>
        /// Gets/Sets whether the tabs can be select
        /// </summary>
        /// <remarks>deprecated in jQuery UI 1.7, use collapsible.</remarks>
        [jQueryOption("deselectable")]
        public bool? Deselectable { get; set; }

        /// <summary>
        ///  Gets/Sets the current selected tab's index
        /// </summary>
        /// <remarks>Zero-based index of the tab to be selected on initialization. To set all tabs to nselected pass -1 as value.</remarks>
        [jQueryOption("selected")]
        public int? SelectedIndex{get;set;}

        /// <summary>
        /// Gets/Sets the HTML content of this string is shown in a tab title while remote content is loading. 
        /// </summary>
        /// <remarks>
        /// Pass in empty string to deactivate that behavior.
        /// </remarks>
        [jQueryOption("spinner")]
        public string Spinner { get; set; }

        /// <summary>
        /// HTML template from which a new tab panel is created in case of adding a tab with the add method or when creating a 
        /// panel for a remote tab on the fly.
        /// </summary>
        [jQueryOption("panelTemplate")]
        public string HtmlContentTemplate { get; set; }

        /// <summary>
        /// HTML template from which a new tab is created and added. The placeholders #{href} and #{label} are replaced with the url and tab label that are passed as arguments to the add method.
        /// </summary>
        [jQueryOption("tabTemplate")]
        public string HtmlTabTemplate { get; set; }

        [jQueryIgnore]
        public TabsLayouts TabsLayout { get; set; }

        /// <summary>
        ///Gets/Sets the tabs client load event handler.
        /// </summary>
        /// <remarks>This event is triggered after the content of a remote tab has been loaded.</remarks>
        [jQueryOption("load", ValueType = JavaScriptTypes.Function, FunctionParams = new string[] { "event", "ui" })]
        public string OnTabLoad { get; set; }

        /// <summary>
        /// Gets/Sets the tabs client show event handler.
        /// </summary>
        /// <remarks>
        /// This event is triggered when a tab is shown.
        /// </remarks>
        [jQueryOption("show", ValueType = JavaScriptTypes.Function, FunctionParams = new string[] { "event", "ui" })]
        public string OnTabShow { get; set; }

        /// <summary>
        /// Gets/Sets the tabs add event handler.
        /// </summary>
        /// <remarks>
        /// This event is triggered when a tab is added
        /// </remarks>
        [jQueryOption("add", ValueType = JavaScriptTypes.Function, FunctionParams = new string[] { "event", "ui" })]
        public string OnTabAdd { get; set; }

        /// <summary>
        /// Gets/Sets the tab remove event handler.
        /// </summary>
        /// <remarks>
        /// This event is triggered when a tab is removed.
        /// </remarks>
        [jQueryOption("remove", ValueType = JavaScriptTypes.Function, FunctionParams = new string[] { "event", "ui" })]
        public string OnTabRemove { get; set; }

        /// <summary>
        /// Gets/Sets the tabs client tab selected event handler.
        /// </summary>
        /// <remarks>
        /// This event is triggered when a tab is selected.
        /// </remarks>
        [jQueryOption("select", ValueType = JavaScriptTypes.Function, FunctionParams = new string[] { "event", "ui" })]
        public string OnTabSelected { get; set; }

        /// <summary>
        /// Gets/Sets the tabs client enabled event handler.
        /// </summary>
        /// <remarks>
        /// This event is triggered when a tab is enabled.
        /// </remarks>
        [jQueryOption("enable", ValueType = JavaScriptTypes.Function, FunctionParams = new string[] { "event", "ui" })]
        public string OnTabEnabled { get; set; }

        /// <summary>
        /// Gets/Sets the tabs client disabled event handler.
        /// </summary>
        /// <remarks>
        /// This event is triggered when a tab is disable.
        /// </remarks>
        [jQueryOption("disable", ValueType = JavaScriptTypes.Function, FunctionParams = new string[] { "event", "ui" })]
        public string OnTabDisabled { get; set; }

        [jQueryOption("event")]
        public DomEvents ActiveTabEvent { get; set; }

        [jQueryOption("disabled")]
        public string[] DisableTabs { get; set; }

        [jQueryOption("fx",ValueType=JavaScriptTypes.JSON)]
        public object Animations { get; set; }

        [jQueryOption("ajaxOptions",ValueType=JavaScriptTypes.JSON)]
        public jQueryAjaxOptions AjaxOptions { get; set; }
    
    }
}
