﻿//  Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace DNA.Mvc.jQuery
{
    public class TabViewBuilder:ViewComponentBuilder<TabView,TabViewBuilder>
    {
        public TabViewBuilder(TabView component, AjaxHelper helper) : base(component, helper) { }
        
        public TabViewBuilder Load(string contentUrl)
        {
            this.Component.RemoteContentUrl = contentUrl;
            return this;
        }

        public TabViewBuilder Template(Action value)
        {
            this.Component.Template = value;
            return this;
        }
    }
}
