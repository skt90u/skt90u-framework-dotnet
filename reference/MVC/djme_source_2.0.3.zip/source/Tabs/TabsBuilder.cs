﻿//  Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace DNA.Mvc.jQuery
{
    public class TabsBuilder:jQueryComponentBuilder<TabsOptions,Tabs,TabsBuilder>
    {
        public TabsBuilder(Tabs component, AjaxHelper helper) : base(component, helper) { }

        public TabsBuilder Views(Action<TabViewFactory> value)
        {
            var factory = new TabViewFactory(this.Component, Helper);
            value.Invoke(factory);
            return this;
        }

        protected override string jQueryPluginName
        {
            get 
            {
                if (options != null) 
                { 
                    if ((options.TabsLayout==TabsLayouts.Left) || (options.TabsLayout==TabsLayouts.Right))
                        return "tags";
                }
                return "tabs"; 
            }
        }

        public TabsBuilder Layout(TabsLayouts layout)
        {
            Options(opts => {
                options.TabsLayout = layout;
            });
            return this;
        }


        public override void Render()
        {    
            if (options != null)
            {
                if (options.TabsLayout == TabsLayouts.Bottom)
                    Component.HtmlAttributes.Add("class", "tabs-bottom");
                    Helper.RegisterStartupScript("$(\".tabs-bottom .ui-tabs-nav, .tabs-bottom .ui-tabs-nav > *\" ).removeClass(\"ui-corner-all ui-corner-top\").addClass(\"ui-corner-bottom\");");
            }

            base.Render();

            if (options != null)
            {
                if (options.TabsLayout == TabsLayouts.Bottom)
                Helper.RegisterStartupScript("$(\".tabs-bottom .ui-tabs-nav, .tabs-bottom .ui-tabs-nav > *\" ).removeClass(\"ui-corner-all ui-corner-top\").addClass(\"ui-corner-bottom\");");
            }

            if ((options != null) && (options.IsSortable))
                Helper.RegisterStartupScript("$(\"#"+Component.Id+"\").find(\".ui-tabs-nav\").sortable({ axis: \"x\" });");
        }
    }
}
