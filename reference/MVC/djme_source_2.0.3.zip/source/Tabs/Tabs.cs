﻿//  Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.UI;

namespace DNA.Mvc.jQuery
{
    public class Tabs : ContainerViewComponent<TabView>
    {
        public List<TabView> Views
        {
            get { return this.InnerItems.Select(view => { return (TabView)view; }).ToList(); }
            set { this.InnerItems = value; }
        }

        public override void RenderContent(System.Web.UI.HtmlTextWriter writer)
        {
            writer.WriteFullBeginTag("ul");
            int i = 0;
            foreach (var view in InnerItems)
            {
                writer.WriteFullBeginTag("li");
                writer.WriteBeginTag("a");
                view.Name = this.Name + "_tab_" + i.ToString();
                if (!string.IsNullOrEmpty(view.RemoteContentUrl))
                    writer.WriteAttribute("href", view.RemoteContentUrl);
                else
                    writer.WriteAttribute("href", "#" + view.Name);

                writer.Write(HtmlTextWriter.TagRightChar);
                writer.Write(view.Title);
                writer.WriteEndTag("a");
                writer.WriteEndTag("li");
                i++;
            }

            writer.WriteEndTag("ul");



            foreach (var view in InnerItems)
            {
                if (string.IsNullOrEmpty(view.RemoteContentUrl))
                    view.Render(writer);
            }
        }
    }
}
