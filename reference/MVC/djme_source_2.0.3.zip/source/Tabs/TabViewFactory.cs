﻿//  Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace DNA.Mvc.jQuery
{
    public class TabViewFactory : ViewComponentBuilderFactory<TabView>
    {
        public TabViewFactory(IComponentItemContainer<TabView> container, AjaxHelper helper) : base(container, helper) { }

        public TabViewBuilder Add(string title)
        {
            var item = new TabView() { Title = title };
            Container.Items.Add(item);
            Container.OnItemAdded(item);
            return new TabViewBuilder(item, Helper);
        }

        public TabViewBuilder Add(string title, string remoteContentUrl)
        {
            var item = new TabView() {
             Title=title,
             RemoteContentUrl=remoteContentUrl
            };
            Container.Items.Add(item);
            Container.OnItemAdded(item);
            return new TabViewBuilder(item, Helper);
        }
    }
}
