﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Mvc;

namespace DNA.Mvc.jQuery
{
    /// <summary>
    /// Specified the jQuery option info for jQueryOptionsBuilder.
    /// </summary>
    [AttributeUsage(AttributeTargets.Property, Inherited = true, AllowMultiple = false)]
    public class jQueryOptionAttribute : Attribute
    {
        private JavaScriptTypes valueType = JavaScriptTypes.String;

        /// <summary>
        /// Gets/Sets the function parameters.
        /// </summary>
        public string[] FunctionParams { get; set; }

        /// <summary>
        /// Gets/Sets wheather the jQuery option allows null value.
        /// </summary>
        public bool AllowNull { get; set; }

        /// <summary>
        /// Gets/Sets the jQuery option value type.
        /// </summary>
        public JavaScriptTypes ValueType
        {
            get { return valueType; }
            set { valueType = value; }
        }

        /// <summary>
        /// Gets/Sets the Default value of the jQuery option.
        /// </summary>
        public object DefaultValue { get; set; }

        /// <summary>
        /// Gets/Sets the jQuery option name
        /// </summary>
        public string Name { get; set; }
        
        /// <summary>
        /// Initizialize the jQueryOptionAttribute by specified the jQuery option name.
        /// </summary>
        /// <param name="name">Specified the jQuery option name.</param>
        public jQueryOptionAttribute(string name) { Name = name; }
        
        /// <summary>
        /// Initizialize the jQueryOptionAttribute by specified the jQuery option name and default value.
        /// </summary>
        /// <param name="name">Specified the jQuery option name.</param>
        /// <param name="defaultValue">The jQuery option default value.</param>
        public jQueryOptionAttribute(string name, object defaultValue) { Name = name; DefaultValue = defaultValue; }
    }
}
