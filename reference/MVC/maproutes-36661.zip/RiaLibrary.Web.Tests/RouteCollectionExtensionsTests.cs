﻿using RiaLibrary.Web;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Web.Routing;
using System.Reflection;
using System.Web.Mvc;

namespace RiaLibrary.Web.Tests
{
    public class TestController : Controller
    {
        [Url("", 1)]
        public ActionResult Home()
        {
            return View();
        }

        [Url("about", 3)]
        public ActionResult About()
        {
            return View();
        }

        [Url("product/{name}", "name=hello", "name=[a-z]+", 4)]
        public ActionResult Product()
        {
            return View();
        }

        [Url("contacts", 2)]
        public ActionResult Contacts()
        {
            return View();
        }

        [Url("store/{category?}")]
        public ActionResult Store()
        {
            return View();
        }
    }

    [TestClass]
    public class RouteCollectionExtensionsTests
    {
        [TestMethod]
        public void MapRoutes_Should_Register_All_Attribute_Based_Routes_from_an_Assembly()
        {
            // Arrange
            var routes = new RouteCollection();
            var assembly = this.GetType().Assembly;

            // Execute
            routes.MapRoutes(assembly);

            // Verify
            Assert.AreEqual(5, routes.Count);
            Assert.AreEqual("", ((Route)routes[0]).Url);
            Assert.AreEqual("contacts", ((Route)routes[1]).Url);
            Assert.AreEqual("about", ((Route)routes[2]).Url);
            Assert.AreEqual("product/{name}", ((Route)routes[3]).Url);
            Assert.AreEqual(3, ((Route)routes[3]).Defaults.Count);
            Assert.AreEqual("", ((Route)routes[3]).Defaults["name"]);
            Assert.AreEqual("Test", ((Route)routes[3]).Defaults["Controller"]);
            Assert.AreEqual("Product", ((Route)routes[3]).Defaults["Action"]);
            Assert.AreEqual(1, ((Route)routes[3]).Constraints.Count);
        }
    }
}
