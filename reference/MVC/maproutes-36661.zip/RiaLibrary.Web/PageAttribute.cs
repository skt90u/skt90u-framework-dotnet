﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Mvc;

namespace RiaLibrary.Web
{
    [AttributeUsage(AttributeTargets.Method, Inherited = true, AllowMultiple = false)]
    public class PageAttribute : ActionFilterAttribute
    {
        /// <summary>
        /// Page ID
        /// </summary>
        public Guid ID { get; set; }

        /// <summary>
        /// Page title
        /// </summary>
        public string Title { get; set; }

        /// <summary>
        /// Page description
        /// </summary>
        public string Description { get; set; }
    }
}
