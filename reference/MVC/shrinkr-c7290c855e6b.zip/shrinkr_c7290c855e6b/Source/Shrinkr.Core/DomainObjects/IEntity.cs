namespace Shrinkr.DomainObjects
{
    public interface IEntity
    {
        long Id
        {
            get;
        }
    }
}