﻿namespace Shrinkr.DomainObjects
{
    using Infrastructure;

    public class PossibleSpamDetectedEvent : EventBase<EventArgs<Alias>>
    {
    }
}