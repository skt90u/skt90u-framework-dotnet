﻿namespace Shrinkr.DomainObjects
{
    public class Referrer
    {
        public virtual string Domain
        {
            get;
            set;
        }

        public virtual string Url
        {
            get;
            set;
        }
    }
}