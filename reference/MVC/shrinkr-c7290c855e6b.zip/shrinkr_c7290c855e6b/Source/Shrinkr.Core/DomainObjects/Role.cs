﻿namespace Shrinkr.DomainObjects
{
    public enum Role
    {
        User = 0,
        Administrator = 1
    }
}