namespace Shrinkr.Infrastructure
{
    public enum ThumbnailSize
    {
        Small,
        Medium,
        Large
    }
}