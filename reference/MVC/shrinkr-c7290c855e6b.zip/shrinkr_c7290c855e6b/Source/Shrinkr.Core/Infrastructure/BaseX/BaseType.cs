﻿namespace Shrinkr.Infrastructure
{
    public enum BaseType
    {
        BaseThirtySix,
        BaseSixtyTwo
    }
}