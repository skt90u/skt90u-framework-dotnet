using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Kazi Manzur Rashid & Muhammad Mosa")]
[assembly: AssemblyCopyright("Copyright Kazi Manzur Rashid & Muhammad Mosa � 2010")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: ComVisible(false)]