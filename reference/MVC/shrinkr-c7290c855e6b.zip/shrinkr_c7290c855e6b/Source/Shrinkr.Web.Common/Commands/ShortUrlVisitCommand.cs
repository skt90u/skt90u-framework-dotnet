﻿namespace Shrinkr.Web
{
    public class ShortUrlVisitCommand : UserCommand
    {
        public string Alias
        {
            get;
            set;
        }
    }
}