﻿namespace Shrinkr.Web
{
    public class ProfileCommand : UserCommand
    {
    }
}