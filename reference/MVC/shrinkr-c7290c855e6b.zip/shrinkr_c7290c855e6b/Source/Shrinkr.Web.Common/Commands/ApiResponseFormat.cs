﻿namespace Shrinkr.Web
{
    public enum ApiResponseFormat
    {
        Text,
        Json,
        Xml
    }
}