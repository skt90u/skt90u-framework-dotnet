﻿namespace Shrinkr.Web
{
    public class ShortUrlListCommand : UserCommand
    {
        public int? Page
        {
            get;
            set;
        }
    }
}