﻿using System;
using System.Reflection;
using System.Resources;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Security;

[assembly: AssemblyTitle("Shrinkr.Web.Common")]
[assembly: AssemblyProduct("Shrinkr.Web.Common")]
[assembly: AllowPartiallyTrustedCallers]
[assembly: CLSCompliant(true)]
[assembly: Guid("754b7905-ac2c-419b-9745-8de31bb6a449")]
[assembly: InternalsVisibleTo("Shrinkr.Web.Common.UnitTests")]
[assembly: NeutralResourcesLanguage("en", UltimateResourceFallbackLocation.MainAssembly)]