﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyProduct("Shrinkr.AcceptanceTests")]
[assembly: AssemblyTitle("Shrinkr.AcceptanceTests")]
[assembly: Guid("61a09337-b9b3-4249-b986-13361c221317")]