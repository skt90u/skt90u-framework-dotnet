﻿using System;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security;

[assembly: AssemblyTitle("Shrinkr.Web.MixStack")]
[assembly: AssemblyProduct("Shrinkr.Web.MixStack")]
[assembly: AllowPartiallyTrustedCallers]
[assembly: CLSCompliant(true)]
[assembly: Guid("E386D8A9-54D3-44E6-AB4C-7FFF31543EB4")]