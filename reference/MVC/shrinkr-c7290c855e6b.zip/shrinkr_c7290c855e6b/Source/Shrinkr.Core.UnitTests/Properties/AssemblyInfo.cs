﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyProduct("Shrinkr.Core.UnitTests")]
[assembly: AssemblyTitle("Shrinkr.Core.UnitTests")]
[assembly: Guid("c4533ed1-ce4e-46ab-b96f-589f5ca5b7b3")]