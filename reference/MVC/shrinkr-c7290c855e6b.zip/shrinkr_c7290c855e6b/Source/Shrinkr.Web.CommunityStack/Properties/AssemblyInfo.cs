﻿using System;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security;

[assembly: AssemblyTitle("Shrinkr.Web.CommunityStack")]
[assembly: AssemblyProduct("Shrinkr.Web.CommunityStack")]
[assembly: AllowPartiallyTrustedCallers]
[assembly: CLSCompliant(true)]
[assembly: Guid("0bac78d6-ab62-426d-b41a-025126ca2d76")]