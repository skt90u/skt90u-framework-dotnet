﻿using System;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Security;

[assembly: AssemblyTitle("Shrinkr.Infrastructure.NHibernate")]
[assembly: AssemblyProduct("Shrinkr.Infrastructure.NHibernate")]
[assembly: AllowPartiallyTrustedCallers]
[assembly: CLSCompliant(false)]
[assembly: Guid("c10b2b61-2e92-463d-a8fb-dfcfc3996f69")]
[assembly: InternalsVisibleTo("Shrinkr.Infrastructure.NHibernate.IntegrationTests")]