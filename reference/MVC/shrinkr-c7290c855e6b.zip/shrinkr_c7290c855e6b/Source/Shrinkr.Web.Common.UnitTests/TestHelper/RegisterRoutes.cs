﻿namespace Shrinkr.Web.UnitTests
{
    using System.Web.Routing;

    public class RegisterRoutes : ConfigureRoutes
    {
        public RegisterRoutes() : base(RouteTable.Routes)
        {
        }
    }
}