﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Shrinkr.Web.Common.UnitTests")]
[assembly: AssemblyProduct("Shrinkr.Web.Common.UnitTests")]
[assembly: Guid("b5ed8aac-c48f-466f-8c4e-56a662a13e6b")]
