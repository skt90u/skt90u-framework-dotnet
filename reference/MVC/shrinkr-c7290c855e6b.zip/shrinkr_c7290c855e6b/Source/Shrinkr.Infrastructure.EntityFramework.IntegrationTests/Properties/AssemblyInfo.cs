﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyProduct("Shrinkr.Infrastructure.EntityFramework.IntegrationTests")]
[assembly: AssemblyTitle("Shrinkr.Infrastructure.EntityFramework.IntegrationTests")]
[assembly: Guid("1bd720e8-e25a-49e8-a4a8-3e8f8bb19e91")]