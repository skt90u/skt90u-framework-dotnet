﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyProduct("Shrinkr.Infrastructure.NHibernate.IntegrationTests")]
[assembly: AssemblyTitle("Shrinkr.Infrastructure.NHibernate.IntegrationTests")]
[assembly: Guid("7909d4b2-9a94-44fa-a44d-ce1938712e06")]