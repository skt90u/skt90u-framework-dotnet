﻿using System;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security;

[assembly: AssemblyTitle("Shrinkr.Web.MicrosoftStack")]
[assembly: AssemblyProduct("Shrinkr.Web.MicrosoftStack")]
[assembly: AllowPartiallyTrustedCallers]
[assembly: CLSCompliant(true)]
[assembly: Guid("cf7113e4-59b9-4ad8-8501-e1c044c2c3e1")]