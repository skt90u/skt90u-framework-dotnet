﻿using System;
using System.Reflection;
using System.Resources;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Shrinkr.Client.Console")]
[assembly: AssemblyProduct("Shrinkr.Client.Console")]
[assembly: Guid("b7fcd33d-370f-4a8e-9452-7c32c678a3bf")]
[assembly: NeutralResourcesLanguage("en", UltimateResourceFallbackLocation.MainAssembly)]
[assembly: CLSCompliant(true)]
