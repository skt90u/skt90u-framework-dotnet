﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Kazi Manzur Rashid & Muhammad Mosa")]
[assembly: AssemblyCopyright("Copyright Kazi Manzur Rashid & Muhammad Mosa © 2010")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyProduct("Shrinkr.Client.Seesmic")]
[assembly: AssemblyTitle("Shrinkr.Client.Seesmic")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: Guid("ee5e7349-ffe0-444c-9b5a-f35ea8b9ec2d")]