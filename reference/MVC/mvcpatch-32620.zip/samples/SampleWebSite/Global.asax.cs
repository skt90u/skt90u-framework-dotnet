﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;
using MvcPatch;
using SampleWebSite.Models.Blogs;

namespace SampleWebSite
{
    // Note: For instructions on enabling IIS6 or IIS7 classic mode, 
    // visit http://go.microsoft.com/?LinkId=9394801

    public class MvcApplication : System.Web.HttpApplication
    {
        public static void RegisterRoutes(RouteCollection routes)
        {
            routes.Clear();

            // Turns off the unnecessary file exists check
            routes.RouteExistingFiles = true;

            // Ignore axd files such as assest, image, sitemap etc
            routes.IgnoreRoute("{resource}.axd/{*pathInfo}");

            // Ignore the assets directory which contains images, js, css & html
            routes.IgnoreRoute("images/{*pathInfo}");

            // Ignore the error directory which contains error pages
            routes.IgnoreRoute("styles/{*pathInfo}");

            //Exclude favicon (google toolbar request gif file as fav icon which is weird)
            routes.IgnoreRoute("{*favicon}", new { favicon = @"(.*/)?favicon.([iI][cC][oO]|[gG][iI][fF])(/.*)?" });

            routes.MapDomain(
                "Blog",
                "http://{userName}.blogs.{*domain}",
                new { area = "Blog" },
                innerRoutes =>
                {
                    innerRoutes.MapRoute(
                        "Index",
                        "",
                        new { controller = "Blog", action = "Index" },
                        new { controller = "Blog", action = "Index" });

                    innerRoutes.MapRoute(
                        "Default",
                        "{controller}/{action}/{id}",
                        new { controller = "Home", action = "Index", id = "" });
                });
        }

        protected void Application_Start()
        {
            RegisterRoutes(RouteTable.Routes);

            ControllerBuilder.Current.SetControllerFactory(new AreaControllerFactory());

            ModelBinders.Binders.Add(typeof(Post), new PostBinder());
        }
    }
}