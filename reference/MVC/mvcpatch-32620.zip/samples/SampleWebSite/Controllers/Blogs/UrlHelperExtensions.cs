﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Linq.Expressions;
using System.Web.Mvc;
using MvcPatch;

namespace SampleWebSite.Controllers.Blogs
{
    public static class UrlHelperExtensions
    {
        public static string ToBlog(this UrlHelper urlHelper, Expression<Action<BlogController>> action)
        {
            return urlHelper.Action<BlogController>(action);
        }

        public static string ToBlog(this UrlHelper urlHelper, Expression<Action<BlogController>> action, object routeValues)
        {
            return urlHelper.Action<BlogController>(action, routeValues);
        }
    }
}
