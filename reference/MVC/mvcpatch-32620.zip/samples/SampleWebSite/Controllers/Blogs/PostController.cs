using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Mvc.Ajax;
using MvcPatch;
using SampleWebSite.Models.Blogs;

namespace SampleWebSite.Controllers.Blogs
{
    [Area("Blog")]
    public class PostController : Controller
    {
        public ActionResult Detail(Post post)
        {
            return View(post);
        }
    }
}
