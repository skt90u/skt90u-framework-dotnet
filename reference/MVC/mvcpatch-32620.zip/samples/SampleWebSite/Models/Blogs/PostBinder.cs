﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MvcPatch;
using System.Web.Routing;

namespace SampleWebSite.Models.Blogs
{
    public class PostBinder : IModelBinder, IRouteBinder
    {
        public object BindModel(ControllerContext controllerContext, ModelBindingContext bindingContext)
        {
            return new Post
            {
                PostID = Int32.Parse(controllerContext.HttpContext.Request.QueryString["id"]),
                Title = controllerContext.HttpContext.Request.QueryString["title"]
            };
        }

        public RouteValueDictionary BindRoute(RequestContext requestContext, RouteBindingContext bindingContext)
        {
            Post post = (Post)bindingContext.Model;
            return new RouteValueDictionary(new { id = post.PostID, title = post.Title });
        }
    }
}
