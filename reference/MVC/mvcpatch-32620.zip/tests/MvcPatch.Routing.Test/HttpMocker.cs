﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using Moq;

namespace MvcPatch.Routing.Test
{
    public static class HttpMocker
    {
        public static Mock<HttpContextBase> MockRequest(string url, out Mock<HttpRequestWrapper> mockRequest)
        {
            int index = url.IndexOf('?');
            string path = index >= 0 ? url.Substring(0, index) : url;
            string queryString = index >= 0 ? url.Substring(index + 1) : "";

            var realRequest = new HttpRequest("", path, queryString);
            mockRequest = new Mock<HttpRequestWrapper>(realRequest) { CallBase = true };
            mockRequest
                .Setup(r => r.AppRelativeCurrentExecutionFilePath)
                .Returns("~" + realRequest.CurrentExecutionFilePath);

            var mockContext = new Mock<HttpContextBase>();
            mockContext.Setup(c => c.Request).Returns(mockRequest.Object);
            return mockContext;
        }
    }
}
