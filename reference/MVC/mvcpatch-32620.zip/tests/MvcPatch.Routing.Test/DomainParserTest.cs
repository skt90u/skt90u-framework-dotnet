﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Xunit;
using System.Web.Routing;

namespace MvcPatch.Routing.Test
{
    public class DomainParserTest
    {
        [Fact]
        public void Capture_Segments()
        {
            var parser = new DomainParser("http://{sub_domain}.{*domain}");
            var sorted = parser.Segments.OrderBy(s => s).ToList();
            Assert.Equal("domain", sorted[0]);
            Assert.Equal("sub_domain", sorted[1]);
        }

        [Fact]
        public void Parse_Domain()
        {
            var parser = new DomainParser("{scheme}://{sub_domain}.{*domain}");
            var values = parser.Match(new Uri("http://space.cnblogs.com"));
            Assert.Equal("http", values["scheme"]);
            Assert.Equal("space", values["sub_domain"]);
            Assert.Equal("cnblogs.com", values["domain"]);

            var sslParser = new DomainParser("https://{sub_domain}.{*domain}");
            Assert.Null(sslParser.Match(new Uri("http://www.cnblogs.com")));
        }

        [Fact]
        public void Build_Domain()
        {
            var parser = new DomainParser("{scheme}://{sub_domain}.{*domain}");

            var currentValues = new RouteValueDictionary(
                new { scheme = "http", domain = "cnblogs.com", sub_domain = "space" });

            var values = new RouteValueDictionary(
                new { sub_domain = "space" });

            Assert.Equal("http://space.cnblogs.com", parser.Bind(currentValues, values));

            Assert.Null(parser.Bind(null, null));
        }
    }
}
