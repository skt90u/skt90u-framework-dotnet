﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Xunit;
using System.Web.Routing;

namespace MvcPatch.Routing.Test
{
    public class ParsedRouteTest
    {
        [Fact]
        public void Match_Url()
        {
            var parsedRoute = RouteParser.Parse("{controller}/{action}/{id}");
            var values = parsedRoute.Match("Home/Index/5", null);
            Assert.Equal("Home", values["controller"]);
            Assert.Equal("Index", values["action"]);
            Assert.Equal("5", values["id"]);
        }

        [Fact]
        public void Bind_Url()
        {
            var currentValues = new RouteValueDictionary();
            currentValues["controller"] = "Account";
            currentValues["action"] = "Login";

            var values = new RouteValueDictionary();
            values["controller"] = "Home";
            values["action"] = "Index";
            values["hello"] = "world";
            values["id"] = 5;

            var parsedRoute = RouteParser.Parse("{controller}/{action}/{*id}");
            var boundUrl = parsedRoute.Bind(null, values, null, null);
            Assert.Equal("Home/Index/5?hello=world", boundUrl.Url);
        }
    }
}
