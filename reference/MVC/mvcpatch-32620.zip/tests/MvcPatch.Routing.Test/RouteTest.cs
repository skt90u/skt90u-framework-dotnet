﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Xunit;
using Moq;
using System.Web;
using System.Web.Routing;

namespace MvcPatch.Routing.Test
{
    public class RouteTest
    {
        [Fact]
        public void GetVirtualPath_with_Constraints_but_Failed()
        {
            Mock<HttpRequestWrapper> mockRequest;
            var mockHttpContext = HttpMocker.MockRequest("http://blogs.cnblogs.com/Home/Index/5", out mockRequest);

            Route route = new Route(
                "{controller}/{action}/{id}",
                new RouteValueDictionary(),
                new RouteValueDictionary() { { "id", @"\d+" } },
                new StopRoutingHandler());

            var routeData = route.GetRouteData(mockHttpContext.Object);

            Assert.Equal("Home", routeData.GetRequiredString("controller"));
            Assert.Equal("Index", routeData.GetRequiredString("action"));
            Assert.Equal("5", routeData.GetRequiredString("id"));

            var values = new RouteValueDictionary();
            values.Add("controller", "Blog");
            values.Add("action", "Detail");
            values.Add("id", "adf");

            var path = route.GetVirtualPath(new RequestContext(mockHttpContext.Object, routeData), values);
            Assert.Null(path);
        }
    }
}
