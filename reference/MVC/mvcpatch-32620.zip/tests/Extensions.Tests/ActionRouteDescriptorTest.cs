﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Mvc;
using System.Web.Routing;
using Xunit;

namespace MvcPatch.Tests
{
    public class ActionRouteDescriptorTest
    {
        [Area("TestArea")]
        public class TestController : Controller
        {
            [RouteName("TestRoute")]
            public ActionResult WithRouteName()
            {
                throw new NotImplementedException();
            }

            [ActionName("TestAction")]
            public ActionResult WithActionName()
            {
                throw new NotImplementedException();
            }

            public ActionResult WithParameterBinders(
                [ModelBinder(typeof(ReusableBinder))]int a1,
                [Binder(typeof(NormalBinder))]int a2,
                [ModelBinder(typeof(NormalBinder))]int a3)
            {
                throw new NotImplementedException();
            }
        }

        [Reusable]
        public class ReusableBinder : IModelBinder, IRouteBinder
        {
            public object BindModel(ControllerContext controllerContext, ModelBindingContext bindingContext)
            {
                throw new NotImplementedException();
            }

            public RouteValueDictionary BindRoute(RequestContext requestContext, RouteBindingContext bindingContext)
            {
                throw new NotImplementedException();
            }
        }

        public class NormalBinder : IModelBinder, IRouteBinder
        {
            public object BindModel(ControllerContext controllerContext, ModelBindingContext bindingContext)
            {
                throw new NotImplementedException();
            }

            public RouteValueDictionary BindRoute(RequestContext requestContext, RouteBindingContext bindingContext)
            {
                throw new NotImplementedException();
            }
        }

        [Fact]
        public void Basic_Info_with_Route_Name()
        {
            var method = typeof(TestController).GetMethod("WithRouteName");
            var descriptor = new ActionRouteDescriptor(method);

            Assert.Equal("TestArea", descriptor.Area);
            Assert.Equal("TestRoute", descriptor.RouteName);
            Assert.Equal("WithRouteName", descriptor.Name);
            Assert.Equal("Test", descriptor.ControllerName);
        }

        [Fact]
        public void Basic_Info_with_Action_Name()
        {
            var method = typeof(TestController).GetMethod("WithActionName");
            var descriptor = new ActionRouteDescriptor(method);

            Assert.Equal("TestArea", descriptor.Area);
            Assert.Equal("", descriptor.RouteName);
            Assert.Equal("TestAction", descriptor.Name);
            Assert.Equal("Test", descriptor.ControllerName);
        }

        [Fact]
        public void Parameter_Parameter_Binders()
        {
            var method = typeof(TestController).GetMethod("WithParameterBinders");
            var descriptor = new ActionRouteDescriptor(method);

            Assert.Same(descriptor.GetBinder(0), descriptor.GetBinder(0));
            Assert.Same(descriptor.GetBinder(1), descriptor.GetBinder(1));
            Assert.NotSame(descriptor.GetBinder(2), descriptor.GetBinder(2));
        }
    }
}
