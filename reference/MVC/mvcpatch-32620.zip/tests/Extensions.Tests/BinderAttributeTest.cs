﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Mvc;
using Xunit;

namespace MvcPatch.Tests
{
    public class BinderAttributeTest
    {
        private class TestBinder : IModelBinder
        {
            #region IModelBinder Members

            public object BindModel(ControllerContext controllerContext, ModelBindingContext bindingContext)
            {
                throw new NotImplementedException();
            }

            #endregion
        }

        [Fact]
        public void Singleton_Binder()
        {
            var attr = new BinderAttribute(typeof(TestBinder));
            Assert.Same(attr.GetBinder(), attr.GetBinder());
        }

        [Fact]
        public void Multiple_Binder()
        {
            var attr = new BinderAttribute(typeof(TestBinder), false);
            Assert.NotSame(attr.GetBinder(), attr.GetBinder());
        }
    }
}
