﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Mvc;
using Xunit;

namespace MvcPatch.Tests
{
    public class DummyControllerCacheTest
    {
        public class TestController : Controller { }

        [Fact]
        public void SimpleTest()
        {
            var c = DummyControllerCache<TestController>.Instance;
            Assert.NotNull(c);
        }
    }
}
