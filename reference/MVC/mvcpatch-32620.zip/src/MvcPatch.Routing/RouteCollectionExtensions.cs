﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Routing;

namespace MvcPatch.Routing
{
    public static class RouteCollectionExtensions
    {
        public static VirtualPathData GetVirtualPathEx(this RouteCollection routeCollection, RequestContext requestContext, string routeName, RouteValueDictionary values)
        {
            var route = routeCollection[routeName];
            if (route == null) return null;

            return routeCollection.GetVirtualPathEx(route, requestContext, values);
        }

        public static VirtualPathData GetVirtualPathEx(this RouteCollection routeCollection, RequestContext requestContext, RouteValueDictionary values)
        {
            return routeCollection.GetVirtualPathEx(null, requestContext, values);
        }

        private static VirtualPathData GetVirtualPathEx(this RouteCollection routeCollection, RouteBase route, RequestContext requestContext, RouteValueDictionary values)
        {
            var path = route == null ? routeCollection.GetVirtualPathExBase(requestContext, values) : route.GetVirtualPath(requestContext, values);
            if (path == null) return null;

            if (WithScheme(path.VirtualPath)) return path;

            path.VirtualPath = GetUrlWithApplicationPath(requestContext, path.VirtualPath);
            return path;
        }

        private static string GetUrlWithApplicationPath(RequestContext requestContext, string virtualPath)
        {
            string appPath = requestContext.HttpContext.Request.ApplicationPath ?? string.Empty;
            if (!appPath.EndsWith("/", StringComparison.OrdinalIgnoreCase))
            {
                appPath = appPath + "/";
            }

            return appPath + virtualPath;
        }

        private static bool WithScheme(string url)
        {
            return url.StartsWith("http://", StringComparison.OrdinalIgnoreCase) ||
                url.StartsWith("https://", StringComparison.OrdinalIgnoreCase);
        }

        private static VirtualPathData GetVirtualPathExBase(this RouteCollection routeCollection, RequestContext requestContext, RouteValueDictionary values)
        {
            foreach (var route in routeCollection)
            {
                var path = route.GetVirtualPath(requestContext, values);
                if (path != null) return path;
            }

            return null;
        }
    }
}
