﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Routing;

namespace MvcPatch.Routing
{
    public static class RouteExtensions
    {
        public static DomainRoute WithDomain(this RouteBase innerRoute, string pattern, object defaults, object constraints)
        {
            return new DomainRoute(
                innerRoute,
                pattern,
                defaults == null ? null : new RouteValueDictionary(defaults),
                constraints == null ? null : new RouteValueDictionary(constraints));
        }
    }
}
