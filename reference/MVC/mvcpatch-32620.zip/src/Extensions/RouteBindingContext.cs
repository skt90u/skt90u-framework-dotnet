﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MvcPatch
{
    public class RouteBindingContext
    {
        public object Model { get; set; }

        public Type ModelType { get; set; }

        public string ModelName { get; set; }
    }
}
