﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Reflection;
using System.Web.Mvc;

namespace MvcPatch
{
    public class ActionRouteDescriptorCache_V1 : ReaderWriterCache<MethodInfo, ActionRouteDescriptor_V1>
    {
        protected override ActionRouteDescriptor_V1 Create(MethodInfo key)
        {
            return new ActionRouteDescriptor_V1(key);
        }
    }
}
