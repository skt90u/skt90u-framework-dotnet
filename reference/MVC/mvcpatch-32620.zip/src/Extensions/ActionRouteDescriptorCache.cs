﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;

namespace MvcPatch
{
    internal class ActionRouteDescriptorCache : ImmutableDictionaryCache<MethodInfo, ActionRouteDescriptor>
    {
        protected override ActionRouteDescriptor Create(MethodInfo key)
        {
            return new ActionRouteDescriptor(key);
        }
    }
}
