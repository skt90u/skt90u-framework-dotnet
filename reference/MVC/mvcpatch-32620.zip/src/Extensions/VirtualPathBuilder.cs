﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Web.Routing;
using MvcPatch.Routing;

namespace MvcPatch
{
    public class VirtualPathBuilder
    {
        public VirtualPathBuilder(string routeName, RouteValueDictionary routeValues)
        {
            this.RouteName = routeName ?? "";
            this.RouteValues = routeValues ?? new RouteValueDictionary();
        }

        public string RouteName { get; private set; }

        public RouteValueDictionary RouteValues { get; private set; }

        public VirtualPathData GetVirtualPath(RouteCollection routeCollection, RequestContext requestContext)
        {
            if (String.IsNullOrEmpty(this.RouteName))
            {
                return routeCollection.GetVirtualPathEx(requestContext, this.RouteValues);
            }
            else
            {
                return routeCollection.GetVirtualPathEx(requestContext, this.RouteName, this.RouteValues);
            }
        }

        private static ActionRouteDescriptorCache s_cache = new ActionRouteDescriptorCache();

        public static VirtualPathBuilder Create(RequestContext requestContext, MethodInfo action, object[] args)
        {
            return Create(requestContext, action, args, (RouteValueDictionary)null);
        }

        public static VirtualPathBuilder Create(RequestContext requestContext, MethodInfo action, object[] args, RouteValueDictionary routeValues)
        {
            var descriptor = s_cache.Get(action);

            var rvd = new RouteValueDictionary();

            rvd.Add("controller", descriptor.ControllerName);
            rvd.Add("action", descriptor.Name);
            rvd.Add("area", descriptor.Area);

            AddParameterValues(requestContext, rvd, action, args, descriptor);

            if (routeValues != null)
            {
                foreach (var pair in routeValues)
                {
                    rvd.Add(pair.Key, pair.Value);
                }
            }

            return new VirtualPathBuilder(descriptor.RouteName, rvd);
        }

        public static VirtualPathBuilder Create(RequestContext requestContext, MethodInfo action, object[] args, object routeValues)
        {
            return Create(requestContext, action, args, routeValues == null ? null : new RouteValueDictionary(routeValues));
        }

        private static void AddParameterValues(RequestContext requestContext, RouteValueDictionary rvd, MethodInfo action, object[] args, ActionRouteDescriptor descriptor)
        {
            var parameters = action.GetParameters();

            for (int i = 0; i < parameters.Length; i++)
            {
                var routeBinder = descriptor.GetBinder(i);
                var param = parameters[i];

                if (routeBinder == null)
                {
                    rvd.Add(param.Name, args[i]);
                }
                else
                {
                    var bindingContext = new RouteBindingContext
                    {
                        Model = args[i],
                        ModelName = param.Name,
                        ModelType = param.ParameterType
                    };

                    var values = routeBinder.BindRoute(requestContext, bindingContext);

                    if (values != null && values.Count > 0)
                    {
                        foreach (var pair in values)
                        {
                            rvd.Add(pair.Key, pair.Value);
                        }
                    }
                }
            }
        }
    }
}
