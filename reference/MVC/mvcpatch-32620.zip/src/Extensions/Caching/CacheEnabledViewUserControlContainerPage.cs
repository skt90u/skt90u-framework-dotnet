﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Mvc;

namespace MvcPatch.Caching
{
    public class CacheEnabledViewUserControlContainerPage : ViewPage
    {
        protected override System.Web.UI.HtmlTextWriter CreateHtmlTextWriter(System.IO.TextWriter tw)
        {
            return base.CreateHtmlTextWriter(Html.CreateCacheWriter(tw));
        }
    }
}
