﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace MvcPatch
{
    public abstract class ReaderWriterCache<TKey, TValue>
    {
        protected ReaderWriterCache()
            : this(null)
        {
        }

        protected ReaderWriterCache(IEqualityComparer<TKey> comparer)
        {
            this.m_storage = comparer == null ? new Dictionary<TKey, TValue>()
                : new Dictionary<TKey, TValue>(comparer);
        }

        private readonly Dictionary<TKey, TValue> m_storage;
        private readonly ReaderWriterLockSlim m_rwLock = new ReaderWriterLockSlim();

        protected abstract TValue Create(TKey key);

        public TValue Get(TKey key)
        {
            TValue value;

            this.m_rwLock.EnterReadLock();
            try
            {
                if (this.m_storage.TryGetValue(key, out value))
                {
                    return value;
                }
            }
            finally
            {
                this.m_rwLock.ExitReadLock();
            }

            this.m_rwLock.EnterWriteLock();
            try
            {
                if (this.m_storage.TryGetValue(key, out value))
                {
                    return value;
                }

                value = this.Create(key);
                this.m_storage.Add(key, value);

                return value;
            }
            finally
            {
                this.m_rwLock.ExitWriteLock();
            }
        }
    }
}
