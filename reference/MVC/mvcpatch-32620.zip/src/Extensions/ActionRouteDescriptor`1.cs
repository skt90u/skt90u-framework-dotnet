﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Reflection;
using System.Web.Mvc;

namespace MvcPatch
{
    public class ActionRouteDescriptor_V1
    {
        private MethodInfo m_action;
        private Dictionary<ParameterInfo, Func<IRouteBinder>> m_binderFactories;

        public ActionRouteDescriptor_V1(MethodInfo actionInfo)
        {
            if (actionInfo == null) throw new ArgumentNullException("actionInfo");

            this.m_action = actionInfo;
            this.Name = GetName(actionInfo);
            this.Area = AreaHelper.GetArea(actionInfo.ReflectedType);
            this.RouteName = GetRouteName(actionInfo);
            this.ControllerName = GetControllerName(actionInfo.ReflectedType);

            this.m_binderFactories = new Dictionary<ParameterInfo, Func<IRouteBinder>>();
            foreach (var parameter in actionInfo.GetParameters())
            {
                this.m_binderFactories.Add(parameter, GetBinderFactory(parameter));
            }
        }

        public string Name { get; private set; }

        public string Area { get; private set; }

        public string RouteName { get; private set; }

        public string ControllerName { get; private set; }

        public IRouteBinder GetRouteBinder(ParameterInfo parameterInfo)
        {
            return this.m_binderFactories[parameterInfo].Invoke();
        }

        private static string GetControllerName(Type controllerType)
        {
            string controllerTypeName = controllerType.Name;
            if (!controllerTypeName.EndsWith("Controller", StringComparison.OrdinalIgnoreCase))
            {
                throw new ArgumentException("The controller name must end with 'Controller'.", "action");
            }

            var controllerName = controllerTypeName.Substring(0, controllerTypeName.Length - "Controller".Length);
            if (controllerName.Length == 0)
            {
                throw new ArgumentException("Cannot route to the Controller class", "action");
            }

            return controllerName;
        }

        private static string GetName(MethodInfo actionInfo)
        {
            var attribute = (ActionNameAttribute)actionInfo.GetCustomAttributes(typeof(ActionNameAttribute), false).SingleOrDefault();
            return attribute == null ? actionInfo.Name : attribute.Name;
        }

        private static string GetRouteName(MethodInfo actionInfo)
        {
            var attribute = (RouteNameAttribute)actionInfo.GetCustomAttributes(typeof(RouteNameAttribute), false).SingleOrDefault();
            return attribute == null ? "" : attribute.Name;
        }

        private static Func<IRouteBinder> GetBinderFactory(ParameterInfo parameterInfo)
        {
            var factory = GetBinderAttribute(parameterInfo) ?? GetBinderAttribute(parameterInfo.ParameterType);

            if (factory == null) return () => GetDynamicRouteBinder(parameterInfo);

            return () => (factory.GetBinder() as IRouteBinder) ?? GetDynamicRouteBinder(parameterInfo);
        }

        private static CustomModelBinderAttribute GetBinderAttribute(ICustomAttributeProvider element)
        {
            var attrs = (CustomModelBinderAttribute[])element.GetCustomAttributes(typeof(CustomModelBinderAttribute), true /* inherit */);
            if (attrs == null) return null;

            switch (attrs.Length)
            {
                case 0: return null;
                case 1: return attrs[0];
                default:
                    throw new InvalidOperationException("Multiple binder is forbidden.");
            }
        }

        private static IRouteBinder GetDynamicRouteBinder(ParameterInfo parameterInfo)
        {
            return ModelBinders.Binders.GetBinder(parameterInfo.ParameterType) as IRouteBinder;
        }
    }
}
