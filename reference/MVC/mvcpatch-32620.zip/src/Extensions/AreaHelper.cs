﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MvcPatch
{
    public static class AreaHelper
    {
        public static string GetArea(Type type)
        {
            if (type == null) throw new ArgumentNullException("type");
            var attribute = (AreaAttribute)type.GetCustomAttributes(typeof(AreaAttribute), true).SingleOrDefault();

            return attribute == null ? "" : attribute.Name;
        }
    }
}
