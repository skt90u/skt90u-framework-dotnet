﻿/* ****************************************************************************
 *
 * Copyright (c) Microsoft Corporation. All rights reserved.
 *
 * This software is subject to the Microsoft Public License (Ms-PL). 
 * A copy of the license can be found in the license.htm file included 
 * in this distribution.
 *
 * You must not remove this notice, or any other, from this software.
 *
 * ***************************************************************************/

namespace System.Web.Mvc
{
    using System;
    using System.Web.Routing;
using System.IO;
    using System.Web.UI;

    public class AjaxHelper
    {

        public AjaxHelper(ViewPage viewPage, ViewContext viewContext, IViewDataContainer viewDataContainer)
            : this(viewPage, viewContext, viewDataContainer, RouteTable.Routes)
        {
        }

        public AjaxHelper(ViewPage viewPage, ViewContext viewContext, IViewDataContainer viewDataContainer, RouteCollection routeCollection)
        {
            if (viewPage == null)
            {
                throw new ArgumentNullException("viewPage");
            }
            if (viewContext == null)
            {
                throw new ArgumentNullException("viewContext");
            }
            if (viewDataContainer == null)
            {
                throw new ArgumentNullException("viewDataContainer");
            }
            if (routeCollection == null)
            {
                throw new ArgumentNullException("routeCollection");
            }

            ViewPage = viewPage;
            ViewContext = viewContext;
            ViewDataContainer = viewDataContainer;
            RouteCollection = routeCollection;
        }

        public RouteCollection RouteCollection
        {
            get;
            private set;
        }

        public ViewContext ViewContext
        {
            get;
            private set;
        }

        public ViewPage ViewPage
        {
            get;
            private set;
        }

        public HtmlTextWriter Output
        {
            get
            {
                return this.ViewPage.Writer;
            }
        }

        public ViewDataDictionary ViewData
        {
            get
            {
                return ViewDataContainer.ViewData;
            }
        }

        public IViewDataContainer ViewDataContainer
        {
            get;
            private set;
        }
    }
}
