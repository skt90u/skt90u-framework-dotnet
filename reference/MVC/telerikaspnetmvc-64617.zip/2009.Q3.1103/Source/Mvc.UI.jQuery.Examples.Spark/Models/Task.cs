namespace Mvc.UI.jQuery.Examples.SparkView
{
    public class Task
    {
        public string Name
        {
            get;
            set;
        }

        public int Completed
        {
            get;
            set;
        }
    }
}