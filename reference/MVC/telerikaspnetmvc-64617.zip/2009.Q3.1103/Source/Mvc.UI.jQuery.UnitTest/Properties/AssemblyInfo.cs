// (c) Copyright Telerik Corp. 
// This source is subject to the Microsoft Public License. 
// See http://www.microsoft.com/opensource/licenses.mspx#Ms-PL. 
// All other rights reserved.

using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Mvc.UI.jQuery.UnitTest")]
[assembly: AssemblyProduct("Mvc.UI.jQuery.UnitTest")]
[assembly: Guid("a67849d6-488b-44d5-a7e1-d2644e48410e")]