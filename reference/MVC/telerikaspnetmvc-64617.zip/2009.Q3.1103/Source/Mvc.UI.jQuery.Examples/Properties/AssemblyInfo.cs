﻿using System;
using System.Reflection;
using System.Runtime.InteropServices;

[assembly : AssemblyTitle("Telerik.Web.Mvc.WebTest")]
[assembly : AssemblyProduct("Telerik.Web.Mvc.WebTest")]
[assembly : AssemblyDescription("")]
[assembly : AssemblyConfiguration("")]
[assembly : AssemblyCompany("Telerik")]
[assembly : AssemblyCopyright("Copyright © 2009")]
[assembly : AssemblyTrademark("")]
[assembly : AssemblyCulture("")]
[assembly : ComVisible(false)]
[assembly : AssemblyVersion("0.0.0.1")]
[assembly : AssemblyFileVersion("0.0.0.1")]
[assembly : Guid("7c44783b-0228-46ab-8bf0-aee3136f3457")]
[assembly : CLSCompliant(true)]