﻿namespace Telerik.Web.Mvc.JavaScriptTest
{
    using System;
    
    public class Customer
    {
        public string Name { get; set; }
        public DateTime BirthDate { get; set; }
        public bool Active { get; set; }
    }
}
