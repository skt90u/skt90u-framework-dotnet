namespace Telerik.Web.Mvc.Examples
{
	using System.Web.Mvc;

    public partial class PanelBarController : Controller
	{
        public ActionResult Sprites()
		{
			return View();
		}
    }
}