namespace Telerik.Web.Mvc.Examples
{
	using System.Web.Mvc;

    public partial class TabStripController : Controller
	{
        public ActionResult FirstLook(string expandMode)
        {
            return View();
        }
    }
}