namespace Telerik.Web.Mvc.Examples
{
	using System.Web.Mvc;

    public partial class MenuController : Controller
	{
		public ActionResult ClientSideEvents()
        {
            return View();
        }
    }
}