﻿namespace Telerik.Web.Mvc.Examples.Models
{
    public class CustomerDto
    {
        public string ContactName
        {
            get;
            set;
        }

        public string Address
        {
            get;
            set;
        }

        public string CustomerID
        {
            get;
            set;
        }

        public string Country
        {
            get;
            set;
        }
    }
}
