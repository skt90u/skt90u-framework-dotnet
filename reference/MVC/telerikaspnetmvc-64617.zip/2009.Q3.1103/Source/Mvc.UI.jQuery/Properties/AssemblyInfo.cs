// (c) Copyright 2002-2009 Telerik 
// This source is subject to the GNU General Public License, version 2
// See http://www.gnu.org/licenses/gpl-2.0.html. 
// All other rights reserved.

using System;
using System.Reflection;
using System.Resources;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Mvc.UI.jQuery")]
[assembly: AssemblyProduct("Mvc.UI.jQuery")]
[assembly: Guid("cafae3a5-908f-4a15-b682-2c82b262933d")]
[assembly: CLSCompliant(true)]
[assembly: NeutralResourcesLanguage("en", UltimateResourceFallbackLocation.MainAssembly)]
[assembly: InternalsVisibleTo("Mvc.UI.jQuery.UnitTest")]