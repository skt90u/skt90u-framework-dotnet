namespace Telerik.Web.Mvc.HelpProcessor
{
    public class Topic
    {
        public string Id { get; set; }
        public string FriendlyUrl { get; set; }
    }
}