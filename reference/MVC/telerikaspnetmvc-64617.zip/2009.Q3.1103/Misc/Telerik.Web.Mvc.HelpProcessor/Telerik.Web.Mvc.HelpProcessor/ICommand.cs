namespace Telerik.Web.Mvc.HelpProcessor
{
    internal interface ICommand
    {
        void Execute(string path);
    }
}