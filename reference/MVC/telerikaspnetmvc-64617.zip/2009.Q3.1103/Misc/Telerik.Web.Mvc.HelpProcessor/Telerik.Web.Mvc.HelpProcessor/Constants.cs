﻿namespace Telerik.Web.Mvc.HelpProcessor
{
    class Constants
    {
        public const string TokFile = "WebTOC.xml";
    }
}
