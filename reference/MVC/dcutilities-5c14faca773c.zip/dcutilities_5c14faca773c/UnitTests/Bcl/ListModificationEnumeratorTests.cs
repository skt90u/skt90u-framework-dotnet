using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;


namespace DigitallyCreated.Utilities.Bcl
{
	/// <summary>
	/// Tests for the <see cref="ListModificationEnumerator{T}"/>
	/// </summary>
	[TestClass]
	public class ListModificationEnumeratorTests
	{
		/// <summary>
		/// Test simple enumeration
		/// </summary>
		[TestMethod]
		public void TestEnumerating()
		{
			List<int> list = new List<int> { 1, 2, 3, };
			IModificationEnumerator<int> enumerator = list.GetModificationEnumerator();
			
			Assert.AreEqual(0, enumerator.Current);
			Assert.IsTrue(enumerator.MoveNext());
			Assert.AreEqual(1, enumerator.Current);
			Assert.IsTrue(enumerator.MoveNext());
			Assert.AreEqual(2, enumerator.Current);
			Assert.IsTrue(enumerator.MoveNext());
			Assert.AreEqual(3, enumerator.Current);
			Assert.IsFalse(enumerator.MoveNext());
			Assert.AreEqual(0, enumerator.Current);
		}

		
		/// <summary>
		/// Test adding while enumerating
		/// </summary>
		[TestMethod]
		public void TestAdding()
		{
			List<int> list = new List<int> { 1, 2, 3, };
			IModificationEnumerator<int> enumerator = list.GetModificationEnumerator();

			Assert.AreEqual(0, enumerator.Current);
			enumerator.Add(4);
			Assert.AreEqual(0, enumerator.Current);
			Assert.IsTrue(enumerator.MoveNext());
			Assert.AreEqual(1, enumerator.Current);
			enumerator.Add(5);
			enumerator.Add(6);
			Assert.IsTrue(enumerator.MoveNext());
			Assert.AreEqual(2, enumerator.Current);
			Assert.IsTrue(enumerator.MoveNext());
			Assert.AreEqual(3, enumerator.Current);
			enumerator.Add(7);
			Assert.IsFalse(enumerator.MoveNext());
			Assert.AreEqual(0, enumerator.Current);

			enumerator = list.GetModificationEnumerator();
			Assert.AreEqual(0, enumerator.Current);
			Assert.IsTrue(enumerator.MoveNext());
			Assert.AreEqual(4, enumerator.Current);
			Assert.IsTrue(enumerator.MoveNext());
			Assert.AreEqual(1, enumerator.Current);
			Assert.IsTrue(enumerator.MoveNext());
			Assert.AreEqual(5, enumerator.Current);
			Assert.IsTrue(enumerator.MoveNext());
			Assert.AreEqual(6, enumerator.Current);
			Assert.IsTrue(enumerator.MoveNext());
			Assert.AreEqual(2, enumerator.Current);
			Assert.IsTrue(enumerator.MoveNext());
			Assert.AreEqual(3, enumerator.Current);
			Assert.IsTrue(enumerator.MoveNext());
			Assert.AreEqual(7, enumerator.Current);
			Assert.IsFalse(enumerator.MoveNext());
			Assert.AreEqual(0, enumerator.Current);
		}


		/// <summary>
		/// Test adding when past the end of the enumeration
		/// </summary>
		[TestMethod]
		[ExpectedException(typeof(InvalidOperationException))]
		public void TestAddingPastEnd()
		{
			List<int> list = new List<int> { 1, 2, 3, };
			IModificationEnumerator<int> enumerator = list.GetModificationEnumerator();

			Assert.IsTrue(enumerator.MoveNext());
			Assert.IsTrue(enumerator.MoveNext());
			Assert.IsTrue(enumerator.MoveNext());
			Assert.IsFalse(enumerator.MoveNext());
			enumerator.Add(4);
		}


		/// <summary>
		/// Test replacing while enumerating
		/// </summary>
		[TestMethod]
		public void TestReplacing()
		{
			List<int> list = new List<int> { 1, 2, 3, };
			IModificationEnumerator<int> enumerator = list.GetModificationEnumerator();

			Assert.IsTrue(enumerator.MoveNext());
			Assert.AreEqual(1, enumerator.Current);
			Assert.AreEqual(1, enumerator.Replace(4));
			Assert.AreEqual(4, enumerator.Current);

			Assert.IsTrue(enumerator.MoveNext());
			Assert.AreEqual(2, enumerator.Current);
			Assert.AreEqual(2, enumerator.Replace(5));
			Assert.AreEqual(5, enumerator.Current);

			Assert.IsTrue(enumerator.MoveNext());
			Assert.AreEqual(3, enumerator.Current);
			Assert.AreEqual(3, enumerator.Replace(6));
			Assert.AreEqual(6, enumerator.Current);
		}


		/// <summary>
		/// Test replacing before the beginning of the enumeration
		/// </summary>
		[TestMethod]
		[ExpectedException(typeof(InvalidOperationException))]
		public void TestReplaceBeforeBeginning()
		{
			List<int> list = new List<int> { 1, 2, 3, };
			IModificationEnumerator<int> enumerator = list.GetModificationEnumerator();

			enumerator.Replace(4);
		}


		/// <summary>
		/// Test replacing after the end of the enumeration
		/// </summary>
		[TestMethod]
		[ExpectedException(typeof(InvalidOperationException))]
		public void TestReplaceAfterEnd()
		{
			List<int> list = new List<int> { 1, 2, 3, };
			IModificationEnumerator<int> enumerator = list.GetModificationEnumerator();

			Assert.IsTrue(enumerator.MoveNext());
			Assert.IsTrue(enumerator.MoveNext());
			Assert.IsTrue(enumerator.MoveNext());
			Assert.IsFalse(enumerator.MoveNext());
			enumerator.Replace(4);
		}


		/// <summary>
		/// Test removing while enumerating
		/// </summary>
		[TestMethod]
		public void TestRemoving()
		{
			List<int> list = new List<int> { 1, 2, 3, };
			IModificationEnumerator<int> enumerator = list.GetModificationEnumerator();

			Assert.IsTrue(enumerator.MoveNext());
			Assert.AreEqual(1, enumerator.Current);
			Assert.IsTrue(enumerator.RemoveAndMoveNext());
			Assert.AreEqual(2, enumerator.Current);
			Assert.IsTrue(enumerator.RemoveAndMoveNext());
			Assert.AreEqual(3, enumerator.Current);
			Assert.IsFalse(enumerator.RemoveAndMoveNext());
			Assert.AreEqual(0, enumerator.Current);

			Assert.AreEqual(0, list.Count);
		}


		/// <summary>
		/// Test removing before the beginning of the enumeration
		/// </summary>
		[TestMethod]
		[ExpectedException(typeof(InvalidOperationException))]
		public void TestRemoveBeforeBeginning()
		{
			List<int> list = new List<int> { 1, 2, 3, };
			IModificationEnumerator<int> enumerator = list.GetModificationEnumerator();

			enumerator.RemoveAndMoveNext();
		}


		/// <summary>
		/// Test removing after the end of the enumeration
		/// </summary>
		[TestMethod]
		[ExpectedException(typeof(InvalidOperationException))]
		public void TestRemoveAfterEnd()
		{
			List<int> list = new List<int> { 1, 2, 3, };
			IModificationEnumerator<int> enumerator = list.GetModificationEnumerator();

			Assert.IsTrue(enumerator.MoveNext());
			Assert.IsTrue(enumerator.MoveNext());
			Assert.IsTrue(enumerator.MoveNext());
			Assert.IsFalse(enumerator.MoveNext());
			enumerator.RemoveAndMoveNext();
		}


		/// <summary>
		/// Test resetting while enumerating
		/// </summary>
		[TestMethod]
		public void TestResetting()
		{
			List<int> list = new List<int> { 1, 2, 3, };
			IModificationEnumerator<int> enumerator = list.GetModificationEnumerator();

			Assert.IsTrue(enumerator.MoveNext());
			Assert.AreEqual(1, enumerator.Current);
			Assert.IsTrue(enumerator.MoveNext());
			Assert.AreEqual(2, enumerator.Current);
			
			enumerator.Reset();

			Assert.AreEqual(0, enumerator.Current);
			Assert.IsTrue(enumerator.MoveNext());
			Assert.AreEqual(1, enumerator.Current);
			Assert.IsTrue(enumerator.MoveNext());
			Assert.AreEqual(2, enumerator.Current);
			Assert.IsTrue(enumerator.MoveNext());
			Assert.AreEqual(3, enumerator.Current);
			Assert.IsFalse(enumerator.MoveNext());
			Assert.AreEqual(0, enumerator.Current);
		}
	}
}