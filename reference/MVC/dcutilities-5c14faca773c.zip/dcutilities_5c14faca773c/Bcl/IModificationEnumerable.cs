﻿using System.Collections.Generic;


namespace DigitallyCreated.Utilities.Bcl
{
	/// <summary>
	/// An <see cref="IEnumerable{T}"/> whose <see cref="IEnumerable{T}.GetEnumerator"/> method returns
	/// a <see cref="IModificationEnumerable{T}"/>.
	/// </summary>
	/// <typeparam name="T">The type of object being enumerated</typeparam>
	public interface IModificationEnumerable<T> : IEnumerable<T>
	{
		/// <summary>
		/// Returns an enumerator that iterates through the collection.
		/// </summary>
		/// <returns>
		/// A <see cref="IModificationEnumerator{T}"/> that can be used to iterate through the collection.
		/// </returns>
		new IModificationEnumerator<T> GetEnumerator();
	}
}