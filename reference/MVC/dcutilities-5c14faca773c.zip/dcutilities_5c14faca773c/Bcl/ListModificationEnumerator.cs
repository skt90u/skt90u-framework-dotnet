using System;
using System.Collections;
using System.Collections.Generic;


namespace DigitallyCreated.Utilities.Bcl
{
	/// <summary>
	/// The <see cref="ListModificationEnumerator{T}"/> is an <see cref="IModificationEnumerator{T}"/>
	/// that works for any <see cref="IList{T}"/>.
	/// </summary>
	/// <remarks>
	/// This class does not support concurrent access to the underlying <see cref="IList{T}"/> and <strong>will
	/// not warn you</strong> if concurrent access occurs.
	/// </remarks>
	/// <typeparam name="T">The type of object being enumerated</typeparam>
	/// <seealso cref="IModificationEnumerator{T}"/>
	public class ListModificationEnumerator<T> : IModificationEnumerator<T>
	{
		private readonly IList<T> _List;
		private int _CurrentIndex;
		private int _NextIndex;
		private T _Current;


		/// <summary>
		/// Constructor, creates a <see cref="ListModificationEnumerator{T}"/> that enumerates over
		/// <paramref name="list"/>
		/// </summary>
		/// <param name="list">The <see cref="IList{T}"/> to enumerate over</param>
		public ListModificationEnumerator(IList<T> list)
		{
			if (list == null)
				throw new ArgumentNullException("list");

			_List = list;
			Reset();
		}


		/// <summary>
		/// Advances the enumerator to the next element of the collection.
		/// </summary>
		/// <returns>
		/// <see langword="true"/> if the enumerator was successfully advanced to the next element; 
		/// <see langword="false"/> if the enumerator has passed the end of the collection.
		/// </returns>
		public bool MoveNext()
		{
			if (_NextIndex < _List.Count)
			{
				_CurrentIndex = _NextIndex;
				_Current = _List[_CurrentIndex];
				_NextIndex++;
				return true;
			}

			_Current = default(T);
			_NextIndex++;
			_CurrentIndex++;
			return false;
		}


		/// <summary>
		/// Sets the enumerator to its initial position, which is before the first element in the collection.
		/// </summary>
		public void Reset()
		{
			_NextIndex = 0;
			_CurrentIndex = -1;
			_Current = default(T);
		}


		/// <summary>
		/// Gets the element in the collection at the current position of the enumerator.
		/// </summary>
		/// <returns>
		/// The element in the collection at the current position of the enumerator or the <see langword="default"/>
		/// value of <typeparamref name="T"/> if the current position is before the start or after the end of
		/// the collection.
		/// </returns>
		public T Current
		{
			get { return _Current; }
		}


		/// <summary>
		/// Gets the element in the collection at the current position of the enumerator.
		/// </summary>
		/// <returns>
		/// The element in the collection at the current position of the enumerator or the <see langword="default"/>
		/// value of <typeparamref name="T"/> if the current position is before the start or after the end of
		/// the collection.
		/// </returns>
		object IEnumerator.Current
		{
			get { return Current; }
		}


		/// <summary>
		/// Replaces the <see cref="IEnumerator{T}.Current"/> item with the specified <paramref name="item"/>.
		/// </summary>
		/// <param name="item">The item to replace with</param>
		/// <returns>The item that was replaced</returns>
		/// <exception cref="InvalidOperationException">
		/// If the enumerator has not been advanced to at least the first item or if the enumerator has moved past the
		/// end of the enumerable.
		/// </exception>
		public T Replace(T item)
		{
			if (_CurrentIndex == -1)
				throw new InvalidOperationException("The enumerator has not been advanced to at least the first item");
			if (_CurrentIndex >= _List.Count)
				throw new InvalidOperationException("The enumerator has moved past the end of the collection");
			
			T current = _Current;
			_List[_CurrentIndex] = item;
			_Current = item;
			return current;
		}


		/// <summary>
		/// Removes the <see cref="IEnumerator{T}.Current"/> item from the <see cref="IEnumerable{T}"/>and moves to
		/// the next item.
		/// </summary>
		/// <returns>
		/// <see langword="true"/> if the enumerator was successfully advanced to the next element; 
		/// <see langword="false"/> if the enumerator has passed the end of the collection.
		/// </returns>
		/// <exception cref="InvalidOperationException">
		/// If the enumerator has not been advanced to at least the first item or if the enumerator has moved past the
		/// end of the enumerable.
		/// </exception>
		public bool RemoveAndMoveNext()
		{
			if (_CurrentIndex == -1)
				throw new InvalidOperationException("The enumerator has not been advanced to at least the first item");
			if (_CurrentIndex >= _List.Count)
				throw new InvalidOperationException("The enumerator has moved past the end of the collection");

			_List.RemoveAt(_CurrentIndex);
			_CurrentIndex--; //Move to the previous item
			_NextIndex--; //We've deleted one, so next index moves backwards one
			return MoveNext();
		}


		/// <summary>
		/// Add the specified <paramref name="item"/> before the item that would be the 
		/// <see cref="IEnumerator{T}.Current"/> item after a call to <see cref="IEnumerator.MoveNext"/>. The item is
		/// inserted before the implicit cursor, which means the next call to <see cref="IEnumerator.MoveNext"/> 
		/// is unaffected by any number of calls to this method (effectively skipping the added items).
		/// </summary>
		/// <param name="item">The item to add</param>
		/// <exception cref="InvalidOperationException">
		/// If the enumerator has moved past the end of the enumerable.
		/// </exception>
		public void Add(T item)
		{
			if (_NextIndex > _List.Count)
				throw new InvalidOperationException("The enumerator has moved past the end of the collection");

			_List.Insert(_NextIndex, item);
			_NextIndex++;
		}


		/// <summary>
		/// Performs application-defined tasks associated with freeing, releasing, or resetting unmanaged resources.
		/// </summary>
		public void Dispose()
		{
		}
	}
}