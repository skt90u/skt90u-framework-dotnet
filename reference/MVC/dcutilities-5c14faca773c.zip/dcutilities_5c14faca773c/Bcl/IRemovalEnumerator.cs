using System;
using System.Collections.Generic;


namespace DigitallyCreated.Utilities.Bcl
{
	/// <summary>
	/// An <see cref="IRemovalEnumerator{T}"/> is an <see cref="IEnumerator{T}"/> that is able to
	/// remove items as you enumerate over whatever it is enumerating over.
	/// </summary>
	/// <typeparam name="T">The type of object being enumerated</typeparam>
	public interface IRemovalEnumerator<out T> : IEnumerator<T>
	{
		/// <summary>
		/// Removes the <see cref="IEnumerator{T}.Current"/> item from the <see cref="IEnumerable{T}"/>and moves to
		/// the next item.
		/// </summary>
		/// <returns>
		/// <see langword="true"/> if the enumerator was successfully advanced to the next element; 
		/// <see langword="false"/> if the enumerator has passed the end of the collection.
		/// </returns>
		/// <exception cref="InvalidOperationException">
		/// If the enumerator has not been advanced to at least the first item or if the enumerator has moved past the
		/// end of the enumerable.
		/// </exception>
		bool RemoveAndMoveNext();
	}
}