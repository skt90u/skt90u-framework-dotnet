using System;
using System.Collections;
using System.Collections.Generic;


namespace DigitallyCreated.Utilities.Bcl
{
	/// <summary>
	/// The <see cref="LinkedListModificationEnumerator{T}"/> is an <see cref="IModificationEnumerator{T}"/>that
	/// works for any <see cref="LinkedList{T}"/>.
	/// </summary>
	/// <remarks>
	/// This class does not support concurrent access to the underlying <see cref="LinkedList{T}"/> and 
	/// <strong>will not warn you</strong> if concurrent access occurs.
	/// </remarks>
	/// <typeparam name="T">The type of object being enumerated</typeparam>
	/// <seealso cref="IModificationEnumerator{T}"/>
	public class LinkedListModificationEnumerator<T> : IModificationEnumerator<T>
	{
		private readonly LinkedList<T> _LinkedList;
		private LinkedListNode<T> _CurrentNode;
		private LinkedListNode<T> _BeforeNextNode;
		private bool _ReachedEnd;


		/// <summary>
		/// Constructor, creates a <see cref="LinkedListModificationEnumerator{T}"/> that enumerates over
		/// <paramref name="linkedList"/>
		/// </summary>
		/// <param name="linkedList">The <see cref="LinkedList{T}"/> to enumerate over</param>
		public LinkedListModificationEnumerator(LinkedList<T> linkedList)
		{
			if (linkedList == null)
				throw new ArgumentNullException("linkedList");

			_LinkedList = linkedList;
			Reset();
		}


		/// <summary>
		/// Advances the enumerator to the next element of the collection.
		/// </summary>
		/// <returns>
		/// <see langword="true"/> if the enumerator was successfully advanced to the next element; 
		/// <see langword="false"/> if the enumerator has passed the end of the collection.
		/// </returns>
		public bool MoveNext()
		{
			if (_ReachedEnd)
				return false;

			_CurrentNode = _BeforeNextNode;

			if (_CurrentNode == null)
				_CurrentNode = _LinkedList.First;
			else
				_CurrentNode = _CurrentNode.Next;

			_BeforeNextNode = _CurrentNode;

			if (_CurrentNode == null)
			{
				_ReachedEnd = true;
				return false;
			}

			return true;
		}


		/// <summary>
		/// Sets the enumerator to its initial position, which is before the first element in the collection.
		/// </summary>
		public void Reset()
		{
			_CurrentNode = null;
			_BeforeNextNode = null;
			_ReachedEnd = false;
		}


		/// <summary>
		/// Gets the element in the collection at the current position of the enumerator.
		/// </summary>
		/// <returns>
		/// The element in the collection at the current position of the enumerator or the <see langword="default"/>
		/// value of <typeparamref name="T"/> if the current position is before the start or after the end of
		/// the enumeration.
		/// </returns>
		public T Current
		{
			get { return _CurrentNode == null ? default(T) : _CurrentNode.Value; }
		}


		/// <summary>
		/// Gets the current element in the collection.
		/// </summary>
		/// <returns>
		/// The element in the collection at the current position of the enumerator or the <see langword="default"/>
		/// value of <typeparamref name="T"/> if the current position is before the start or after the end of
		/// the collection.
		/// </returns>
		object IEnumerator.Current
		{
			get { return Current; }
		}


		/// <summary>
		/// Replaces the <see cref="IEnumerator{T}.Current"/> item with the specified <paramref name="item"/>.
		/// </summary>
		/// <param name="item">The item to replace with</param>
		/// <returns>The item that was replaced</returns>
		/// <exception cref="InvalidOperationException">
		/// If the enumerator has not been advanced to at least the first item or if the enumerator has moved past the
		/// end of the collection.
		/// </exception>
		public T Replace(T item)
		{
			if (_ReachedEnd)
				throw new InvalidOperationException("The enumerator has moved past the end of the collection");
			if (_CurrentNode == null)
				throw new InvalidOperationException("The enumerator has not been advanced to at least the first item.");

			T current = _CurrentNode.Value;
			_CurrentNode.Value = item;
			return current;
		}


		/// <summary>
		/// Removes the <see cref="IEnumerator{T}.Current"/> item from the <see cref="IEnumerable{T}"/>and moves to
		/// the next item.
		/// </summary>
		/// <returns>
		/// <see langword="true"/> if the enumerator was successfully advanced to the next element; 
		/// <see langword="false"/> if the enumerator has passed the end of the collection.
		/// </returns>
		/// <exception cref="InvalidOperationException">
		/// If the enumerator has not been advanced to at least the first item or if the enumerator has moved past the
		/// end of the enumerable.
		/// </exception>
		public bool RemoveAndMoveNext()
		{
			if (_ReachedEnd)
				throw new InvalidOperationException("The enumerator has moved past the end of the collection");
			if (_CurrentNode == null)
				throw new InvalidOperationException("The enumerator has not been advanced to at least the first item.");

			LinkedListNode<T> previousNode = _CurrentNode;
			bool retval = MoveNext();
			_LinkedList.Remove(previousNode);
			return retval;
		}


		/// <summary>
		/// Add the specified <paramref name="item"/> before the item that would be the 
		/// <see cref="IEnumerator{T}.Current"/> item after a call to <see cref="IEnumerator.MoveNext"/>. The item is
		/// inserted before the implicit cursor, which means the next call to <see cref="IEnumerator.MoveNext"/> 
		/// is unaffected by any number of calls to this method (effectively skipping the added items).
		/// </summary>
		/// <param name="item">The item to add</param>
		/// <exception cref="InvalidOperationException">
		/// If the enumerator has moved past the end of the enumerable.
		/// </exception>
		public void Add(T item)
		{
			if (_ReachedEnd)
				throw new InvalidOperationException("The enumerator has moved past the end of the collection");

			if (_CurrentNode == null)
				_BeforeNextNode = _LinkedList.AddFirst(item);
			else
				_BeforeNextNode = _LinkedList.AddAfter(_BeforeNextNode, item);
		}


		/// <summary>
		/// Performs application-defined tasks associated with freeing, releasing, or resetting unmanaged resources.
		/// </summary>
		public void Dispose()
		{
		}
	}
}