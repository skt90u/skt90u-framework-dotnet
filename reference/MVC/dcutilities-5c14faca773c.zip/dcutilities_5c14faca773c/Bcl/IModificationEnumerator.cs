using System;
using System.Collections;
using System.Collections.Generic;


namespace DigitallyCreated.Utilities.Bcl
{
	/// <summary>
	/// An <see cref="IModificationEnumerable{T}"/> is able to modify the collection that is being
	/// enumerated over as it is being enumerated over.
	/// </summary>
	/// <typeparam name="T">The type of object being enumerated</typeparam>
	public interface IModificationEnumerator<T> : IRemovalEnumerator<T>
	{
		/// <summary>
		/// Replaces the <see cref="IEnumerator{T}.Current"/> item with the specified <paramref name="item"/>.
		/// </summary>
		/// <param name="item">The item to replace with</param>
		/// <returns>The item that was replaced</returns>
		/// <exception cref="InvalidOperationException">
		/// If the enumerator has not been advanced to at least the first item or if the enumerator has moved past the
		/// end of the enumerable.
		/// </exception>
		T Replace(T item);


		/// <summary>
		/// Add the specified <paramref name="item"/> before the item that would be the 
		/// <see cref="IEnumerator{T}.Current"/> item after a call to <see cref="IEnumerator.MoveNext"/>. The item is
		/// inserted before the implicit cursor, which means the next call to <see cref="IEnumerator.MoveNext"/> 
		/// is unaffected by any number of calls to this method (effectively skipping the added items).
		/// </summary>
		/// <param name="item">The item to add</param>
		/// <exception cref="InvalidOperationException">
		/// If the enumerator has moved past the end of the enumerable.
		/// </exception>
		void Add(T item);
	}
}