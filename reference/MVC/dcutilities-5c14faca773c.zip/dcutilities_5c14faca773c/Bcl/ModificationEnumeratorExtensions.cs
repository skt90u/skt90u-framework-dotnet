using System.Collections;
using System.Collections.Generic;


namespace DigitallyCreated.Utilities.Bcl
{
	/// <summary>
	/// Adds extension methods to <see cref="IList{T}"/> and <see cref="LinkedList{T}"/> that enables you to get
	/// them as <see cref="IModificationEnumerable{T}"/>s and get <see cref="IModificationEnumerator{T}"/>s for
	/// them.
	/// </summary>
	public static class ModificationEnumeratorExtensions
	{
		/// <summary>
		/// Gets a <see cref="IModificationEnumerator{T}"/> that enumerates the specified <paramref name="list"/>
		/// </summary>
		/// <typeparam name="T">The type of object being enumerated</typeparam>
		/// <param name="list">The <see cref="IList{T}"/> to enumerate</param>
		/// <returns>The <see cref="IModificationEnumerator{T}"/></returns>
		public static IModificationEnumerator<T> GetModificationEnumerator<T>(this IList<T> list)
		{
			return new ListModificationEnumerator<T>(list);
		}


		/// <summary>
		/// Gets a <see cref="IModificationEnumerator{T}"/> that enumerates the specified 
		/// <paramref name="linkedList"/>
		/// </summary>
		/// <typeparam name="T">The type of object being enumerated</typeparam>
		/// <param name="linkedList">The <see cref="LinkedList{T}"/> to enumerate</param>
		/// <returns>The <see cref="IModificationEnumerator{T}"/></returns>
		public static IModificationEnumerator<T> GetModificationEnumerator<T>(this LinkedList<T> linkedList)
		{
			return new LinkedListModificationEnumerator<T>(linkedList);
		}


		/// <summary>
		/// Returns the specified <paramref name="list"/> wrapped in a <see cref="IModificationEnumerable{T}"/>
		/// </summary>
		/// <typeparam name="T">The type of object being enumerated</typeparam>
		/// <param name="list">The <see cref="IList{T}"/> to wrap</param>
		/// <returns>The <see cref="IModificationEnumerable{T}"/></returns>
		public static IModificationEnumerable<T> AsModificationEnumerable<T>(this IList<T> list)
		{
			return new ListModificationEnumerable<T>(list);
		}


		/// <summary>
		/// Returns the specified <paramref name="linkedList"/> wrapped in a <see cref="IModificationEnumerable{T}"/>
		/// </summary>
		/// <typeparam name="T">The type of object being enumerated</typeparam>
		/// <param name="linkedList">The <see cref="LinkedList{T}"/> to wrap</param>
		/// <returns>The <see cref="IModificationEnumerable{T}"/></returns>
		public static IModificationEnumerable<T> AsModificationEnumerable<T>(this LinkedList<T> linkedList)
		{
			return new LinkedListModificationEnumerable<T>(linkedList);
		}



		/// <summary>
		/// A wrapper class that wraps an <see cref="IList{T}"/>
		/// </summary>
		/// <typeparam name="T">The type of object being enumerated</typeparam>
		private class ListModificationEnumerable<T> : IModificationEnumerable<T>
		{
			private readonly IList<T> _List;


			/// <summary>
			/// Constructor, creates a <see cref="ListModificationEnumerable{T}"/>
			/// </summary>
			/// <param name="list">The <see cref="IList{T}"/></param>
			public ListModificationEnumerable(IList<T> list)
			{
				_List = list;
			}


			/// <summary>
			/// Returns an enumerator that iterates through the collection.
			/// </summary>
			/// <returns>
			/// A <see cref="IModificationEnumerator{T}"/> that can be used to iterate through the collection.
			/// </returns>
			public IModificationEnumerator<T> GetEnumerator()
			{
				return new ListModificationEnumerator<T>(_List);
			}


			/// <summary>
			/// Returns an enumerator that iterates through the collection.
			/// </summary>
			/// <returns>
			/// A <see cref="IEnumerator{T}"/> that can be used to iterate through the collection.
			/// </returns>
			IEnumerator<T> IEnumerable<T>.GetEnumerator()
			{
				return GetEnumerator();
			}


			/// <summary>
			/// Returns an enumerator that iterates through a collection.
			/// </summary>
			/// <returns>
			/// An <see cref="IEnumerator"/> object that can be used to iterate through the collection.
			/// </returns>
			IEnumerator IEnumerable.GetEnumerator()
			{
				return GetEnumerator();
			}
		}


		/// <summary>
		/// A wrapper class that wraps a <see cref="LinkedList{T}"/>
		/// </summary>
		/// <typeparam name="T">The type of object being enumerated</typeparam>
		private class LinkedListModificationEnumerable<T> : IModificationEnumerable<T>
		{
			private readonly LinkedList<T> _LinkedList;


			/// <summary>
			/// Constructor, creates a <see cref="LinkedListModificationEnumerable{T}"/>
			/// </summary>
			/// <param name="linkedList">The <see cref="LinkedList{T}"/></param>
			public LinkedListModificationEnumerable(LinkedList<T> linkedList)
			{
				_LinkedList = linkedList;
			}


			/// <summary>
			/// Returns an enumerator that iterates through the collection.
			/// </summary>
			/// <returns>
			/// A <see cref="IModificationEnumerator{T}"/> that can be used to iterate through the collection.
			/// </returns>
			public IModificationEnumerator<T> GetEnumerator()
			{
				return new LinkedListModificationEnumerator<T>(_LinkedList);
			}


			/// <summary>
			/// Returns an enumerator that iterates through the collection.
			/// </summary>
			/// <returns>
			/// A <see cref="IEnumerator{T}"/> that can be used to iterate through the collection.
			/// </returns>
			IEnumerator<T> IEnumerable<T>.GetEnumerator()
			{
				return GetEnumerator();
			}


			/// <summary>
			/// Returns an enumerator that iterates through a collection.
			/// </summary>
			/// <returns>
			/// An <see cref="IEnumerator"/> object that can be used to iterate through the collection.
			/// </returns>
			IEnumerator IEnumerable.GetEnumerator()
			{
				return GetEnumerator();
			}
		}
	}
}