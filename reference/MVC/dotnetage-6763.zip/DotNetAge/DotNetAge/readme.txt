﻿ Copyright (c) 2011 Ray Liang (http://www.dotnetage.com)
 Dual licensed under the MIT and GPL licenses:
 http://www.opensource.org/licenses/mit-license.php
 http://www.gnu.org/licenses/gpl.html
 
 ==Overview==
      Version: 2.0 alpha
	  Release date: 2011-3-6

==Release notes==

===What is new in DotNetAge 2.0 ? ===
* Completely update DJME to DJME2, enhance user experience ,more beautiful and more interactively visit DJME project home to lean more about
DJME http://www.dotnetage.com/sites/home/djme.html
* A new widget engine has came! Faster and easiler.
* Runtime performance enhanced.
* SEO enhanced.
* UI Designer enhanced
* A new web resources explorer.
* Page manager enhanced
* BlogML supports added that allows you import/export your blog data to/from dotnetage publishing.


===Resources===
   DotNetAge project home page:  http://www.dotnetage.com/sites/home/dna.html
   DotNetAge developers network: http://www.dotnetage.com/sites/home/devnetwork.html
   DotNetAge installation manual:http://www.dotnetage.com/publishing/home/2011/03/06/6837/dotnetage-2-installation-manual.html
   DotNetAge community:http://www.dotnetage.com/community/forum/


*************************************************************************** Release info**********************************************************************
   Version:1.1
   Released:2010-11-3

** Resources **
   DotNetAge Quick start - http://www.dotnetage.com/sites/home/lean.html
   DotNetAge Developement guide - http://www.dotnetage.com/sites/home/develop.html	
   Installation manual  -  http://www.dotnetage.com/publishing/home/2010/10/27/3/installation-guide-of-dotnetage.html
   Register your personal web site on DotNetAge -  http://www.dotnetage.com/Account/Register

** Notes **
  If you using DotNetAge in VS.NET after install DotNetAge you can use the build-in administrator to login DotNetAge
  The build-in administrator account is below:
           *User name:administrator
           *Password: administrator

** Release notes for DotNetAge 1.1 **

What is new in DotNetAge 1.1 ?  - http://www.dotnetage.com/sites/home/download.html

D.N.A Core updates
   1.Improve runtime performance , more stabilize.
   2.The DNA core objects model added.
   3.*Personalization features added that allows users create the personal website, manage their resources, store personal data

DynamicUI
  1.Fixed the PageManager could not move page node bug.
  2.Enhance SiteMapActionAttribute allows sharing page and personalize page definition
  3.Enhance webpage dynamic creation.
  4.Format the page uri as friendly using the SEO URLs.
  5.Enhance page sitemap auto discovery for google web master tools.
  6.Enhance the page feeds for Rss & Atom

Widgets
  1.Widget extensions added - allows developer render widgets at design time
  2.Impalement Widget standard for W3C
  3.New feature widget added -  Feed widget , supports Rss feed and atom feed.
  4.Supports ansync widget action.
  5.Widget scopes added  - categorized the public widgets and personal widgets.

Themes update
   *Enabling Email Notification mechanism
      1.Added notify mail for User change password, User Registration,   Personal website creation.

Web resource management
  1.The File sharing service was renamed as web resource service
  2.Allows personalization resource store
  3.Access the public / personalization resource in normal Uri format.
  4.Resource Uri protection feature added.
  *You can use the web resource service like WebDav.

Open standards interfaces added.
    * Rss,Atom object model
    * RSD object model
    * Blogging
          o MetaWeblog object model
          o BlogML obejct model
          o Mobletype RPC interfae
          o Blogger RPC interface
          o Workpress RPC interface
    * Ping service RPC interface

Management (Console)
   1.Web Master tools added - support the google, yahoo and bing.
   2.Resource protection management features added - Allows you manage which website can link to your web resource.

Deploy & installation
   1.WebML -A template markup language that allows you using Xml to define the web, pages, widgets and data.
   2.Blog application template added.
   3.Multiple blogs application template added.
   4.Company web template added.
   5.Enterprise web template added.
 

Build-in application enhancement
Publishing system ( authoring system is rename to publishing system.)
   1. Fixed the CategoryManager could not create category bug
   2. Publishing system object model added.
   3. Enhance the CategoryManager that can move category in category  treeview
   4. Fixed could not get publishing entrance bug.
   5. Supports Windows live writer.
   6. Supports Trackback & Pingback
   7. Supports XmlRpc
   8. Supports Metaweblog, Moveable Type, Blogger and Wordpress rpc methods
   9. Add set of feature widgets for publishing system added - BlogRoll widget,PostRoll widget,
  10. Headlines widget,MulitTabHeadlines widget,HotReads widget,RecentComments widget,SummaryView widget,
  11. Article menu widget,MyActions widget.
  12. Relative article/post auto detect feature added.
  13. Enhance Article/Post reading experience.
  14. Fix the rating could not use bug.
  15. Supports private, draft for article/post.
  16. Supports permalink, slug for article/post.
  17. Supports multiple categories for article/post



