﻿/**********************************************************************/
/* InstallCommon.SQL                                                  */
/*                                                                    */
/* Installs the tables, triggers and stored procedures necessary for  */
/* supporting some features of ASP.Net                                */
/*
** Copyright Microsoft, Inc. 2003
** All Rights Reserved.
*/
/**********************************************************************/


SET QUOTED_IDENTIFIER OFF
SET ANSI_NULLS ON         -- We don't want (NULL = NULL) == TRUE
GO
SET ANSI_PADDING ON
GO
SET ANSI_NULL_DFLT_ON ON
GO

DECLARE @dbname nvarchar(128)
DECLARE @dboptions nvarchar(1024)

SET @dboptions = N'/**/'
SET @dbname = N'PlaceholderForDbName'

IF (NOT EXISTS (SELECT name
                FROM master.dbo.sysdatabases
                WHERE name = @dbname))
BEGIN
  PRINT 'Creating the ' + @dbname + ' database...'
  DECLARE @cmd nvarchar(500)
  SET @cmd = 'CREATE DATABASE [' + @dbname + '] ' + @dboptions
  EXEC(@cmd)
END
GO

USE [PlaceholderForDbName]
GO

/*************************************************************/
/*************************************************************/
/*************************************************************/
-- Create the temporary permission tables and stored procedures
-- TO preserve the permissions of an object.
--
-- We use this method instead of using CREATE (if the object
-- doesn't exist) and ALTER (if the object exists) because the
-- latter one either requires the use of dynamic SQL (which we want to
-- avoid) or writing the body of the object (e.g. an SP or view) twice,
-- once use CREATE and again using ALTER.


IF (OBJECT_ID('tempdb.#aspnet_Permissions') IS NOT NULL)
BEGIN
    DROP TABLE #aspnet_Permissions
END
GO

CREATE TABLE #aspnet_Permissions
(
    Owner     sysname,
    Object    sysname,
    Grantee   sysname,
    Grantor   sysname,
    ProtectType char(10),
    [Action]    varchar(60),
    [Column]    sysname
)

INSERT INTO #aspnet_Permissions
EXEC sp_helprotect

IF (EXISTS (SELECT name
              FROM sysobjects
             WHERE (name = N'aspnet_Setup_RestorePermissions')
               AND (type = 'P')))
DROP PROCEDURE [dbo].aspnet_Setup_RestorePermissions
GO

CREATE PROCEDURE [dbo].aspnet_Setup_RestorePermissions
    @name   sysname
AS
BEGIN
    DECLARE @object sysname
    DECLARE @protectType char(10)
    DECLARE @action varchar(60)
    DECLARE @grantee sysname
    DECLARE @cmd nvarchar(500)
    DECLARE c1 cursor FORWARD_ONLY FOR
        SELECT Object, ProtectType, [Action], Grantee FROM #aspnet_Permissions where Object = @name

    OPEN c1

    FETCH c1 INTO @object, @protectType, @action, @grantee
    WHILE (@@fetch_status = 0)
    BEGIN
        SET @cmd = @protectType + ' ' + @action + ' on ' + @object + ' TO [' + @grantee + ']'
        EXEC (@cmd)
        FETCH c1 INTO @object, @protectType, @action, @grantee
    END

    CLOSE c1
    DEALLOCATE c1
END
GO

/*************************************************************/
/*************************************************************/
/*************************************************************/

IF (EXISTS (SELECT name
              FROM sysobjects
             WHERE (name = N'aspnet_Setup_RemoveAllRoleMembers')
               AND (type = 'P')))
DROP PROCEDURE [dbo].aspnet_Setup_RemoveAllRoleMembers
GO

CREATE PROCEDURE [dbo].aspnet_Setup_RemoveAllRoleMembers
    @name   sysname
AS
BEGIN
    CREATE TABLE #aspnet_RoleMembers
    (
        Group_name      sysname,
        Group_id        smallint,
        Users_in_group  sysname,
        User_id         smallint
    )

    INSERT INTO #aspnet_RoleMembers
    EXEC sp_helpuser @name

    DECLARE @user_id smallint
    DECLARE @cmd nvarchar(500)
    DECLARE c1 cursor FORWARD_ONLY FOR
        SELECT User_id FROM #aspnet_RoleMembers

    OPEN c1

    FETCH c1 INTO @user_id
    WHILE (@@fetch_status = 0)
    BEGIN
        SET @cmd = 'EXEC sp_droprolemember ' + '''' + @name + ''', ''' + USER_NAME(@user_id) + ''''
        EXEC (@cmd)
        FETCH c1 INTO @user_id
    END

    CLOSE c1
    DEALLOCATE c1
END
GO

/*************************************************************/
/*************************************************************/
/*************************************************************/
-- Create the aspnet_Applications table.

IF (NOT EXISTS (SELECT name
                FROM sysobjects
                WHERE (name = N'aspnet_Applications')
                  AND (type = 'U')))
BEGIN
  PRINT 'Creating the aspnet_Applications table...'
  CREATE TABLE [dbo].aspnet_Applications (
    ApplicationName         nvarchar(256)               NOT NULL UNIQUE,
    LoweredApplicationName  nvarchar(256)               NOT NULL UNIQUE,
    ApplicationId           uniqueidentifier            PRIMARY KEY NONCLUSTERED DEFAULT NEWID(),
    Description             nvarchar(256)       )
  CREATE CLUSTERED INDEX aspnet_Applications_Index ON [dbo].aspnet_Applications(LoweredApplicationName)
END
GO

/*************************************************************/
/*************************************************************/
/*************************************************************/
-- Create the aspnet_Users table
IF (NOT EXISTS (SELECT name
                FROM sysobjects
                WHERE (name = N'aspnet_Users')
                  AND (type = 'U')))
BEGIN
  PRINT 'Creating the aspnet_Users table...'
  CREATE TABLE [dbo].aspnet_Users (
    ApplicationId    uniqueidentifier    NOT NULL FOREIGN KEY REFERENCES [dbo].aspnet_Applications(ApplicationId),
    UserId           uniqueidentifier    NOT NULL PRIMARY KEY NONCLUSTERED DEFAULT NEWID(),
    UserName         nvarchar(256)       NOT NULL,
    LoweredUserName  nvarchar(256)	     NOT NULL,
    MobileAlias      nvarchar(16)        DEFAULT NULL,
    IsAnonymous      bit                 NOT NULL DEFAULT 0,
    LastActivityDate DATETIME            NOT NULL)

   CREATE UNIQUE CLUSTERED INDEX aspnet_Users_Index ON [dbo].aspnet_Users(ApplicationId, LoweredUserName)
   CREATE NONCLUSTERED INDEX aspnet_Users_Index2 ON [dbo].aspnet_Users(ApplicationId, LastActivityDate)
END
GO

/*************************************************************/
/*************************************************************/
/*************************************************************/
-- Create the aspnet_SchemaVersions table
IF (NOT EXISTS (SELECT name
                FROM sysobjects
                WHERE (name = N'aspnet_SchemaVersions')
                  AND (type = 'U')))
BEGIN
  PRINT 'Creating the aspnet_SchemaVersions table...'
  CREATE TABLE [dbo].aspnet_SchemaVersions (
    Feature                  nvarchar(128)  NOT NULL PRIMARY KEY CLUSTERED( Feature, CompatibleSchemaVersion ),
    CompatibleSchemaVersion  nvarchar(128)	NOT NULL,
    IsCurrentVersion         bit            NOT NULL )
END
GO

/*************************************************************/
/*************************************************************/
------------- Create Stored Procedures
/*************************************************************/
/*************************************************************/
-- RegisterSchemaVersion SP

IF (EXISTS (SELECT name
              FROM sysobjects
             WHERE (name = N'aspnet_RegisterSchemaVersion')
               AND (type = 'P')))
DROP PROCEDURE [dbo].aspnet_RegisterSchemaVersion
GO

CREATE PROCEDURE [dbo].aspnet_RegisterSchemaVersion
    @Feature                   nvarchar(128),
    @CompatibleSchemaVersion   nvarchar(128),
    @IsCurrentVersion          bit,
    @RemoveIncompatibleSchema  bit
AS
BEGIN
    IF( @RemoveIncompatibleSchema = 1 )
    BEGIN
        DELETE FROM dbo.aspnet_SchemaVersions WHERE Feature = LOWER( @Feature )
    END
    ELSE
    BEGIN
        IF( @IsCurrentVersion = 1 )
        BEGIN
            UPDATE dbo.aspnet_SchemaVersions
            SET IsCurrentVersion = 0
            WHERE Feature = LOWER( @Feature )
        END
    END

    INSERT  dbo.aspnet_SchemaVersions( Feature, CompatibleSchemaVersion, IsCurrentVersion )
    VALUES( LOWER( @Feature ), @CompatibleSchemaVersion, @IsCurrentVersion )
END
GO

DECLARE @command nvarchar(4000)

SET @command = 'GRANT EXECUTE ON [dbo].aspnet_Setup_RestorePermissions TO ' + QUOTENAME(user)
EXEC (@command)
SET @command = 'GRANT EXECUTE ON [dbo].aspnet_RegisterSchemaVersion TO ' + QUOTENAME(user)
EXEC (@command)
GO

-- Restore the permissions
EXEC [dbo].aspnet_Setup_RestorePermissions N'aspnet_RegisterSchemaVersion'
GO

-- Create common schema version
EXEC [dbo].aspnet_RegisterSchemaVersion N'Common', N'1', 1, 1
GO

/*************************************************************/
/*************************************************************/
-- CheckSchemaVersion SP

IF (EXISTS (SELECT name
              FROM sysobjects
             WHERE (name = N'aspnet_CheckSchemaVersion')
               AND (type = 'P')))
DROP PROCEDURE [dbo].aspnet_CheckSchemaVersion
GO

CREATE PROCEDURE [dbo].aspnet_CheckSchemaVersion
    @Feature                   nvarchar(128),
    @CompatibleSchemaVersion   nvarchar(128)
AS
BEGIN
    IF (EXISTS( SELECT  *
                FROM    dbo.aspnet_SchemaVersions
                WHERE   Feature = LOWER( @Feature ) AND
                        CompatibleSchemaVersion = @CompatibleSchemaVersion ))
        RETURN 0

    RETURN 1
END
GO

-- Restore the permissions
EXEC [dbo].aspnet_Setup_RestorePermissions N'aspnet_CheckSchemaVersion'
GO

/*************************************************************/
/*************************************************************/
-- CreateApplication SP

IF (EXISTS (SELECT name
              FROM sysobjects
             WHERE (name = N'aspnet_Applications_CreateApplication')
               AND (type = 'P')))
DROP PROCEDURE [dbo].aspnet_Applications_CreateApplication
GO

CREATE PROCEDURE [dbo].aspnet_Applications_CreateApplication
    @ApplicationName      nvarchar(256),
    @ApplicationId        uniqueidentifier OUTPUT
AS
BEGIN
    SELECT  @ApplicationId = ApplicationId FROM dbo.aspnet_Applications WHERE LOWER(@ApplicationName) = LoweredApplicationName

    IF(@ApplicationId IS NULL)
    BEGIN
        DECLARE @TranStarted   bit
        SET @TranStarted = 0

        IF( @@TRANCOUNT = 0 )
        BEGIN
	        BEGIN TRANSACTION
	        SET @TranStarted = 1
        END
        ELSE
    	    SET @TranStarted = 0

        SELECT  @ApplicationId = ApplicationId
        FROM dbo.aspnet_Applications WITH (UPDLOCK, HOLDLOCK)
        WHERE LOWER(@ApplicationName) = LoweredApplicationName

        IF(@ApplicationId IS NULL)
        BEGIN
            SELECT  @ApplicationId = NEWID()
            INSERT  dbo.aspnet_Applications (ApplicationId, ApplicationName, LoweredApplicationName)
            VALUES  (@ApplicationId, @ApplicationName, LOWER(@ApplicationName))
        END


        IF( @TranStarted = 1 )
        BEGIN
            IF(@@ERROR = 0)
            BEGIN
	        SET @TranStarted = 0
	        COMMIT TRANSACTION
            END
            ELSE
            BEGIN
                SET @TranStarted = 0
                ROLLBACK TRANSACTION
            END
        END
    END
END
GO

-- Restore the permissions
EXEC [dbo].aspnet_Setup_RestorePermissions N'aspnet_Applications_CreateApplication'
GO

/*************************************************************/
/*************************************************************/
-- UnRegisterSchemaVersion SP

IF (EXISTS (SELECT name
              FROM sysobjects
             WHERE (name = N'aspnet_UnRegisterSchemaVersion')
               AND (type = 'P')))
DROP PROCEDURE [dbo].aspnet_UnRegisterSchemaVersion
GO

CREATE PROCEDURE [dbo].aspnet_UnRegisterSchemaVersion
    @Feature                   nvarchar(128),
    @CompatibleSchemaVersion   nvarchar(128)
AS
BEGIN
    DELETE FROM dbo.aspnet_SchemaVersions
        WHERE   Feature = LOWER(@Feature) AND @CompatibleSchemaVersion = CompatibleSchemaVersion
END
GO

-- Restore the permissions
EXEC [dbo].aspnet_Setup_RestorePermissions N'aspnet_UnRegisterSchemaVersion'
GO

/*************************************************************/
/*************************************************************/
-- CreateUser SP

IF (EXISTS (SELECT name
              FROM sysobjects
             WHERE (name = N'aspnet_Users_CreateUser')
               AND (type = 'P')))
DROP PROCEDURE [dbo].aspnet_Users_CreateUser
GO

CREATE PROCEDURE [dbo].aspnet_Users_CreateUser
    @ApplicationId    uniqueidentifier,
    @UserName         nvarchar(256),
    @IsUserAnonymous  bit,
    @LastActivityDate DATETIME,
    @UserId           uniqueidentifier OUTPUT
AS
BEGIN
    IF( @UserId IS NULL )
        SELECT @UserId = NEWID()
    ELSE
    BEGIN
        IF( EXISTS( SELECT UserId FROM dbo.aspnet_Users
                    WHERE @UserId = UserId ) )
            RETURN -1
    END

    INSERT dbo.aspnet_Users (ApplicationId, UserId, UserName, LoweredUserName, IsAnonymous, LastActivityDate)
    VALUES (@ApplicationId, @UserId, @UserName, LOWER(@UserName), @IsUserAnonymous, @LastActivityDate)

    RETURN 0
END
GO

-- Restore the permissions
EXEC [dbo].aspnet_Setup_RestorePermissions N'aspnet_Users_CreateUser'
GO

/*************************************************************/
/*************************************************************/
--- DeleteUser SP

IF (EXISTS (SELECT name
              FROM sysobjects
             WHERE (name = N'aspnet_Users_DeleteUser')
               AND (type = 'P')))
DROP PROCEDURE [dbo].aspnet_Users_DeleteUser
GO
CREATE PROCEDURE [dbo].aspnet_Users_DeleteUser
    @ApplicationName  nvarchar(256),
    @UserName         nvarchar(256),
    @TablesToDeleteFrom int,
    @NumTablesDeletedFrom int OUTPUT
AS
BEGIN
    DECLARE @UserId               uniqueidentifier
    SELECT  @UserId               = NULL
    SELECT  @NumTablesDeletedFrom = 0

    DECLARE @TranStarted   bit
    SET @TranStarted = 0

    IF( @@TRANCOUNT = 0 )
    BEGIN
	    BEGIN TRANSACTION
	    SET @TranStarted = 1
    END
    ELSE
	SET @TranStarted = 0

    DECLARE @ErrorCode   int
    DECLARE @RowCount    int

    SET @ErrorCode = 0
    SET @RowCount  = 0

    SELECT  @UserId = u.UserId
    FROM    dbo.aspnet_Users u, dbo.aspnet_Applications a
    WHERE   u.LoweredUserName       = LOWER(@UserName)
        AND u.ApplicationId         = a.ApplicationId
        AND LOWER(@ApplicationName) = a.LoweredApplicationName

    IF (@UserId IS NULL)
    BEGIN
        GOTO Cleanup
    END

    -- Delete from Membership table if (@TablesToDeleteFrom & 1) is set
    IF ((@TablesToDeleteFrom & 1) <> 0 AND
        (EXISTS (SELECT name FROM sysobjects WHERE (name = N'vw_aspnet_MembershipUsers') AND (type = 'V'))))
    BEGIN
        DELETE FROM dbo.aspnet_Membership WHERE @UserId = UserId

        SELECT @ErrorCode = @@ERROR,
               @RowCount = @@ROWCOUNT

        IF( @ErrorCode <> 0 )
            GOTO Cleanup

        IF (@RowCount <> 0)
            SELECT  @NumTablesDeletedFrom = @NumTablesDeletedFrom + 1
    END

    -- Delete from aspnet_UsersInRoles table if (@TablesToDeleteFrom & 2) is set
    IF ((@TablesToDeleteFrom & 2) <> 0  AND
        (EXISTS (SELECT name FROM sysobjects WHERE (name = N'vw_aspnet_UsersInRoles') AND (type = 'V'))) )
    BEGIN
        DELETE FROM dbo.aspnet_UsersInRoles WHERE @UserId = UserId

        SELECT @ErrorCode = @@ERROR,
                @RowCount = @@ROWCOUNT

        IF( @ErrorCode <> 0 )
            GOTO Cleanup

        IF (@RowCount <> 0)
            SELECT  @NumTablesDeletedFrom = @NumTablesDeletedFrom + 1
    END

    -- Delete from aspnet_Profile table if (@TablesToDeleteFrom & 4) is set
    IF ((@TablesToDeleteFrom & 4) <> 0  AND
        (EXISTS (SELECT name FROM sysobjects WHERE (name = N'vw_aspnet_Profiles') AND (type = 'V'))) )
    BEGIN
        DELETE FROM dbo.aspnet_Profile WHERE @UserId = UserId

        SELECT @ErrorCode = @@ERROR,
                @RowCount = @@ROWCOUNT

        IF( @ErrorCode <> 0 )
            GOTO Cleanup

        IF (@RowCount <> 0)
            SELECT  @NumTablesDeletedFrom = @NumTablesDeletedFrom + 1
    END

    -- Delete from aspnet_PersonalizationPerUser table if (@TablesToDeleteFrom & 8) is set
    IF ((@TablesToDeleteFrom & 8) <> 0  AND
        (EXISTS (SELECT name FROM sysobjects WHERE (name = N'vw_aspnet_WebPartState_User') AND (type = 'V'))) )
    BEGIN
        DELETE FROM dbo.aspnet_PersonalizationPerUser WHERE @UserId = UserId

        SELECT @ErrorCode = @@ERROR,
                @RowCount = @@ROWCOUNT

        IF( @ErrorCode <> 0 )
            GOTO Cleanup

        IF (@RowCount <> 0)
            SELECT  @NumTablesDeletedFrom = @NumTablesDeletedFrom + 1
    END

    -- Delete from aspnet_Users table if (@TablesToDeleteFrom & 1,2,4 & 8) are all set
    IF ((@TablesToDeleteFrom & 1) <> 0 AND
        (@TablesToDeleteFrom & 2) <> 0 AND
        (@TablesToDeleteFrom & 4) <> 0 AND
        (@TablesToDeleteFrom & 8) <> 0 AND
        (EXISTS (SELECT UserId FROM dbo.aspnet_Users WHERE @UserId = UserId)))
    BEGIN
        DELETE FROM dbo.aspnet_Users WHERE @UserId = UserId

        SELECT @ErrorCode = @@ERROR,
                @RowCount = @@ROWCOUNT

        IF( @ErrorCode <> 0 )
            GOTO Cleanup

        IF (@RowCount <> 0)
            SELECT  @NumTablesDeletedFrom = @NumTablesDeletedFrom + 1
    END

    IF( @TranStarted = 1 )
    BEGIN
	    SET @TranStarted = 0
	    COMMIT TRANSACTION
    END

    RETURN 0

Cleanup:
    SET @NumTablesDeletedFrom = 0

    IF( @TranStarted = 1 )
    BEGIN
        SET @TranStarted = 0
	    ROLLBACK TRANSACTION
    END

    RETURN @ErrorCode

END
GO

/*************************************************************/
/*************************************************************/
/*************************************************************/
/*************************************************************/

-- Restore the permissions
EXEC [dbo].aspnet_Setup_RestorePermissions N'aspnet_Users_DeleteUser'
GO

/*************************************************************/
/*************************************************************/
--- aspnet_AnyDataInTables SP

IF (EXISTS (SELECT name
              FROM sysobjects
             WHERE (name = N'aspnet_AnyDataInTables')
               AND (type = 'P')))
DROP PROCEDURE [dbo].aspnet_AnyDataInTables
GO
CREATE PROCEDURE [dbo].aspnet_AnyDataInTables
    @TablesToCheck int
AS
BEGIN
    -- Check Membership table if (@TablesToCheck & 1) is set
    IF ((@TablesToCheck & 1) <> 0 AND
        (EXISTS (SELECT name FROM sysobjects WHERE (name = N'vw_aspnet_MembershipUsers') AND (type = 'V'))))
    BEGIN
        IF (EXISTS(SELECT TOP 1 UserId FROM dbo.aspnet_Membership))
        BEGIN
            SELECT N'aspnet_Membership'
            RETURN
        END
    END

    -- Check aspnet_Roles table if (@TablesToCheck & 2) is set
    IF ((@TablesToCheck & 2) <> 0  AND
        (EXISTS (SELECT name FROM sysobjects WHERE (name = N'vw_aspnet_Roles') AND (type = 'V'))) )
    BEGIN
        IF (EXISTS(SELECT TOP 1 RoleId FROM dbo.aspnet_Roles))
        BEGIN
            SELECT N'aspnet_Roles'
            RETURN
        END
    END

    -- Check aspnet_Profile table if (@TablesToCheck & 4) is set
    IF ((@TablesToCheck & 4) <> 0  AND
        (EXISTS (SELECT name FROM sysobjects WHERE (name = N'vw_aspnet_Profiles') AND (type = 'V'))) )
    BEGIN
        IF (EXISTS(SELECT TOP 1 UserId FROM dbo.aspnet_Profile))
        BEGIN
            SELECT N'aspnet_Profile'
            RETURN
        END
    END

    -- Check aspnet_PersonalizationPerUser table if (@TablesToCheck & 8) is set
    IF ((@TablesToCheck & 8) <> 0  AND
        (EXISTS (SELECT name FROM sysobjects WHERE (name = N'vw_aspnet_WebPartState_User') AND (type = 'V'))) )
    BEGIN
        IF (EXISTS(SELECT TOP 1 UserId FROM dbo.aspnet_PersonalizationPerUser))
        BEGIN
            SELECT N'aspnet_PersonalizationPerUser'
            RETURN
        END
    END

    -- Check aspnet_PersonalizationPerUser table if (@TablesToCheck & 16) is set
    IF ((@TablesToCheck & 16) <> 0  AND
        (EXISTS (SELECT name FROM sysobjects WHERE (name = N'aspnet_WebEvent_LogEvent') AND (type = 'P'))) )
    BEGIN
        IF (EXISTS(SELECT TOP 1 * FROM dbo.aspnet_WebEvent_Events))
        BEGIN
            SELECT N'aspnet_WebEvent_Events'
            RETURN
        END
    END

    -- Check aspnet_Users table if (@TablesToCheck & 1,2,4 & 8) are all set
    IF ((@TablesToCheck & 1) <> 0 AND
        (@TablesToCheck & 2) <> 0 AND
        (@TablesToCheck & 4) <> 0 AND
        (@TablesToCheck & 8) <> 0 AND
        (@TablesToCheck & 32) <> 0 AND
        (@TablesToCheck & 128) <> 0 AND
        (@TablesToCheck & 256) <> 0 AND
        (@TablesToCheck & 512) <> 0 AND
        (@TablesToCheck & 1024) <> 0)
    BEGIN
        IF (EXISTS(SELECT TOP 1 UserId FROM dbo.aspnet_Users))
        BEGIN
            SELECT N'aspnet_Users'
            RETURN
        END
        IF (EXISTS(SELECT TOP 1 ApplicationId FROM dbo.aspnet_Applications))
        BEGIN
            SELECT N'aspnet_Applications'
            RETURN
        END
    END
END
GO

/*************************************************************/
/*************************************************************/
/*************************************************************/
/*************************************************************/
DECLARE @command nvarchar(400)
SET @command = 'GRANT EXECUTE ON [dbo].aspnet_AnyDataInTables TO ' + QUOTENAME(user)
EXEC (@command)
GO

-- Restore the permissions
EXEC [dbo].aspnet_Setup_RestorePermissions N'aspnet_AnyDataInTables'
GO

/*************************************************************/
/*************************************************************/

IF (NOT EXISTS (SELECT name
                FROM sysobjects
                WHERE (name = N'vw_aspnet_Applications')
                  AND (type = 'V')))
BEGIN
  PRINT 'Creating the vw_aspnet_Applications view...'
  EXEC('
  CREATE VIEW [dbo].[vw_aspnet_Applications]
  AS SELECT [dbo].[aspnet_Applications].[ApplicationName], [dbo].[aspnet_Applications].[LoweredApplicationName], [dbo].[aspnet_Applications].[ApplicationId], [dbo].[aspnet_Applications].[Description]
  FROM [dbo].[aspnet_Applications]
  ')
END

-- Restore the permissions
EXEC [dbo].aspnet_Setup_RestorePermissions N'vw_aspnet_Applications'
GO

/*************************************************************/
/*************************************************************/

IF (NOT EXISTS (SELECT name
                FROM sysobjects
                WHERE (name = N'vw_aspnet_Users')
                  AND (type = 'V')))
BEGIN
  PRINT 'Creating the vw_aspnet_Users view...'
  EXEC('
  CREATE VIEW [dbo].[vw_aspnet_Users]
  AS SELECT [dbo].[aspnet_Users].[ApplicationId], [dbo].[aspnet_Users].[UserId], [dbo].[aspnet_Users].[UserName], [dbo].[aspnet_Users].[LoweredUserName], [dbo].[aspnet_Users].[MobileAlias], [dbo].[aspnet_Users].[IsAnonymous], [dbo].[aspnet_Users].[LastActivityDate]
  FROM [dbo].[aspnet_Users]
  ')
END

-- Restore the permissions
EXEC [dbo].aspnet_Setup_RestorePermissions N'vw_aspnet_Users'
GO

/*************************************************************/
/*************************************************************/
DECLARE @command nvarchar(4000)

SET @command = 'REVOKE EXECUTE ON [dbo].aspnet_Setup_RestorePermissions from ' + QUOTENAME(user)
EXEC (@command)
SET @command = 'REVOKE EXECUTE ON [dbo].aspnet_RegisterSchemaVersion from ' + QUOTENAME(user)
EXEC (@command)
GO

DROP TABLE #aspnet_Permissions
GO

/**********************************************************************/
/* InstallMembership.SQL                                              */
/*                                                                    */
/* Installs the tables, triggers and stored procedures necessary for  */
/* supporting the aspnet feature of ASP.Net                           */
/*                                                                    */
/* InstallCommon.sql must be run before running this file.            */
/*
** Copyright Microsoft, Inc. 2002
** All Rights Reserved.
*/
/**********************************************************************/

SET QUOTED_IDENTIFIER OFF
SET ANSI_NULLS ON         
GO
SET ANSI_PADDING ON
GO
SET ANSI_NULL_DFLT_ON ON
GO


DECLARE @dbname nvarchar(128)

SET @dbname = N'PlaceholderForDbName'

IF (NOT EXISTS (SELECT name
                FROM master.dbo.sysdatabases
                WHERE ('[' + name + ']' = @dbname OR name = @dbname)))
BEGIN
  RAISERROR('The database ''%s'' cannot be found. Please run InstallCommon.sql first.', 18, 1, @dbname)
END
GO

USE [PlaceholderForDbName]
GO

IF (NOT EXISTS (SELECT name
                FROM sysobjects
                WHERE (name = N'aspnet_Applications')
                  AND (type = 'U')))
BEGIN
  RAISERROR('The table ''aspnet_Applications'' cannot be found. Please use aspnet_regsql.exe for installing ASP.NET application services.', 18, 1)
END

IF (NOT EXISTS (SELECT name
                FROM sysobjects
                WHERE (name = N'aspnet_Users')
                  AND (type = 'U')))
BEGIN
  RAISERROR('The table ''aspnet_Users'' cannot be found. Please use aspnet_regsql.exe for installing ASP.NET application services.', 18, 1)
END

IF (NOT EXISTS (SELECT name
              FROM sysobjects
             WHERE (name = N'aspnet_Applications_CreateApplication')
               AND (type = 'P')))
BEGIN
  RAISERROR('The stored procedure ''aspnet_Applications_CreateApplication'' cannot be found. Please use aspnet_regsql.exe for installing ASP.NET application services.', 18, 1)
END

IF (NOT EXISTS (SELECT name
              FROM sysobjects
             WHERE (name = N'aspnet_Users_CreateUser')
               AND (type = 'P')))
BEGIN
  RAISERROR('The stored procedure ''aspnet_Users_CreateUser'' cannot be found. Please use aspnet_regsql.exe for installing ASP.NET application services.', 18, 1)
END

IF (NOT EXISTS (SELECT name
              FROM sysobjects
             WHERE (name = N'aspnet_Users_DeleteUser')
               AND (type = 'P')))
BEGIN
  RAISERROR('The stored procedure ''aspnet_Users_DeleteUser'' cannot be found. Please use aspnet_regsql.exe for installing ASP.NET application services.', 18, 1)
END

/*************************************************************/
/*************************************************************/
IF (NOT EXISTS (SELECT name
                FROM sysobjects
                WHERE (name = N'aspnet_Membership')
                  AND (type = 'U')))
BEGIN
  
  CREATE TABLE dbo.aspnet_Membership (
        ApplicationId                           uniqueidentifier    NOT NULL FOREIGN KEY REFERENCES dbo.aspnet_Applications(ApplicationId),
        UserId                                  uniqueidentifier    NOT NULL PRIMARY KEY NONCLUSTERED FOREIGN KEY REFERENCES dbo.aspnet_Users(UserId),
        Password                                nvarchar(128)       NOT NULL,
        PasswordFormat                          int                 NOT NULL DEFAULT 0,
        PasswordSalt                            nvarchar(128)       NOT NULL,
        MobilePIN                               nvarchar(16),
        Email                                   nvarchar(256),
        LoweredEmail                            nvarchar(256),
        PasswordQuestion                        nvarchar(256),
        PasswordAnswer                          nvarchar(128),
        IsApproved                              bit                 NOT NULL,
        IsLockedOut                             bit                 NOT NULL,
        CreateDate                              datetime            NOT NULL,
        LastLoginDate                           datetime            NOT NULL,
        LastPasswordChangedDate                 datetime            NOT NULL,
        LastLockoutDate                         datetime            NOT NULL,
        FailedPasswordAttemptCount              int                 NOT NULL,
        FailedPasswordAttemptWindowStart        datetime            NOT NULL,
        FailedPasswordAnswerAttemptCount        int                 NOT NULL,
        FailedPasswordAnswerAttemptWindowStart  datetime            NOT NULL,
        Comment                                 ntext )
  CREATE CLUSTERED INDEX aspnet_Membership_index ON aspnet_Membership(ApplicationId, LoweredEmail)
END
GO

/*************************************************************/
/*************************************************************/
/*************************************************************/

DECLARE @ver int
DECLARE @version nchar(100)
DECLARE @dot int
DECLARE @hyphen int
DECLARE @SqlToExec nchar(400)

SELECT @ver = 8
SELECT @version = @@Version
SELECT @hyphen  = CHARINDEX(N' - ', @version)
IF (NOT(@hyphen IS NULL) AND @hyphen > 0)
BEGIN
    SELECT @hyphen = @hyphen + 3
    SELECT @dot    = CHARINDEX(N'.', @version, @hyphen)
    IF (NOT(@dot IS NULL) AND @dot > @hyphen)
    BEGIN
        SELECT @version = SUBSTRING(@version, @hyphen, @dot - @hyphen)
        SELECT @ver     = CONVERT(int, @version)
    END
END

/*************************************************************/

IF (@ver >= 8)
    EXEC sp_tableoption N'aspnet_Membership', 'text in row', 3000

/*************************************************************/
/*************************************************************/

IF (EXISTS (SELECT name
              FROM sysobjects
             WHERE (name = N'aspnet_Membership_CreateUser')
               AND (type = 'P')))
DROP PROCEDURE dbo.aspnet_Membership_CreateUser
GO
CREATE PROCEDURE dbo.aspnet_Membership_CreateUser
    @ApplicationName                        nvarchar(256),
    @UserName                               nvarchar(256),
    @Password                               nvarchar(128),
    @PasswordSalt                           nvarchar(128),
    @Email                                  nvarchar(256),
    @PasswordQuestion                       nvarchar(256),
    @PasswordAnswer                         nvarchar(128),
    @IsApproved                             bit,
    @CurrentTimeUtc                         datetime,
    @CreateDate                             datetime = NULL,
    @UniqueEmail                            int      = 0,
    @PasswordFormat                         int      = 0,
    @UserId                                 uniqueidentifier OUTPUT
AS
BEGIN
    DECLARE @ApplicationId uniqueidentifier
    SELECT  @ApplicationId = NULL

    DECLARE @NewUserId uniqueidentifier
    SELECT @NewUserId = NULL

    DECLARE @IsLockedOut bit
    SET @IsLockedOut = 0

    DECLARE @LastLockoutDate  datetime
    SET @LastLockoutDate = CONVERT( datetime, '17540101', 112 )

    DECLARE @FailedPasswordAttemptCount int
    SET @FailedPasswordAttemptCount = 0

    DECLARE @FailedPasswordAttemptWindowStart  datetime
    SET @FailedPasswordAttemptWindowStart = CONVERT( datetime, '17540101', 112 )

    DECLARE @FailedPasswordAnswerAttemptCount int
    SET @FailedPasswordAnswerAttemptCount = 0

    DECLARE @FailedPasswordAnswerAttemptWindowStart  datetime
    SET @FailedPasswordAnswerAttemptWindowStart = CONVERT( datetime, '17540101', 112 )

    DECLARE @NewUserCreated bit
    DECLARE @ReturnValue   int
    SET @ReturnValue = 0

    DECLARE @ErrorCode     int
    SET @ErrorCode = 0

    DECLARE @TranStarted   bit
    SET @TranStarted = 0

    IF( @@TRANCOUNT = 0 )
    BEGIN
	    BEGIN TRANSACTION
	    SET @TranStarted = 1
    END
    ELSE
    	SET @TranStarted = 0

    EXEC dbo.aspnet_Applications_CreateApplication @ApplicationName, @ApplicationId OUTPUT

    IF( @@ERROR <> 0 )
    BEGIN
        SET @ErrorCode = -1
        GOTO Cleanup
    END

    SET @CreateDate = @CurrentTimeUtc

    SELECT  @NewUserId = UserId FROM dbo.aspnet_Users WHERE LOWER(@UserName) = LoweredUserName AND @ApplicationId = ApplicationId
    IF ( @NewUserId IS NULL )
    BEGIN
        SET @NewUserId = @UserId
        EXEC @ReturnValue = dbo.aspnet_Users_CreateUser @ApplicationId, @UserName, 0, @CreateDate, @NewUserId OUTPUT
        SET @NewUserCreated = 1
    END
    ELSE
    BEGIN
        SET @NewUserCreated = 0
        IF( @NewUserId <> @UserId AND @UserId IS NOT NULL )
        BEGIN
            SET @ErrorCode = 6
            GOTO Cleanup
        END
    END

    IF( @@ERROR <> 0 )
    BEGIN
        SET @ErrorCode = -1
        GOTO Cleanup
    END

    IF( @ReturnValue = -1 )
    BEGIN
        SET @ErrorCode = 10
        GOTO Cleanup
    END

    IF ( EXISTS ( SELECT UserId
                  FROM   dbo.aspnet_Membership
                  WHERE  @NewUserId = UserId ) )
    BEGIN
        SET @ErrorCode = 6
        GOTO Cleanup
    END

    SET @UserId = @NewUserId

    IF (@UniqueEmail = 1)
    BEGIN
        IF (EXISTS (SELECT *
                    FROM  dbo.aspnet_Membership m WITH ( UPDLOCK, HOLDLOCK )
                    WHERE ApplicationId = @ApplicationId AND LoweredEmail = LOWER(@Email)))
        BEGIN
            SET @ErrorCode = 7
            GOTO Cleanup
        END
    END

    IF (@NewUserCreated = 0)
    BEGIN
        UPDATE dbo.aspnet_Users
        SET    LastActivityDate = @CreateDate
        WHERE  @UserId = UserId
        IF( @@ERROR <> 0 )
        BEGIN
            SET @ErrorCode = -1
            GOTO Cleanup
        END
    END

    INSERT INTO dbo.aspnet_Membership
                ( ApplicationId,
                  UserId,
                  Password,
                  PasswordSalt,
                  Email,
                  LoweredEmail,
                  PasswordQuestion,
                  PasswordAnswer,
                  PasswordFormat,
                  IsApproved,
                  IsLockedOut,
                  CreateDate,
                  LastLoginDate,
                  LastPasswordChangedDate,
                  LastLockoutDate,
                  FailedPasswordAttemptCount,
                  FailedPasswordAttemptWindowStart,
                  FailedPasswordAnswerAttemptCount,
                  FailedPasswordAnswerAttemptWindowStart )
         VALUES ( @ApplicationId,
                  @UserId,
                  @Password,
                  @PasswordSalt,
                  @Email,
                  LOWER(@Email),
                  @PasswordQuestion,
                  @PasswordAnswer,
                  @PasswordFormat,
                  @IsApproved,
                  @IsLockedOut,
                  @CreateDate,
                  @CreateDate,
                  @CreateDate,
                  @LastLockoutDate,
                  @FailedPasswordAttemptCount,
                  @FailedPasswordAttemptWindowStart,
                  @FailedPasswordAnswerAttemptCount,
                  @FailedPasswordAnswerAttemptWindowStart )

    IF( @@ERROR <> 0 )
    BEGIN
        SET @ErrorCode = -1
        GOTO Cleanup
    END

    IF( @TranStarted = 1 )
    BEGIN
	    SET @TranStarted = 0
	    COMMIT TRANSACTION
    END

    RETURN 0

Cleanup:

    IF( @TranStarted = 1 )
    BEGIN
        SET @TranStarted = 0
    	ROLLBACK TRANSACTION
    END

    RETURN @ErrorCode

END
GO

/*************************************************************/
/*************************************************************/

IF (EXISTS (SELECT name
              FROM sysobjects
             WHERE (name = N'aspnet_Membership_GetUserByName')
               AND (type = 'P')))
DROP PROCEDURE dbo.aspnet_Membership_GetUserByName
GO
CREATE PROCEDURE dbo.aspnet_Membership_GetUserByName
    @ApplicationName      nvarchar(256),
    @UserName             nvarchar(256),
    @CurrentTimeUtc       datetime,
    @UpdateLastActivity   bit = 0
AS
BEGIN
    DECLARE @UserId uniqueidentifier

    IF (@UpdateLastActivity = 1)
    BEGIN
        /*-- select user ID from aspnet_users table--*/
        SELECT TOP 1 @UserId = u.UserId
        FROM    dbo.aspnet_Applications a, dbo.aspnet_Users u, dbo.aspnet_Membership m
        WHERE    LOWER(@ApplicationName) = a.LoweredApplicationName AND
                u.ApplicationId = a.ApplicationId    AND
                LOWER(@UserName) = u.LoweredUserName AND u.UserId = m.UserId

        IF (@@ROWCOUNT = 0) /*-- Username not found--*/
            RETURN -1

        UPDATE   dbo.aspnet_Users
        SET      LastActivityDate = @CurrentTimeUtc
        WHERE    @UserId = UserId

        SELECT m.Email, m.PasswordQuestion, m.Comment, m.IsApproved,
                m.CreateDate, m.LastLoginDate, u.LastActivityDate, m.LastPasswordChangedDate,
                u.UserId, m.IsLockedOut, m.LastLockoutDate
        FROM    dbo.aspnet_Applications a, dbo.aspnet_Users u, dbo.aspnet_Membership m
        WHERE  @UserId = u.UserId AND u.UserId = m.UserId 
    END
    ELSE
    BEGIN
        SELECT TOP 1 m.Email, m.PasswordQuestion, m.Comment, m.IsApproved,
                m.CreateDate, m.LastLoginDate, u.LastActivityDate, m.LastPasswordChangedDate,
                u.UserId, m.IsLockedOut,m.LastLockoutDate
        FROM    dbo.aspnet_Applications a, dbo.aspnet_Users u, dbo.aspnet_Membership m
        WHERE    LOWER(@ApplicationName) = a.LoweredApplicationName AND
                u.ApplicationId = a.ApplicationId    AND
                LOWER(@UserName) = u.LoweredUserName AND u.UserId = m.UserId

        IF (@@ROWCOUNT = 0) /*-- Username not found--*/
            RETURN -1
    END

    RETURN 0
END
GO

/*************************************************************/
/*************************************************************/

IF (EXISTS (SELECT name
              FROM sysobjects
             WHERE (name = N'aspnet_Membership_GetUserByUserId')
               AND (type = 'P')))
DROP PROCEDURE dbo.aspnet_Membership_GetUserByUserId
GO
CREATE PROCEDURE dbo.aspnet_Membership_GetUserByUserId
    @UserId               uniqueidentifier,
    @CurrentTimeUtc       datetime,
    @UpdateLastActivity   bit = 0
AS
BEGIN
    IF ( @UpdateLastActivity = 1 )
    BEGIN
        UPDATE   dbo.aspnet_Users
        SET      LastActivityDate = @CurrentTimeUtc
        FROM     dbo.aspnet_Users
        WHERE    @UserId = UserId

        IF ( @@ROWCOUNT = 0 ) /*-- User ID not found--*/
            RETURN -1
    END

    SELECT  m.Email, m.PasswordQuestion, m.Comment, m.IsApproved,
            m.CreateDate, m.LastLoginDate, u.LastActivityDate,
            m.LastPasswordChangedDate, u.UserName, m.IsLockedOut,
            m.LastLockoutDate
    FROM    dbo.aspnet_Users u, dbo.aspnet_Membership m
    WHERE   @UserId = u.UserId AND u.UserId = m.UserId

    IF ( @@ROWCOUNT = 0 ) /*-- User ID not found--*/
       RETURN -1

    RETURN 0
END
GO

/*************************************************************/
/*************************************************************/

IF (EXISTS (SELECT name
              FROM sysobjects
             WHERE (name = N'aspnet_Membership_GetUserByEmail')
               AND (type = 'P')))
DROP PROCEDURE dbo.aspnet_Membership_GetUserByEmail
GO
CREATE PROCEDURE dbo.aspnet_Membership_GetUserByEmail
    @ApplicationName  nvarchar(256),
    @Email            nvarchar(256)
AS
BEGIN
    IF( @Email IS NULL )
        SELECT  u.UserName
        FROM    dbo.aspnet_Applications a, dbo.aspnet_Users u, dbo.aspnet_Membership m
        WHERE   LOWER(@ApplicationName) = a.LoweredApplicationName AND
                u.ApplicationId = a.ApplicationId    AND
                u.UserId = m.UserId AND
                m.LoweredEmail IS NULL
    ELSE
        SELECT  u.UserName
        FROM    dbo.aspnet_Applications a, dbo.aspnet_Users u, dbo.aspnet_Membership m
        WHERE   LOWER(@ApplicationName) = a.LoweredApplicationName AND
                u.ApplicationId = a.ApplicationId    AND
                u.UserId = m.UserId AND
                LOWER(@Email) = m.LoweredEmail

    IF (@@rowcount = 0)
        RETURN(1)
    RETURN(0)
END
GO

/*************************************************************/
/*************************************************************/

IF ( EXISTS( SELECT name
             FROM sysobjects
             WHERE ( name = N'aspnet_Membership_GetPasswordWithFormat' )
                   AND ( type = 'P' ) ) )
DROP PROCEDURE dbo.aspnet_Membership_GetPasswordWithFormat
GO
CREATE PROCEDURE dbo.aspnet_Membership_GetPasswordWithFormat
    @ApplicationName                nvarchar(256),
    @UserName                       nvarchar(256),
    @UpdateLastLoginActivityDate    bit,
    @CurrentTimeUtc                 datetime
AS
BEGIN
    DECLARE @IsLockedOut                        bit
    DECLARE @UserId                             uniqueidentifier
    DECLARE @Password                           nvarchar(128)
    DECLARE @PasswordSalt                       nvarchar(128)
    DECLARE @PasswordFormat                     int
    DECLARE @FailedPasswordAttemptCount         int
    DECLARE @FailedPasswordAnswerAttemptCount   int
    DECLARE @IsApproved                         bit
    DECLARE @LastActivityDate                   datetime
    DECLARE @LastLoginDate                      datetime

    SELECT  @UserId          = NULL

    SELECT  @UserId = u.UserId, @IsLockedOut = m.IsLockedOut, @Password=Password, @PasswordFormat=PasswordFormat,
            @PasswordSalt=PasswordSalt, @FailedPasswordAttemptCount=FailedPasswordAttemptCount,
		    @FailedPasswordAnswerAttemptCount=FailedPasswordAnswerAttemptCount, @IsApproved=IsApproved,
            @LastActivityDate = LastActivityDate, @LastLoginDate = LastLoginDate
    FROM    dbo.aspnet_Applications a, dbo.aspnet_Users u, dbo.aspnet_Membership m
    WHERE   LOWER(@ApplicationName) = a.LoweredApplicationName AND
            u.ApplicationId = a.ApplicationId    AND
            u.UserId = m.UserId AND
            LOWER(@UserName) = u.LoweredUserName

    IF (@UserId IS NULL)
        RETURN 1

    IF (@IsLockedOut = 1)
        RETURN 99

    SELECT   @Password, @PasswordFormat, @PasswordSalt, @FailedPasswordAttemptCount,
             @FailedPasswordAnswerAttemptCount, @IsApproved, @LastLoginDate, @LastActivityDate

    IF (@UpdateLastLoginActivityDate = 1 AND @IsApproved = 1)
    BEGIN
        UPDATE  dbo.aspnet_Membership
        SET     LastLoginDate = @CurrentTimeUtc
        WHERE   UserId = @UserId

        UPDATE  dbo.aspnet_Users
        SET     LastActivityDate = @CurrentTimeUtc
        WHERE   @UserId = UserId
    END


    RETURN 0
END
GO
/*************************************************************/
/*************************************************************/

IF ( EXISTS( SELECT name
             FROM sysobjects
             WHERE ( name = N'aspnet_Membership_UpdateUserInfo' )
                   AND ( type = 'P' ) ) )
DROP PROCEDURE dbo.aspnet_Membership_UpdateUserInfo
GO
CREATE PROCEDURE dbo.aspnet_Membership_UpdateUserInfo
    @ApplicationName                nvarchar(256),
    @UserName                       nvarchar(256),
    @IsPasswordCorrect              bit,
    @UpdateLastLoginActivityDate    bit,
    @MaxInvalidPasswordAttempts     int,
    @PasswordAttemptWindow          int,
    @CurrentTimeUtc                 datetime,
    @LastLoginDate                  datetime,
    @LastActivityDate               datetime
AS
BEGIN
    DECLARE @UserId                                 uniqueidentifier
    DECLARE @IsApproved                             bit
    DECLARE @IsLockedOut                            bit
    DECLARE @LastLockoutDate                        datetime
    DECLARE @FailedPasswordAttemptCount             int
    DECLARE @FailedPasswordAttemptWindowStart       datetime
    DECLARE @FailedPasswordAnswerAttemptCount       int
    DECLARE @FailedPasswordAnswerAttemptWindowStart datetime

    DECLARE @ErrorCode     int
    SET @ErrorCode = 0

    DECLARE @TranStarted   bit
    SET @TranStarted = 0

    IF( @@TRANCOUNT = 0 )
    BEGIN
	    BEGIN TRANSACTION
	    SET @TranStarted = 1
    END
    ELSE
    	SET @TranStarted = 0

    SELECT  @UserId = u.UserId,
            @IsApproved = m.IsApproved,
            @IsLockedOut = m.IsLockedOut,
            @LastLockoutDate = m.LastLockoutDate,
            @FailedPasswordAttemptCount = m.FailedPasswordAttemptCount,
            @FailedPasswordAttemptWindowStart = m.FailedPasswordAttemptWindowStart,
            @FailedPasswordAnswerAttemptCount = m.FailedPasswordAnswerAttemptCount,
            @FailedPasswordAnswerAttemptWindowStart = m.FailedPasswordAnswerAttemptWindowStart
    FROM    dbo.aspnet_Applications a, dbo.aspnet_Users u, dbo.aspnet_Membership m WITH ( UPDLOCK )
    WHERE   LOWER(@ApplicationName) = a.LoweredApplicationName AND
            u.ApplicationId = a.ApplicationId    AND
            u.UserId = m.UserId AND
            LOWER(@UserName) = u.LoweredUserName

    IF ( @@rowcount = 0 )
    BEGIN
        SET @ErrorCode = 1
        GOTO Cleanup
    END

    IF( @IsLockedOut = 1 )
    BEGIN
        GOTO Cleanup
    END

    IF( @IsPasswordCorrect = 0 )
    BEGIN
        IF( @CurrentTimeUtc > DATEADD( minute, @PasswordAttemptWindow, @FailedPasswordAttemptWindowStart ) )
        BEGIN
            SET @FailedPasswordAttemptWindowStart = @CurrentTimeUtc
            SET @FailedPasswordAttemptCount = 1
        END
        ELSE
        BEGIN
            SET @FailedPasswordAttemptWindowStart = @CurrentTimeUtc
            SET @FailedPasswordAttemptCount = @FailedPasswordAttemptCount + 1
        END

        BEGIN
            IF( @FailedPasswordAttemptCount >= @MaxInvalidPasswordAttempts )
            BEGIN
                SET @IsLockedOut = 1
                SET @LastLockoutDate = @CurrentTimeUtc
            END
        END
    END
    ELSE
    BEGIN
        IF( @FailedPasswordAttemptCount > 0 OR @FailedPasswordAnswerAttemptCount > 0 )
        BEGIN
            SET @FailedPasswordAttemptCount = 0
            SET @FailedPasswordAttemptWindowStart = CONVERT( datetime, '17540101', 112 )
            SET @FailedPasswordAnswerAttemptCount = 0
            SET @FailedPasswordAnswerAttemptWindowStart = CONVERT( datetime, '17540101', 112 )
            SET @LastLockoutDate = CONVERT( datetime, '17540101', 112 )
        END
    END

    IF( @UpdateLastLoginActivityDate = 1 )
    BEGIN
        UPDATE  dbo.aspnet_Users
        SET     LastActivityDate = @LastActivityDate
        WHERE   @UserId = UserId

        IF( @@ERROR <> 0 )
        BEGIN
            SET @ErrorCode = -1
            GOTO Cleanup
        END

        UPDATE  dbo.aspnet_Membership
        SET     LastLoginDate = @LastLoginDate
        WHERE   UserId = @UserId

        IF( @@ERROR <> 0 )
        BEGIN
            SET @ErrorCode = -1
            GOTO Cleanup
        END
    END


    UPDATE dbo.aspnet_Membership
    SET IsLockedOut = @IsLockedOut, LastLockoutDate = @LastLockoutDate,
        FailedPasswordAttemptCount = @FailedPasswordAttemptCount,
        FailedPasswordAttemptWindowStart = @FailedPasswordAttemptWindowStart,
        FailedPasswordAnswerAttemptCount = @FailedPasswordAnswerAttemptCount,
        FailedPasswordAnswerAttemptWindowStart = @FailedPasswordAnswerAttemptWindowStart
    WHERE @UserId = UserId

    IF( @@ERROR <> 0 )
    BEGIN
        SET @ErrorCode = -1
        GOTO Cleanup
    END

    IF( @TranStarted = 1 )
    BEGIN
	SET @TranStarted = 0
	COMMIT TRANSACTION
    END

    RETURN @ErrorCode

Cleanup:

    IF( @TranStarted = 1 )
    BEGIN
        SET @TranStarted = 0
    	ROLLBACK TRANSACTION
    END

    RETURN @ErrorCode

END
GO

/*************************************************************/
/*************************************************************/

IF (EXISTS (SELECT name
              FROM sysobjects
             WHERE (name = N'aspnet_Membership_GetPassword')
               AND (type = 'P')))
DROP PROCEDURE dbo.aspnet_Membership_GetPassword
GO
CREATE PROCEDURE dbo.aspnet_Membership_GetPassword
    @ApplicationName                nvarchar(256),
    @UserName                       nvarchar(256),
    @MaxInvalidPasswordAttempts     int,
    @PasswordAttemptWindow          int,
    @CurrentTimeUtc                 datetime,
    @PasswordAnswer                 nvarchar(128) = NULL
AS
BEGIN
    DECLARE @UserId                                 uniqueidentifier
    DECLARE @PasswordFormat                         int
    DECLARE @Password                               nvarchar(128)
    DECLARE @passAns                                nvarchar(128)
    DECLARE @IsLockedOut                            bit
    DECLARE @LastLockoutDate                        datetime
    DECLARE @FailedPasswordAttemptCount             int
    DECLARE @FailedPasswordAttemptWindowStart       datetime
    DECLARE @FailedPasswordAnswerAttemptCount       int
    DECLARE @FailedPasswordAnswerAttemptWindowStart datetime

    DECLARE @ErrorCode     int
    SET @ErrorCode = 0

    DECLARE @TranStarted   bit
    SET @TranStarted = 0

    IF( @@TRANCOUNT = 0 )
    BEGIN
	    BEGIN TRANSACTION
	    SET @TranStarted = 1
    END
    ELSE
    	SET @TranStarted = 0

    SELECT  @UserId = u.UserId,
            @Password = m.Password,
            @passAns = m.PasswordAnswer,
            @PasswordFormat = m.PasswordFormat,
            @IsLockedOut = m.IsLockedOut,
            @LastLockoutDate = m.LastLockoutDate,
            @FailedPasswordAttemptCount = m.FailedPasswordAttemptCount,
            @FailedPasswordAttemptWindowStart = m.FailedPasswordAttemptWindowStart,
            @FailedPasswordAnswerAttemptCount = m.FailedPasswordAnswerAttemptCount,
            @FailedPasswordAnswerAttemptWindowStart = m.FailedPasswordAnswerAttemptWindowStart
    FROM    dbo.aspnet_Applications a, dbo.aspnet_Users u, dbo.aspnet_Membership m WITH ( UPDLOCK )
    WHERE   LOWER(@ApplicationName) = a.LoweredApplicationName AND
            u.ApplicationId = a.ApplicationId    AND
            u.UserId = m.UserId AND
            LOWER(@UserName) = u.LoweredUserName

    IF ( @@rowcount = 0 )
    BEGIN
        SET @ErrorCode = 1
        GOTO Cleanup
    END

    IF( @IsLockedOut = 1 )
    BEGIN
        SET @ErrorCode = 99
        GOTO Cleanup
    END

    IF ( NOT( @PasswordAnswer IS NULL ) )
    BEGIN
        IF( ( @passAns IS NULL ) OR ( LOWER( @passAns ) <> LOWER( @PasswordAnswer ) ) )
        BEGIN
            IF( @CurrentTimeUtc > DATEADD( minute, @PasswordAttemptWindow, @FailedPasswordAnswerAttemptWindowStart ) )
            BEGIN
                SET @FailedPasswordAnswerAttemptWindowStart = @CurrentTimeUtc
                SET @FailedPasswordAnswerAttemptCount = 1
            END
            ELSE
            BEGIN
                SET @FailedPasswordAnswerAttemptCount = @FailedPasswordAnswerAttemptCount + 1
                SET @FailedPasswordAnswerAttemptWindowStart = @CurrentTimeUtc
            END

            BEGIN
                IF( @FailedPasswordAnswerAttemptCount >= @MaxInvalidPasswordAttempts )
                BEGIN
                    SET @IsLockedOut = 1
                    SET @LastLockoutDate = @CurrentTimeUtc
                END
            END

            SET @ErrorCode = 3
        END
        ELSE
        BEGIN
            IF( @FailedPasswordAnswerAttemptCount > 0 )
            BEGIN
                SET @FailedPasswordAnswerAttemptCount = 0
                SET @FailedPasswordAnswerAttemptWindowStart = CONVERT( datetime, '17540101', 112 )
            END
        END

        UPDATE dbo.aspnet_Membership
        SET IsLockedOut = @IsLockedOut, LastLockoutDate = @LastLockoutDate,
            FailedPasswordAttemptCount = @FailedPasswordAttemptCount,
            FailedPasswordAttemptWindowStart = @FailedPasswordAttemptWindowStart,
            FailedPasswordAnswerAttemptCount = @FailedPasswordAnswerAttemptCount,
            FailedPasswordAnswerAttemptWindowStart = @FailedPasswordAnswerAttemptWindowStart
        WHERE @UserId = UserId

        IF( @@ERROR <> 0 )
        BEGIN
            SET @ErrorCode = -1
            GOTO Cleanup
        END
    END

    IF( @TranStarted = 1 )
    BEGIN
	SET @TranStarted = 0
	COMMIT TRANSACTION
    END

    IF( @ErrorCode = 0 )
        SELECT @Password, @PasswordFormat

    RETURN @ErrorCode

Cleanup:

    IF( @TranStarted = 1 )
    BEGIN
        SET @TranStarted = 0
    	ROLLBACK TRANSACTION
    END

    RETURN @ErrorCode

END
GO

/*************************************************************/
/*************************************************************/

IF (EXISTS (SELECT name
              FROM sysobjects
             WHERE (name = N'aspnet_Membership_SetPassword')
               AND (type = 'P')))
DROP PROCEDURE dbo.aspnet_Membership_SetPassword
GO
CREATE PROCEDURE dbo.aspnet_Membership_SetPassword
    @ApplicationName  nvarchar(256),
    @UserName         nvarchar(256),
    @NewPassword      nvarchar(128),
    @PasswordSalt     nvarchar(128),
    @CurrentTimeUtc   datetime,
    @PasswordFormat   int = 0
AS
BEGIN
    DECLARE @UserId uniqueidentifier
    SELECT  @UserId = NULL
    SELECT  @UserId = u.UserId
    FROM    dbo.aspnet_Users u, dbo.aspnet_Applications a, dbo.aspnet_Membership m
    WHERE   LoweredUserName = LOWER(@UserName) AND
            u.ApplicationId = a.ApplicationId  AND
            LOWER(@ApplicationName) = a.LoweredApplicationName AND
            u.UserId = m.UserId

    IF (@UserId IS NULL)
        RETURN(1)

    UPDATE dbo.aspnet_Membership
    SET Password = @NewPassword, PasswordFormat = @PasswordFormat, PasswordSalt = @PasswordSalt,
        LastPasswordChangedDate = @CurrentTimeUtc
    WHERE @UserId = UserId
    RETURN(0)
END
GO

/*************************************************************/
/*************************************************************/

IF (EXISTS (SELECT name
              FROM sysobjects
             WHERE (name = N'aspnet_Membership_ResetPassword')
               AND (type = 'P')))
DROP PROCEDURE dbo.aspnet_Membership_ResetPassword
GO
CREATE PROCEDURE dbo.aspnet_Membership_ResetPassword
    @ApplicationName             nvarchar(256),
    @UserName                    nvarchar(256),
    @NewPassword                 nvarchar(128),
    @MaxInvalidPasswordAttempts  int,
    @PasswordAttemptWindow       int,
    @PasswordSalt                nvarchar(128),
    @CurrentTimeUtc              datetime,
    @PasswordFormat              int = 0,
    @PasswordAnswer              nvarchar(128) = NULL
AS
BEGIN
    DECLARE @IsLockedOut                            bit
    DECLARE @LastLockoutDate                        datetime
    DECLARE @FailedPasswordAttemptCount             int
    DECLARE @FailedPasswordAttemptWindowStart       datetime
    DECLARE @FailedPasswordAnswerAttemptCount       int
    DECLARE @FailedPasswordAnswerAttemptWindowStart datetime

    DECLARE @UserId                                 uniqueidentifier
    SET     @UserId = NULL

    DECLARE @ErrorCode     int
    SET @ErrorCode = 0

    DECLARE @TranStarted   bit
    SET @TranStarted = 0

    IF( @@TRANCOUNT = 0 )
    BEGIN
	    BEGIN TRANSACTION
	    SET @TranStarted = 1
    END
    ELSE
    	SET @TranStarted = 0

    SELECT  @UserId = u.UserId
    FROM    dbo.aspnet_Users u, dbo.aspnet_Applications a, dbo.aspnet_Membership m
    WHERE   LoweredUserName = LOWER(@UserName) AND
            u.ApplicationId = a.ApplicationId  AND
            LOWER(@ApplicationName) = a.LoweredApplicationName AND
            u.UserId = m.UserId

    IF ( @UserId IS NULL )
    BEGIN
        SET @ErrorCode = 1
        GOTO Cleanup
    END

    SELECT @IsLockedOut = IsLockedOut,
           @LastLockoutDate = LastLockoutDate,
           @FailedPasswordAttemptCount = FailedPasswordAttemptCount,
           @FailedPasswordAttemptWindowStart = FailedPasswordAttemptWindowStart,
           @FailedPasswordAnswerAttemptCount = FailedPasswordAnswerAttemptCount,
           @FailedPasswordAnswerAttemptWindowStart = FailedPasswordAnswerAttemptWindowStart
    FROM dbo.aspnet_Membership WITH ( UPDLOCK )
    WHERE @UserId = UserId

    IF( @IsLockedOut = 1 )
    BEGIN
        SET @ErrorCode = 99
        GOTO Cleanup
    END

    UPDATE dbo.aspnet_Membership
    SET    Password = @NewPassword,
           LastPasswordChangedDate = @CurrentTimeUtc,
           PasswordFormat = @PasswordFormat,
           PasswordSalt = @PasswordSalt
    WHERE  @UserId = UserId AND
           ( ( @PasswordAnswer IS NULL ) OR ( LOWER( PasswordAnswer ) = LOWER( @PasswordAnswer ) ) )

    IF ( @@ROWCOUNT = 0 )
        BEGIN
            IF( @CurrentTimeUtc > DATEADD( minute, @PasswordAttemptWindow, @FailedPasswordAnswerAttemptWindowStart ) )
            BEGIN
                SET @FailedPasswordAnswerAttemptWindowStart = @CurrentTimeUtc
                SET @FailedPasswordAnswerAttemptCount = 1
            END
            ELSE
            BEGIN
                SET @FailedPasswordAnswerAttemptWindowStart = @CurrentTimeUtc
                SET @FailedPasswordAnswerAttemptCount = @FailedPasswordAnswerAttemptCount + 1
            END

            BEGIN
                IF( @FailedPasswordAnswerAttemptCount >= @MaxInvalidPasswordAttempts )
                BEGIN
                    SET @IsLockedOut = 1
                    SET @LastLockoutDate = @CurrentTimeUtc
                END
            END

            SET @ErrorCode = 3
        END
    ELSE
        BEGIN
            IF( @FailedPasswordAnswerAttemptCount > 0 )
            BEGIN
                SET @FailedPasswordAnswerAttemptCount = 0
                SET @FailedPasswordAnswerAttemptWindowStart = CONVERT( datetime, '17540101', 112 )
            END
        END

    IF( NOT ( @PasswordAnswer IS NULL ) )
    BEGIN
        UPDATE dbo.aspnet_Membership
        SET IsLockedOut = @IsLockedOut, LastLockoutDate = @LastLockoutDate,
            FailedPasswordAttemptCount = @FailedPasswordAttemptCount,
            FailedPasswordAttemptWindowStart = @FailedPasswordAttemptWindowStart,
            FailedPasswordAnswerAttemptCount = @FailedPasswordAnswerAttemptCount,
            FailedPasswordAnswerAttemptWindowStart = @FailedPasswordAnswerAttemptWindowStart
        WHERE @UserId = UserId

        IF( @@ERROR <> 0 )
        BEGIN
            SET @ErrorCode = -1
            GOTO Cleanup
        END
    END

    IF( @TranStarted = 1 )
    BEGIN
	SET @TranStarted = 0
	COMMIT TRANSACTION
    END

    RETURN @ErrorCode

Cleanup:

    IF( @TranStarted = 1 )
    BEGIN
        SET @TranStarted = 0
    	ROLLBACK TRANSACTION
    END

    RETURN @ErrorCode

END
GO

/*************************************************************/
/*************************************************************/

IF (EXISTS (SELECT name
              FROM sysobjects
             WHERE (name = N'aspnet_Membership_UnlockUser')
               AND (type = 'P')))
DROP PROCEDURE dbo.aspnet_Membership_UnlockUser
GO
CREATE PROCEDURE dbo.aspnet_Membership_UnlockUser
    @ApplicationName                         nvarchar(256),
    @UserName                                nvarchar(256)
AS
BEGIN
    DECLARE @UserId uniqueidentifier
    SELECT  @UserId = NULL
    SELECT  @UserId = u.UserId
    FROM    dbo.aspnet_Users u, dbo.aspnet_Applications a, dbo.aspnet_Membership m
    WHERE   LoweredUserName = LOWER(@UserName) AND
            u.ApplicationId = a.ApplicationId  AND
            LOWER(@ApplicationName) = a.LoweredApplicationName AND
            u.UserId = m.UserId

    IF ( @UserId IS NULL )
        RETURN 1

    UPDATE dbo.aspnet_Membership
    SET IsLockedOut = 0,
        FailedPasswordAttemptCount = 0,
        FailedPasswordAttemptWindowStart = CONVERT( datetime, '17540101', 112 ),
        FailedPasswordAnswerAttemptCount = 0,
        FailedPasswordAnswerAttemptWindowStart = CONVERT( datetime, '17540101', 112 ),
        LastLockoutDate = CONVERT( datetime, '17540101', 112 )
    WHERE @UserId = UserId

    RETURN 0
END
GO

/*************************************************************/
/*************************************************************/

IF (EXISTS (SELECT name
              FROM sysobjects
             WHERE (name = N'aspnet_Membership_UpdateUser')
               AND (type = 'P')))
DROP PROCEDURE dbo.aspnet_Membership_UpdateUser
GO
CREATE PROCEDURE dbo.aspnet_Membership_UpdateUser
    @ApplicationName      nvarchar(256),
    @UserName             nvarchar(256),
    @Email                nvarchar(256),
    @Comment              ntext,
    @IsApproved           bit,
    @LastLoginDate        datetime,
    @LastActivityDate     datetime,
    @UniqueEmail          int,
    @CurrentTimeUtc       datetime
AS
BEGIN
    DECLARE @UserId uniqueidentifier
    DECLARE @ApplicationId uniqueidentifier
    SELECT  @UserId = NULL
    SELECT  @UserId = u.UserId, @ApplicationId = a.ApplicationId
    FROM    dbo.aspnet_Users u, dbo.aspnet_Applications a, dbo.aspnet_Membership m
    WHERE   LoweredUserName = LOWER(@UserName) AND
            u.ApplicationId = a.ApplicationId  AND
            LOWER(@ApplicationName) = a.LoweredApplicationName AND
            u.UserId = m.UserId

    IF (@UserId IS NULL)
        RETURN(1)

    IF (@UniqueEmail = 1)
    BEGIN
        IF (EXISTS (SELECT *
                    FROM  dbo.aspnet_Membership WITH (UPDLOCK, HOLDLOCK)
                    WHERE ApplicationId = @ApplicationId  AND @UserId <> UserId AND LoweredEmail = LOWER(@Email)))
        BEGIN
            RETURN(7)
        END
    END

    DECLARE @TranStarted   bit
    SET @TranStarted = 0

    IF( @@TRANCOUNT = 0 )
    BEGIN
	    BEGIN TRANSACTION
	    SET @TranStarted = 1
    END
    ELSE
	SET @TranStarted = 0

    UPDATE dbo.aspnet_Users WITH (ROWLOCK)
    SET
         LastActivityDate = @LastActivityDate
    WHERE
       @UserId = UserId

    IF( @@ERROR <> 0 )
        GOTO Cleanup

    UPDATE dbo.aspnet_Membership WITH (ROWLOCK)
    SET
         Email            = @Email,
         LoweredEmail     = LOWER(@Email),
         Comment          = @Comment,
         IsApproved       = @IsApproved,
         LastLoginDate    = @LastLoginDate
    WHERE
       @UserId = UserId

    IF( @@ERROR <> 0 )
        GOTO Cleanup

    IF( @TranStarted = 1 )
    BEGIN
	SET @TranStarted = 0
	COMMIT TRANSACTION
    END

    RETURN 0

Cleanup:

    IF( @TranStarted = 1 )
    BEGIN
        SET @TranStarted = 0
    	ROLLBACK TRANSACTION
    END

    RETURN -1
END
GO

IF (EXISTS (SELECT name
              FROM sysobjects
             WHERE (name = N'aspnet_Membership_ChangePasswordQuestionAndAnswer')
               AND (type = 'P')))
DROP PROCEDURE dbo.aspnet_Membership_ChangePasswordQuestionAndAnswer
GO
CREATE PROCEDURE dbo.aspnet_Membership_ChangePasswordQuestionAndAnswer
    @ApplicationName       nvarchar(256),
    @UserName              nvarchar(256),
    @NewPasswordQuestion   nvarchar(256),
    @NewPasswordAnswer     nvarchar(128)
AS
BEGIN
    DECLARE @UserId uniqueidentifier
    SELECT  @UserId = NULL
    SELECT  @UserId = u.UserId
    FROM    dbo.aspnet_Membership m, dbo.aspnet_Users u, dbo.aspnet_Applications a
    WHERE   LoweredUserName = LOWER(@UserName) AND
            u.ApplicationId = a.ApplicationId  AND
            LOWER(@ApplicationName) = a.LoweredApplicationName AND
            u.UserId = m.UserId
    IF (@UserId IS NULL)
    BEGIN
        RETURN(1)
    END

    UPDATE dbo.aspnet_Membership
    SET    PasswordQuestion = @NewPasswordQuestion, PasswordAnswer = @NewPasswordAnswer
    WHERE  UserId=@UserId
    RETURN(0)
END
GO


IF (EXISTS (SELECT name
              FROM sysobjects
             WHERE (name = N'aspnet_Membership_GetAllUsers')
               AND (type = 'P')))
DROP PROCEDURE dbo.aspnet_Membership_GetAllUsers
GO
CREATE PROCEDURE dbo.aspnet_Membership_GetAllUsers
    @ApplicationName       nvarchar(256),
    @PageIndex             int,
    @PageSize              int
AS
BEGIN
    DECLARE @ApplicationId uniqueidentifier
    SELECT  @ApplicationId = NULL
    SELECT  @ApplicationId = ApplicationId FROM dbo.aspnet_Applications WHERE LOWER(@ApplicationName) = LoweredApplicationName
    IF (@ApplicationId IS NULL)
        RETURN 0


    /*-- Set the page bounds--*/
    DECLARE @PageLowerBound int
    DECLARE @PageUpperBound int
    DECLARE @TotalRecords   int
    SET @PageLowerBound = @PageSize * @PageIndex
    SET @PageUpperBound = @PageSize - 1 + @PageLowerBound

    /*-- Create a temp table TO store the select results--*/
    CREATE TABLE #PageIndexForUsers
    (
        IndexId int IDENTITY (0, 1) NOT NULL,
        UserId uniqueidentifier
    )

    /*-- Insert into our temp table--*/
    INSERT INTO #PageIndexForUsers (UserId)
    SELECT u.UserId
    FROM   dbo.aspnet_Membership m, dbo.aspnet_Users u
    WHERE  u.ApplicationId = @ApplicationId AND u.UserId = m.UserId
    ORDER BY u.UserName

    SELECT @TotalRecords = @@ROWCOUNT

    SELECT u.UserName, m.Email, m.PasswordQuestion, m.Comment, m.IsApproved,
            m.CreateDate,
            m.LastLoginDate,
            u.LastActivityDate,
            m.LastPasswordChangedDate,
            u.UserId, m.IsLockedOut,
            m.LastLockoutDate
    FROM   dbo.aspnet_Membership m, dbo.aspnet_Users u, #PageIndexForUsers p
    WHERE  u.UserId = p.UserId AND u.UserId = m.UserId AND
           p.IndexId >= @PageLowerBound AND p.IndexId <= @PageUpperBound
    ORDER BY u.UserName
    RETURN @TotalRecords
END
GO

IF (EXISTS (SELECT name
              FROM sysobjects
             WHERE (name = N'aspnet_Membership_GetNumberOfUsersOnline')
               AND (type = 'P')))
DROP PROCEDURE dbo.aspnet_Membership_GetNumberOfUsersOnline
GO
CREATE PROCEDURE dbo.aspnet_Membership_GetNumberOfUsersOnline
    @ApplicationName            nvarchar(256),
    @MinutesSinceLastInActive   int,
    @CurrentTimeUtc             datetime
AS
BEGIN
    DECLARE @DateActive datetime
    SELECT  @DateActive = DATEADD(minute,  -(@MinutesSinceLastInActive), @CurrentTimeUtc)

    DECLARE @NumOnline int
    SELECT  @NumOnline = COUNT(*)
    FROM    dbo.aspnet_Users u(NOLOCK),
            dbo.aspnet_Applications a(NOLOCK),
            dbo.aspnet_Membership m(NOLOCK)
    WHERE   u.ApplicationId = a.ApplicationId                  AND
            LastActivityDate > @DateActive                     AND
            a.LoweredApplicationName = LOWER(@ApplicationName) AND
            u.UserId = m.UserId
    RETURN(@NumOnline)
END
GO


IF (EXISTS (SELECT name
              FROM sysobjects
             WHERE (name = N'aspnet_Membership_FindUsersByName')
               AND (type = 'P')))
DROP PROCEDURE dbo.aspnet_Membership_FindUsersByName
GO
CREATE PROCEDURE dbo.aspnet_Membership_FindUsersByName
    @ApplicationName       nvarchar(256),
    @UserNameToMatch       nvarchar(256),
    @PageIndex             int,
    @PageSize              int
AS
BEGIN
    DECLARE @ApplicationId uniqueidentifier
    SELECT  @ApplicationId = NULL
    SELECT  @ApplicationId = ApplicationId FROM dbo.aspnet_Applications WHERE LOWER(@ApplicationName) = LoweredApplicationName
    IF (@ApplicationId IS NULL)
        RETURN 0

    /*-- Set the page bounds--*/
    DECLARE @PageLowerBound int
    DECLARE @PageUpperBound int
    DECLARE @TotalRecords   int
    SET @PageLowerBound = @PageSize * @PageIndex
    SET @PageUpperBound = @PageSize - 1 + @PageLowerBound

    /*-- Create a temp table TO store the select results--*/
    CREATE TABLE #PageIndexForUsers
    (
        IndexId int IDENTITY (0, 1) NOT NULL,
        UserId uniqueidentifier
    )

    /*-- Insert into our temp table--*/
    INSERT INTO #PageIndexForUsers (UserId)
        SELECT u.UserId
        FROM   dbo.aspnet_Users u, dbo.aspnet_Membership m
        WHERE  u.ApplicationId = @ApplicationId AND m.UserId = u.UserId AND u.LoweredUserName LIKE LOWER(@UserNameToMatch)
        ORDER BY u.UserName


    SELECT  u.UserName, m.Email, m.PasswordQuestion, m.Comment, m.IsApproved,
            m.CreateDate,
            m.LastLoginDate,
            u.LastActivityDate,
            m.LastPasswordChangedDate,
            u.UserId, m.IsLockedOut,
            m.LastLockoutDate
    FROM   dbo.aspnet_Membership m, dbo.aspnet_Users u, #PageIndexForUsers p
    WHERE  u.UserId = p.UserId AND u.UserId = m.UserId AND
           p.IndexId >= @PageLowerBound AND p.IndexId <= @PageUpperBound
    ORDER BY u.UserName

    SELECT  @TotalRecords = COUNT(*)
    FROM    #PageIndexForUsers
    RETURN @TotalRecords
END
GO
/*************************************************************/
/*************************************************************/
IF (EXISTS (SELECT name
              FROM sysobjects
             WHERE (name = N'aspnet_Membership_FindUsersByEmail')
               AND (type = 'P')))
DROP PROCEDURE dbo.aspnet_Membership_FindUsersByEmail
GO
CREATE PROCEDURE dbo.aspnet_Membership_FindUsersByEmail
    @ApplicationName       nvarchar(256),
    @EmailToMatch          nvarchar(256),
    @PageIndex             int,
    @PageSize              int
AS
BEGIN
    DECLARE @ApplicationId uniqueidentifier
    SELECT  @ApplicationId = NULL
    SELECT  @ApplicationId = ApplicationId FROM dbo.aspnet_Applications WHERE LOWER(@ApplicationName) = LoweredApplicationName
    IF (@ApplicationId IS NULL)
        RETURN 0

    /*-- Set the page bounds--*/
    DECLARE @PageLowerBound int
    DECLARE @PageUpperBound int
    DECLARE @TotalRecords   int
    SET @PageLowerBound = @PageSize * @PageIndex
    SET @PageUpperBound = @PageSize - 1 + @PageLowerBound

    /*-- Create a temp table TO store the select results--*/
    CREATE TABLE #PageIndexForUsers
    (
        IndexId int IDENTITY (0, 1) NOT NULL,
        UserId uniqueidentifier
    )

    /*-- Insert into our temp table--*/
    IF( @EmailToMatch IS NULL )
        INSERT INTO #PageIndexForUsers (UserId)
            SELECT u.UserId
            FROM   dbo.aspnet_Users u, dbo.aspnet_Membership m
            WHERE  u.ApplicationId = @ApplicationId AND m.UserId = u.UserId AND m.Email IS NULL
            ORDER BY m.LoweredEmail
    ELSE
        INSERT INTO #PageIndexForUsers (UserId)
            SELECT u.UserId
            FROM   dbo.aspnet_Users u, dbo.aspnet_Membership m
            WHERE  u.ApplicationId = @ApplicationId AND m.UserId = u.UserId AND m.LoweredEmail LIKE LOWER(@EmailToMatch)
            ORDER BY m.LoweredEmail

    SELECT  u.UserName, m.Email, m.PasswordQuestion, m.Comment, m.IsApproved,
            m.CreateDate,
            m.LastLoginDate,
            u.LastActivityDate,
            m.LastPasswordChangedDate,
            u.UserId, m.IsLockedOut,
            m.LastLockoutDate
    FROM   dbo.aspnet_Membership m, dbo.aspnet_Users u, #PageIndexForUsers p
    WHERE  u.UserId = p.UserId AND u.UserId = m.UserId AND
           p.IndexId >= @PageLowerBound AND p.IndexId <= @PageUpperBound
    ORDER BY m.LoweredEmail

    SELECT  @TotalRecords = COUNT(*)
    FROM    #PageIndexForUsers
    RETURN @TotalRecords
END
GO

IF (NOT EXISTS (SELECT name
                FROM sysobjects
                WHERE (name = N'vw_aspnet_MembershipUsers')
                  AND (type = 'V')))
BEGIN
  PRINT 'Creating the vw_aspnet_MembershipUsers view...'
  EXEC('
  CREATE VIEW [dbo].[vw_aspnet_MembershipUsers]
  AS SELECT [dbo].[aspnet_Membership].[UserId],
            [dbo].[aspnet_Membership].[PasswordFormat],
            [dbo].[aspnet_Membership].[MobilePIN],
            [dbo].[aspnet_Membership].[Email],
            [dbo].[aspnet_Membership].[LoweredEmail],
            [dbo].[aspnet_Membership].[PasswordQuestion],
            [dbo].[aspnet_Membership].[PasswordAnswer],
            [dbo].[aspnet_Membership].[IsApproved],
            [dbo].[aspnet_Membership].[IsLockedOut],
            [dbo].[aspnet_Membership].[CreateDate],
            [dbo].[aspnet_Membership].[LastLoginDate],
            [dbo].[aspnet_Membership].[LastPasswordChangedDate],
            [dbo].[aspnet_Membership].[LastLockoutDate],
            [dbo].[aspnet_Membership].[FailedPasswordAttemptCount],
            [dbo].[aspnet_Membership].[FailedPasswordAttemptWindowStart],
            [dbo].[aspnet_Membership].[FailedPasswordAnswerAttemptCount],
            [dbo].[aspnet_Membership].[FailedPasswordAnswerAttemptWindowStart],
            [dbo].[aspnet_Membership].[Comment],
            [dbo].[aspnet_Users].[ApplicationId],
            [dbo].[aspnet_Users].[UserName],
            [dbo].[aspnet_Users].[MobileAlias],
            [dbo].[aspnet_Users].[IsAnonymous],
            [dbo].[aspnet_Users].[LastActivityDate]
  FROM [dbo].[aspnet_Membership] INNER JOIN [dbo].[aspnet_Users]
      ON [dbo].[aspnet_Membership].[UserId] = [dbo].[aspnet_Users].[UserId]
  ')
END
GO

/*--Create Membership schema version--*/

DECLARE @command nvarchar(4000)
SET @command = 'GRANT EXECUTE ON [dbo].aspnet_RegisterSchemaVersion TO ' + QUOTENAME(user)
EXECUTE (@command)
GO

EXEC [dbo].aspnet_RegisterSchemaVersion N'Membership', N'1', 1, 1
GO

/*--Create Membership roles--*/

IF ( NOT EXISTS ( SELECT name
                  FROM sysusers
                  WHERE issqlrole = 1
                  AND name = N'aspnet_Membership_FullAccess'  ) )
EXEC sp_addrole N'aspnet_Membership_FullAccess'

IF ( NOT EXISTS ( SELECT name
                  FROM sysusers
                  WHERE issqlrole = 1
                  AND name = N'aspnet_Membership_BasicAccess'  ) )
EXEC sp_addrole N'aspnet_Membership_BasicAccess'

IF ( NOT EXISTS ( SELECT name
                  FROM sysusers
                  WHERE issqlrole = 1
                  AND name = N'aspnet_Membership_ReportingAccess'  ) )
EXEC sp_addrole N'aspnet_Membership_ReportingAccess'
GO

EXEC sp_addrolemember N'aspnet_Membership_BasicAccess', N'aspnet_Membership_FullAccess'
EXEC sp_addrolemember N'aspnet_Membership_ReportingAccess', N'aspnet_Membership_FullAccess'
GO


/*Stored Procedure rights for BasicAcess*/

GRANT EXECUTE ON dbo.aspnet_Membership_GetUserByUserId TO aspnet_Membership_BasicAccess
GRANT EXECUTE ON dbo.aspnet_Membership_GetUserByName TO aspnet_Membership_BasicAccess
GRANT EXECUTE ON dbo.aspnet_Membership_GetUserByEmail TO aspnet_Membership_BasicAccess
GRANT EXECUTE ON dbo.aspnet_Membership_GetPassword TO aspnet_Membership_BasicAccess
GRANT EXECUTE ON dbo.aspnet_Membership_GetPasswordWithFormat TO aspnet_Membership_BasicAccess
GRANT EXECUTE ON dbo.aspnet_Membership_UpdateUserInfo TO aspnet_Membership_BasicAccess
GRANT EXECUTE ON dbo.aspnet_Membership_GetNumberOfUsersOnline TO aspnet_Membership_BasicAccess
GRANT EXECUTE ON dbo.aspnet_CheckSchemaVersion TO aspnet_Membership_BasicAccess
GRANT EXECUTE ON dbo.aspnet_RegisterSchemaVersion TO aspnet_Membership_BasicAccess
GRANT EXECUTE ON dbo.aspnet_UnRegisterSchemaVersion TO aspnet_Membership_BasicAccess


/*--Stored Procedure rights for ReportingAccess--*/
GRANT EXECUTE ON dbo.aspnet_Membership_GetUserByUserId TO aspnet_Membership_ReportingAccess
GRANT EXECUTE ON dbo.aspnet_Membership_GetUserByName TO aspnet_Membership_ReportingAccess
GRANT EXECUTE ON dbo.aspnet_Membership_GetUserByEmail TO aspnet_Membership_ReportingAccess
GRANT EXECUTE ON dbo.aspnet_Membership_GetAllUsers TO aspnet_Membership_ReportingAccess
GRANT EXECUTE ON dbo.aspnet_Membership_GetNumberOfUsersOnline TO aspnet_Membership_ReportingAccess
GRANT EXECUTE ON dbo.aspnet_Membership_FindUsersByName TO aspnet_Membership_ReportingAccess
GRANT EXECUTE ON dbo.aspnet_Membership_FindUsersByEmail TO aspnet_Membership_ReportingAccess
GRANT EXECUTE ON dbo.aspnet_CheckSchemaVersion TO aspnet_Membership_ReportingAccess
GRANT EXECUTE ON dbo.aspnet_RegisterSchemaVersion TO aspnet_Membership_ReportingAccess
GRANT EXECUTE ON dbo.aspnet_UnRegisterSchemaVersion TO aspnet_Membership_ReportingAccess


/*--Additional stored procedure rights for FullAccess--*/

GRANT EXECUTE ON dbo.aspnet_Users_DeleteUser TO aspnet_Membership_FullAccess

GRANT EXECUTE ON dbo.aspnet_Membership_CreateUser TO aspnet_Membership_FullAccess
GRANT EXECUTE ON dbo.aspnet_Membership_SetPassword TO aspnet_Membership_FullAccess
GRANT EXECUTE ON dbo.aspnet_Membership_ResetPassword TO aspnet_Membership_FullAccess
GRANT EXECUTE ON dbo.aspnet_Membership_UpdateUser TO aspnet_Membership_FullAccess
GRANT EXECUTE ON dbo.aspnet_Membership_ChangePasswordQuestionAndAnswer TO aspnet_Membership_FullAccess
GRANT EXECUTE ON dbo.aspnet_Membership_UnlockUser TO aspnet_Membership_FullAccess


/*--View rights--*/

GRANT SELECT ON dbo.vw_aspnet_Applications TO aspnet_Membership_ReportingAccess
GRANT SELECT ON dbo.vw_aspnet_Users TO aspnet_Membership_ReportingAccess

GRANT SELECT ON dbo.vw_aspnet_MembershipUsers TO aspnet_Membership_ReportingAccess


DECLARE @command nvarchar(4000)
SET @command = 'REVOKE EXECUTE ON [dbo].aspnet_RegisterSchemaVersion FROM ' + QUOTENAME(user)
EXECUTE (@command)
GO

/**********************************************************************/
/* InstallProfile.SQL                                         */
/*                                                                    */
/* Installs the tables, triggers and stored procedures necessary for  */
/* supporting the aspnet feature of ASP.Net                           */
/*                                                                    */
/* InstallCommon.sql must be run before running this file.            */
/*
** Copyright Microsoft, Inc. 2002
** All Rights Reserved.
*/
/**********************************************************************/
/*
PRINT '------------------------------------------------'
PRINT 'Starting execution of InstallProfile.SQL'
PRINT '------------------------------------------------'
*/

SET QUOTED_IDENTIFIER OFF -- We don't use quoted identifiers
SET ANSI_NULLS ON         -- We don't want (NULL = NULL) == TRUE
GO
SET ANSI_PADDING ON
GO
SET ANSI_NULL_DFLT_ON ON
GO

/*************************************************************/
/*************************************************************/
/*************************************************************/
/*************************************************************/
/*************************************************************/

DECLARE @dbname nvarchar(128)

SET @dbname = N'PlaceholderForDbName'

IF (NOT EXISTS (SELECT name
                FROM master.dbo.sysdatabases
                WHERE ('[' + name + ']' = @dbname OR name = @dbname)))
BEGIN
  RAISERROR('The database ''%s'' cannot be found. Please run InstallCommon.sql first.', 18, 1, @dbname)
END
GO

USE [PlaceholderForDbName]
GO

IF (NOT EXISTS (SELECT name
                FROM sysobjects
                WHERE (name = N'aspnet_Applications')
                  AND (type = 'U')))
BEGIN
  RAISERROR('The table ''aspnet_Applications'' cannot be found. Please use aspnet_regsql.exe for installing ASP.NET application services.', 18, 1)
END

IF (NOT EXISTS (SELECT name
                FROM sysobjects
                WHERE (name = N'aspnet_Users')
                  AND (type = 'U')))
BEGIN
  RAISERROR('The table ''aspnet_Users'' cannot be found. Please use aspnet_regsql.exe for installing ASP.NET application services.', 18, 1)
END

IF (NOT EXISTS (SELECT name
              FROM sysobjects
             WHERE (name = N'aspnet_Applications_CreateApplication')
               AND (type = 'P')))
BEGIN
  RAISERROR('The stored procedure ''aspnet_Applications_CreateApplication'' cannot be found. Please use aspnet_regsql.exe for installing ASP.NET application services.', 18, 1)
END

IF (NOT EXISTS (SELECT name
              FROM sysobjects
             WHERE (name = N'aspnet_Users_CreateUser')
               AND (type = 'P')))
BEGIN
  RAISERROR('The stored procedure ''aspnet_Users_CreateUser'' cannot be found. Please use aspnet_regsql.exe for installing ASP.NET application services.', 18, 1)
END

IF (NOT EXISTS (SELECT name
              FROM sysobjects
             WHERE (name = N'aspnet_Users_DeleteUser')
               AND (type = 'P')))
BEGIN
  RAISERROR('The stored procedure ''aspnet_Users_DeleteUser'' cannot be found. Please use aspnet_regsql.exe for installing ASP.NET application services.', 18, 1)
END

/*************************************************************/
/*************************************************************/
/*************************************************************/
/*************************************************************/
/*************************************************************/

IF (NOT EXISTS (SELECT name
                FROM sysobjects
                WHERE (name = N'aspnet_Profile')
                  AND (type = 'U')))
BEGIN
  PRINT 'Creating the aspnet_Profile table...'
  CREATE TABLE dbo.aspnet_Profile (
        UserId                   uniqueidentifier   PRIMARY KEY FOREIGN KEY REFERENCES dbo.aspnet_Users(UserId),
        PropertyNames            ntext NOT NULL,
        PropertyValuesString     ntext NOT NULL,
        PropertyValuesBinary     image NOT NULL,
        LastUpdatedDate          datetime NOT NULL)
END

/*************************************************************/
/*************************************************************/
/*************************************************************/
/*************************************************************/

IF (EXISTS (SELECT name
              FROM sysobjects
             WHERE (name = N'aspnet_Profile_GetProperties')
               AND (type = 'P')))
DROP PROCEDURE dbo.aspnet_Profile_GetProperties
GO

CREATE PROCEDURE dbo.aspnet_Profile_GetProperties
    @ApplicationName      nvarchar(256),
    @UserName             nvarchar(256),
    @CurrentTimeUtc       datetime
AS
BEGIN
    DECLARE @ApplicationId uniqueidentifier
    SELECT  @ApplicationId = NULL
    SELECT  @ApplicationId = ApplicationId FROM dbo.aspnet_Applications WHERE LOWER(@ApplicationName) = LoweredApplicationName
    IF (@ApplicationId IS NULL)
        RETURN

    DECLARE @UserId uniqueidentifier
    SELECT  @UserId = NULL

    SELECT @UserId = UserId
    FROM   dbo.aspnet_Users
    WHERE  ApplicationId = @ApplicationId AND LoweredUserName = LOWER(@UserName)

    IF (@UserId IS NULL)
        RETURN
    SELECT TOP 1 PropertyNames, PropertyValuesString, PropertyValuesBinary
    FROM         dbo.aspnet_Profile
    WHERE        UserId = @UserId

    IF (@@ROWCOUNT > 0)
    BEGIN
        UPDATE dbo.aspnet_Users
        SET    LastActivityDate=@CurrentTimeUtc
        WHERE  UserId = @UserId
    END
END
GO

/*************************************************************/
/*************************************************************/

IF (EXISTS (SELECT name
              FROM sysobjects
             WHERE (name = N'aspnet_Profile_SetProperties')
               AND (type = 'P')))
DROP PROCEDURE dbo.aspnet_Profile_SetProperties
GO

CREATE PROCEDURE dbo.aspnet_Profile_SetProperties
    @ApplicationName        nvarchar(256),
    @PropertyNames          ntext,
    @PropertyValuesString   ntext,
    @PropertyValuesBinary   image,
    @UserName               nvarchar(256),
    @IsUserAnonymous        bit,
    @CurrentTimeUtc         datetime
AS
BEGIN
    DECLARE @ApplicationId uniqueidentifier
    SELECT  @ApplicationId = NULL

    DECLARE @ErrorCode     int
    SET @ErrorCode = 0

    DECLARE @TranStarted   bit
    SET @TranStarted = 0

    IF( @@TRANCOUNT = 0 )
    BEGIN
       BEGIN TRANSACTION
       SET @TranStarted = 1
    END
    ELSE
    	SET @TranStarted = 0

    EXEC dbo.aspnet_Applications_CreateApplication @ApplicationName, @ApplicationId OUTPUT

    IF( @@ERROR <> 0 )
    BEGIN
        SET @ErrorCode = -1
        GOTO Cleanup
    END

    DECLARE @UserId uniqueidentifier
    DECLARE @LastActivityDate datetime
    SELECT  @UserId = NULL
    SELECT  @LastActivityDate = @CurrentTimeUtc

    SELECT @UserId = UserId
    FROM   dbo.aspnet_Users
    WHERE  ApplicationId = @ApplicationId AND LoweredUserName = LOWER(@UserName)
    IF (@UserId IS NULL)
        EXEC dbo.aspnet_Users_CreateUser @ApplicationId, @UserName, @IsUserAnonymous, @LastActivityDate, @UserId OUTPUT

    IF( @@ERROR <> 0 )
    BEGIN
        SET @ErrorCode = -1
        GOTO Cleanup
    END

    UPDATE dbo.aspnet_Users
    SET    LastActivityDate=@CurrentTimeUtc
    WHERE  UserId = @UserId

    IF( @@ERROR <> 0 )
    BEGIN
        SET @ErrorCode = -1
        GOTO Cleanup
    END

    IF (EXISTS( SELECT *
               FROM   dbo.aspnet_Profile
               WHERE  UserId = @UserId))
        UPDATE dbo.aspnet_Profile
        SET    PropertyNames=@PropertyNames, PropertyValuesString = @PropertyValuesString,
               PropertyValuesBinary = @PropertyValuesBinary, LastUpdatedDate=@CurrentTimeUtc
        WHERE  UserId = @UserId
    ELSE
        INSERT INTO dbo.aspnet_Profile(UserId, PropertyNames, PropertyValuesString, PropertyValuesBinary, LastUpdatedDate)
             VALUES (@UserId, @PropertyNames, @PropertyValuesString, @PropertyValuesBinary, @CurrentTimeUtc)

    IF( @@ERROR <> 0 )
    BEGIN
        SET @ErrorCode = -1
        GOTO Cleanup
    END

    IF( @TranStarted = 1 )
    BEGIN
    	SET @TranStarted = 0
    	COMMIT TRANSACTION
    END

    RETURN 0

Cleanup:

    IF( @TranStarted = 1 )
    BEGIN
        SET @TranStarted = 0
    	ROLLBACK TRANSACTION
    END

    RETURN @ErrorCode

END
GO
/*************************************************************/
/*************************************************************/
IF (EXISTS (SELECT name
              FROM sysobjects
             WHERE (name = N'aspnet_Profile_DeleteProfiles')
               AND (type = 'P')))
DROP PROCEDURE dbo.aspnet_Profile_DeleteProfiles
GO

CREATE PROCEDURE dbo.aspnet_Profile_DeleteProfiles
    @ApplicationName        nvarchar(256),
    @UserNames              nvarchar(4000)
AS
BEGIN
    DECLARE @UserName     nvarchar(256)
    DECLARE @CurrentPos   int
    DECLARE @NextPos      int
    DECLARE @NumDeleted   int
    DECLARE @DeletedUser  int
    DECLARE @TranStarted  bit
    DECLARE @ErrorCode    int

    SET @ErrorCode = 0
    SET @CurrentPos = 1
    SET @NumDeleted = 0
    SET @TranStarted = 0

    IF( @@TRANCOUNT = 0 )
    BEGIN
        BEGIN TRANSACTION
        SET @TranStarted = 1
    END
    ELSE
    	SET @TranStarted = 0

    WHILE (@CurrentPos <= LEN(@UserNames))
    BEGIN
        SELECT @NextPos = CHARINDEX(N',', @UserNames,  @CurrentPos)
        IF (@NextPos = 0 OR @NextPos IS NULL)
            SELECT @NextPos = LEN(@UserNames) + 1

        SELECT @UserName = SUBSTRING(@UserNames, @CurrentPos, @NextPos - @CurrentPos)
        SELECT @CurrentPos = @NextPos+1

        IF (LEN(@UserName) > 0)
        BEGIN
            SELECT @DeletedUser = 0
            EXEC dbo.aspnet_Users_DeleteUser @ApplicationName, @UserName, 4, @DeletedUser OUTPUT
            IF( @@ERROR <> 0 )
            BEGIN
                SET @ErrorCode = -1
                GOTO Cleanup
            END
            IF (@DeletedUser <> 0)
                SELECT @NumDeleted = @NumDeleted + 1
        END
    END
    SELECT @NumDeleted
    IF (@TranStarted = 1)
    BEGIN
    	SET @TranStarted = 0
    	COMMIT TRANSACTION
    END
    SET @TranStarted = 0

    RETURN 0

Cleanup:
    IF (@TranStarted = 1 )
    BEGIN
        SET @TranStarted = 0
    	ROLLBACK TRANSACTION
    END
    RETURN @ErrorCode
END
GO

/*************************************************************/
/*************************************************************/
IF (EXISTS (SELECT name
              FROM sysobjects
             WHERE (name = N'aspnet_Profile_DeleteInactiveProfiles')
               AND (type = 'P')))
DROP PROCEDURE dbo.aspnet_Profile_DeleteInactiveProfiles
GO

CREATE PROCEDURE dbo.aspnet_Profile_DeleteInactiveProfiles
    @ApplicationName        nvarchar(256),
    @ProfileAuthOptions     int,
    @InactiveSinceDate      datetime
AS
BEGIN
    DECLARE @ApplicationId uniqueidentifier
    SELECT  @ApplicationId = NULL
    SELECT  @ApplicationId = ApplicationId FROM aspnet_Applications WHERE LOWER(@ApplicationName) = LoweredApplicationName
    IF (@ApplicationId IS NULL)
    BEGIN
        SELECT  0
        RETURN
    END

    DELETE
    FROM    dbo.aspnet_Profile
    WHERE   UserId IN
            (   SELECT  UserId
                FROM    dbo.aspnet_Users u
                WHERE   ApplicationId = @ApplicationId
                        AND (LastActivityDate <= @InactiveSinceDate)
                        AND (
                                (@ProfileAuthOptions = 2)
                             OR (@ProfileAuthOptions = 0 AND IsAnonymous = 1)
                             OR (@ProfileAuthOptions = 1 AND IsAnonymous = 0)
                            )
            )

    SELECT  @@ROWCOUNT
END
GO

/*************************************************************/
/*************************************************************/
 IF (EXISTS (SELECT name
              FROM sysobjects
             WHERE (name = N'aspnet_Profile_GetNumberOfInactiveProfiles')
               AND (type = 'P')))
DROP PROCEDURE dbo.aspnet_Profile_GetNumberOfInactiveProfiles
GO

CREATE PROCEDURE dbo.aspnet_Profile_GetNumberOfInactiveProfiles
    @ApplicationName        nvarchar(256),
    @ProfileAuthOptions     int,
    @InactiveSinceDate      datetime
AS
BEGIN
    DECLARE @ApplicationId uniqueidentifier
    SELECT  @ApplicationId = NULL
    SELECT  @ApplicationId = ApplicationId FROM aspnet_Applications WHERE LOWER(@ApplicationName) = LoweredApplicationName
    IF (@ApplicationId IS NULL)
    BEGIN
        SELECT 0
        RETURN
    END

    SELECT  COUNT(*)
    FROM    dbo.aspnet_Users u, dbo.aspnet_Profile p
    WHERE   ApplicationId = @ApplicationId
        AND u.UserId = p.UserId
        AND (LastActivityDate <= @InactiveSinceDate)
        AND (
                (@ProfileAuthOptions = 2)
                OR (@ProfileAuthOptions = 0 AND IsAnonymous = 1)
                OR (@ProfileAuthOptions = 1 AND IsAnonymous = 0)
            )
END
GO


/*************************************************************/
/*************************************************************/
IF (EXISTS (SELECT name
              FROM sysobjects
             WHERE (name = N'aspnet_Profile_GetProfiles')
               AND (type = 'P')))
DROP PROCEDURE dbo.aspnet_Profile_GetProfiles
GO

CREATE PROCEDURE dbo.aspnet_Profile_GetProfiles
    @ApplicationName        nvarchar(256),
    @ProfileAuthOptions     int,
    @PageIndex              int,
    @PageSize               int,
    @UserNameToMatch        nvarchar(256) = NULL,
    @InactiveSinceDate      datetime      = NULL
AS
BEGIN
    DECLARE @ApplicationId uniqueidentifier
    SELECT  @ApplicationId = NULL
    SELECT  @ApplicationId = ApplicationId FROM aspnet_Applications WHERE LOWER(@ApplicationName) = LoweredApplicationName
    IF (@ApplicationId IS NULL)
        RETURN

    -- Set the page bounds
    DECLARE @PageLowerBound int
    DECLARE @PageUpperBound int
    DECLARE @TotalRecords   int
    SET @PageLowerBound = @PageSize * @PageIndex
    SET @PageUpperBound = @PageSize - 1 + @PageLowerBound

    -- Create a temp table TO store the select results
    CREATE TABLE #PageIndexForUsers
    (
        IndexId int IDENTITY (0, 1) NOT NULL,
        UserId uniqueidentifier
    )

    -- Insert into our temp table
    INSERT INTO #PageIndexForUsers (UserId)
        SELECT  u.UserId
        FROM    dbo.aspnet_Users u, dbo.aspnet_Profile p
        WHERE   ApplicationId = @ApplicationId
            AND u.UserId = p.UserId
            AND (@InactiveSinceDate IS NULL OR LastActivityDate <= @InactiveSinceDate)
            AND (     (@ProfileAuthOptions = 2)
                   OR (@ProfileAuthOptions = 0 AND IsAnonymous = 1)
                   OR (@ProfileAuthOptions = 1 AND IsAnonymous = 0)
                 )
            AND (@UserNameToMatch IS NULL OR LoweredUserName LIKE LOWER(@UserNameToMatch))
        ORDER BY UserName

    SELECT  u.UserName, u.IsAnonymous, u.LastActivityDate, p.LastUpdatedDate,
            DATALENGTH(p.PropertyNames) + DATALENGTH(p.PropertyValuesString) + DATALENGTH(p.PropertyValuesBinary)
    FROM    dbo.aspnet_Users u, dbo.aspnet_Profile p, #PageIndexForUsers i
    WHERE   u.UserId = p.UserId AND p.UserId = i.UserId AND i.IndexId >= @PageLowerBound AND i.IndexId <= @PageUpperBound

    SELECT COUNT(*)
    FROM   #PageIndexForUsers

    DROP TABLE #PageIndexForUsers
END
GO

/*************************************************************/
/*************************************************************/
IF (NOT EXISTS (SELECT name
                FROM sysobjects
                WHERE (name = N'vw_aspnet_Profiles')
                  AND (type = 'V')))
BEGIN
  PRINT 'Creating the vw_aspnet_Profiles view...'
  EXEC(N'
  CREATE VIEW [dbo].[vw_aspnet_Profiles]
  AS SELECT [dbo].[aspnet_Profile].[UserId], [dbo].[aspnet_Profile].[LastUpdatedDate],
      [DataSize]=  DATALENGTH([dbo].[aspnet_Profile].[PropertyNames])
                 + DATALENGTH([dbo].[aspnet_Profile].[PropertyValuesString])
                 + DATALENGTH([dbo].[aspnet_Profile].[PropertyValuesBinary])
  FROM [dbo].[aspnet_Profile]
  ')
END
GO

/*************************************************************/
/*************************************************************/

--
--Create Profile schema version
--

DECLARE @command nvarchar(4000)
SET @command = 'GRANT EXECUTE ON [dbo].aspnet_RegisterSchemaVersion TO ' + QUOTENAME(user)
EXECUTE (@command)
GO

EXEC [dbo].aspnet_RegisterSchemaVersion N'Profile', N'1', 1, 1
GO

/*************************************************************/
/*************************************************************/

--
--Create Profile roles
--

IF ( NOT EXISTS ( SELECT name
                  FROM sysusers
                  WHERE issqlrole = 1
                  AND name = N'aspnet_Profile_FullAccess' ) )
EXEC sp_addrole N'aspnet_Profile_FullAccess'

IF ( NOT EXISTS ( SELECT name
                  FROM sysusers
                  WHERE issqlrole = 1
                  AND name = N'aspnet_Profile_BasicAccess' ) )
EXEC sp_addrole N'aspnet_Profile_BasicAccess'

IF ( NOT EXISTS ( SELECT name
                  FROM sysusers
                  WHERE issqlrole = 1
                  AND name = N'aspnet_Profile_ReportingAccess' ) )
EXEC sp_addrole N'aspnet_Profile_ReportingAccess'
GO

EXEC sp_addrolemember N'aspnet_Profile_BasicAccess', N'aspnet_Profile_FullAccess'
EXEC sp_addrolemember N'aspnet_Profile_ReportingAccess', N'aspnet_Profile_FullAccess'
GO

--
--Stored Procedure rights for BasicAccess
--
GRANT EXECUTE ON dbo.aspnet_Profile_GetProperties TO aspnet_Profile_BasicAccess
GRANT EXECUTE ON dbo.aspnet_Profile_SetProperties TO aspnet_Profile_BasicAccess
GRANT EXECUTE ON dbo.aspnet_CheckSchemaVersion TO aspnet_Profile_BasicAccess
GRANT EXECUTE ON dbo.aspnet_RegisterSchemaVersion TO aspnet_Profile_BasicAccess
GRANT EXECUTE ON dbo.aspnet_UnRegisterSchemaVersion TO aspnet_Profile_BasicAccess

--
--Stored Procedure rights for ReportingAccess
--
GRANT EXECUTE ON dbo.aspnet_Profile_GetNumberOfInactiveProfiles TO aspnet_Profile_ReportingAccess
GRANT EXECUTE ON dbo.aspnet_Profile_GetProfiles TO aspnet_Profile_ReportingAccess
GRANT EXECUTE ON dbo.aspnet_CheckSchemaVersion TO aspnet_Profile_ReportingAccess
GRANT EXECUTE ON dbo.aspnet_RegisterSchemaVersion TO aspnet_Profile_ReportingAccess
GRANT EXECUTE ON dbo.aspnet_UnRegisterSchemaVersion TO aspnet_Profile_ReportingAccess

--
--Additional stored procedure rights for FullAccess
--
GRANT EXECUTE ON dbo.aspnet_Profile_DeleteProfiles TO aspnet_Profile_FullAccess
GRANT EXECUTE ON dbo.aspnet_Profile_DeleteInactiveProfiles TO aspnet_Profile_FullAccess

--
--View rights
--
GRANT SELECT ON dbo.vw_aspnet_Applications TO aspnet_Profile_ReportingAccess
GRANT SELECT ON dbo.vw_aspnet_Users TO aspnet_Profile_ReportingAccess

GRANT SELECT ON dbo.vw_aspnet_Profiles TO aspnet_Profile_ReportingAccess
GO

-------------------------------------------------------------------------
--- Version specific install
-------------------------------------------------------------------------

DECLARE @ver int
DECLARE @version nchar(100)
DECLARE @dot int
DECLARE @hyphen int
DECLARE @SqlToExec nchar(400)

SELECT @ver = 8
SELECT @version = @@Version
SELECT @hyphen  = CHARINDEX(N' - ', @version)
IF (NOT(@hyphen IS NULL) AND @hyphen > 0)
BEGIN
    SELECT @hyphen = @hyphen + 3
    SELECT @dot    = CHARINDEX(N'.', @version, @hyphen)
    IF (NOT(@dot IS NULL) AND @dot > @hyphen)
    BEGIN
        SELECT @version = SUBSTRING(@version, @hyphen, @dot - @hyphen)
        SELECT @ver     = CONVERT(int, @version)
    END
END

IF (@ver >= 8)
BEGIN
    EXEC sp_tableoption N'aspnet_Profile', 'text in row', 6000
END
GO
/*************************************************************/
/*************************************************************/
/*************************************************************/
/*************************************************************/


DECLARE @command nvarchar(4000)
SET @command = 'REVOKE EXECUTE ON [dbo].aspnet_RegisterSchemaVersion FROM ' + QUOTENAME(user)
EXECUTE (@command)
GO
/*
PRINT '-------------------------------------------------'
PRINT 'Completed execution of InstallProfile.SQL'
PRINT '-------------------------------------------------'
*/

/**********************************************************************/
/* InstallRoles.SQL                                                   */
/*                                                                    */
/* Installs the tables, triggers and stored procedures necessary for  */
/* supporting the aspnet feature of ASP.Net                           */
/*                                                                    */
/* InstallCommon.sql must be run before running this file.            */
/*
** Copyright Microsoft, Inc. 2002
** All Rights Reserved.
*/
/**********************************************************************/
/*
PRINT '--------------------------------------'
PRINT 'Starting execution of InstallRoles.SQL'
PRINT '--------------------------------------'
*/

SET QUOTED_IDENTIFIER OFF -- We don't use quoted identifiers
SET ANSI_NULLS ON         -- We don't want (NULL = NULL) == TRUE
GO
SET ANSI_PADDING ON
GO
SET ANSI_NULL_DFLT_ON ON
GO

/*************************************************************/
/*************************************************************/
/*************************************************************/
/*************************************************************/
/*************************************************************/

DECLARE @dbname nvarchar(128)

SET @dbname = N'PlaceholderForDbName'

IF (NOT EXISTS (SELECT name
                FROM master.dbo.sysdatabases
                WHERE ('[' + name + ']' = @dbname OR name = @dbname)))
BEGIN
  RAISERROR('The database ''%s'' cannot be found. Please run InstallCommon.sql first.', 18, 1, @dbname)
END
GO

USE [PlaceholderForDbName]
GO

IF (NOT EXISTS (SELECT name
                FROM sysobjects
                WHERE (name = N'aspnet_Applications')
                  AND (type = 'U')))
BEGIN
  RAISERROR('The table ''aspnet_Applications'' cannot be found. Please use aspnet_regsql.exe for installing ASP.NET application services.', 18, 1)
END

IF (NOT EXISTS (SELECT name
                FROM sysobjects
                WHERE (name = N'aspnet_Users')
                  AND (type = 'U')))
BEGIN
  RAISERROR('The table ''aspnet_Users'' cannot be found. Please use aspnet_regsql.exe for installing ASP.NET application services.', 18, 1)
END

IF (NOT EXISTS (SELECT name
              FROM sysobjects
             WHERE (name = N'aspnet_Applications_CreateApplication')
               AND (type = 'P')))
BEGIN
  RAISERROR('The stored procedure ''aspnet_Applications_CreateApplication'' cannot be found. Please use aspnet_regsql.exe for installing ASP.NET application services.', 18, 1)
END

IF (NOT EXISTS (SELECT name
              FROM sysobjects
             WHERE (name = N'aspnet_Users_CreateUser')
               AND (type = 'P')))
BEGIN
  RAISERROR('The stored procedure ''aspnet_Users_CreateUser'' cannot be found. Please use aspnet_regsql.exe for installing ASP.NET application services.', 18, 1)
END

IF (NOT EXISTS (SELECT name
              FROM sysobjects
             WHERE (name = N'aspnet_Users_DeleteUser')
               AND (type = 'P')))
BEGIN
  RAISERROR('The stored procedure ''aspnet_Users_DeleteUser'' cannot be found. Please use aspnet_regsql.exe for installing ASP.NET application services.', 18, 1)
END

/*************************************************************/
/*************************************************************/

IF (NOT EXISTS (SELECT name
                FROM sysobjects
                WHERE (name = N'aspnet_Roles')
                  AND (type = 'U')))
BEGIN
  PRINT 'Creating the aspnet_Roles table...'
  CREATE TABLE dbo.aspnet_Roles (
        ApplicationId    uniqueidentifier    NOT NULL FOREIGN KEY REFERENCES dbo.aspnet_Applications(ApplicationId),
        RoleId           uniqueidentifier    PRIMARY KEY  NONCLUSTERED DEFAULT NEWID(),
        RoleName         nvarchar(256)       NOT NULL,
        LoweredRoleName  nvarchar(256)       NOT NULL,
        Description      nvarchar(256)       )
 CREATE UNIQUE  CLUSTERED  INDEX aspnet_Roles_index1 ON  dbo.aspnet_Roles(ApplicationId, LoweredRoleName)
END
GO

/*************************************************************/
/*************************************************************/

IF (NOT EXISTS (SELECT name
                FROM sysobjects
                WHERE (name = N'aspnet_UsersInRoles')
                  AND (type = 'U')))
BEGIN
  PRINT 'Creating the aspnet_UsersInRoles table...'
  CREATE TABLE dbo.aspnet_UsersInRoles (
        UserId     uniqueidentifier NOT NULL PRIMARY KEY(UserId, RoleId) FOREIGN KEY REFERENCES dbo.aspnet_Users (UserId),
        RoleId     uniqueidentifier NOT NULL FOREIGN KEY REFERENCES dbo.aspnet_Roles (RoleId))

  CREATE INDEX aspnet_UsersInRoles_index ON  dbo.aspnet_UsersInRoles(RoleId)
END


/*************************************************************/
/*************************************************************/
/*************************************************************/
/*************************************************************/

IF (EXISTS (SELECT name
              FROM sysobjects
             WHERE (name = N'aspnet_UsersInRoles_IsUserInRole')
               AND (type = 'P')))
DROP PROCEDURE dbo.aspnet_UsersInRoles_IsUserInRole
GO

CREATE PROCEDURE dbo.aspnet_UsersInRoles_IsUserInRole
    @ApplicationName  nvarchar(256),
    @UserName         nvarchar(256),
    @RoleName         nvarchar(256)
AS
BEGIN
    DECLARE @ApplicationId uniqueidentifier
    SELECT  @ApplicationId = NULL
    SELECT  @ApplicationId = ApplicationId FROM aspnet_Applications WHERE LOWER(@ApplicationName) = LoweredApplicationName
    IF (@ApplicationId IS NULL)
        RETURN(2)
    DECLARE @UserId uniqueidentifier
    SELECT  @UserId = NULL
    DECLARE @RoleId uniqueidentifier
    SELECT  @RoleId = NULL

    SELECT  @UserId = UserId
    FROM    dbo.aspnet_Users
    WHERE   LoweredUserName = LOWER(@UserName) AND ApplicationId = @ApplicationId

    IF (@UserId IS NULL)
        RETURN(2)

    SELECT  @RoleId = RoleId
    FROM    dbo.aspnet_Roles
    WHERE   LoweredRoleName = LOWER(@RoleName) AND ApplicationId = @ApplicationId

    IF (@RoleId IS NULL)
        RETURN(3)

    IF (EXISTS( SELECT * FROM dbo.aspnet_UsersInRoles WHERE  UserId = @UserId AND RoleId = @RoleId))
        RETURN(1)
    ELSE
        RETURN(0)
END
GO

/*************************************************************/
/*************************************************************/

IF (EXISTS (SELECT name
              FROM sysobjects
             WHERE (name = N'aspnet_UsersInRoles_GetRolesForUser')
               AND (type = 'P')))
DROP PROCEDURE dbo.aspnet_UsersInRoles_GetRolesForUser
GO

CREATE PROCEDURE dbo.aspnet_UsersInRoles_GetRolesForUser
    @ApplicationName  nvarchar(256),
    @UserName         nvarchar(256)
AS
BEGIN
    DECLARE @ApplicationId uniqueidentifier
    SELECT  @ApplicationId = NULL
    SELECT  @ApplicationId = ApplicationId FROM aspnet_Applications WHERE LOWER(@ApplicationName) = LoweredApplicationName
    IF (@ApplicationId IS NULL)
        RETURN(1)
    DECLARE @UserId uniqueidentifier
    SELECT  @UserId = NULL

    SELECT  @UserId = UserId
    FROM    dbo.aspnet_Users
    WHERE   LoweredUserName = LOWER(@UserName) AND ApplicationId = @ApplicationId

    IF (@UserId IS NULL)
        RETURN(1)

    SELECT r.RoleName
    FROM   dbo.aspnet_Roles r, dbo.aspnet_UsersInRoles ur
    WHERE  r.RoleId = ur.RoleId AND r.ApplicationId = @ApplicationId AND ur.UserId = @UserId
    ORDER BY r.RoleName
    RETURN (0)
END
GO

/*************************************************************/
/*************************************************************/
IF (EXISTS (SELECT name
              FROM sysobjects
             WHERE (name = N'aspnet_Roles_CreateRole')
               AND (type = 'P')))
DROP PROCEDURE dbo.aspnet_Roles_CreateRole
GO
CREATE PROCEDURE dbo.aspnet_Roles_CreateRole
    @ApplicationName  nvarchar(256),
    @RoleName         nvarchar(256)
AS
BEGIN
    DECLARE @ApplicationId uniqueidentifier
    SELECT  @ApplicationId = NULL

    DECLARE @ErrorCode     int
    SET @ErrorCode = 0

    DECLARE @TranStarted   bit
    SET @TranStarted = 0

    IF( @@TRANCOUNT = 0 )
    BEGIN
        BEGIN TRANSACTION
        SET @TranStarted = 1
    END
    ELSE
        SET @TranStarted = 0

    EXEC dbo.aspnet_Applications_CreateApplication @ApplicationName, @ApplicationId OUTPUT

    IF( @@ERROR <> 0 )
    BEGIN
        SET @ErrorCode = -1
        GOTO Cleanup
    END

    IF (EXISTS(SELECT RoleId FROM dbo.aspnet_Roles WHERE LoweredRoleName = LOWER(@RoleName) AND ApplicationId = @ApplicationId))
    BEGIN
        SET @ErrorCode = 1
        GOTO Cleanup
    END

    INSERT INTO dbo.aspnet_Roles
                (ApplicationId, RoleName, LoweredRoleName)
         VALUES (@ApplicationId, @RoleName, LOWER(@RoleName))

    IF( @@ERROR <> 0 )
    BEGIN
        SET @ErrorCode = -1
        GOTO Cleanup
    END

    IF( @TranStarted = 1 )
    BEGIN
        SET @TranStarted = 0
        COMMIT TRANSACTION
    END

    RETURN(0)

Cleanup:

    IF( @TranStarted = 1 )
    BEGIN
        SET @TranStarted = 0
        ROLLBACK TRANSACTION
    END

    RETURN @ErrorCode

END
GO

/*************************************************************/
/*************************************************************/

IF (EXISTS (SELECT name
              FROM sysobjects
             WHERE (name = N'aspnet_Roles_DeleteRole')
               AND (type = 'P')))
DROP PROCEDURE dbo.aspnet_Roles_DeleteRole
GO

CREATE PROCEDURE dbo.aspnet_Roles_DeleteRole
    @ApplicationName            nvarchar(256),
    @RoleName                   nvarchar(256),
    @DeleteOnlyIfRoleIsEmpty    bit
AS
BEGIN
    DECLARE @ApplicationId uniqueidentifier
    SELECT  @ApplicationId = NULL
    SELECT  @ApplicationId = ApplicationId FROM aspnet_Applications WHERE LOWER(@ApplicationName) = LoweredApplicationName
    IF (@ApplicationId IS NULL)
        RETURN(1)

    DECLARE @ErrorCode     int
    SET @ErrorCode = 0

    DECLARE @TranStarted   bit
    SET @TranStarted = 0

    IF( @@TRANCOUNT = 0 )
    BEGIN
        BEGIN TRANSACTION
        SET @TranStarted = 1
    END
    ELSE
        SET @TranStarted = 0

    DECLARE @RoleId   uniqueidentifier
    SELECT  @RoleId = NULL
    SELECT  @RoleId = RoleId FROM dbo.aspnet_Roles WHERE LoweredRoleName = LOWER(@RoleName) AND ApplicationId = @ApplicationId

    IF (@RoleId IS NULL)
    BEGIN
        SELECT @ErrorCode = 1
        GOTO Cleanup
    END
    IF (@DeleteOnlyIfRoleIsEmpty <> 0)
    BEGIN
        IF (EXISTS (SELECT RoleId FROM dbo.aspnet_UsersInRoles  WHERE @RoleId = RoleId))
        BEGIN
            SELECT @ErrorCode = 2
            GOTO Cleanup
        END
    END


    DELETE FROM dbo.aspnet_UsersInRoles  WHERE @RoleId = RoleId

    IF( @@ERROR <> 0 )
    BEGIN
        SET @ErrorCode = -1
        GOTO Cleanup
    END

    DELETE FROM dbo.aspnet_Roles WHERE @RoleId = RoleId  AND ApplicationId = @ApplicationId

    IF( @@ERROR <> 0 )
    BEGIN
        SET @ErrorCode = -1
        GOTO Cleanup
    END

    IF( @TranStarted = 1 )
    BEGIN
        SET @TranStarted = 0
        COMMIT TRANSACTION
    END

    RETURN(0)

Cleanup:

    IF( @TranStarted = 1 )
    BEGIN
        SET @TranStarted = 0
        ROLLBACK TRANSACTION
    END

    RETURN @ErrorCode
END
GO

/*************************************************************/
/*************************************************************/

IF (EXISTS (SELECT name
              FROM sysobjects
             WHERE (name = N'aspnet_Roles_RoleExists')
               AND (type = 'P')))
DROP PROCEDURE dbo.aspnet_Roles_RoleExists
GO

CREATE PROCEDURE dbo.aspnet_Roles_RoleExists
    @ApplicationName  nvarchar(256),
    @RoleName         nvarchar(256)
AS
BEGIN
    DECLARE @ApplicationId uniqueidentifier
    SELECT  @ApplicationId = NULL
    SELECT  @ApplicationId = ApplicationId FROM aspnet_Applications WHERE LOWER(@ApplicationName) = LoweredApplicationName
    IF (@ApplicationId IS NULL)
        RETURN(0)
    IF (EXISTS (SELECT RoleName FROM dbo.aspnet_Roles WHERE LOWER(@RoleName) = LoweredRoleName AND ApplicationId = @ApplicationId ))
        RETURN(1)
    ELSE
        RETURN(0)
END
GO

/*************************************************************/
/*************************************************************/

IF (EXISTS (SELECT name
              FROM sysobjects
             WHERE (name = N'aspnet_UsersInRoles_AddUsersToRoles')
               AND (type = 'P')))
DROP PROCEDURE dbo.aspnet_UsersInRoles_AddUsersToRoles
GO
IF (EXISTS (SELECT name
              FROM sysobjects
             WHERE (name = N'aspnet_UsersInRoles_RemoveUsersFromRoles')
               AND (type = 'P')))
DROP PROCEDURE dbo.aspnet_UsersInRoles_RemoveUsersFromRoles
GO

DECLARE @ver            int
DECLARE @version        nchar(100)
DECLARE @dot            int
DECLARE @hyphen         int
DECLARE @SqlToExec      nchar(4000)

SELECT @ver = 7
SELECT @version = @@Version
SELECT @hyphen  = CHARINDEX(N' - ', @version)
IF (NOT(@hyphen IS NULL) AND @hyphen > 0)
BEGIN
    SELECT @hyphen = @hyphen + 3
    SELECT @dot    = CHARINDEX(N'.', @version, @hyphen)
    IF (NOT(@dot IS NULL) AND @dot > @hyphen)
    BEGIN
        SELECT @version = SUBSTRING(@version, @hyphen, @dot - @hyphen)
        SELECT @ver     = CONVERT(int, @version)
    END
END

IF (@ver > 7)
SELECT @SqlToExec = N'
CREATE PROCEDURE dbo.aspnet_UsersInRoles_AddUsersToRoles
	@ApplicationName  nvarchar(256),
	@UserNames		  nvarchar(4000),
	@RoleNames		  nvarchar(4000),
	@CurrentTimeUtc   datetime
AS
BEGIN
	DECLARE @AppId uniqueidentifier
	SELECT  @AppId = NULL
	SELECT  @AppId = ApplicationId FROM aspnet_Applications WHERE LOWER(@ApplicationName) = LoweredApplicationName
	IF (@AppId IS NULL)
		RETURN(2)
	DECLARE @TranStarted   bit
	SET @TranStarted = 0

	IF( @@TRANCOUNT = 0 )
	BEGIN
		BEGIN TRANSACTION
		SET @TranStarted = 1
	END

	DECLARE @tbNames	table(Name nvarchar(256) NOT NULL PRIMARY KEY)
	DECLARE @tbRoles	table(RoleId uniqueidentifier NOT NULL PRIMARY KEY)
	DECLARE @tbUsers	table(UserId uniqueidentifier NOT NULL PRIMARY KEY)
	DECLARE @Num		int
	DECLARE @Pos		int
	DECLARE @NextPos	int
	DECLARE @Name		nvarchar(256)

	SET @Num = 0
	SET @Pos = 1
	WHILE(@Pos <= LEN(@RoleNames))
	BEGIN
		SELECT @NextPos = CHARINDEX(N'','', @RoleNames,  @Pos)
		IF (@NextPos = 0 OR @NextPos IS NULL)
			SELECT @NextPos = LEN(@RoleNames) + 1
		SELECT @Name = RTRIM(LTRIM(SUBSTRING(@RoleNames, @Pos, @NextPos - @Pos)))
		SELECT @Pos = @NextPos+1

		INSERT INTO @tbNames VALUES (@Name)
		SET @Num = @Num + 1
	END

	INSERT INTO @tbRoles
	  SELECT RoleId
	  FROM   dbo.aspnet_Roles ar, @tbNames t
	  WHERE  LOWER(t.Name) = ar.LoweredRoleName AND ar.ApplicationId = @AppId

	IF (@@ROWCOUNT <> @Num)
	BEGIN
		SELECT TOP 1 Name
		FROM   @tbNames
		WHERE  LOWER(Name) NOT IN (SELECT ar.LoweredRoleName FROM dbo.aspnet_Roles ar,  @tbRoles r WHERE r.RoleId = ar.RoleId)
		IF( @TranStarted = 1 )
			ROLLBACK TRANSACTION
		RETURN(2)
	END

	DELETE FROM @tbNames WHERE 1=1
	SET @Num = 0
	SET @Pos = 1

	WHILE(@Pos <= LEN(@UserNames))
	BEGIN
		SELECT @NextPos = CHARINDEX(N'','', @UserNames,  @Pos)
		IF (@NextPos = 0 OR @NextPos IS NULL)
			SELECT @NextPos = LEN(@UserNames) + 1
		SELECT @Name = RTRIM(LTRIM(SUBSTRING(@UserNames, @Pos, @NextPos - @Pos)))
		SELECT @Pos = @NextPos+1

		INSERT INTO @tbNames VALUES (@Name)
		SET @Num = @Num + 1
	END

	INSERT INTO @tbUsers
	  SELECT UserId
	  FROM   dbo.aspnet_Users ar, @tbNames t
	  WHERE  LOWER(t.Name) = ar.LoweredUserName AND ar.ApplicationId = @AppId

	IF (@@ROWCOUNT <> @Num)
	BEGIN
		DELETE FROM @tbNames
		WHERE LOWER(Name) IN (SELECT LoweredUserName FROM dbo.aspnet_Users au,  @tbUsers u WHERE au.UserId = u.UserId)

		INSERT dbo.aspnet_Users (ApplicationId, UserId, UserName, LoweredUserName, IsAnonymous, LastActivityDate)
		  SELECT @AppId, NEWID(), Name, LOWER(Name), 0, @CurrentTimeUtc
		  FROM   @tbNames

		INSERT INTO @tbUsers
		  SELECT  UserId
		  FROM	dbo.aspnet_Users au, @tbNames t
		  WHERE   LOWER(t.Name) = au.LoweredUserName AND au.ApplicationId = @AppId
	END

	IF (EXISTS (SELECT * FROM dbo.aspnet_UsersInRoles ur, @tbUsers tu, @tbRoles tr WHERE tu.UserId = ur.UserId AND tr.RoleId = ur.RoleId))
	BEGIN
		SELECT TOP 1 UserName, RoleName
		FROM		 dbo.aspnet_UsersInRoles ur, @tbUsers tu, @tbRoles tr, aspnet_Users u, aspnet_Roles r
		WHERE		u.UserId = tu.UserId AND r.RoleId = tr.RoleId AND tu.UserId = ur.UserId AND tr.RoleId = ur.RoleId

		IF( @TranStarted = 1 )
			ROLLBACK TRANSACTION
		RETURN(3)
	END

	INSERT INTO dbo.aspnet_UsersInRoles (UserId, RoleId)
	SELECT UserId, RoleId
	FROM @tbUsers, @tbRoles

	IF( @TranStarted = 1 )
		COMMIT TRANSACTION
	RETURN(0)
END'
ELSE
SELECT @SqlToExec = N'
CREATE PROCEDURE dbo.aspnet_UsersInRoles_AddUsersToRoles
	@ApplicationName	nvarchar(256),
	@UserNames			nvarchar(4000),
	@RoleNames			nvarchar(4000),
	@CurrentTimeUtc		datetime
AS
BEGIN
	DECLARE @AppId uniqueidentifier
	SELECT  @AppId = NULL
	SELECT  @AppId = ApplicationId FROM aspnet_Applications WHERE LOWER(@ApplicationName) = LoweredApplicationName
	IF (@AppId IS NULL)
		RETURN(2)

	DECLARE @TranStarted   bit
	SET @TranStarted = 0
	IF( @@TRANCOUNT = 0 )
	BEGIN
		BEGIN TRANSACTION
		SET @TranStarted = 1
	END

	DECLARE @RoleId		uniqueidentifier
	DECLARE @UserId		uniqueidentifier
	DECLARE @UserName	nvarchar(256)
	DECLARE @RoleName	nvarchar(256)

	DECLARE @CurrentPosU	int
	DECLARE @NextPosU		int
	DECLARE @CurrentPosR	int
	DECLARE @NextPosR		int

	SELECT  @CurrentPosU = 1

	WHILE(@CurrentPosU <= LEN(@UserNames))
	BEGIN
		SELECT @NextPosU = CHARINDEX(N'','', @UserNames,  @CurrentPosU)
		IF (@NextPosU = 0 OR @NextPosU IS NULL)
			SELECT @NextPosU = LEN(@UserNames) + 1

		SELECT @UserName = SUBSTRING(@UserNames, @CurrentPosU, @NextPosU - @CurrentPosU)
		SELECT @CurrentPosU = @NextPosU+1

		SELECT @CurrentPosR = 1
		WHILE(@CurrentPosR <= LEN(@RoleNames))
		BEGIN
			SELECT @NextPosR = CHARINDEX(N'','', @RoleNames,  @CurrentPosR)
			IF (@NextPosR = 0 OR @NextPosR IS NULL)
				SELECT @NextPosR = LEN(@RoleNames) + 1
			SELECT @RoleName = SUBSTRING(@RoleNames, @CurrentPosR, @NextPosR - @CurrentPosR)
			SELECT @CurrentPosR = @NextPosR+1
			SELECT @RoleId = NULL
			SELECT @RoleId = RoleId FROM dbo.aspnet_Roles WHERE LoweredRoleName = LOWER(@RoleName) AND ApplicationId = @AppId
			IF (@RoleId IS NULL)
			BEGIN
				SELECT @RoleName
				IF( @TranStarted = 1 )
					ROLLBACK TRANSACTION
				RETURN(2)
			END

			SELECT @UserId = NULL
			SELECT @UserId = UserId FROM dbo.aspnet_Users WHERE LoweredUserName = LOWER(@UserName) AND ApplicationId = @AppId
			IF (@UserId IS NULL)
			BEGIN
				EXEC dbo.aspnet_Users_CreateUser @AppId, @UserName, 0, @CurrentTimeUtc, @UserId OUTPUT
			END

			IF (EXISTS(SELECT * FROM dbo.aspnet_UsersInRoles WHERE @UserId = UserId AND @RoleId = RoleId))
			BEGIN
				SELECT @UserName, @RoleName
				IF( @TranStarted = 1 )
					ROLLBACK TRANSACTION
				RETURN(3)
			END
			INSERT INTO dbo.aspnet_UsersInRoles (UserId, RoleId) VALUES(@UserId, @RoleId)
		END
	END
	IF( @TranStarted = 1 )
		COMMIT TRANSACTION
	RETURN(0)
END'

EXEC sp_executesql @SqlToExec

IF (@ver > 7)
SELECT @SqlToExec = N'
CREATE PROCEDURE dbo.aspnet_UsersInRoles_RemoveUsersFromRoles
	@ApplicationName  nvarchar(256),
	@UserNames		  nvarchar(4000),
	@RoleNames		  nvarchar(4000)
AS
BEGIN
	DECLARE @AppId uniqueidentifier
	SELECT  @AppId = NULL
	SELECT  @AppId = ApplicationId FROM aspnet_Applications WHERE LOWER(@ApplicationName) = LoweredApplicationName
	IF (@AppId IS NULL)
		RETURN(2)


	DECLARE @TranStarted   bit
	SET @TranStarted = 0

	IF( @@TRANCOUNT = 0 )
	BEGIN
		BEGIN TRANSACTION
		SET @TranStarted = 1
	END

	DECLARE @tbNames  table(Name nvarchar(256) NOT NULL PRIMARY KEY)
	DECLARE @tbRoles  table(RoleId uniqueidentifier NOT NULL PRIMARY KEY)
	DECLARE @tbUsers  table(UserId uniqueidentifier NOT NULL PRIMARY KEY)
	DECLARE @Num	  int
	DECLARE @Pos	  int
	DECLARE @NextPos  int
	DECLARE @Name	  nvarchar(256)
	DECLARE @CountAll int
	DECLARE @CountU	  int
	DECLARE @CountR	  int


	SET @Num = 0
	SET @Pos = 1
	WHILE(@Pos <= LEN(@RoleNames))
	BEGIN
		SELECT @NextPos = CHARINDEX(N'','', @RoleNames,  @Pos)
		IF (@NextPos = 0 OR @NextPos IS NULL)
			SELECT @NextPos = LEN(@RoleNames) + 1
		SELECT @Name = RTRIM(LTRIM(SUBSTRING(@RoleNames, @Pos, @NextPos - @Pos)))
		SELECT @Pos = @NextPos+1

		INSERT INTO @tbNames VALUES (@Name)
		SET @Num = @Num + 1
	END

	INSERT INTO @tbRoles
	  SELECT RoleId
	  FROM   dbo.aspnet_Roles ar, @tbNames t
	  WHERE  LOWER(t.Name) = ar.LoweredRoleName AND ar.ApplicationId = @AppId
	SELECT @CountR = @@ROWCOUNT

	IF (@CountR <> @Num)
	BEGIN
		SELECT TOP 1 N'''', Name
		FROM   @tbNames
		WHERE  LOWER(Name) NOT IN (SELECT ar.LoweredRoleName FROM dbo.aspnet_Roles ar,  @tbRoles r WHERE r.RoleId = ar.RoleId)
		IF( @TranStarted = 1 )
			ROLLBACK TRANSACTION
		RETURN(2)
	END


	DELETE FROM @tbNames WHERE 1=1
	SET @Num = 0
	SET @Pos = 1


	WHILE(@Pos <= LEN(@UserNames))
	BEGIN
		SELECT @NextPos = CHARINDEX(N'','', @UserNames,  @Pos)
		IF (@NextPos = 0 OR @NextPos IS NULL)
			SELECT @NextPos = LEN(@UserNames) + 1
		SELECT @Name = RTRIM(LTRIM(SUBSTRING(@UserNames, @Pos, @NextPos - @Pos)))
		SELECT @Pos = @NextPos+1

		INSERT INTO @tbNames VALUES (@Name)
		SET @Num = @Num + 1
	END

	INSERT INTO @tbUsers
	  SELECT UserId
	  FROM   dbo.aspnet_Users ar, @tbNames t
	  WHERE  LOWER(t.Name) = ar.LoweredUserName AND ar.ApplicationId = @AppId

	SELECT @CountU = @@ROWCOUNT
	IF (@CountU <> @Num)
	BEGIN
		SELECT TOP 1 Name, N''''
		FROM   @tbNames
		WHERE  LOWER(Name) NOT IN (SELECT au.LoweredUserName FROM dbo.aspnet_Users au,  @tbUsers u WHERE u.UserId = au.UserId)

		IF( @TranStarted = 1 )
			ROLLBACK TRANSACTION
		RETURN(1)
	END

	SELECT  @CountAll = COUNT(*)
	FROM	dbo.aspnet_UsersInRoles ur, @tbUsers u, @tbRoles r
	WHERE   ur.UserId = u.UserId AND ur.RoleId = r.RoleId

	IF (@CountAll <> @CountU * @CountR)
	BEGIN
		SELECT TOP 1 UserName, RoleName
		FROM		 @tbUsers tu, @tbRoles tr, dbo.aspnet_Users u, dbo.aspnet_Roles r
		WHERE		 u.UserId = tu.UserId AND r.RoleId = tr.RoleId AND
					 tu.UserId NOT IN (SELECT ur.UserId FROM dbo.aspnet_UsersInRoles ur WHERE ur.RoleId = tr.RoleId) AND
					 tr.RoleId NOT IN (SELECT ur.RoleId FROM dbo.aspnet_UsersInRoles ur WHERE ur.UserId = tu.UserId)
		IF( @TranStarted = 1 )
			ROLLBACK TRANSACTION
		RETURN(3)
	END

	DELETE FROM dbo.aspnet_UsersInRoles
	WHERE UserId IN (SELECT UserId FROM @tbUsers)
	  AND RoleId IN (SELECT RoleId FROM @tbRoles)
	IF( @TranStarted = 1 )
		COMMIT TRANSACTION
	RETURN(0)
END
'
ELSE
SELECT @SqlToExec = N'
CREATE PROCEDURE dbo.aspnet_UsersInRoles_RemoveUsersFromRoles
	@ApplicationName  nvarchar(256),
	@UserNames		  nvarchar(4000),
	@RoleNames		  nvarchar(4000)
AS
BEGIN
	DECLARE @AppId uniqueidentifier
	SELECT  @AppId = NULL
	SELECT  @AppId = ApplicationId FROM aspnet_Applications WHERE LOWER(@ApplicationName) = LoweredApplicationName
	IF (@AppId IS NULL)
		RETURN(2)


	DECLARE @TranStarted   bit
	SET @TranStarted = 0

	IF( @@TRANCOUNT = 0 )
	BEGIN
		BEGIN TRANSACTION
		SET @TranStarted = 1
	END

	DECLARE @RoleId		uniqueidentifier
	DECLARE @UserId		uniqueidentifier
	DECLARE @UserName	nvarchar(256)
	DECLARE @RoleName	nvarchar(256)

	DECLARE @CurrentPosU	int
	DECLARE @NextPosU		int
	DECLARE @CurrentPosR	int
	DECLARE @NextPosR		int

	SELECT  @CurrentPosU = 1

	WHILE(@CurrentPosU <= LEN(@UserNames))
	BEGIN
		SELECT @NextPosU = CHARINDEX(N'','', @UserNames,  @CurrentPosU)
		IF (@NextPosU = 0  OR @NextPosU IS NULL)
			SELECT @NextPosU = LEN(@UserNames)+1
		SELECT @UserName = SUBSTRING(@UserNames, @CurrentPosU, @NextPosU - @CurrentPosU)
		SELECT @CurrentPosU = @NextPosU+1

		SELECT @CurrentPosR = 1
		WHILE(@CurrentPosR <= LEN(@RoleNames))
		BEGIN
			SELECT @NextPosR = CHARINDEX(N'','', @RoleNames,  @CurrentPosR)
			IF (@NextPosR = 0 OR @NextPosR IS NULL)
				SELECT @NextPosR = LEN(@RoleNames)+1
			SELECT @RoleName = SUBSTRING(@RoleNames, @CurrentPosR, @NextPosR - @CurrentPosR)
			SELECT @CurrentPosR = @NextPosR+1

			SELECT @RoleId = NULL
			SELECT @RoleId = RoleId FROM dbo.aspnet_Roles WHERE LoweredRoleName = LOWER(@RoleName) AND ApplicationId = @AppId
			IF (@RoleId IS NULL)
			BEGIN
				SELECT N'''', @RoleName
				IF( @TranStarted = 1 )
					ROLLBACK TRANSACTION
				RETURN(2)
			END

			SELECT @UserId = NULL
			SELECT @UserId = UserId FROM dbo.aspnet_Users WHERE LoweredUserName = LOWER(@UserName) AND ApplicationId = @AppId
			IF (@UserId IS NULL)
			BEGIN
				SELECT @UserName, N''''
				IF( @TranStarted = 1 )
					ROLLBACK TRANSACTION
				RETURN(1)
			END

			IF (NOT(EXISTS(SELECT * FROM dbo.aspnet_UsersInRoles WHERE @UserId = UserId AND @RoleId = RoleId)))
			BEGIN
				SELECT @UserName, @RoleName
				IF( @TranStarted = 1 )
					ROLLBACK TRANSACTION
				RETURN(3)
			END
			DELETE FROM dbo.aspnet_UsersInRoles WHERE (UserId = @UserId AND RoleId = @RoleId)
		END
	END
	IF( @TranStarted = 1 )
		COMMIT TRANSACTION
	RETURN(0)
END
'
EXEC sp_executesql @SqlToExec
GO
/*************************************************************/
/*************************************************************/

IF (EXISTS (SELECT name
              FROM sysobjects
             WHERE (name = N'aspnet_UsersInRoles_GetUsersInRoles')
               AND (type = 'P')))
DROP PROCEDURE dbo.aspnet_UsersInRoles_GetUsersInRoles
GO

CREATE PROCEDURE dbo.aspnet_UsersInRoles_GetUsersInRoles
    @ApplicationName  nvarchar(256),
    @RoleName         nvarchar(256)
AS
BEGIN
    DECLARE @ApplicationId uniqueidentifier
    SELECT  @ApplicationId = NULL
    SELECT  @ApplicationId = ApplicationId FROM aspnet_Applications WHERE LOWER(@ApplicationName) = LoweredApplicationName
    IF (@ApplicationId IS NULL)
        RETURN(1)
     DECLARE @RoleId uniqueidentifier
     SELECT  @RoleId = NULL

     SELECT  @RoleId = RoleId
     FROM    dbo.aspnet_Roles
     WHERE   LOWER(@RoleName) = LoweredRoleName AND ApplicationId = @ApplicationId

     IF (@RoleId IS NULL)
         RETURN(1)

    SELECT u.UserName
    FROM   dbo.aspnet_Users u, dbo.aspnet_UsersInRoles ur
    WHERE  u.UserId = ur.UserId AND @RoleId = ur.RoleId AND u.ApplicationId = @ApplicationId
    ORDER BY u.UserName
    RETURN(0)
END
GO

/*************************************************************/
/*************************************************************/

IF (EXISTS (SELECT name
              FROM sysobjects
             WHERE (name = N'aspnet_UsersInRoles_FindUsersInRole')
               AND (type = 'P')))
DROP PROCEDURE dbo.aspnet_UsersInRoles_FindUsersInRole
GO

CREATE PROCEDURE dbo.aspnet_UsersInRoles_FindUsersInRole
    @ApplicationName  nvarchar(256),
    @RoleName         nvarchar(256),
    @UserNameToMatch  nvarchar(256)
AS
BEGIN
    DECLARE @ApplicationId uniqueidentifier
    SELECT  @ApplicationId = NULL
    SELECT  @ApplicationId = ApplicationId FROM aspnet_Applications WHERE LOWER(@ApplicationName) = LoweredApplicationName
    IF (@ApplicationId IS NULL)
        RETURN(1)
     DECLARE @RoleId uniqueidentifier
     SELECT  @RoleId = NULL

     SELECT  @RoleId = RoleId
     FROM    dbo.aspnet_Roles
     WHERE   LOWER(@RoleName) = LoweredRoleName AND ApplicationId = @ApplicationId

     IF (@RoleId IS NULL)
         RETURN(1)

    SELECT u.UserName
    FROM   dbo.aspnet_Users u, dbo.aspnet_UsersInRoles ur
    WHERE  u.UserId = ur.UserId AND @RoleId = ur.RoleId AND u.ApplicationId = @ApplicationId AND LoweredUserName LIKE LOWER(@UserNameToMatch)
    ORDER BY u.UserName
    RETURN(0)
END
GO

/*************************************************************/
/*************************************************************/

IF (EXISTS (SELECT name
              FROM sysobjects
             WHERE (name = N'aspnet_Roles_GetAllRoles')
               AND (type = 'P')))
DROP PROCEDURE dbo.aspnet_Roles_GetAllRoles
GO

CREATE PROCEDURE dbo.aspnet_Roles_GetAllRoles (
    @ApplicationName           nvarchar(256))
AS
BEGIN
    DECLARE @ApplicationId uniqueidentifier
    SELECT  @ApplicationId = NULL
    SELECT  @ApplicationId = ApplicationId FROM aspnet_Applications WHERE LOWER(@ApplicationName) = LoweredApplicationName
    IF (@ApplicationId IS NULL)
        RETURN
    SELECT RoleName
    FROM   dbo.aspnet_Roles WHERE ApplicationId = @ApplicationId
    ORDER BY RoleName
END
GO

/*************************************************************/
/*************************************************************/

IF (NOT EXISTS (SELECT name
                FROM sysobjects
                WHERE (name = N'vw_aspnet_Roles')
                  AND (type = 'V')))
BEGIN
  PRINT 'Creating the vw_aspnet_Roles view...'
  EXEC(N'
  CREATE VIEW [dbo].[vw_aspnet_Roles]
  AS SELECT [dbo].[aspnet_Roles].[ApplicationId], [dbo].[aspnet_Roles].[RoleId], [dbo].[aspnet_Roles].[RoleName], [dbo].[aspnet_Roles].[LoweredRoleName], [dbo].[aspnet_Roles].[Description]
  FROM [dbo].[aspnet_Roles]
  ')
END
GO

/*************************************************************/
/*************************************************************/

IF (NOT EXISTS (SELECT name
                FROM sysobjects
                WHERE (name = N'vw_aspnet_UsersInRoles')
                  AND (type = 'V')))
BEGIN
  PRINT 'Creating the vw_aspnet_UsersInRoles view...'
  EXEC(N'
  CREATE VIEW [dbo].[vw_aspnet_UsersInRoles]
  AS SELECT [dbo].[aspnet_UsersInRoles].[UserId], [dbo].[aspnet_UsersInRoles].[RoleId]
  FROM [dbo].[aspnet_UsersInRoles]
  ')
END
GO

/*************************************************************/
/*************************************************************/

--
--Create Role Manager schema version
--

DECLARE @command nvarchar(4000)
SET @command = 'GRANT EXECUTE ON [dbo].aspnet_RegisterSchemaVersion TO ' + QUOTENAME(user)
EXECUTE (@command)
GO

EXEC [dbo].aspnet_RegisterSchemaVersion N'Role Manager', N'1', 1, 1
GO

/*************************************************************/
/*************************************************************/

--
--Create Role Manager roles
--

IF ( NOT EXISTS ( SELECT name
                  FROM sysusers
                  WHERE issqlrole = 1
                  AND name = N'aspnet_Roles_FullAccess'  ) )
EXEC sp_addrole N'aspnet_Roles_FullAccess'

IF ( NOT EXISTS ( SELECT name
                  FROM sysusers
                  WHERE issqlrole = 1
                  AND name = N'aspnet_Roles_BasicAccess'  ) )
EXEC sp_addrole N'aspnet_Roles_BasicAccess'

IF ( NOT EXISTS ( SELECT name
                  FROM sysusers
                  WHERE issqlrole = 1
                  AND name = N'aspnet_Roles_ReportingAccess'  ) )
EXEC sp_addrole N'aspnet_Roles_ReportingAccess'
GO

EXEC sp_addrolemember N'aspnet_Roles_BasicAccess', N'aspnet_Roles_FullAccess'
EXEC sp_addrolemember N'aspnet_Roles_ReportingAccess', N'aspnet_Roles_FullAccess'
GO

--
--Stored Procedure rights for BasicAccess
--
GRANT EXECUTE ON dbo.aspnet_UsersInRoles_IsUserInRole TO aspnet_Roles_BasicAccess
GRANT EXECUTE ON dbo.aspnet_UsersInRoles_GetRolesForUser TO aspnet_Roles_BasicAccess
GRANT EXECUTE ON dbo.aspnet_CheckSchemaVersion TO aspnet_Roles_BasicAccess
GRANT EXECUTE ON dbo.aspnet_RegisterSchemaVersion TO aspnet_Roles_BasicAccess
GRANT EXECUTE ON dbo.aspnet_UnRegisterSchemaVersion TO aspnet_Roles_BasicAccess

--
--Stored Procedure rights for ReportingAccess
--
GRANT EXECUTE ON dbo.aspnet_UsersInRoles_IsUserInRole TO aspnet_Roles_ReportingAccess
GRANT EXECUTE ON dbo.aspnet_UsersInRoles_GetRolesForUser TO aspnet_Roles_ReportingAccess
GRANT EXECUTE ON dbo.aspnet_Roles_RoleExists TO aspnet_Roles_ReportingAccess
GRANT EXECUTE ON dbo.aspnet_UsersInRoles_GetUsersInRoles TO aspnet_Roles_ReportingAccess
GRANT EXECUTE ON dbo.aspnet_UsersInRoles_FindUsersInRole TO aspnet_Roles_ReportingAccess
GRANT EXECUTE ON dbo.aspnet_Roles_GetAllRoles TO aspnet_Roles_ReportingAccess
GRANT EXECUTE ON dbo.aspnet_CheckSchemaVersion TO aspnet_Roles_ReportingAccess
GRANT EXECUTE ON dbo.aspnet_RegisterSchemaVersion TO aspnet_Roles_ReportingAccess
GRANT EXECUTE ON dbo.aspnet_UnRegisterSchemaVersion TO aspnet_Roles_ReportingAccess

--
--Additional stored procedure rights for FullAccess
--

GRANT EXECUTE ON dbo.aspnet_Roles_CreateRole TO aspnet_Roles_FullAccess
GRANT EXECUTE ON dbo.aspnet_Roles_DeleteRole TO aspnet_Roles_FullAccess
GRANT EXECUTE ON dbo.aspnet_UsersInRoles_AddUsersToRoles TO aspnet_Roles_FullAccess
GRANT EXECUTE ON dbo.aspnet_UsersInRoles_RemoveUsersFromRoles TO aspnet_Roles_FullAccess

--
--View rights
--
GRANT SELECT ON dbo.vw_aspnet_Applications TO aspnet_Roles_ReportingAccess
GRANT SELECT ON dbo.vw_aspnet_Users TO aspnet_Roles_ReportingAccess

GRANT SELECT ON dbo.vw_aspnet_Roles TO aspnet_Roles_ReportingAccess
GRANT SELECT ON dbo.vw_aspnet_UsersInRoles TO aspnet_Roles_ReportingAccess

GO

/*************************************************************/
/*************************************************************/
/*************************************************************/
/*************************************************************/

DECLARE @command nvarchar(4000)
SET @command = 'REVOKE EXECUTE ON [dbo].aspnet_RegisterSchemaVersion FROM ' + QUOTENAME(user)
EXECUTE (@command)
GO
/*
PRINT '---------------------------------------'
PRINT 'Completed execution of InstallRoles.SQL'
PRINT '---------------------------------------'
*/



-- ===============================================================================
-- Author:		<Ray liang>
-- Create date: <2010-10-21>
-- Description:	<Install the tables and storeprocedures for DotNetAge core.>
-- Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
-- Dual licensed under the MIT and GPL licenses:
-- http://www.opensource.org/licenses/mit-license.php
-- http://www.gnu.org/licenses/gpl.html
-- ===============================================================================


USE [PlaceholderForDbName]
GO

/****** Object:  Table [dbo].[dna_PermissionSets]    Script Date: 10/21/2010 21:20:55 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dna_PermissionSets]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[dna_PermissionSets](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[Name] [nvarchar](100) NOT NULL,
	[Title] [nvarchar](255) NULL,
	[Description] [ntext] NULL,
 CONSTRAINT [PK_PermissionSets] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[dna_EventLog]    Script Date: 10/21/2010 21:20:55 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dna_EventLog]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[dna_EventLog](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[ClientAddress] [nvarchar](255) NOT NULL,
	[Controller] [nvarchar](255) NOT NULL,
	[Action] [nvarchar](255) NOT NULL,
	[UserName] [nvarchar](255) NULL,
	[IsAnonymous] [bit] NOT NULL,
	[Logged] [datetime] NOT NULL,
	[Browser] [nvarchar](50) NOT NULL,
	[Version] [nvarchar](1024) NOT NULL,
	[Host] [nvarchar](1024) NOT NULL,
	[RawUrl] [nvarchar](2048) NOT NULL,
	[UserAgent] [nvarchar](1024) NOT NULL,
	[UrlRefer] [nvarchar](2048) NULL,
	[WebName] [nvarchar](1024) NULL,
	[HttpMethod] [nvarchar](50) NULL,
	[QueryString] [nvarchar](2048) NULL,
	[Cookies] [nvarchar](2048) NULL,
	[Bytes] [int] NULL,
 CONSTRAINT [PK_dna_Log] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[dna_PackageInfos]    Script Date: 10/21/2010 21:20:55 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dna_PackageInfos]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[dna_PackageInfos](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[Name] [nvarchar](50) NOT NULL,
	[ShortName] [nvarchar](50) NULL,
	[Description] [ntext] NULL,
	[AuthorName] [nvarchar](50) NULL,
	[AuthorWebSite] [nvarchar](1024) NULL,
	[AuthorEmail] [nvarchar](1024) NULL,
	[Organization] [nvarchar](255) NULL,
	[IconUrl] [nvarchar](1024) NULL,
	[IconHeight] [int] NULL,
	[IconWidth] [int] NULL,
	[ReleaseNotes] [ntext] NULL,
	[Version] [nvarchar](50) NULL,
	[Installed] [datetime] NULL,
	[Published] [datetime] NULL,
	[LicensesXML] [ntext] NULL,
	[FileList] [ntext] NULL,
	[HelpLink] [nvarchar](50) NULL,
	[SupportLink] [nvarchar](50) NULL,
	[AssemblyName] [nvarchar](255) NULL,
	[AssemblyFullName] [nvarchar](1024) NULL,
 CONSTRAINT [PK_Packages] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[dna_WidgetCategories]    Script Date: 10/21/2010 21:20:55 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dna_WidgetCategories]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[dna_WidgetCategories](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Title] [nvarchar](50) NULL,
	[Description] [ntext] NULL,
 CONSTRAINT [PK_Categories] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[dna_WebSettings]    Script Date: 10/21/2010 21:20:55 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dna_WebSettings]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[dna_WebSettings](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Title] [nvarchar](50) NULL,
	[Description] [ntext] NULL,
	[LogoImageUrl] [nvarchar](1024) NULL,
	[SearchKeywords] [ntext] NULL,
	[TimeZone] [nvarchar](255) NULL,
	[Theme] [nvarchar](255) NULL,
	[Copyright] [ntext] NULL,
	[DefaultLanguage] [nvarchar](50) NULL,
	[ShortcutIconUrl] [nvarchar](1024) NULL,
	[Layout] [nvarchar](1024) NULL,
	[Data] [ntext] NULL,
	[AllowExtensions] [ntext] NULL,
	[MaximumFileSize] [int] NOT NULL,
	[MasterName] [nvarchar](1024) NULL,
	[SMTPHost] [nvarchar](1024) NULL,
	[SMTPPassword] [nvarchar](255) NULL,
	[SMTPUserName] [nvarchar](255) NULL,
	[SMTPPort] [int] NOT NULL,
	[SMTPUsedDefaultCredentials] [bit] NOT NULL,
	[SiteMailAccount] [nvarchar](1024) NULL,
	[MostOnlineUserCount] [int] NOT NULL,
	[MostOnlined] [datetime] NOT NULL,
	[CssText] [ntext] NULL,
	[EnableUserRegistration] [bit] NOT NULL,
	[DefaultUrl] [nvarchar](1024) NULL,
	[Name] [nvarchar](1024) NOT NULL,
	[Owner] [nvarchar](256) NOT NULL,
	[Created] [datetime] NOT NULL,
	[IsEnabled] [bit] NOT NULL,
	[CacheDuration] [int] NOT NULL,
	[Type] [int] NOT NULL,
 CONSTRAINT [PK_Portals] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[dna_WebPages]    Script Date: 10/21/2010 21:20:55 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dna_WebPages]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[dna_WebPages](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[Path] [nvarchar](1024) NOT NULL,
	[Title] [nvarchar](255) NULL,
	[Description] [ntext] NULL,
	[ViewData] [ntext] NULL,
	[ViewName] [nvarchar](255) NULL,
	[IsStatic] [bit] NOT NULL,
	[ShowInMenu] [bit] NOT NULL,
	[IsShared] [bit] NOT NULL,
	[AllowAnonymous] [bit] NOT NULL,
	[Pos] [int] NOT NULL,
	[ParentID] [int] NOT NULL,
	[Target] [nvarchar](50) NOT NULL,
	[LastModified] [datetime] NOT NULL,
	[Created] [datetime] NOT NULL,
	[Owner] [nvarchar](255) NOT NULL,
	[LinkUrl] [nvarchar](1024) NULL,
	[WebID] [int] NOT NULL,
 CONSTRAINT [PK_WebPages] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
END
GO

/****** Object:  StoredProcedure [dbo].[dna_getOnlineUsers]    Script Date: 10/21/2010 21:20:54 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF EXISTS(SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dna_getOnlineUsers]') AND type in (N'P', N'PC')) BEGIN
   DROP PROCEDURE [dbo].[dna_statistics]
END
GO

CREATE PROCEDURE [dbo].[dna_getOnlineUsers]
@webName nvarchar(1024),
@isAnonymous bit,
@interval int
AS
BEGIN
SET NOCOUNT ON;
SELECT distinct userName 
FROM [dna_eventlog]
WHERE IsAnonymous=@isAnonymous AND
      (Logged Between DateAdd(MINUTE,-@interval,GetDate()) AND GetDate()) AND
      [dna_EventLog].[WebName]=@webName
END

GO

/****** Object:  Table [dbo].[dna_Permissions]    Script Date: 10/21/2010 21:20:55 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dna_Permissions]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[dna_Permissions](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[Controller] [nvarchar](255) NOT NULL,
	[Action] [nvarchar](255) NOT NULL,
	[PermissionSetID] [int] NOT NULL,
	[Title] [nvarchar](255) NULL,
	[Description] [ntext] NULL,
	[Assembly] [nvarchar](1024) NOT NULL,
 CONSTRAINT [PK_Permissions] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[dna_WidgetDescriptors]    Script Date: 10/21/2010 21:20:55 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dna_WidgetDescriptors]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[dna_WidgetDescriptors](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[CatID] [int] NOT NULL,
	[PackageID] [int] NOT NULL,
	[Title] [nvarchar](50) NULL,
	[Url] [nvarchar](1024) NULL,
	[Action] [nvarchar](255) NULL,
	[Defaults] [ntext] NULL,
	[IsClosable] [bit] NULL,
	[ShowHeader] [bit] NULL,
	[Version] [nvarchar](50) NULL,
	[ImageUrl] [nvarchar](1024) NULL,
	[Description] [ntext] NULL,
	[Controller] [nvarchar](255) NULL,
	[IconUrl] [nvarchar](1024) NULL,
	[ShowBorder] [bit] NOT NULL,
	[Scopes] [int] NOT NULL,
	[IsDeletable] [bit] NULL,
 CONSTRAINT [PK_WidgetMetas] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[dna_Widgets]    Script Date: 10/21/2010 21:20:55 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dna_Widgets]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[dna_Widgets](
	[ID] [uniqueidentifier] NOT NULL,
	[Title] [nvarchar](255) NULL,
	[TitleLinkUrl] [nvarchar](1024) NULL,
	[IconUrl] [nvarchar](1024) NULL,
	[ShowHeader] [bit] NOT NULL,
	[ShowBorder] [bit] NOT NULL,
	[IsDeletable] [bit] NOT NULL,
	[IsClosable] [bit] NOT NULL,
	[IsExpanded] [bit] NOT NULL,
	[Pos] [int] NOT NULL,
	[Data] [varbinary](max) NULL,
	[Url] [nvarchar](1024) NULL,
	[Action] [nvarchar](255) NULL,
	[ZoneID] [nvarchar](255) NOT NULL,
	[PageID] [int] NOT NULL,
	[DescriptorID] [int] NOT NULL,
	[Controller] [nvarchar](255) NULL,
	[BackgroundColor] [nvarchar](10) NULL,
	[ForeColor] [nvarchar](10) NULL,
	[Scope] [int] NOT NULL,
	[IsStatic] [bit] NULL,
 CONSTRAINT [PK_Widgets] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[dna_PermsInRoles]    Script Date: 10/21/2010 21:20:55 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dna_PermsInRoles]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[dna_PermsInRoles](
	[PermID] [int] NOT NULL,
	[RoleName] [nvarchar](50) NOT NULL,
 CONSTRAINT [PK_PermsInRoles] PRIMARY KEY CLUSTERED 
(
	[PermID] ASC,
	[RoleName] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[dna_WebPageRoles]    Script Date: 10/21/2010 21:20:55 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dna_WebPageRoles]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[dna_WebPageRoles](
	[RoleName] [nvarchar](256) NOT NULL,
	[PageID] [int] NOT NULL,
 CONSTRAINT [PK_dna_WebPageRoles] PRIMARY KEY CLUSTERED 
(
	[RoleName] ASC,
	[PageID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO

/****** Object:  StoredProcedure [dbo].[dna_statistics]    Script Date: 10/21/2010 21:20:54 ******/

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF EXISTS(SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dna_statistics]') AND type in (N'P', N'PC')) BEGIN
   DROP PROCEDURE [dbo].[dna_statistics]
END
GO

CREATE PROCEDURE [dbo].[dna_statistics]
@webName nvarchar(1024),
@interval int
AS
BEGIN
	SET NOCOUNT ON;

DECLARE @mostUserCount int,
        @mostOnlined datetime

SELECT distinct ClientAddress,CONVERT(varchar(30),Logged,101) as loggedstr
INTO #tmp
FROM [dbo].[dna_eventlog]
WHERE [WebName] = @webName
ORDER BY loggedstr

SELECT TOP 1 COUNT(ClientAddress) AS AccessCount,
       LoggedStr AS Logged
INTO #a
FROM  #tmp
GROUP BY loggedstr
ORDER BY AccessCount DESC


SELECT @mostUserCount=a.AccessCount,
       @mostOnlined=CONVERT(datetime,a.Logged)
FROM #a a

DROP TABLE #a
DROP TABLE #tmp

IF @mostUserCount is NULL
   SET @mostUserCount=0
IF @mostOnlined IS NULL
   SET @mostOnlined=CONVERT(datetime,GETDATE())

SELECT Count(distinct clientAddress) AS Visits,
       Count(clientAddress) AS PageView,
       RegistedUserCount = (SELECT Count(UserID)FROM [aspnet_Membership]),
       OnlineGuests=(select Count(distinct userName)FROM [dna_eventlog] WHERE IsAnonymous=1 AND(Logged Between DateAdd(MINUTE,-@interval,GetDate()) AND GetDate()) AND [dna_EventLog].[WebName]=@webName),
       OnlineRegisters=(select Count(distinct userName)FROM [dna_eventlog] WHERE IsAnonymous=0 AND(Logged Between DateAdd(MINUTE,-@interval,GetDate()) AND GetDate()) AND [dna_EventLog].[WebName]=@webName),
       MostOnlineCount=@mostUserCount,
       MostOnlined=@mostOnlined
FROM [dna_eventlog]
WHERE DatePart(YYYY,logged)=DatePart(YYYY,GetDate()) AND
      DatePart(MM,logged)=DatePart(MM,GetDate()) AND
      DatePart(dd,logged)=DatePart(dd,GetDate())AND
      [dna_EventLog].[WebName]=@webName
END
GO

/****** Object:  Default [DF_Packages_IconHeight]    Script Date: 10/21/2010 21:20:55 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_Packages_IconHeight]') AND parent_object_id = OBJECT_ID(N'[dbo].[dna_PackageInfos]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_Packages_IconHeight]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[dna_PackageInfos] ADD  CONSTRAINT [DF_Packages_IconHeight]  DEFAULT ((16)) FOR [IconHeight]
END


End
GO
/****** Object:  Default [DF_Packages_IconWidth]    Script Date: 10/21/2010 21:20:55 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_Packages_IconWidth]') AND parent_object_id = OBJECT_ID(N'[dbo].[dna_PackageInfos]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_Packages_IconWidth]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[dna_PackageInfos] ADD  CONSTRAINT [DF_Packages_IconWidth]  DEFAULT ((16)) FOR [IconWidth]
END


End
GO
/****** Object:  Default [DF_Packages_Version]    Script Date: 10/21/2010 21:20:55 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_Packages_Version]') AND parent_object_id = OBJECT_ID(N'[dbo].[dna_PackageInfos]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_Packages_Version]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[dna_PackageInfos] ADD  CONSTRAINT [DF_Packages_Version]  DEFAULT (N'v1.0.0.0') FOR [Version]
END


End
GO
/****** Object:  Default [DF_Packages_LastUpdated]    Script Date: 10/21/2010 21:20:55 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_Packages_LastUpdated]') AND parent_object_id = OBJECT_ID(N'[dbo].[dna_PackageInfos]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_Packages_LastUpdated]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[dna_PackageInfos] ADD  CONSTRAINT [DF_Packages_LastUpdated]  DEFAULT (getdate()) FOR [Installed]
END


End
GO
/****** Object:  Default [DF_dna_Log_IsAnonymous]    Script Date: 10/21/2010 21:20:55 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_dna_Log_IsAnonymous]') AND parent_object_id = OBJECT_ID(N'[dbo].[dna_EventLog]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_dna_Log_IsAnonymous]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[dna_EventLog] ADD  CONSTRAINT [DF_dna_Log_IsAnonymous]  DEFAULT ((1)) FOR [IsAnonymous]
END


End
GO
/****** Object:  Default [DF_dna_WebPages_IsStatic]    Script Date: 10/21/2010 21:20:55 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_dna_WebPages_IsStatic]') AND parent_object_id = OBJECT_ID(N'[dbo].[dna_WebPages]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_dna_WebPages_IsStatic]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[dna_WebPages] ADD  CONSTRAINT [DF_dna_WebPages_IsStatic]  DEFAULT ((0)) FOR [IsStatic]
END


End
GO
/****** Object:  Default [DF_WebPages_ShowInMenu]    Script Date: 10/21/2010 21:20:55 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_WebPages_ShowInMenu]') AND parent_object_id = OBJECT_ID(N'[dbo].[dna_WebPages]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_WebPages_ShowInMenu]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[dna_WebPages] ADD  CONSTRAINT [DF_WebPages_ShowInMenu]  DEFAULT ((0)) FOR [ShowInMenu]
END


End
GO
/****** Object:  Default [DF_dna_WebPages_IsShared]    Script Date: 10/21/2010 21:20:55 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_dna_WebPages_IsShared]') AND parent_object_id = OBJECT_ID(N'[dbo].[dna_WebPages]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_dna_WebPages_IsShared]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[dna_WebPages] ADD  CONSTRAINT [DF_dna_WebPages_IsShared]  DEFAULT ((1)) FOR [IsShared]
END


End
GO
/****** Object:  Default [DF_dna_WebPages_AllowAnonymous]    Script Date: 10/21/2010 21:20:55 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_dna_WebPages_AllowAnonymous]') AND parent_object_id = OBJECT_ID(N'[dbo].[dna_WebPages]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_dna_WebPages_AllowAnonymous]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[dna_WebPages] ADD  CONSTRAINT [DF_dna_WebPages_AllowAnonymous]  DEFAULT ((1)) FOR [AllowAnonymous]
END


End
GO
/****** Object:  Default [DF_WebPages_Pos]    Script Date: 10/21/2010 21:20:55 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_WebPages_Pos]') AND parent_object_id = OBJECT_ID(N'[dbo].[dna_WebPages]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_WebPages_Pos]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[dna_WebPages] ADD  CONSTRAINT [DF_WebPages_Pos]  DEFAULT ((0)) FOR [Pos]
END


End
GO
/****** Object:  Default [DF_dna_WebPages_ParentID]    Script Date: 10/21/2010 21:20:55 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_dna_WebPages_ParentID]') AND parent_object_id = OBJECT_ID(N'[dbo].[dna_WebPages]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_dna_WebPages_ParentID]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[dna_WebPages] ADD  CONSTRAINT [DF_dna_WebPages_ParentID]  DEFAULT ((-1)) FOR [ParentID]
END


End
GO
/****** Object:  Default [DF_WebPages_Target]    Script Date: 10/21/2010 21:20:55 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_WebPages_Target]') AND parent_object_id = OBJECT_ID(N'[dbo].[dna_WebPages]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_WebPages_Target]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[dna_WebPages] ADD  CONSTRAINT [DF_WebPages_Target]  DEFAULT ('_self') FOR [Target]
END


End
GO
/****** Object:  Default [DF_dna_WebPages_LastModified]    Script Date: 10/21/2010 21:20:55 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_dna_WebPages_LastModified]') AND parent_object_id = OBJECT_ID(N'[dbo].[dna_WebPages]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_dna_WebPages_LastModified]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[dna_WebPages] ADD  CONSTRAINT [DF_dna_WebPages_LastModified]  DEFAULT (getdate()) FOR [LastModified]
END


End
GO
/****** Object:  Default [DF_dna_WebPages_Created]    Script Date: 10/21/2010 21:20:55 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_dna_WebPages_Created]') AND parent_object_id = OBJECT_ID(N'[dbo].[dna_WebPages]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_dna_WebPages_Created]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[dna_WebPages] ADD  CONSTRAINT [DF_dna_WebPages_Created]  DEFAULT (getdate()) FOR [Created]
END


End
GO
/****** Object:  Default [DF_dna_WebPages_Owner]    Script Date: 10/21/2010 21:20:55 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_dna_WebPages_Owner]') AND parent_object_id = OBJECT_ID(N'[dbo].[dna_WebPages]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_dna_WebPages_Owner]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[dna_WebPages] ADD  CONSTRAINT [DF_dna_WebPages_Owner]  DEFAULT (N'') FOR [Owner]
END


End
GO
/****** Object:  Default [DF_dna_WebSettings_MaximumFileSize]    Script Date: 10/21/2010 21:20:55 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_dna_WebSettings_MaximumFileSize]') AND parent_object_id = OBJECT_ID(N'[dbo].[dna_WebSettings]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_dna_WebSettings_MaximumFileSize]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[dna_WebSettings] ADD  CONSTRAINT [DF_dna_WebSettings_MaximumFileSize]  DEFAULT ((1024000000)) FOR [MaximumFileSize]
END


End
GO
/****** Object:  Default [DF_dna_WebSettings_SMTPPort]    Script Date: 10/21/2010 21:20:55 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_dna_WebSettings_SMTPPort]') AND parent_object_id = OBJECT_ID(N'[dbo].[dna_WebSettings]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_dna_WebSettings_SMTPPort]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[dna_WebSettings] ADD  CONSTRAINT [DF_dna_WebSettings_SMTPPort]  DEFAULT ((25)) FOR [SMTPPort]
END


End
GO
/****** Object:  Default [DF_dna_WebSettings_SMTPUsedDefaultCredentials]    Script Date: 10/21/2010 21:20:55 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_dna_WebSettings_SMTPUsedDefaultCredentials]') AND parent_object_id = OBJECT_ID(N'[dbo].[dna_WebSettings]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_dna_WebSettings_SMTPUsedDefaultCredentials]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[dna_WebSettings] ADD  CONSTRAINT [DF_dna_WebSettings_SMTPUsedDefaultCredentials]  DEFAULT ((1)) FOR [SMTPUsedDefaultCredentials]
END


End
GO
/****** Object:  Default [DF_dna_WebSettings_MostOnlineUserCount]    Script Date: 10/21/2010 21:20:55 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_dna_WebSettings_MostOnlineUserCount]') AND parent_object_id = OBJECT_ID(N'[dbo].[dna_WebSettings]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_dna_WebSettings_MostOnlineUserCount]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[dna_WebSettings] ADD  CONSTRAINT [DF_dna_WebSettings_MostOnlineUserCount]  DEFAULT ((0)) FOR [MostOnlineUserCount]
END


End
GO
/****** Object:  Default [DF_dna_WebSettings_MostOnlined]    Script Date: 10/21/2010 21:20:55 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_dna_WebSettings_MostOnlined]') AND parent_object_id = OBJECT_ID(N'[dbo].[dna_WebSettings]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_dna_WebSettings_MostOnlined]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[dna_WebSettings] ADD  CONSTRAINT [DF_dna_WebSettings_MostOnlined]  DEFAULT (getdate()) FOR [MostOnlined]
END


End
GO
/****** Object:  Default [DF_dna_WebSettings_Created]    Script Date: 10/21/2010 21:20:55 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_dna_WebSettings_Created]') AND parent_object_id = OBJECT_ID(N'[dbo].[dna_WebSettings]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_dna_WebSettings_Created]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[dna_WebSettings] ADD  CONSTRAINT [DF_dna_WebSettings_Created]  DEFAULT (getdate()) FOR [Created]
END


End
GO
/****** Object:  Default [DF_dna_WebSettings_IsEnabled]    Script Date: 10/21/2010 21:20:55 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_dna_WebSettings_IsEnabled]') AND parent_object_id = OBJECT_ID(N'[dbo].[dna_WebSettings]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_dna_WebSettings_IsEnabled]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[dna_WebSettings] ADD  CONSTRAINT [DF_dna_WebSettings_IsEnabled]  DEFAULT ((1)) FOR [IsEnabled]
END


End
GO
/****** Object:  Default [DF_dna_WebSettings_CacheDuration]    Script Date: 10/21/2010 21:20:55 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_dna_WebSettings_CacheDuration]') AND parent_object_id = OBJECT_ID(N'[dbo].[dna_WebSettings]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_dna_WebSettings_CacheDuration]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[dna_WebSettings] ADD  CONSTRAINT [DF_dna_WebSettings_CacheDuration]  DEFAULT ((0)) FOR [CacheDuration]
END


End
GO
/****** Object:  Default [DF_dna_WebSettings_Type]    Script Date: 10/21/2010 21:20:55 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_dna_WebSettings_Type]') AND parent_object_id = OBJECT_ID(N'[dbo].[dna_WebSettings]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_dna_WebSettings_Type]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[dna_WebSettings] ADD  CONSTRAINT [DF_dna_WebSettings_Type]  DEFAULT ((0)) FOR [Type]
END


End
GO
/****** Object:  Default [DF_WidgetMetas_IsClosable]    Script Date: 10/21/2010 21:20:55 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_WidgetMetas_IsClosable]') AND parent_object_id = OBJECT_ID(N'[dbo].[dna_WidgetDescriptors]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_WidgetMetas_IsClosable]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[dna_WidgetDescriptors] ADD  CONSTRAINT [DF_WidgetMetas_IsClosable]  DEFAULT ((1)) FOR [IsClosable]
END


End
GO
/****** Object:  Default [DF_WidgetMetas_ShowHeader]    Script Date: 10/21/2010 21:20:55 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_WidgetMetas_ShowHeader]') AND parent_object_id = OBJECT_ID(N'[dbo].[dna_WidgetDescriptors]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_WidgetMetas_ShowHeader]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[dna_WidgetDescriptors] ADD  CONSTRAINT [DF_WidgetMetas_ShowHeader]  DEFAULT ((1)) FOR [ShowHeader]
END


End
GO
/****** Object:  Default [DF_WidgetMetas_Version]    Script Date: 10/21/2010 21:20:55 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_WidgetMetas_Version]') AND parent_object_id = OBJECT_ID(N'[dbo].[dna_WidgetDescriptors]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_WidgetMetas_Version]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[dna_WidgetDescriptors] ADD  CONSTRAINT [DF_WidgetMetas_Version]  DEFAULT (N'v1.0') FOR [Version]
END


End
GO
/****** Object:  Default [DF_dna_WidgetDescriptors_ShowBorder]    Script Date: 10/21/2010 21:20:55 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_dna_WidgetDescriptors_ShowBorder]') AND parent_object_id = OBJECT_ID(N'[dbo].[dna_WidgetDescriptors]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_dna_WidgetDescriptors_ShowBorder]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[dna_WidgetDescriptors] ADD  CONSTRAINT [DF_dna_WidgetDescriptors_ShowBorder]  DEFAULT ((1)) FOR [ShowBorder]
END


End
GO
/****** Object:  Default [DF_dna_WidgetDescriptors_Scopes]    Script Date: 10/21/2010 21:20:55 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_dna_WidgetDescriptors_Scopes]') AND parent_object_id = OBJECT_ID(N'[dbo].[dna_WidgetDescriptors]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_dna_WidgetDescriptors_Scopes]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[dna_WidgetDescriptors] ADD  CONSTRAINT [DF_dna_WidgetDescriptors_Scopes]  DEFAULT ((0)) FOR [Scopes]
END


End
GO
/****** Object:  Default [DF_dna_WidgetDescriptors_IsDeletable]    Script Date: 10/21/2010 21:20:55 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_dna_WidgetDescriptors_IsDeletable]') AND parent_object_id = OBJECT_ID(N'[dbo].[dna_WidgetDescriptors]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_dna_WidgetDescriptors_IsDeletable]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[dna_WidgetDescriptors] ADD  CONSTRAINT [DF_dna_WidgetDescriptors_IsDeletable]  DEFAULT ((1)) FOR [IsDeletable]
END


End
GO
/****** Object:  Default [DF_Widgets_ID]    Script Date: 10/21/2010 21:20:55 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_Widgets_ID]') AND parent_object_id = OBJECT_ID(N'[dbo].[dna_Widgets]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_Widgets_ID]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[dna_Widgets] ADD  CONSTRAINT [DF_Widgets_ID]  DEFAULT (newid()) FOR [ID]
END


End
GO
/****** Object:  Default [DF_Widgets_ShowHeader]    Script Date: 10/21/2010 21:20:55 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_Widgets_ShowHeader]') AND parent_object_id = OBJECT_ID(N'[dbo].[dna_Widgets]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_Widgets_ShowHeader]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[dna_Widgets] ADD  CONSTRAINT [DF_Widgets_ShowHeader]  DEFAULT ((1)) FOR [ShowHeader]
END


End
GO
/****** Object:  Default [DF_dna_Widgets_ShowBorder]    Script Date: 10/21/2010 21:20:55 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_dna_Widgets_ShowBorder]') AND parent_object_id = OBJECT_ID(N'[dbo].[dna_Widgets]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_dna_Widgets_ShowBorder]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[dna_Widgets] ADD  CONSTRAINT [DF_dna_Widgets_ShowBorder]  DEFAULT ((1)) FOR [ShowBorder]
END


End
GO
/****** Object:  Default [DF_Widgets_IsDeletable]    Script Date: 10/21/2010 21:20:55 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_Widgets_IsDeletable]') AND parent_object_id = OBJECT_ID(N'[dbo].[dna_Widgets]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_Widgets_IsDeletable]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[dna_Widgets] ADD  CONSTRAINT [DF_Widgets_IsDeletable]  DEFAULT ((1)) FOR [IsDeletable]
END


End
GO
/****** Object:  Default [DF_Widgets_IsClosable]    Script Date: 10/21/2010 21:20:55 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_Widgets_IsClosable]') AND parent_object_id = OBJECT_ID(N'[dbo].[dna_Widgets]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_Widgets_IsClosable]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[dna_Widgets] ADD  CONSTRAINT [DF_Widgets_IsClosable]  DEFAULT ((1)) FOR [IsClosable]
END


End
GO
/****** Object:  Default [DF_Widgets_IsExpanded]    Script Date: 10/21/2010 21:20:55 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_Widgets_IsExpanded]') AND parent_object_id = OBJECT_ID(N'[dbo].[dna_Widgets]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_Widgets_IsExpanded]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[dna_Widgets] ADD  CONSTRAINT [DF_Widgets_IsExpanded]  DEFAULT ((1)) FOR [IsExpanded]
END


End
GO
/****** Object:  Default [DF_Widgets_Pos]    Script Date: 10/21/2010 21:20:55 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_Widgets_Pos]') AND parent_object_id = OBJECT_ID(N'[dbo].[dna_Widgets]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_Widgets_Pos]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[dna_Widgets] ADD  CONSTRAINT [DF_Widgets_Pos]  DEFAULT ((0)) FOR [Pos]
END


End
GO
/****** Object:  Default [DF_Widgets_ZoneID]    Script Date: 10/21/2010 21:20:55 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_Widgets_ZoneID]') AND parent_object_id = OBJECT_ID(N'[dbo].[dna_Widgets]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_Widgets_ZoneID]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[dna_Widgets] ADD  CONSTRAINT [DF_Widgets_ZoneID]  DEFAULT ('zone1') FOR [ZoneID]
END


End
GO
/****** Object:  Default [DF_dna_Widgets_Scopes]    Script Date: 10/21/2010 21:20:55 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_dna_Widgets_Scopes]') AND parent_object_id = OBJECT_ID(N'[dbo].[dna_Widgets]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_dna_Widgets_Scopes]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[dna_Widgets] ADD  CONSTRAINT [DF_dna_Widgets_Scopes]  DEFAULT ((0)) FOR [Scope]
END


End
GO
/****** Object:  Default [DF_dna_Widgets_IsStatic]    Script Date: 10/21/2010 21:20:55 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_dna_Widgets_IsStatic]') AND parent_object_id = OBJECT_ID(N'[dbo].[dna_Widgets]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_dna_Widgets_IsStatic]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[dna_Widgets] ADD  CONSTRAINT [DF_dna_Widgets_IsStatic]  DEFAULT ((0)) FOR [IsStatic]
END


End
GO
/****** Object:  ForeignKey [FK_Permissions_PermissionSets]    Script Date: 10/21/2010 21:20:55 ******/
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Permissions_PermissionSets]') AND parent_object_id = OBJECT_ID(N'[dbo].[dna_Permissions]'))
ALTER TABLE [dbo].[dna_Permissions]  WITH CHECK ADD  CONSTRAINT [FK_Permissions_PermissionSets] FOREIGN KEY([PermissionSetID])
REFERENCES [dbo].[dna_PermissionSets] ([ID])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Permissions_PermissionSets]') AND parent_object_id = OBJECT_ID(N'[dbo].[dna_Permissions]'))
ALTER TABLE [dbo].[dna_Permissions] CHECK CONSTRAINT [FK_Permissions_PermissionSets]
GO
/****** Object:  ForeignKey [FK_PermsInRoles_Permissions]    Script Date: 10/21/2010 21:20:55 ******/
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_PermsInRoles_Permissions]') AND parent_object_id = OBJECT_ID(N'[dbo].[dna_PermsInRoles]'))
ALTER TABLE [dbo].[dna_PermsInRoles]  WITH CHECK ADD  CONSTRAINT [FK_PermsInRoles_Permissions] FOREIGN KEY([PermID])
REFERENCES [dbo].[dna_Permissions] ([ID])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_PermsInRoles_Permissions]') AND parent_object_id = OBJECT_ID(N'[dbo].[dna_PermsInRoles]'))
ALTER TABLE [dbo].[dna_PermsInRoles] CHECK CONSTRAINT [FK_PermsInRoles_Permissions]
GO
/****** Object:  ForeignKey [FK_PermsInRoles_PermsInRoles]    Script Date: 10/21/2010 21:20:55 ******/
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_PermsInRoles_PermsInRoles]') AND parent_object_id = OBJECT_ID(N'[dbo].[dna_PermsInRoles]'))
ALTER TABLE [dbo].[dna_PermsInRoles]  WITH CHECK ADD  CONSTRAINT [FK_PermsInRoles_PermsInRoles] FOREIGN KEY([PermID], [RoleName])
REFERENCES [dbo].[dna_PermsInRoles] ([PermID], [RoleName])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_PermsInRoles_PermsInRoles]') AND parent_object_id = OBJECT_ID(N'[dbo].[dna_PermsInRoles]'))
ALTER TABLE [dbo].[dna_PermsInRoles] CHECK CONSTRAINT [FK_PermsInRoles_PermsInRoles]
GO
/****** Object:  ForeignKey [FK_dna_WebPageRoles_dna_WebPages]    Script Date: 10/21/2010 21:20:55 ******/
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_dna_WebPageRoles_dna_WebPages]') AND parent_object_id = OBJECT_ID(N'[dbo].[dna_WebPageRoles]'))
ALTER TABLE [dbo].[dna_WebPageRoles]  WITH CHECK ADD  CONSTRAINT [FK_dna_WebPageRoles_dna_WebPages] FOREIGN KEY([PageID])
REFERENCES [dbo].[dna_WebPages] ([ID])
ON DELETE CASCADE
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_dna_WebPageRoles_dna_WebPages]') AND parent_object_id = OBJECT_ID(N'[dbo].[dna_WebPageRoles]'))
ALTER TABLE [dbo].[dna_WebPageRoles] CHECK CONSTRAINT [FK_dna_WebPageRoles_dna_WebPages]
GO
/****** Object:  ForeignKey [FK_dna_Web_dna_WebPages]    Script Date: 10/21/2010 21:20:55 ******/
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_dna_Web_dna_WebPages]') AND parent_object_id = OBJECT_ID(N'[dbo].[dna_WebPages]'))
ALTER TABLE [dbo].[dna_WebPages]  WITH CHECK ADD  CONSTRAINT [FK_dna_Web_dna_WebPages] FOREIGN KEY([WebID])
REFERENCES [dbo].[dna_WebSettings] ([Id])
ON DELETE CASCADE
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_dna_Web_dna_WebPages]') AND parent_object_id = OBJECT_ID(N'[dbo].[dna_WebPages]'))
ALTER TABLE [dbo].[dna_WebPages] CHECK CONSTRAINT [FK_dna_Web_dna_WebPages]
GO
/****** Object:  ForeignKey [FK_dna_WidgetDescriptor_dna_PackageInfos]    Script Date: 10/21/2010 21:20:55 ******/
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_dna_WidgetDescriptor_dna_PackageInfos]') AND parent_object_id = OBJECT_ID(N'[dbo].[dna_WidgetDescriptors]'))
ALTER TABLE [dbo].[dna_WidgetDescriptors]  WITH CHECK ADD  CONSTRAINT [FK_dna_WidgetDescriptor_dna_PackageInfos] FOREIGN KEY([PackageID])
REFERENCES [dbo].[dna_PackageInfos] ([ID])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_dna_WidgetDescriptor_dna_PackageInfos]') AND parent_object_id = OBJECT_ID(N'[dbo].[dna_WidgetDescriptors]'))
ALTER TABLE [dbo].[dna_WidgetDescriptors] CHECK CONSTRAINT [FK_dna_WidgetDescriptor_dna_PackageInfos]
GO
/****** Object:  ForeignKey [FK_WidgetMetas_Categories]    Script Date: 10/21/2010 21:20:55 ******/
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_WidgetMetas_Categories]') AND parent_object_id = OBJECT_ID(N'[dbo].[dna_WidgetDescriptors]'))
ALTER TABLE [dbo].[dna_WidgetDescriptors]  WITH CHECK ADD  CONSTRAINT [FK_WidgetMetas_Categories] FOREIGN KEY([CatID])
REFERENCES [dbo].[dna_WidgetCategories] ([Id])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_WidgetMetas_Categories]') AND parent_object_id = OBJECT_ID(N'[dbo].[dna_WidgetDescriptors]'))
ALTER TABLE [dbo].[dna_WidgetDescriptors] CHECK CONSTRAINT [FK_WidgetMetas_Categories]
GO
/****** Object:  ForeignKey [FK_dna_Widgets_dna_WidgetDescriptors]    Script Date: 10/21/2010 21:20:55 ******/
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_dna_Widgets_dna_WidgetDescriptors]') AND parent_object_id = OBJECT_ID(N'[dbo].[dna_Widgets]'))
ALTER TABLE [dbo].[dna_Widgets]  WITH CHECK ADD  CONSTRAINT [FK_dna_Widgets_dna_WidgetDescriptors] FOREIGN KEY([DescriptorID])
REFERENCES [dbo].[dna_WidgetDescriptors] ([ID])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_dna_Widgets_dna_WidgetDescriptors]') AND parent_object_id = OBJECT_ID(N'[dbo].[dna_Widgets]'))
ALTER TABLE [dbo].[dna_Widgets] CHECK CONSTRAINT [FK_dna_Widgets_dna_WidgetDescriptors]
GO
/****** Object:  ForeignKey [FK_Widgets_WebPages]    Script Date: 10/21/2010 21:20:55 ******/
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Widgets_WebPages]') AND parent_object_id = OBJECT_ID(N'[dbo].[dna_Widgets]'))
ALTER TABLE [dbo].[dna_Widgets]  WITH CHECK ADD  CONSTRAINT [FK_Widgets_WebPages] FOREIGN KEY([PageID])
REFERENCES [dbo].[dna_WebPages] ([ID])
ON DELETE CASCADE
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Widgets_WebPages]') AND parent_object_id = OBJECT_ID(N'[dbo].[dna_Widgets]'))
ALTER TABLE [dbo].[dna_Widgets] CHECK CONSTRAINT [FK_Widgets_WebPages]
GO

-- ===============================================================================
-- Author:		<Ray liang>
-- Create date: <2010-10-21>
-- Description:	<Install the tables and storeprocedures for DotNetAge publishing application plugin>
-- Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
-- Dual licensed under the MIT and GPL licenses:
-- http://www.opensource.org/licenses/mit-license.php
-- http://www.gnu.org/licenses/gpl.html
-- ===============================================================================

USE [PlaceholderForDbName]
GO
/****** Object:  Table [dbo].[publishing_Category]    Script Date: 10/21/2010 21:37:13 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[publishing_Category]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[publishing_Category](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[Title] [nvarchar](50) NOT NULL,
	[Description] [ntext] NULL,
	[Url] [nvarchar](1024) NULL,
	[ParentID] [int] NULL,
	[IsModerated] [bit] NOT NULL,
	[EnableVersioning] [bit] NOT NULL,
	[ArticleType] [int] NULL,
	[TotalPosts] [int] NOT NULL,
	[LastPosted] [datetime] NULL,
	[Path] [nvarchar](1024) NULL,
	[Pos] [int] NOT NULL,
	[AllowAnonymousPostComment] [bit] NOT NULL,
 CONSTRAINT [PK_ArticleCategories] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[publishing_Articles]    Script Date: 10/21/2010 21:37:13 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[publishing_Articles]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[publishing_Articles](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[Title] [nvarchar](255) NOT NULL,
	[Summary] [ntext] NULL,
	[Body] [ntext] NULL,
	[Tags] [nvarchar](255) NULL,
	[Reads] [int] NOT NULL,
	[Rating] [float] NOT NULL,
	[LastModified] [datetime] NOT NULL,
	[Posted] [datetime] NOT NULL,
	[UserName] [nvarchar](50) NULL,
	[ParentID] [int] NULL,
	[Version] [int] NOT NULL,
	[CategoryID] [int] NOT NULL,
	[IsPublished] [bit] NOT NULL,
	[IsAppoved] [bit] NOT NULL,
	[ContentFormat] [int] NOT NULL,
	[TotalRatings] [int] NOT NULL,
	[TotalComments] [int] NOT NULL,
	[Language] [nvarchar](50) NULL,
	[PingUrls] [ntext] NULL,
	[Pos] [int] NOT NULL,
	[Path] [nvarchar](1024) NULL,
	[AllowPingback] [bit] NOT NULL,
	[IsPrivate] [bit] NOT NULL,
	[PermaLink] [nvarchar](1024) NULL,
	[AllowComments] [bit] NOT NULL,
	[Categories] [nvarchar](1024) NULL,
	[SendTrackbackUrls] [ntext] NULL,
	[Slug] [nvarchar](1024) NULL,
	[RelatedPosts] [nvarchar](1024) NULL,
	[Password] [nvarchar](50) NULL,
 CONSTRAINT [PK_Articles] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[publishing_ArticleTracks]    Script Date: 10/21/2010 21:37:13 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[publishing_ArticleTracks]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[publishing_ArticleTracks](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[HasRead] [datetime] NOT NULL,
	[UserName] [nvarchar](1024) NULL,
	[IPAddress] [nchar](50) NULL,
	[ArticleID] [int] NOT NULL,
	[UserAgent] [nvarchar](1024) NULL,
 CONSTRAINT [PK_authoring_articlereads] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[publishing_Versions]    Script Date: 10/21/2010 21:37:13 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[publishing_Versions]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[publishing_Versions](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[Body] [ntext] NULL,
	[LastModified] [datetime] NOT NULL,
	[Version] [int] NULL,
	[ArticleID] [int] NOT NULL,
	[Modified] [nvarchar](50) NULL,
 CONSTRAINT [PK_ArticleVersions] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[publishing_TranslatedCopy]    Script Date: 10/21/2010 21:37:13 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[publishing_TranslatedCopy]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[publishing_TranslatedCopy](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[ArticleID] [int] NOT NULL,
	[Body] [ntext] NULL,
	[Title] [nvarchar](255) NULL,
	[Summary] [ntext] NULL,
	[Language] [nvarchar](50) NULL,
	[ContentFormat] [int] NOT NULL,
 CONSTRAINT [PK_TranslatedCopy] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[publishing_Ratings]    Script Date: 10/21/2010 21:37:13 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[publishing_Ratings]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[publishing_Ratings](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[IP] [nvarchar](50) NULL,
	[Rating] [int] NOT NULL,
	[ArticleID] [int] NOT NULL,
 CONSTRAINT [PK_ArticleRatings] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[publishing_Comments]    Script Date: 10/21/2010 21:37:13 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[publishing_Comments]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[publishing_Comments](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[ArticleID] [int] NOT NULL,
	[UserName] [nvarchar](50) NULL,
	[Posted] [datetime] NOT NULL,
	[IP] [nvarchar](50) NOT NULL,
	[Body] [ntext] NULL,
	[Email] [nvarchar](1024) NULL,
	[WebSite] [nvarchar](1024) NULL,
	[Title] [nvarchar](1024) NULL,
	[IsPingback] [bit] NOT NULL,
	[IsTrackback] [bit] NOT NULL,
 CONSTRAINT [PK_Comments] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
END
GO
/****** Object:  Default [DF_icontent_Articles_Reads]    Script Date: 10/21/2010 21:37:13 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_icontent_Articles_Reads]') AND parent_object_id = OBJECT_ID(N'[dbo].[publishing_Articles]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_icontent_Articles_Reads]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[publishing_Articles] ADD  CONSTRAINT [DF_icontent_Articles_Reads]  DEFAULT ((0)) FOR [Reads]
END


End
GO
/****** Object:  Default [DF_icontent_Articles_Rating]    Script Date: 10/21/2010 21:37:13 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_icontent_Articles_Rating]') AND parent_object_id = OBJECT_ID(N'[dbo].[publishing_Articles]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_icontent_Articles_Rating]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[publishing_Articles] ADD  CONSTRAINT [DF_icontent_Articles_Rating]  DEFAULT ((0)) FOR [Rating]
END


End
GO
/****** Object:  Default [DF_icontent_Articles_LastModified]    Script Date: 10/21/2010 21:37:13 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_icontent_Articles_LastModified]') AND parent_object_id = OBJECT_ID(N'[dbo].[publishing_Articles]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_icontent_Articles_LastModified]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[publishing_Articles] ADD  CONSTRAINT [DF_icontent_Articles_LastModified]  DEFAULT (getdate()) FOR [LastModified]
END


End
GO
/****** Object:  Default [DF_icontent_Articles_Posted]    Script Date: 10/21/2010 21:37:13 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_icontent_Articles_Posted]') AND parent_object_id = OBJECT_ID(N'[dbo].[publishing_Articles]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_icontent_Articles_Posted]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[publishing_Articles] ADD  CONSTRAINT [DF_icontent_Articles_Posted]  DEFAULT (getdate()) FOR [Posted]
END


End
GO
/****** Object:  Default [DF_icontent_Articles_Version]    Script Date: 10/21/2010 21:37:13 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_icontent_Articles_Version]') AND parent_object_id = OBJECT_ID(N'[dbo].[publishing_Articles]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_icontent_Articles_Version]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[publishing_Articles] ADD  CONSTRAINT [DF_icontent_Articles_Version]  DEFAULT ((0)) FOR [Version]
END


End
GO
/****** Object:  Default [DF_icontent_Articles_IsPublished]    Script Date: 10/21/2010 21:37:13 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_icontent_Articles_IsPublished]') AND parent_object_id = OBJECT_ID(N'[dbo].[publishing_Articles]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_icontent_Articles_IsPublished]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[publishing_Articles] ADD  CONSTRAINT [DF_icontent_Articles_IsPublished]  DEFAULT ((1)) FOR [IsPublished]
END


End
GO
/****** Object:  Default [DF_icontent_Articles_IsAppoved]    Script Date: 10/21/2010 21:37:13 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_icontent_Articles_IsAppoved]') AND parent_object_id = OBJECT_ID(N'[dbo].[publishing_Articles]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_icontent_Articles_IsAppoved]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[publishing_Articles] ADD  CONSTRAINT [DF_icontent_Articles_IsAppoved]  DEFAULT ((1)) FOR [IsAppoved]
END


End
GO
/****** Object:  Default [DF_authoring_Articles_ContentFormat]    Script Date: 10/21/2010 21:37:13 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_authoring_Articles_ContentFormat]') AND parent_object_id = OBJECT_ID(N'[dbo].[publishing_Articles]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_authoring_Articles_ContentFormat]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[publishing_Articles] ADD  CONSTRAINT [DF_authoring_Articles_ContentFormat]  DEFAULT ((1)) FOR [ContentFormat]
END


End
GO
/****** Object:  Default [DF_Articles_TotalRatings]    Script Date: 10/21/2010 21:37:13 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_Articles_TotalRatings]') AND parent_object_id = OBJECT_ID(N'[dbo].[publishing_Articles]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_Articles_TotalRatings]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[publishing_Articles] ADD  CONSTRAINT [DF_Articles_TotalRatings]  DEFAULT ((0)) FOR [TotalRatings]
END


End
GO
/****** Object:  Default [DF_Articles_TotalComments]    Script Date: 10/21/2010 21:37:13 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_Articles_TotalComments]') AND parent_object_id = OBJECT_ID(N'[dbo].[publishing_Articles]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_Articles_TotalComments]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[publishing_Articles] ADD  CONSTRAINT [DF_Articles_TotalComments]  DEFAULT ((0)) FOR [TotalComments]
END


End
GO
/****** Object:  Default [DF_icontent_Articles_Pos]    Script Date: 10/21/2010 21:37:13 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_icontent_Articles_Pos]') AND parent_object_id = OBJECT_ID(N'[dbo].[publishing_Articles]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_icontent_Articles_Pos]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[publishing_Articles] ADD  CONSTRAINT [DF_icontent_Articles_Pos]  DEFAULT ((0)) FOR [Pos]
END


End
GO
/****** Object:  Default [DF_authoring_Articles_AllowPingback]    Script Date: 10/21/2010 21:37:13 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_authoring_Articles_AllowPingback]') AND parent_object_id = OBJECT_ID(N'[dbo].[publishing_Articles]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_authoring_Articles_AllowPingback]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[publishing_Articles] ADD  CONSTRAINT [DF_authoring_Articles_AllowPingback]  DEFAULT ((1)) FOR [AllowPingback]
END


End
GO
/****** Object:  Default [DF_authoring_Articles_IsPrivate]    Script Date: 10/21/2010 21:37:13 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_authoring_Articles_IsPrivate]') AND parent_object_id = OBJECT_ID(N'[dbo].[publishing_Articles]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_authoring_Articles_IsPrivate]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[publishing_Articles] ADD  CONSTRAINT [DF_authoring_Articles_IsPrivate]  DEFAULT ((0)) FOR [IsPrivate]
END


End
GO
/****** Object:  Default [DF_authoring_Articles_AllowComments]    Script Date: 10/21/2010 21:37:13 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_authoring_Articles_AllowComments]') AND parent_object_id = OBJECT_ID(N'[dbo].[publishing_Articles]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_authoring_Articles_AllowComments]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[publishing_Articles] ADD  CONSTRAINT [DF_authoring_Articles_AllowComments]  DEFAULT ((1)) FOR [AllowComments]
END


End
GO
/****** Object:  Default [DF_authoring_articlereads_HasRead]    Script Date: 10/21/2010 21:37:13 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_authoring_articlereads_HasRead]') AND parent_object_id = OBJECT_ID(N'[dbo].[publishing_ArticleTracks]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_authoring_articlereads_HasRead]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[publishing_ArticleTracks] ADD  CONSTRAINT [DF_authoring_articlereads_HasRead]  DEFAULT (getdate()) FOR [HasRead]
END


End
GO
/****** Object:  Default [DF_ArticleCategories_IsModerated]    Script Date: 10/21/2010 21:37:13 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_ArticleCategories_IsModerated]') AND parent_object_id = OBJECT_ID(N'[dbo].[publishing_Category]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_ArticleCategories_IsModerated]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[publishing_Category] ADD  CONSTRAINT [DF_ArticleCategories_IsModerated]  DEFAULT ((0)) FOR [IsModerated]
END


End
GO
/****** Object:  Default [DF_ArticleCategories_EnableVersioning]    Script Date: 10/21/2010 21:37:13 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_ArticleCategories_EnableVersioning]') AND parent_object_id = OBJECT_ID(N'[dbo].[publishing_Category]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_ArticleCategories_EnableVersioning]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[publishing_Category] ADD  CONSTRAINT [DF_ArticleCategories_EnableVersioning]  DEFAULT ((1)) FOR [EnableVersioning]
END


End
GO
/****** Object:  Default [DF_ArticleCategories_ArticleType]    Script Date: 10/21/2010 21:37:13 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_ArticleCategories_ArticleType]') AND parent_object_id = OBJECT_ID(N'[dbo].[publishing_Category]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_ArticleCategories_ArticleType]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[publishing_Category] ADD  CONSTRAINT [DF_ArticleCategories_ArticleType]  DEFAULT ((0)) FOR [ArticleType]
END


End
GO
/****** Object:  Default [DF_ArticleCategories_TotalPosts]    Script Date: 10/21/2010 21:37:13 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_ArticleCategories_TotalPosts]') AND parent_object_id = OBJECT_ID(N'[dbo].[publishing_Category]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_ArticleCategories_TotalPosts]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[publishing_Category] ADD  CONSTRAINT [DF_ArticleCategories_TotalPosts]  DEFAULT ((0)) FOR [TotalPosts]
END


End
GO
/****** Object:  Default [DF_authoring_Category_Pos]    Script Date: 10/21/2010 21:37:13 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_authoring_Category_Pos]') AND parent_object_id = OBJECT_ID(N'[dbo].[publishing_Category]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_authoring_Category_Pos]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[publishing_Category] ADD  CONSTRAINT [DF_authoring_Category_Pos]  DEFAULT ((0)) FOR [Pos]
END


End
GO
/****** Object:  Default [DF_authoring_Category_AllowAnonymousPostComment]    Script Date: 10/21/2010 21:37:13 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_authoring_Category_AllowAnonymousPostComment]') AND parent_object_id = OBJECT_ID(N'[dbo].[publishing_Category]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_authoring_Category_AllowAnonymousPostComment]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[publishing_Category] ADD  CONSTRAINT [DF_authoring_Category_AllowAnonymousPostComment]  DEFAULT ((0)) FOR [AllowAnonymousPostComment]
END


End
GO
/****** Object:  Default [DF_icontent_Comments_Posted]    Script Date: 10/21/2010 21:37:13 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_icontent_Comments_Posted]') AND parent_object_id = OBJECT_ID(N'[dbo].[publishing_Comments]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_icontent_Comments_Posted]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[publishing_Comments] ADD  CONSTRAINT [DF_icontent_Comments_Posted]  DEFAULT (getdate()) FOR [Posted]
END


End
GO
/****** Object:  Default [DF_authoring_Comments_IsPingback]    Script Date: 10/21/2010 21:37:13 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_authoring_Comments_IsPingback]') AND parent_object_id = OBJECT_ID(N'[dbo].[publishing_Comments]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_authoring_Comments_IsPingback]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[publishing_Comments] ADD  CONSTRAINT [DF_authoring_Comments_IsPingback]  DEFAULT ((0)) FOR [IsPingback]
END


End
GO
/****** Object:  Default [DF_authoring_Comments_IsTrackback]    Script Date: 10/21/2010 21:37:13 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_authoring_Comments_IsTrackback]') AND parent_object_id = OBJECT_ID(N'[dbo].[publishing_Comments]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_authoring_Comments_IsTrackback]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[publishing_Comments] ADD  CONSTRAINT [DF_authoring_Comments_IsTrackback]  DEFAULT ((0)) FOR [IsTrackback]
END


End
GO
/****** Object:  Default [DF_authoring_TranslatedCopy_ContentFormat]    Script Date: 10/21/2010 21:37:13 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_authoring_TranslatedCopy_ContentFormat]') AND parent_object_id = OBJECT_ID(N'[dbo].[publishing_TranslatedCopy]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_authoring_TranslatedCopy_ContentFormat]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[publishing_TranslatedCopy] ADD  CONSTRAINT [DF_authoring_TranslatedCopy_ContentFormat]  DEFAULT ((0)) FOR [ContentFormat]
END


End
GO
/****** Object:  Default [DF_icontent_Versions_LastModified]    Script Date: 10/21/2010 21:37:13 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_icontent_Versions_LastModified]') AND parent_object_id = OBJECT_ID(N'[dbo].[publishing_Versions]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_icontent_Versions_LastModified]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[publishing_Versions] ADD  CONSTRAINT [DF_icontent_Versions_LastModified]  DEFAULT (getdate()) FOR [LastModified]
END


End
GO
/****** Object:  ForeignKey [FK_Articles_ArticleCategories]    Script Date: 10/21/2010 21:37:13 ******/
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Articles_ArticleCategories]') AND parent_object_id = OBJECT_ID(N'[dbo].[publishing_Articles]'))
ALTER TABLE [dbo].[publishing_Articles]  WITH CHECK ADD  CONSTRAINT [FK_Articles_ArticleCategories] FOREIGN KEY([CategoryID])
REFERENCES [dbo].[publishing_Category] ([ID])
ON DELETE CASCADE
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Articles_ArticleCategories]') AND parent_object_id = OBJECT_ID(N'[dbo].[publishing_Articles]'))
ALTER TABLE [dbo].[publishing_Articles] CHECK CONSTRAINT [FK_Articles_ArticleCategories]
GO
/****** Object:  ForeignKey [FK_authoring_ArticleTracks_authoring_Articles]    Script Date: 10/21/2010 21:37:13 ******/
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_authoring_ArticleTracks_authoring_Articles]') AND parent_object_id = OBJECT_ID(N'[dbo].[publishing_ArticleTracks]'))
ALTER TABLE [dbo].[publishing_ArticleTracks]  WITH CHECK ADD  CONSTRAINT [FK_authoring_ArticleTracks_authoring_Articles] FOREIGN KEY([ArticleID])
REFERENCES [dbo].[publishing_Articles] ([ID])
ON DELETE CASCADE
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_authoring_ArticleTracks_authoring_Articles]') AND parent_object_id = OBJECT_ID(N'[dbo].[publishing_ArticleTracks]'))
ALTER TABLE [dbo].[publishing_ArticleTracks] CHECK CONSTRAINT [FK_authoring_ArticleTracks_authoring_Articles]
GO
/****** Object:  ForeignKey [FK_Comments_Articles]    Script Date: 10/21/2010 21:37:13 ******/
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Comments_Articles]') AND parent_object_id = OBJECT_ID(N'[dbo].[publishing_Comments]'))
ALTER TABLE [dbo].[publishing_Comments]  WITH CHECK ADD  CONSTRAINT [FK_Comments_Articles] FOREIGN KEY([ArticleID])
REFERENCES [dbo].[publishing_Articles] ([ID])
ON DELETE CASCADE
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Comments_Articles]') AND parent_object_id = OBJECT_ID(N'[dbo].[publishing_Comments]'))
ALTER TABLE [dbo].[publishing_Comments] CHECK CONSTRAINT [FK_Comments_Articles]
GO
/****** Object:  ForeignKey [FK_ArticleRatings_Articles]    Script Date: 10/21/2010 21:37:13 ******/
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_ArticleRatings_Articles]') AND parent_object_id = OBJECT_ID(N'[dbo].[publishing_Ratings]'))
ALTER TABLE [dbo].[publishing_Ratings]  WITH CHECK ADD  CONSTRAINT [FK_ArticleRatings_Articles] FOREIGN KEY([ArticleID])
REFERENCES [dbo].[publishing_Articles] ([ID])
ON DELETE CASCADE
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_ArticleRatings_Articles]') AND parent_object_id = OBJECT_ID(N'[dbo].[publishing_Ratings]'))
ALTER TABLE [dbo].[publishing_Ratings] CHECK CONSTRAINT [FK_ArticleRatings_Articles]
GO
/****** Object:  ForeignKey [FK_TranslatedCopy_Articles]    Script Date: 10/21/2010 21:37:13 ******/
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_TranslatedCopy_Articles]') AND parent_object_id = OBJECT_ID(N'[dbo].[publishing_TranslatedCopy]'))
ALTER TABLE [dbo].[publishing_TranslatedCopy]  WITH CHECK ADD  CONSTRAINT [FK_TranslatedCopy_Articles] FOREIGN KEY([ArticleID])
REFERENCES [dbo].[publishing_Articles] ([ID])
ON DELETE CASCADE
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_TranslatedCopy_Articles]') AND parent_object_id = OBJECT_ID(N'[dbo].[publishing_TranslatedCopy]'))
ALTER TABLE [dbo].[publishing_TranslatedCopy] CHECK CONSTRAINT [FK_TranslatedCopy_Articles]
GO
/****** Object:  ForeignKey [FK_icontent_Versions_icontent_Articles]    Script Date: 10/21/2010 21:37:13 ******/
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_icontent_Versions_icontent_Articles]') AND parent_object_id = OBJECT_ID(N'[dbo].[publishing_Versions]'))
ALTER TABLE [dbo].[publishing_Versions]  WITH CHECK ADD  CONSTRAINT [FK_icontent_Versions_icontent_Articles] FOREIGN KEY([ArticleID])
REFERENCES [dbo].[publishing_Articles] ([ID])
ON DELETE CASCADE
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_icontent_Versions_icontent_Articles]') AND parent_object_id = OBJECT_ID(N'[dbo].[publishing_Versions]'))
ALTER TABLE [dbo].[publishing_Versions] CHECK CONSTRAINT [FK_icontent_Versions_icontent_Articles]
GO

-- ===============================================================================
-- Author:		<Ray liang>
-- Create date: <2010-10-21>
-- Description:	<Install the tables and storeprocedures for DotNetAge community application plugin.>
-- Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
-- Dual licensed under the MIT and GPL licenses:
-- http://www.opensource.org/licenses/mit-license.php
-- http://www.gnu.org/licenses/gpl.html
-- ===============================================================================


USE [PlaceholderForDbName]
GO
/****** Object:  Table [dbo].[community_Forums]    Script Date: 10/21/2010 21:35:03 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[community_Forums]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[community_Forums](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[Title] [nvarchar](255) NOT NULL,
	[Description] [ntext] NULL,
	[IsGroup] [bit] NOT NULL,
	[ParentID] [int] NOT NULL,
	[IsModerated] [bit] NOT NULL,
	[TotalPosts] [int] NOT NULL,
	[TotalThreads] [int] NOT NULL,
	[LastPostID] [int] NULL,
	[LastPostedUser] [nvarchar](50) NULL,
	[LastPosted] [datetime] NULL,
	[Theme] [nvarchar](255) NULL,
	[IsLock] [bit] NOT NULL,
	[Pos] [int] NOT NULL,
	[AllowAttachment] [bit] NOT NULL,
	[AllowAnonymous] [bit] NOT NULL,
 CONSTRAINT [PK_Forums] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[community_Ranks]    Script Date: 10/21/2010 21:35:03 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[community_Ranks]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[community_Ranks](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[Name] [nvarchar](255) NOT NULL,
	[IsStart] [bit] NOT NULL,
	[MinimumPosts] [int] NOT NULL,
	[ImageUrl] [nvarchar](1024) NULL,
 CONSTRAINT [PK_iforum_Ranks] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[community_Moderators]    Script Date: 10/21/2010 21:35:03 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[community_Moderators]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[community_Moderators](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[Moderator] [nvarchar](50) NOT NULL,
	[ForumID] [int] NOT NULL,
 CONSTRAINT [PK_Moderators] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[community_Threads]    Script Date: 10/21/2010 21:35:03 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[community_Threads]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[community_Threads](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[Title] [nvarchar](255) NOT NULL,
	[Author] [nvarchar](50) NOT NULL,
	[IsPinned] [bit] NOT NULL,
	[TotalReads] [int] NOT NULL,
	[TotalPosts] [int] NOT NULL,
	[Posted] [datetime] NOT NULL,
	[LastPosted] [datetime] NOT NULL,
	[LastPostUser] [nvarchar](50) NOT NULL,
	[LastPostID] [int] NULL,
	[ForumID] [int] NOT NULL,
	[ThreadType] [int] NOT NULL,
	[IsLocked] [bit] NOT NULL,
	[Appoved] [datetime] NULL,
	[Moderator] [nvarchar](50) NULL,
	[IsAppoved] [bit] NOT NULL,
	[LinkTo] [nvarchar](1024) NULL,
 CONSTRAINT [PK_Threads] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[community_Posts]    Script Date: 10/21/2010 21:35:03 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[community_Posts]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[community_Posts](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[UserName] [nvarchar](50) NOT NULL,
	[Title] [nvarchar](255) NULL,
	[Body] [ntext] NULL,
	[IsThread] [bit] NOT NULL,
	[Posted] [datetime] NOT NULL,
	[LastModified] [datetime] NOT NULL,
	[Reads] [int] NOT NULL,
	[Ratings] [int] NOT NULL,
	[IsAppoved] [bit] NOT NULL,
	[Pos] [int] NOT NULL,
	[ForumID] [int] NOT NULL,
	[ThreadID] [int] NOT NULL,
	[ParentID] [int] NULL,
	[IsLocked] [bit] NOT NULL,
	[IP] [nvarchar](50) NULL,
	[Appoved] [datetime] NULL,
	[Moderator] [nvarchar](50) NULL,
	[IsDeleted] [bit] NOT NULL,
	[DeletedReason] [ntext] NULL,
	[Deleted] [date] NULL,
	[DeleteBy] [nvarchar](50) NULL,
 CONSTRAINT [PK_Posts] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
END
GO
/****** Object:  StoredProcedure [dbo].[community_thread_UpdateStates]    Script Date: 10/21/2010 21:35:03 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[community_thread_UpdateStates]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'
-- =============================================
-- Author:		<Ray liang>
-- Create date: <2010-8-16>
-- Description:	<This store procedure use to update the thread state>
-- Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
-- Dual licensed under the MIT and GPL licenses:
-- http://www.opensource.org/licenses/mit-license.php
-- http://www.gnu.org/licenses/gpl.html
-- =============================================
CREATE PROCEDURE [dbo].[community_thread_UpdateStates]
@id int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    DECLARE @totalPosts int,
            @lastPostUser nvarchar(50),   
            @lastPosted datetime,
            @lastPostID int  
   
   
    SELECT @lastPostUser=NULL
    
    SELECT @totalPosts=(SELECT COUNT([ID]) FROM community_Posts WHERE ThreadID=@id)

    IF (@totalPosts>0)
    BEGIN
      SELECT @lastPostID=(SELECT TOP 1 [ID]
                          FROM community_Posts
                          WHERE ThreadID=@id 
                          ORDER BY Posted desc)
      
      SELECT @lastPosted=Posted,
             @lastPostUser=UserName
      FROM community_Posts
      WHERE ID=@lastPostID                    
      
    END                      
    ELSE BEGIN
      SELECT @lastPostID=NULL,
             @lastPostUser=NULL,
             @lastPosted=NULL
    END
                            
    UPDATE community_Threads
    SET TotalPosts=@totalPosts,
        LastPosted=@lastPosted,
        LastPostID=@lastPostID,
        LastPostUser=@lastPostUser
    WHERE ID=@id
    
END

' 
END
GO
/****** Object:  StoredProcedure [dbo].[community_statistics]    Script Date: 10/21/2010 21:35:03 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[community_statistics]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[community_statistics]
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	SELECT TotalThreads=(SELECT COUNT(ID) FROM community_Threads),
	       TotalPosts=(SELECT COUNT(ID) FROM community_Posts WHERE IsDeleted<>1),
	       TodayPosts=(SELECT COUNT(ID) FROM community_Posts WHERE IsDeleted<>1 AND DATEPART(YYYY,Posted)=DATEPART(YYYY,GETDATE()) AND DATEPART(M,Posted)=DATEPART(M,GETDATE()) AND DATEPART(D,Posted)=DATEPART(D,GETDATE())),
	       TodayThreads=(SELECT COUNT(ID) FROM community_Threads WHERE DATEPART(YYYY,Posted)=DATEPART(YYYY,GETDATE()) AND DATEPART(M,Posted)=DATEPART(M,GETDATE()) AND DATEPART(D,Posted)=DATEPART(D,GETDATE()))
END
' 
END
GO
/****** Object:  StoredProcedure [dbo].[community_forum_UpdateStates]    Script Date: 10/21/2010 21:35:03 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[community_forum_UpdateStates]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'
-- Batch submitted through debugger: SQLQuery7.sql|7|0|C:\Users\Ray\AppData\Local\Temp\~vs7AA1.sql
-- =============================================
-- Author:		<Ray liang>
-- Create date: <2010-8-16>
-- Description:	<This store procedure use to update the forum state>
-- Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
-- Dual licensed under the MIT and GPL licenses:
-- http://www.opensource.org/licenses/mit-license.php
-- http://www.gnu.org/licenses/gpl.html
-- =============================================
CREATE PROCEDURE [dbo].[community_forum_UpdateStates]
@id int
AS
BEGIN
	SET NOCOUNT ON;
    DECLARE @totalPosts int,
            @lastPostUser nvarchar(50),   
            @lastPosted datetime,
            @lastPostID int  
   
   
    SELECT @lastPostUser=NULL
    
    SELECT @totalPosts=(SELECT COUNT([ID]) FROM community_Posts WHERE ForumID=@id AND IsAppoved=1)

    IF (@totalPosts>0)
    BEGIN
      SELECT @lastPostID=(SELECT TOP 1 [ID]
                          FROM community_Posts
                          WHERE ForumID=@id AND IsAppoved=1
                          ORDER BY Posted desc)
      
      SELECT @lastPosted=Posted,
             @lastPostUser=UserName
      FROM community_Posts
      WHERE ID=@lastPostID                    
      
    END                      
    ELSE BEGIN
      SELECT @lastPostID=NULL,
             @lastPostUser=NULL,
             @lastPosted=NULL
    END
                            
    UPDATE community_Forums
    SET TotalPosts=@totalPosts,
        TotalThreads=(SELECT COUNT([ID]) FROM community_Threads WHERE ForumID=@id AND IsAppoved=1),
        LastPosted=@lastPosted,
        LastPostID=@lastPostID,
        LastPostedUser=@lastPostUser
    WHERE ID=@id
    
END

' 
END
GO
/****** Object:  Table [dbo].[community_attachments]    Script Date: 10/21/2010 21:35:03 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[community_attachments]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[community_attachments](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[FileName] [nvarchar](1024) NOT NULL,
	[PostID] [int] NOT NULL,
	[ContentType] [nvarchar](50) NULL,
 CONSTRAINT [PK_community_attachments] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
/****** Object:  Default [DF_iforum_Forums_IsGroup]    Script Date: 10/21/2010 21:35:03 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_iforum_Forums_IsGroup]') AND parent_object_id = OBJECT_ID(N'[dbo].[community_Forums]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_iforum_Forums_IsGroup]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[community_Forums] ADD  CONSTRAINT [DF_iforum_Forums_IsGroup]  DEFAULT ((0)) FOR [IsGroup]
END


End
GO
/****** Object:  Default [DF_iforum_Forums_ParentID]    Script Date: 10/21/2010 21:35:03 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_iforum_Forums_ParentID]') AND parent_object_id = OBJECT_ID(N'[dbo].[community_Forums]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_iforum_Forums_ParentID]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[community_Forums] ADD  CONSTRAINT [DF_iforum_Forums_ParentID]  DEFAULT ((0)) FOR [ParentID]
END


End
GO
/****** Object:  Default [DF_iforum_Forums_IsModerated]    Script Date: 10/21/2010 21:35:03 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_iforum_Forums_IsModerated]') AND parent_object_id = OBJECT_ID(N'[dbo].[community_Forums]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_iforum_Forums_IsModerated]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[community_Forums] ADD  CONSTRAINT [DF_iforum_Forums_IsModerated]  DEFAULT ((0)) FOR [IsModerated]
END


End
GO
/****** Object:  Default [DF_iforum_Forums_TotalPosts]    Script Date: 10/21/2010 21:35:03 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_iforum_Forums_TotalPosts]') AND parent_object_id = OBJECT_ID(N'[dbo].[community_Forums]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_iforum_Forums_TotalPosts]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[community_Forums] ADD  CONSTRAINT [DF_iforum_Forums_TotalPosts]  DEFAULT ((0)) FOR [TotalPosts]
END


End
GO
/****** Object:  Default [DF_iforum_Forums_TotalThreads]    Script Date: 10/21/2010 21:35:03 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_iforum_Forums_TotalThreads]') AND parent_object_id = OBJECT_ID(N'[dbo].[community_Forums]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_iforum_Forums_TotalThreads]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[community_Forums] ADD  CONSTRAINT [DF_iforum_Forums_TotalThreads]  DEFAULT ((0)) FOR [TotalThreads]
END


End
GO
/****** Object:  Default [DF_iforum_Forums_LastPostID]    Script Date: 10/21/2010 21:35:03 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_iforum_Forums_LastPostID]') AND parent_object_id = OBJECT_ID(N'[dbo].[community_Forums]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_iforum_Forums_LastPostID]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[community_Forums] ADD  CONSTRAINT [DF_iforum_Forums_LastPostID]  DEFAULT ((0)) FOR [LastPostID]
END


End
GO
/****** Object:  Default [DF_iforum_Forums_IsLock]    Script Date: 10/21/2010 21:35:03 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_iforum_Forums_IsLock]') AND parent_object_id = OBJECT_ID(N'[dbo].[community_Forums]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_iforum_Forums_IsLock]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[community_Forums] ADD  CONSTRAINT [DF_iforum_Forums_IsLock]  DEFAULT ((0)) FOR [IsLock]
END


End
GO
/****** Object:  Default [DF_community_Forums_Pos]    Script Date: 10/21/2010 21:35:03 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_community_Forums_Pos]') AND parent_object_id = OBJECT_ID(N'[dbo].[community_Forums]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_community_Forums_Pos]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[community_Forums] ADD  CONSTRAINT [DF_community_Forums_Pos]  DEFAULT ((0)) FOR [Pos]
END


End
GO
/****** Object:  Default [DF_community_Forums_AllowAttachment]    Script Date: 10/21/2010 21:35:03 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_community_Forums_AllowAttachment]') AND parent_object_id = OBJECT_ID(N'[dbo].[community_Forums]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_community_Forums_AllowAttachment]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[community_Forums] ADD  CONSTRAINT [DF_community_Forums_AllowAttachment]  DEFAULT ((1)) FOR [AllowAttachment]
END


End
GO
/****** Object:  Default [DF_community_Forums_AllowAnonymous]    Script Date: 10/21/2010 21:35:03 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_community_Forums_AllowAnonymous]') AND parent_object_id = OBJECT_ID(N'[dbo].[community_Forums]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_community_Forums_AllowAnonymous]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[community_Forums] ADD  CONSTRAINT [DF_community_Forums_AllowAnonymous]  DEFAULT ((1)) FOR [AllowAnonymous]
END


End
GO
/****** Object:  Default [DF_iforum_Posts_IsThread]    Script Date: 10/21/2010 21:35:03 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_iforum_Posts_IsThread]') AND parent_object_id = OBJECT_ID(N'[dbo].[community_Posts]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_iforum_Posts_IsThread]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[community_Posts] ADD  CONSTRAINT [DF_iforum_Posts_IsThread]  DEFAULT ((0)) FOR [IsThread]
END


End
GO
/****** Object:  Default [DF_iforum_Posts_Posted]    Script Date: 10/21/2010 21:35:03 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_iforum_Posts_Posted]') AND parent_object_id = OBJECT_ID(N'[dbo].[community_Posts]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_iforum_Posts_Posted]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[community_Posts] ADD  CONSTRAINT [DF_iforum_Posts_Posted]  DEFAULT (getdate()) FOR [Posted]
END


End
GO
/****** Object:  Default [DF_iforum_Posts_LastModified]    Script Date: 10/21/2010 21:35:03 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_iforum_Posts_LastModified]') AND parent_object_id = OBJECT_ID(N'[dbo].[community_Posts]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_iforum_Posts_LastModified]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[community_Posts] ADD  CONSTRAINT [DF_iforum_Posts_LastModified]  DEFAULT (getdate()) FOR [LastModified]
END


End
GO
/****** Object:  Default [DF_iforum_Posts_Reads]    Script Date: 10/21/2010 21:35:03 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_iforum_Posts_Reads]') AND parent_object_id = OBJECT_ID(N'[dbo].[community_Posts]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_iforum_Posts_Reads]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[community_Posts] ADD  CONSTRAINT [DF_iforum_Posts_Reads]  DEFAULT ((0)) FOR [Reads]
END


End
GO
/****** Object:  Default [DF_iforum_Posts_Reating]    Script Date: 10/21/2010 21:35:03 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_iforum_Posts_Reating]') AND parent_object_id = OBJECT_ID(N'[dbo].[community_Posts]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_iforum_Posts_Reating]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[community_Posts] ADD  CONSTRAINT [DF_iforum_Posts_Reating]  DEFAULT ((0)) FOR [Ratings]
END


End
GO
/****** Object:  Default [DF_iforum_Posts_IsModerated]    Script Date: 10/21/2010 21:35:03 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_iforum_Posts_IsModerated]') AND parent_object_id = OBJECT_ID(N'[dbo].[community_Posts]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_iforum_Posts_IsModerated]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[community_Posts] ADD  CONSTRAINT [DF_iforum_Posts_IsModerated]  DEFAULT ((0)) FOR [IsAppoved]
END


End
GO
/****** Object:  Default [DF_iforum_Posts_Pos]    Script Date: 10/21/2010 21:35:03 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_iforum_Posts_Pos]') AND parent_object_id = OBJECT_ID(N'[dbo].[community_Posts]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_iforum_Posts_Pos]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[community_Posts] ADD  CONSTRAINT [DF_iforum_Posts_Pos]  DEFAULT ((0)) FOR [Pos]
END


End
GO
/****** Object:  Default [DF_iforum_Posts_IsLocked]    Script Date: 10/21/2010 21:35:03 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_iforum_Posts_IsLocked]') AND parent_object_id = OBJECT_ID(N'[dbo].[community_Posts]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_iforum_Posts_IsLocked]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[community_Posts] ADD  CONSTRAINT [DF_iforum_Posts_IsLocked]  DEFAULT ((0)) FOR [IsLocked]
END


End
GO
/****** Object:  Default [DF_community_Posts_IsDeleted]    Script Date: 10/21/2010 21:35:03 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_community_Posts_IsDeleted]') AND parent_object_id = OBJECT_ID(N'[dbo].[community_Posts]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_community_Posts_IsDeleted]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[community_Posts] ADD  CONSTRAINT [DF_community_Posts_IsDeleted]  DEFAULT ((0)) FOR [IsDeleted]
END


End
GO
/****** Object:  Default [DF_iforum_Ranks_IsStart]    Script Date: 10/21/2010 21:35:03 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_iforum_Ranks_IsStart]') AND parent_object_id = OBJECT_ID(N'[dbo].[community_Ranks]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_iforum_Ranks_IsStart]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[community_Ranks] ADD  CONSTRAINT [DF_iforum_Ranks_IsStart]  DEFAULT ((0)) FOR [IsStart]
END


End
GO
/****** Object:  Default [DF_iforum_Ranks_MinimumPosts]    Script Date: 10/21/2010 21:35:03 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_iforum_Ranks_MinimumPosts]') AND parent_object_id = OBJECT_ID(N'[dbo].[community_Ranks]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_iforum_Ranks_MinimumPosts]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[community_Ranks] ADD  CONSTRAINT [DF_iforum_Ranks_MinimumPosts]  DEFAULT ((0)) FOR [MinimumPosts]
END


End
GO
/****** Object:  Default [DF_iforum_Threads_IsPinned]    Script Date: 10/21/2010 21:35:03 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_iforum_Threads_IsPinned]') AND parent_object_id = OBJECT_ID(N'[dbo].[community_Threads]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_iforum_Threads_IsPinned]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[community_Threads] ADD  CONSTRAINT [DF_iforum_Threads_IsPinned]  DEFAULT ((0)) FOR [IsPinned]
END


End
GO
/****** Object:  Default [DF_iforum_Threads_TotalReads]    Script Date: 10/21/2010 21:35:03 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_iforum_Threads_TotalReads]') AND parent_object_id = OBJECT_ID(N'[dbo].[community_Threads]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_iforum_Threads_TotalReads]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[community_Threads] ADD  CONSTRAINT [DF_iforum_Threads_TotalReads]  DEFAULT ((0)) FOR [TotalReads]
END


End
GO
/****** Object:  Default [DF_iforum_Threads_TotalPosts]    Script Date: 10/21/2010 21:35:03 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_iforum_Threads_TotalPosts]') AND parent_object_id = OBJECT_ID(N'[dbo].[community_Threads]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_iforum_Threads_TotalPosts]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[community_Threads] ADD  CONSTRAINT [DF_iforum_Threads_TotalPosts]  DEFAULT ((0)) FOR [TotalPosts]
END


End
GO
/****** Object:  Default [DF_iforum_Threads_Posted]    Script Date: 10/21/2010 21:35:03 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_iforum_Threads_Posted]') AND parent_object_id = OBJECT_ID(N'[dbo].[community_Threads]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_iforum_Threads_Posted]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[community_Threads] ADD  CONSTRAINT [DF_iforum_Threads_Posted]  DEFAULT (getdate()) FOR [Posted]
END


End
GO
/****** Object:  Default [DF_iforum_Threads_LastPosted]    Script Date: 10/21/2010 21:35:03 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_iforum_Threads_LastPosted]') AND parent_object_id = OBJECT_ID(N'[dbo].[community_Threads]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_iforum_Threads_LastPosted]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[community_Threads] ADD  CONSTRAINT [DF_iforum_Threads_LastPosted]  DEFAULT (getdate()) FOR [LastPosted]
END


End
GO
/****** Object:  Default [DF_iforum_Threads_IsLocked]    Script Date: 10/21/2010 21:35:03 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_iforum_Threads_IsLocked]') AND parent_object_id = OBJECT_ID(N'[dbo].[community_Threads]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_iforum_Threads_IsLocked]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[community_Threads] ADD  CONSTRAINT [DF_iforum_Threads_IsLocked]  DEFAULT ((0)) FOR [IsLocked]
END


End
GO
/****** Object:  Default [DF_community_Threads_IsModerated]    Script Date: 10/21/2010 21:35:03 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_community_Threads_IsModerated]') AND parent_object_id = OBJECT_ID(N'[dbo].[community_Threads]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_community_Threads_IsModerated]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[community_Threads] ADD  CONSTRAINT [DF_community_Threads_IsModerated]  DEFAULT ((0)) FOR [IsAppoved]
END


End
GO
/****** Object:  ForeignKey [FK_community_attachments_community_Posts]    Script Date: 10/21/2010 21:35:03 ******/
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_community_attachments_community_Posts]') AND parent_object_id = OBJECT_ID(N'[dbo].[community_attachments]'))
ALTER TABLE [dbo].[community_attachments]  WITH CHECK ADD  CONSTRAINT [FK_community_attachments_community_Posts] FOREIGN KEY([PostID])
REFERENCES [dbo].[community_Posts] ([ID])
ON DELETE CASCADE
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_community_attachments_community_Posts]') AND parent_object_id = OBJECT_ID(N'[dbo].[community_attachments]'))
ALTER TABLE [dbo].[community_attachments] CHECK CONSTRAINT [FK_community_attachments_community_Posts]
GO
/****** Object:  ForeignKey [FK_Moderators_Moderators]    Script Date: 10/21/2010 21:35:03 ******/
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Moderators_Moderators]') AND parent_object_id = OBJECT_ID(N'[dbo].[community_Moderators]'))
ALTER TABLE [dbo].[community_Moderators]  WITH CHECK ADD  CONSTRAINT [FK_Moderators_Moderators] FOREIGN KEY([ForumID])
REFERENCES [dbo].[community_Forums] ([ID])
ON UPDATE CASCADE
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Moderators_Moderators]') AND parent_object_id = OBJECT_ID(N'[dbo].[community_Moderators]'))
ALTER TABLE [dbo].[community_Moderators] CHECK CONSTRAINT [FK_Moderators_Moderators]
GO
/****** Object:  ForeignKey [FK_Posts_Forums]    Script Date: 10/21/2010 21:35:03 ******/
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Posts_Forums]') AND parent_object_id = OBJECT_ID(N'[dbo].[community_Posts]'))
ALTER TABLE [dbo].[community_Posts]  WITH CHECK ADD  CONSTRAINT [FK_Posts_Forums] FOREIGN KEY([ForumID])
REFERENCES [dbo].[community_Forums] ([ID])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Posts_Forums]') AND parent_object_id = OBJECT_ID(N'[dbo].[community_Posts]'))
ALTER TABLE [dbo].[community_Posts] CHECK CONSTRAINT [FK_Posts_Forums]
GO
/****** Object:  ForeignKey [FK_Posts_Threads]    Script Date: 10/21/2010 21:35:03 ******/
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Posts_Threads]') AND parent_object_id = OBJECT_ID(N'[dbo].[community_Posts]'))
ALTER TABLE [dbo].[community_Posts]  WITH CHECK ADD  CONSTRAINT [FK_Posts_Threads] FOREIGN KEY([ThreadID])
REFERENCES [dbo].[community_Threads] ([ID])
ON DELETE CASCADE
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Posts_Threads]') AND parent_object_id = OBJECT_ID(N'[dbo].[community_Posts]'))
ALTER TABLE [dbo].[community_Posts] CHECK CONSTRAINT [FK_Posts_Threads]
GO
/****** Object:  ForeignKey [FK_Threads_Forums]    Script Date: 10/21/2010 21:35:03 ******/
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Threads_Forums]') AND parent_object_id = OBJECT_ID(N'[dbo].[community_Threads]'))
ALTER TABLE [dbo].[community_Threads]  WITH CHECK ADD  CONSTRAINT [FK_Threads_Forums] FOREIGN KEY([ForumID])
REFERENCES [dbo].[community_Forums] ([ID])
ON DELETE CASCADE
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Threads_Forums]') AND parent_object_id = OBJECT_ID(N'[dbo].[community_Threads]'))
ALTER TABLE [dbo].[community_Threads] CHECK CONSTRAINT [FK_Threads_Forums]
GO

/*=============================================
 Author:		<Ray liang>
 Create date: <2010-10-21>
 Description:	<This sql script file use to insert the base data DotNetAge>
 Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
 Dual licensed under the MIT and GPL licenses:
 http://www.opensource.org/licenses/mit-license.php
 http://www.gnu.org/licenses/gpl.html
 =============================================*/
CREATE FUNCTION [dbo].[base64_encode] (@data VARBINARY(max)) RETURNS VARCHAR(max)
WITH SCHEMABINDING, RETURNS NULL ON NULL INPUT
BEGIN
RETURN (
SELECT [text()] = @data 
FOR XML PATH('')
)
END
GO

CREATE FUNCTION [dbo].[base64_decode] (@base64_text VARCHAR(max)) RETURNS VARBINARY(max)
WITH SCHEMABINDING, RETURNS NULL ON NULL INPUT
BEGIN
DECLARE @x XML; SET @x = @base64_text 
RETURN @x.value('(/)[1]', 'VARBINARY(max)')
END
GO 

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dna_CreateUser]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[p_Create_ASP_User] 
Go

CREATE PROCEDURE dna_CreateUser 
@ApplicationName nvarchar(256),
@UserName nvarchar(256),
@ClearTextPassword nvarchar(128),
@Email nvarchar(256),
@PasswordQuestion nvarchar(256),
@PasswordAnswer nvarchar(128),
@UserId uniqueidentifier OUTPUT 
AS

BEGIN
DECLARE @CurrentTimeUtc datetime
DECLARE @CreateDate datetime
DECLARE @PasswordFormat int
DECLARE @UniqueEmail int
DECLARE @IsApproved bit
DECLARE @salt uniqueidentifier
DECLARE @encoded_hashed_password nvarchar(128)
DECLARE @encoded_salt nvarchar(128)
DECLARE @RC int
SET @IsApproved = 1 
SET @UniqueEmail = 0
SET @PasswordFormat = 1 
SET @salt = NEWID()
SET @encoded_salt = dbo.base64_encode(@salt)
SET @UserId = NEWID() SET @CurrentTimeUtc = GetDate()
SET @CreateDate = GetDate() 
SET @encoded_hashed_password = dbo.base64_encode(HASHBYTES('SHA1', Cast(@salt as varbinary(MAX)) + CAST(@ClearTextPassword AS varbinary(MAX)) )) 

EXECUTE @RC = aspnet_Membership_CreateUser 
@ApplicationName
,@UserName 
,@encoded_hashed_password
,@encoded_salt 
,@Email
,@PasswordQuestion 
,@PasswordAnswer
,@IsApproved 
,@CurrentTimeUtc
,@CreateDate 
,@UniqueEmail
,@PasswordFormat,@UserId OUTPUT 
END
GO

DECLARE @dna_appID uniqueidentifier,
               @dna_adminID uniqueidentifier,
			   @dna_appName nvarchar(256)

SET @dna_appID=N'54055bdc-62a7-4e91-a566-c48ea0b6db7a'
SET @dna_appName=Replace(N'PlaceHolderForAppName',N'Default Web Site','')

INSERT [dbo].[aspnet_Applications] ([ApplicationName], [LoweredApplicationName], [ApplicationId], [Description]) 
VALUES (@dna_appName,LOWER(@dna_appName), @dna_appID, NULL)

INSERT [dbo].[aspnet_Roles] ([ApplicationId], [RoleId], [RoleName], [LoweredRoleName], [Description])
 VALUES (@dna_appID, N'dab90a5e-ecd6-4e7f-9232-e96546b56a52', N'administrators', N'administrators', NULL)

INSERT [dbo].[aspnet_Roles] ([ApplicationId], [RoleId], [RoleName], [LoweredRoleName], [Description]) 
VALUES (@dna_appID, N'3924cf1c-2282-4b60-825b-10d08db04d52', N'guests', N'guests', NULL)

EXEC	 [dbo].[dna_createUser]
        @ApplicationName=@dna_appName,  
		@UserName = N'PlaceHolderForAdministratorName',
		@ClearTextPassword = N'PlaceHolderForAdministratorPassword',
		@Email = N'PlaceHolderForAdministratorEmail',
		@PasswordQuestion = NULL,
		@PasswordAnswer = NULL,
		@UserId = @dna_adminID OUTPUT


INSERT [dbo].[aspnet_UsersInRoles] ([UserId], [RoleId]) 
VALUES (@dna_adminID, N'3924cf1c-2282-4b60-825b-10d08db04d52')

INSERT [dbo].[aspnet_UsersInRoles] ([UserId], [RoleId])
 VALUES (@dna_adminID, N'dab90a5e-ecd6-4e7f-9232-e96546b56a52')

IF NOT EXISTS(SELECT ID FROM [dbo].[Publishing_Category] WHERE [Title]='{site}') BEGIN
		   INSERT INTO [dbo].[Publishing_Category]
				   ([Title]
				   ,[Description]
				   ,[Url]
				   ,[ParentID]
				   ,[IsModerated]
				   ,[EnableVersioning]
				   ,[ArticleType]
				   ,[TotalPosts]
				   ,[LastPosted]
				   ,[Path]
				   ,[Pos]
				   ,[AllowAnonymousPostComment])
			 VALUES
				   ('{site}','','',0,0,0,
					0,0,GETDATE(),
				   '{site}',
				   0,1)
END

IF NOT EXISTS(SELECT ID FROM [dbo].[Publishing_Category] WHERE [Title]='{blogs}') BEGIN
			   INSERT INTO [dbo].[Publishing_Category]
					([Title]
					,[Description]
					,[Url]
					,[ParentID]
					,[IsModerated]
					,[EnableVersioning]
					,[ArticleType]
					,[TotalPosts]
					,[LastPosted]
					,[Path]
					,[Pos]
					,[AllowAnonymousPostComment])
				VALUES
					('{blogs}','','',0,0,0,
					1,0,GETDATE(),
					'{blogs}',
					0,1)
END


SET IDENTITY_INSERT [dbo].[dna_WidgetCategories] ON
INSERT [dbo].[dna_WidgetCategories] ([Id], [Title], [Description]) VALUES (1, N'Shared', NULL)
INSERT [dbo].[dna_WidgetCategories] ([Id], [Title], [Description]) VALUES (2, N'Publishing', NULL)
INSERT [dbo].[dna_WidgetCategories] ([Id], [Title], [Description]) VALUES (3, N'Community', NULL)
SET IDENTITY_INSERT [dbo].[dna_WidgetCategories] OFF

SET IDENTITY_INSERT [dbo].[dna_PackageInfos] ON
INSERT [dbo].[dna_PackageInfos] ([ID], [Name], [ShortName], [Description], [AuthorName], [AuthorWebSite], [AuthorEmail], [Organization], [IconUrl], [IconHeight], [IconWidth], [ReleaseNotes], [Version], [Installed], [Published], [LicensesXML], [FileList], [HelpLink], [SupportLink], [AssemblyName], [AssemblyFullName]) VALUES (1, N'XML-RPC.NET', NULL, N'Requires .NET 2.0 or later', N'', N'', N'', N'Cook Computing', NULL, NULL, NULL, NULL, N'2.5.0.0', CAST(0x00009E19016A7008 AS DateTime), CAST(0x00009E1700B6FB8E AS DateTime), NULL, NULL, NULL, NULL, N'CookComputing.XmlRpcV2', N'CookComputing.XmlRpcV2, Version=2.5.0.0, Culture=neutral, PublicKeyToken=a7d6e17aa302004d')
INSERT [dbo].[dna_PackageInfos] ([ID], [Name], [ShortName], [Description], [AuthorName], [AuthorWebSite], [AuthorEmail], [Organization], [IconUrl], [IconHeight], [IconWidth], [ReleaseNotes], [Version], [Installed], [Published], [LicensesXML], [FileList], [HelpLink], [SupportLink], [AssemblyName], [AssemblyFullName]) VALUES (2, N'CSharpFormat', NULL, N'An extensible framework for generating color-coded HTML 4.01 from source code.', N'', N'', N'', N'manoli.net', NULL, NULL, NULL, NULL, N'2.5.3417.41446', CAST(0x00009E19016A702B AS DateTime), CAST(0x00009E1700B6FB8E AS DateTime), NULL, NULL, NULL, NULL, N'CSharpFormat', N'CSharpFormat, Version=2.5.3417.41446, Culture=neutral, PublicKeyToken=null')
INSERT [dbo].[dna_PackageInfos] ([ID], [Name], [ShortName], [Description], [AuthorName], [AuthorWebSite], [AuthorEmail], [Organization], [IconUrl], [IconHeight], [IconWidth], [ReleaseNotes], [Version], [Installed], [Published], [LicensesXML], [FileList], [HelpLink], [SupportLink], [AssemblyName], [AssemblyFullName]) VALUES (3, N'DotNetAge', NULL, N'The content management system (CMS) base on Mvc & jQuery technique.', N'Ray', N'http://www.dotnetage.com', N'csharp2002@hotmail.com', N'DotNetAge.com', NULL, NULL, NULL, NULL, N'1.1.0.39572', CAST(0x00009E19016A702F AS DateTime), CAST(0x00009E1700B6FB92 AS DateTime), NULL, NULL, NULL, NULL, N'DNA.Mvc', N'DNA.Mvc, Version=1.1.0.39572, Culture=neutral, PublicKeyToken=null')
INSERT [dbo].[dna_PackageInfos] ([ID], [Name], [ShortName], [Description], [AuthorName], [AuthorWebSite], [AuthorEmail], [Organization], [IconUrl], [IconHeight], [IconWidth], [ReleaseNotes], [Version], [Installed], [Published], [LicensesXML], [FileList], [HelpLink], [SupportLink], [AssemblyName], [AssemblyFullName]) VALUES (4, N'DotNetAge jQuery Mvc Extensions', NULL, N'The DotNetAge Mvc Extensions for jQuery ', N'', N'', N'', N'http://www.DotNetAge.com', NULL, NULL, NULL, NULL, N'1.0.4.39571', CAST(0x00009E19016A7103 AS DateTime), CAST(0x00009E1700B6F9BD AS DateTime), NULL, NULL, NULL, NULL, N'DNA.Mvc.jQuery', N'DNA.Mvc.jQuery, Version=1.0.4.39571, Culture=neutral, PublicKeyToken=null')
INSERT [dbo].[dna_PackageInfos] ([ID], [Name], [ShortName], [Description], [AuthorName], [AuthorWebSite], [AuthorEmail], [Organization], [IconUrl], [IconHeight], [IconWidth], [ReleaseNotes], [Version], [Installed], [Published], [LicensesXML], [FileList], [HelpLink], [SupportLink], [AssemblyName], [AssemblyFullName]) VALUES (5, N'ICSharpCode.SharpZipLibrary', NULL, N'A free C# compression library', N'', N'', N'', N'', NULL, NULL, NULL, NULL, N'0.81.0.1407', CAST(0x00009E19016A7106 AS DateTime), CAST(0x00009E1700B6FB8E AS DateTime), NULL, NULL, NULL, NULL, N'SharpZipLib', N'SharpZipLib, Version=0.81.0.1407, Culture=neutral, PublicKeyToken=null')
INSERT [dbo].[dna_PackageInfos] ([ID], [Name], [ShortName], [Description], [AuthorName], [AuthorWebSite], [AuthorEmail], [Organization], [IconUrl], [IconHeight], [IconWidth], [ReleaseNotes], [Version], [Installed], [Published], [LicensesXML], [FileList], [HelpLink], [SupportLink], [AssemblyName], [AssemblyFullName]) VALUES (6, N'System.Web.Mvc.dll', NULL, N'System.Web.Mvc.dll', N'', N'', N'', N'Microsoft Corporation', NULL, NULL, NULL, NULL, N'2.0.0.0', CAST(0x00009E19016A7109 AS DateTime), CAST(0x00009E1700B6FB8E AS DateTime), NULL, NULL, NULL, NULL, N'System.Web.Mvc', N'System.Web.Mvc, Version=2.0.0.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35')
SET IDENTITY_INSERT [dbo].[dna_PackageInfos] OFF

SET IDENTITY_INSERT [dbo].[dna_WidgetDescriptors] ON
INSERT [dbo].[dna_WidgetDescriptors] ([ID], [CatID], [PackageID], [Title], [Url], [Action], [Defaults], [IsClosable], [ShowHeader], [Version], [ImageUrl], [Description], [Controller], [IconUrl], [ShowBorder], [Scopes], [IsDeletable]) VALUES (1, 1, 3, N'Flash', N'', N'Flash', N'{"Width":100,"Url":"","Quality":"high","Height":100,"FlashVars":null,"BackgroundColor":"#ffffff","WMODE":"opaque"}', 1, 0, NULL, N'~/Content/Images/Widgets/flash.png', N'Embedded the Flash object in the widget.', N'Widget', N'~/Content/Images/Widgets/flash_16.png', 0, 0, 1)
INSERT [dbo].[dna_WidgetDescriptors] ([ID], [CatID], [PackageID], [Title], [Url], [Action], [Defaults], [IsClosable], [ShowHeader], [Version], [ImageUrl], [Description], [Controller], [IconUrl], [ShowBorder], [Scopes], [IsDeletable]) VALUES (2, 1, 3, N'Favorites', N'', N'Favorites', N'{"LinkList":null}', 1, 1, NULL, N'~/Content/Images/Widgets/favorite.png', N'Gerenate the a link list for favorites', N'Widget', N'~/Content/Images/Widgets/favorite_16.png', 1, 0, 1)
INSERT [dbo].[dna_WidgetDescriptors] ([ID], [CatID], [PackageID], [Title], [Url], [Action], [Defaults], [IsClosable], [ShowHeader], [Version], [ImageUrl], [Description], [Controller], [IconUrl], [ShowBorder], [Scopes], [IsDeletable]) VALUES (3, 1, 3, N'Donation', N'', N'Donation', N'{"Business":"Example@dotnetage.com","Summary":"If you like this site please buy me a beer.","ReturnUrl":null,"ItemName":"Example donation","Amount":10,"ItemNumber":"2010"}', 1, 1, NULL, N'~/Content/Images/Widgets/heart.png', N'The PayPal donate widget.Post the donate information to the paypal.', N'Widget', N'~/Content/Images/Widgets/heart_16.png', 1, 0, 1)
INSERT [dbo].[dna_WidgetDescriptors] ([ID], [CatID], [PackageID], [Title], [Url], [Action], [Defaults], [IsClosable], [ShowHeader], [Version], [ImageUrl], [Description], [Controller], [IconUrl], [ShowBorder], [Scopes], [IsDeletable]) VALUES (4, 1, 3, N'ImageLink', N'', N'ImageLink', N'{"ImageWidth":null,"ImageHeight":null,"Target":"_blank","Alignment":"center","ImageUrl":null,"LinkUrl":null}', 1, 0, NULL, N'~/Content/Images/Widgets/link.png', N'Display the image by specified url.', N'Widget', N'~/Content/Images/Widgets/link_16.png', 0, 0, 1)
INSERT [dbo].[dna_WidgetDescriptors] ([ID], [CatID], [PackageID], [Title], [Url], [Action], [Defaults], [IsClosable], [ShowHeader], [Version], [ImageUrl], [Description], [Controller], [IconUrl], [ShowBorder], [Scopes], [IsDeletable]) VALUES (5, 1, 3, N'SimpleHtml', N'', N'SimpleHtml', N'{"Text":null}', 1, 0, NULL, N'~/Content/Images/Widgets/markup.png', N'This widget allows you editing the html on the page in WYSAWYG mode.', N'Widget', NULL, 0, 0, 1)
INSERT [dbo].[dna_WidgetDescriptors] ([ID], [CatID], [PackageID], [Title], [Url], [Action], [Defaults], [IsClosable], [ShowHeader], [Version], [ImageUrl], [Description], [Controller], [IconUrl], [ShowBorder], [Scopes], [IsDeletable]) VALUES (6, 1, 3, N'UserInfo', N'', N'UserInfo', N'{}', 1, 1, NULL, N'~/Content/Images/Widgets/user.png', N'Display current user public information.', N'Widget', N'~/Content/Images/Widgets/user_16.png', 1, 0, 1)
INSERT [dbo].[dna_WidgetDescriptors] ([ID], [CatID], [PackageID], [Title], [Url], [Action], [Defaults], [IsClosable], [ShowHeader], [Version], [ImageUrl], [Description], [Controller], [IconUrl], [ShowBorder], [Scopes], [IsDeletable]) VALUES (7, 1, 3, N'WhoIsOnline', N'', N'WhoIsOnline', N'{"Minutes":20}', 1, 1, NULL, N'~/Content/Images/Widgets/users.png', N'Display the statistics information of the website.', N'Widget', N'~/Content/Images/Widgets/users_16.png', 1, 0, 1)
INSERT [dbo].[dna_WidgetDescriptors] ([ID], [CatID], [PackageID], [Title], [Url], [Action], [Defaults], [IsClosable], [ShowHeader], [Version], [ImageUrl], [Description], [Controller], [IconUrl], [ShowBorder], [Scopes], [IsDeletable]) VALUES (8, 1, 3, N'Referring', N'', N'Referring', N'{}', 1, 1, NULL, N'~/Content/Images/Widgets/icon_referrer.png', N'Display which site refer to this website.', N'Widget', N'~/Content/Images/Widgets/icon_referrer_16.png', 1, 0, 1)
INSERT [dbo].[dna_WidgetDescriptors] ([ID], [CatID], [PackageID], [Title], [Url], [Action], [Defaults], [IsClosable], [ShowHeader], [Version], [ImageUrl], [Description], [Controller], [IconUrl], [ShowBorder], [Scopes], [IsDeletable]) VALUES (9, 1, 3, N'WikiViewer', N'', N'WikiViewer', N'{"FileUrl":null}', 1, 0, NULL, N'~/Content/Images/Widgets/wikiviewer.png', N'This widget can display the widget format file.', N'Widget', N'~/Content/Images/Widgets/wikiviewer_16.png', 0, 0, 1)
INSERT [dbo].[dna_WidgetDescriptors] ([ID], [CatID], [PackageID], [Title], [Url], [Action], [Defaults], [IsClosable], [ShowHeader], [Version], [ImageUrl], [Description], [Controller], [IconUrl], [ShowBorder], [Scopes], [IsDeletable]) VALUES (10, 1, 3, N'Wiki', N'', N'Wiki', N'{"Body":""}', 1, 1, NULL, N'~/Content/Images/Widgets/wiki.png', N'The Wiki widget allows you write the article in wiki format.', N'Widget', N'~/Content/Images/Widgets/wiki_16.png', 1, 0, 1)
INSERT [dbo].[dna_WidgetDescriptors] ([ID], [CatID], [PackageID], [Title], [Url], [Action], [Defaults], [IsClosable], [ShowHeader], [Version], [ImageUrl], [Description], [Controller], [IconUrl], [ShowBorder], [Scopes], [IsDeletable]) VALUES (11, 1, 3, N'ContactCard', N'', N'ContactCard', N'{"Address":null,"Fax":null,"Email":null,"WebSite":null,"Company":null,"PostCode":null,"Phone":null,"Mobile":null,"Contact":null}', 1, 1, NULL, N'~/Content/Images/Widgets/contact.png', N'Display the contact info to clients', N'Widget', N'~/Content/Images/Widgets/contact_16.png', 1, 0, 1)
INSERT [dbo].[dna_WidgetDescriptors] ([ID], [CatID], [PackageID], [Title], [Url], [Action], [Defaults], [IsClosable], [ShowHeader], [Version], [ImageUrl], [Description], [Controller], [IconUrl], [ShowBorder], [Scopes], [IsDeletable]) VALUES (12, 1, 3, N'AdSense', N'', N'AdSense', N'{"AdWidth":300,"AdHeight":250,"SlotID":"","ClientCode":""}', 1, 0, NULL, N'~/Content/Images/Widgets/icon_google_36.png', N'Google Ad sense', N'Widget', N'~/Content/Images/Widgets/icon_google_16.png', 0, 0, 1)
INSERT [dbo].[dna_WidgetDescriptors] ([ID], [CatID], [PackageID], [Title], [Url], [Action], [Defaults], [IsClosable], [ShowHeader], [Version], [ImageUrl], [Description], [Controller], [IconUrl], [ShowBorder], [Scopes], [IsDeletable]) VALUES (13, 1, 3, N'BidVertister', N'', N'BidVertister', N'{"BID":"","AdHeight":250,"PID":""}', 1, 1, NULL, NULL, N'BidVertister Ad', N'Widget', NULL, 1, 0, 1)
INSERT [dbo].[dna_WidgetDescriptors] ([ID], [CatID], [PackageID], [Title], [Url], [Action], [Defaults], [IsClosable], [ShowHeader], [Version], [ImageUrl], [Description], [Controller], [IconUrl], [ShowBorder], [Scopes], [IsDeletable]) VALUES (14, 1, 3, N'SendMail', N'', N'SendMail', N'{"Receiver":null,"Subject":null}', 1, 1, NULL, N'~/Content/Images/Widgets/mail_send.png', N'Provides the form to get user info and send to the site admin', N'Widget', N'~/Content/Images/Widgets/mail_send_16.png', 1, 0, 1)
INSERT [dbo].[dna_WidgetDescriptors] ([ID], [CatID], [PackageID], [Title], [Url], [Action], [Defaults], [IsClosable], [ShowHeader], [Version], [ImageUrl], [Description], [Controller], [IconUrl], [ShowBorder], [Scopes], [IsDeletable]) VALUES (15, 2, 3, N'Categories', N'Publishing', N'CategoryNav', N'{}', 1, 1, NULL, N'~/Content/Images/Widgets/cat.png', N'Display all children categories as a link list', N'Category', N'~/Content/Images/Widgets/cat_16.png', 1, 0, 1)
INSERT [dbo].[dna_WidgetDescriptors] ([ID], [CatID], [PackageID], [Title], [Url], [Action], [Defaults], [IsClosable], [ShowHeader], [Version], [ImageUrl], [Description], [Controller], [IconUrl], [ShowBorder], [Scopes], [IsDeletable]) VALUES (16, 3, 3, N'TodayThreads', N'Community', N'TodayThreads', N'{}', 1, 1, NULL, N'~/Content/Images/Widgets/todaypost.png', N'Display a thread list of community for today.', N'Post', N'~/Content/Images/Widgets/todaypost_16.png', 1, 0, 1)
INSERT [dbo].[dna_WidgetDescriptors] ([ID], [CatID], [PackageID], [Title], [Url], [Action], [Defaults], [IsClosable], [ShowHeader], [Version], [ImageUrl], [Description], [Controller], [IconUrl], [ShowBorder], [Scopes], [IsDeletable]) VALUES (17, 3, 3, N'HotThreads', N'Community', N'HotThreads', N'{"MinimizeReads":50}', 1, 1, NULL, N'~/Content/Images/Widgets/hot.png', N'Display a thread list of community for most popular.', N'Post', N'~/Content/Images/Widgets/hot_16.png', 1, 0, 1)
INSERT [dbo].[dna_WidgetDescriptors] ([ID], [CatID], [PackageID], [Title], [Url], [Action], [Defaults], [IsClosable], [ShowHeader], [Version], [ImageUrl], [Description], [Controller], [IconUrl], [ShowBorder], [Scopes], [IsDeletable]) VALUES (18, 2, 3, N'Archives', N'Publishing', N'Archives', N'{"CategoryID":0}', 1, 1, NULL, N'~/Content/Images/Widgets/calendar.png', N'Display an archive list of the current web.', N'Article', N'~/Content/Images/Widgets/calendar_16.png', 1, 0, 1)
INSERT [dbo].[dna_WidgetDescriptors] ([ID], [CatID], [PackageID], [Title], [Url], [Action], [Defaults], [IsClosable], [ShowHeader], [Version], [ImageUrl], [Description], [Controller], [IconUrl], [ShowBorder], [Scopes], [IsDeletable]) VALUES (19, 2, 3, N'TagCloud', N'Publishing', N'TagCloud', N'{"MaximumTags":-1}', 1, 1, NULL, N'~/Content/Images/Widgets/tag.png', N'Display the tag cloud of current web.', N'Article', N'~/Content/Images/Widgets/tag_16.png', 1, 0, 1)
INSERT [dbo].[dna_WidgetDescriptors] ([ID], [CatID], [PackageID], [Title], [Url], [Action], [Defaults], [IsClosable], [ShowHeader], [Version], [ImageUrl], [Description], [Controller], [IconUrl], [ShowBorder], [Scopes], [IsDeletable]) VALUES (20, 2, 3, N'Headlines', N'Publishing', N'HeadLines', N'{"ShowAuthor":true,"ShowDate":true,"CategoryID":0,"TextLen":-1,"Rows":20}', 1, 1, NULL, N'~/Content/Images/Widgets/headline.png', N'Display recent articles title link list of specified category.You can use this widget to display the headline news.', N'Article', N'~/Content/Images/Widgets/headline_16.png', 1, 0, 1)
INSERT [dbo].[dna_WidgetDescriptors] ([ID], [CatID], [PackageID], [Title], [Url], [Action], [Defaults], [IsClosable], [ShowHeader], [Version], [ImageUrl], [Description], [Controller], [IconUrl], [ShowBorder], [Scopes], [IsDeletable]) VALUES (21, 2, 3, N'MultiHeadLines', N'Publishing', N'MultiHeadLines', N'{"ShowDate":true,"CategoryID":0,"TextLen":-1,"Rows":10,"ShowAuthor":true}', 1, 1, NULL, N'~/Content/Images/Widgets/multiheadlines.png', N'Display a multi tab head lines ui.This Widget will load the children categories of specified cateogry and show them in to multi tabs.', N'Article', N'~/Content/Images/Widgets/multiheadlines_16.png', 1, 0, 1)
INSERT [dbo].[dna_WidgetDescriptors] ([ID], [CatID], [PackageID], [Title], [Url], [Action], [Defaults], [IsClosable], [ShowHeader], [Version], [ImageUrl], [Description], [Controller], [IconUrl], [ShowBorder], [Scopes], [IsDeletable]) VALUES (22, 2, 3, N'HotReads', N'Publishing', N'HotReads', N'{"Rows":10}', 1, 1, NULL, NULL, N'HotReads is a widget that search the most reads article/blog post of the web site and display in a link list.', N'Article', NULL, 1, 0, 1)
INSERT [dbo].[dna_WidgetDescriptors] ([ID], [CatID], [PackageID], [Title], [Url], [Action], [Defaults], [IsClosable], [ShowHeader], [Version], [ImageUrl], [Description], [Controller], [IconUrl], [ShowBorder], [Scopes], [IsDeletable]) VALUES (23, 2, 3, N'RecentBlogPost', N'Publishing', N'RecentBlogPost', N'{"TextLen":-1,"Rows":10,"ShowAuthor":true,"ShowDate":true}', 1, 1, NULL, NULL, N'Display the recent blog posts of current website in a title link list.', N'Article', NULL, 1, 1, 1)
INSERT [dbo].[dna_WidgetDescriptors] ([ID], [CatID], [PackageID], [Title], [Url], [Action], [Defaults], [IsClosable], [ShowHeader], [Version], [ImageUrl], [Description], [Controller], [IconUrl], [ShowBorder], [Scopes], [IsDeletable]) VALUES (24, 2, 3, N'BlogRoll', N'Publishing', N'BlogRoll', N'{"Rows":10}', 1, 1, NULL, NULL, N'BlogRoll is a widget that display a list contains the most actively bloggers.', N'Article', NULL, 1, 0, 1)
INSERT [dbo].[dna_WidgetDescriptors] ([ID], [CatID], [PackageID], [Title], [Url], [Action], [Defaults], [IsClosable], [ShowHeader], [Version], [ImageUrl], [Description], [Controller], [IconUrl], [ShowBorder], [Scopes], [IsDeletable]) VALUES (25, 2, 3, N'RecentComments', N'Publishing', N'RecentComments', N'{"Rows":10}', 1, 1, NULL, N'~/Content/Images/Widgets/comment.png', N'Display the recent comments of current web.', N'Article', N'~/Content/Images/Widgets/comment_16.png', 1, 0, 1)
INSERT [dbo].[dna_WidgetDescriptors] ([ID], [CatID], [PackageID], [Title], [Url], [Action], [Defaults], [IsClosable], [ShowHeader], [Version], [ImageUrl], [Description], [Controller], [IconUrl], [ShowBorder], [Scopes], [IsDeletable]) VALUES (26, 2, 3, N'SummaryView', N'Publishing', N'SummaryView', N'{"Rows":10,"CategoryID":0,"IncludeSubCategory":false}', 1, 0, NULL, NULL, NULL, N'Article', NULL, 0, 0, 1)
INSERT [dbo].[dna_WidgetDescriptors] ([ID], [CatID], [PackageID], [Title], [Url], [Action], [Defaults], [IsClosable], [ShowHeader], [Version], [ImageUrl], [Description], [Controller], [IconUrl], [ShowBorder], [Scopes], [IsDeletable]) VALUES (27, 2, 3, N'ArticleMenu', N'Publishing', N'Navigator', N'{"CategoryID":0,"TextLen":-1}', 1, 0, NULL, N'~/Content/Images/Widgets/articlemenu.png', NULL, N'Article', N'~/Content/Images/Widgets/articlemenu_16.png', 1, 0, 1)
INSERT [dbo].[dna_WidgetDescriptors] ([ID], [CatID], [PackageID], [Title], [Url], [Action], [Defaults], [IsClosable], [ShowHeader], [Version], [ImageUrl], [Description], [Controller], [IconUrl], [ShowBorder], [Scopes], [IsDeletable]) VALUES (28, 2, 3, N'MyActions', N'Publishing', N'MyActions', N'{}', 1, 1, NULL, NULL, N'Auto search actions for current user.', N'Article', NULL, 1, 0, 1)
INSERT [dbo].[dna_WidgetDescriptors] ([ID], [CatID], [PackageID], [Title], [Url], [Action], [Defaults], [IsClosable], [ShowHeader], [Version], [ImageUrl], [Description], [Controller], [IconUrl], [ShowBorder], [Scopes], [IsDeletable]) VALUES (29, 2, 3, N'PostRoll', N'Publishing', N'PostRoll', N'{"Rows":10,"ShowAuthorInfo":true}', 1, 0, NULL, NULL, N'PostRoll is a widget that search and display the latest post and show all the post content in a list.Place this widget on 
top site it will search all the blogger posts in web, when place in your personal web site it just search the posts in your web.', N'Article', NULL, 0, 0, 1)
INSERT [dbo].[dna_WidgetDescriptors] ([ID], [CatID], [PackageID], [Title], [Url], [Action], [Defaults], [IsClosable], [ShowHeader], [Version], [ImageUrl], [Description], [Controller], [IconUrl], [ShowBorder], [Scopes], [IsDeletable]) VALUES (30, 3, 3, N'Stat.', N'Community', N'Statistics', N'{}', 1, 1, NULL, N'~/Content/Images/Widgets/stat.png', N'Display the statistics for community', N'Forum', N'~/Content/Images/Widgets/stat_16.png', 1, 0, 1)
INSERT [dbo].[dna_WidgetDescriptors] ([ID], [CatID], [PackageID], [Title], [Url], [Action], [Defaults], [IsClosable], [ShowHeader], [Version], [ImageUrl], [Description], [Controller], [IconUrl], [ShowBorder], [Scopes], [IsDeletable]) VALUES (31, 1, 3, N'Feeds', N'', N'Feeds', N'{"Rows":5,"Url":"http://www.cnblogs.com/sunrack/category/74529.html/rss","ShowFeedInfo":true}', 1, 1, NULL, N'~/Content/Images/Widgets/rss.png', N'Feeds is a widget that allows you subscript rss feed or atom feed.', N'AsyncWidget', N'~/Content/Images/Widgets/rss_16.png', 1, 0, 1)
SET IDENTITY_INSERT [dbo].[dna_WidgetDescriptors] OFF
GO

/**********************************************************************/
/*This script use to update DNA1.1 database to DNA2.0 preview*/
/*Modified:2011-3-4*/
/**********************************************************************/

/*****Update dna_widgetdescriptors****/
BEGIN TRANSACTION
SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.dna_WidgetDescriptors
	DROP CONSTRAINT FK_WidgetMetas_Categories
GO
ALTER TABLE dbo.dna_WidgetCategories SET (LOCK_ESCALATION = TABLE)
GO
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.dna_WidgetDescriptors
	DROP CONSTRAINT FK_dna_WidgetDescriptor_dna_PackageInfos
GO
ALTER TABLE dbo.dna_PackageInfos SET (LOCK_ESCALATION = TABLE)
GO
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.dna_WidgetDescriptors ADD
	InstalledPath nvarchar(1024) NULL,
	TitleLinkUrl nvarchar(1024) NULL
GO
ALTER TABLE dbo.dna_WidgetDescriptors
	DROP COLUMN CatID, PackageID
GO
ALTER TABLE dbo.dna_WidgetDescriptors SET (LOCK_ESCALATION = TABLE)
GO
COMMIT

/*              Data updates                            */
UPDATE dna_WidgetDescriptors
SET Controller='DNA.Mvc.Controllers.WidgetController',
     InstalledPath='Shared\'+[Action]
WHERE Controller='Widget'
GO

UPDATE dna_WidgetDescriptors
SET Controller='DNA.Mvc.Areas.Publishing.Controllers.ArticleController',
     InstalledPath='Publishing\'+[Action]
WHERE Controller='Article'
GO

UPDATE dna_WidgetDescriptors
SET Controller='DNA.Mvc.Areas.Publishing.Controllers.CategoryController',
      InstalledPath='Publishing\'+[Action]
WHERE Controller='Category'
GO

UPDATE dna_WidgetDescriptors
SET Controller='DNA.Mvc.Areas.Community.Controllers.ForumController',
InstalledPath='Community\'+[Action]
WHERE Controller='Forum'
GO

UPDATE dna_WidgetDescriptors
SET Controller='DNA.Mvc.Areas.Community.Controllers.PostController',
InstalledPath='Community\'+[Action]
WHERE Controller='Post'
GO

UPDATE dna_WidgetDescriptors
SET Controller='DNA.Mvc.Controllers.AsyncWidgetController',
InstalledPath='Shared\Feeds'
WHERE Controller='AsyncWidget'
GO