﻿/**********************************************************************/
/*This script use to update DNA1.1 database to DNA2.0 preview*/
/*Modified:2011-3-4*/
/**********************************************************************/

/*****Update dna_widgetdescriptors****/
BEGIN TRANSACTION
SET QUOTED_IDENTIFIER ON
SET ARITHABORT ON
SET NUMERIC_ROUNDABORT OFF
SET CONCAT_NULL_YIELDS_NULL ON
SET ANSI_NULLS ON
SET ANSI_PADDING ON
SET ANSI_WARNINGS ON
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.dna_WidgetDescriptors
	DROP CONSTRAINT FK_WidgetMetas_Categories
GO
ALTER TABLE dbo.dna_WidgetCategories SET (LOCK_ESCALATION = TABLE)
GO
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.dna_WidgetDescriptors
	DROP CONSTRAINT FK_dna_WidgetDescriptor_dna_PackageInfos
GO
ALTER TABLE dbo.dna_PackageInfos SET (LOCK_ESCALATION = TABLE)
GO
COMMIT
BEGIN TRANSACTION
GO
ALTER TABLE dbo.dna_WidgetDescriptors ADD
	InstalledPath nvarchar(1024) NULL,
	TitleLinkUrl nvarchar(1024) NULL
GO
ALTER TABLE dbo.dna_WidgetDescriptors
	DROP COLUMN CatID, PackageID
GO
ALTER TABLE dbo.dna_WidgetDescriptors SET (LOCK_ESCALATION = TABLE)
GO
COMMIT

/*              Data updates                            */
UPDATE dna_WidgetDescriptors
SET Controller='DNA.Mvc.Controllers.WidgetController',
     InstalledPath='Shared\'+[Action]
WHERE Controller='Widget'
GO

UPDATE dna_WidgetDescriptors
SET Controller='DNA.Mvc.Areas.Publishing.Controllers.ArticleController',
     InstalledPath='Publishing\'+[Action]
WHERE Controller='Article'
GO

UPDATE dna_WidgetDescriptors
SET Controller='DNA.Mvc.Areas.Publishing.Controllers.CategoryController',
      InstalledPath='Publishing\'+[Action]
WHERE Controller='Category'
GO

UPDATE dna_WidgetDescriptors
SET Controller='DNA.Mvc.Areas.Community.Controllers.ForumController',
InstalledPath='Community\'+[Action]
WHERE Controller='Forum'
GO

UPDATE dna_WidgetDescriptors
SET Controller='DNA.Mvc.Areas.Community.Controllers.PostController',
InstalledPath='Community\'+[Action]
WHERE Controller='Post'
GO

UPDATE dna_WidgetDescriptors
SET Controller='DNA.Mvc.Controllers.AsyncWidgetController',
InstalledPath='Shared\Feeds'
WHERE Controller='AsyncWidget'
GO

UPDATE dna_WebSettings
SET Theme='default'
GO