﻿-- ===============================================================================
-- Author:		<Ray liang>
-- Create date: <2010-8-30>
-- Description:	<This sql script file use to create the tables,views and storeproduces for DotNetAge>
-- Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
-- Dual licensed under the MIT and GPL licenses:
-- http://www.opensource.org/licenses/mit-license.php
-- http://www.gnu.org/licenses/gpl.html
-- ===============================================================================

/****** Object:  Table [dbo].[dna_PackageInfos]    Script Date: 08/19/2010 11:51:28 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[dna_PackageInfos](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[Name] [nvarchar](50) NOT NULL,
	[ShortName] [nvarchar](50) NULL,
	[Description] [ntext] NULL,
	[AuthorName] [nvarchar](50) NULL,
	[AuthorWebSite] [nvarchar](1024) NULL,
	[AuthorEmail] [nvarchar](1024) NULL,
	[Organization] [nvarchar](255) NULL,
	[IconUrl] [nvarchar](1024) NULL,
	[IconHeight] [int] NULL,
	[IconWidth] [int] NULL,
	[ReleaseNotes] [ntext] NULL,
	[Version] [nvarchar](50) NULL,
	[Installed] [datetime] NULL,
	[Published] [datetime] NULL,
	[LicensesXML] [ntext] NULL,
	[FileList] [ntext] NULL,
	[HelpLink] [nvarchar](50) NULL,
	[SupportLink] [nvarchar](50) NULL,
	[AssemblyName] [nvarchar](255) NULL,
	[AssemblyFullName] [nvarchar](1024) NULL,
 CONSTRAINT [PK_Packages] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO



/****** Object:  Table [dbo].[dna_EventLog]    Script Date: 08/19/2010 11:51:28 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[dna_EventLog](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[ClientAddress] [nvarchar](255) NOT NULL,
	[Controller] [nvarchar](255) NOT NULL,
	[Action] [nvarchar](255) NOT NULL,
	[UserName] [nvarchar](255) NULL,
	[IsAnonymous] [bit] NOT NULL,
	[Logged] [datetime] NOT NULL,
	[Browser] [nvarchar](50) NOT NULL,
	[Version] [nvarchar](1024) NOT NULL,
	[Host] [nvarchar](1024) NOT NULL,
	[RawUrl] [nvarchar](2048) NOT NULL,
	[UserAgent] [nvarchar](1024) NOT NULL,
	[UrlRefer] [nvarchar](2048) NULL,
 CONSTRAINT [PK_dna_Log] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

/****** Object:  Table [dbo].[dna_CommonSettings]    Script Date: 08/19/2010 11:51:28 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[dna_CommonSettings](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[Name] [nvarchar](1024) NOT NULL,
	[Value] [ntext] NOT NULL,
 CONSTRAINT [PK_dna_CommonSettings] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO


/****** Object:  Table [dbo].[dna_WidgetCategories]    Script Date: 08/19/2010 11:51:28 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[dna_WidgetCategories](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Title] [nvarchar](50) NULL,
	[Description] [ntext] NULL,
 CONSTRAINT [PK_Categories] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO



/****** Object:  Table [dbo].[dna_WebSettings]    Script Date: 08/19/2010 11:51:28 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[dna_WebSettings](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Title] [nvarchar](50) NULL,
	[Description] [ntext] NULL,
	[LogoImageUrl] [nvarchar](1024) NULL,
	[SearchKeywords] [ntext] NULL,
	[TimeZone] [nvarchar](255) NULL,
	[Theme] [nvarchar](255) NULL,
	[Copyright] [ntext] NULL,
	[DefaultLanguage] [nvarchar](50) NULL,
	[ShortcutIconUrl] [nvarchar](1024) NULL,
	[GoogleKey] [nvarchar](1024) NULL,
	[Layout] [nvarchar](1024) NULL,
	[Properties] [ntext] NULL,
	[AllowExtensions] [ntext] NULL,
	[MaximumFileSize] [int] NOT NULL,
	[GoogleMapKey] [nvarchar](1024) NULL,
	[MasterName] [nvarchar](1024) NULL,
	[SMTPHost] [nvarchar](1024) NULL,
	[SMTPPassword] [nvarchar](255) NULL,
	[SMTPUserName] [nvarchar](255) NULL,
	[SMTPPort] [int] NOT NULL,
	[SMTPUsedDefaultCredentials] [bit] NOT NULL,
	[SiteMailAccount] [nvarchar](1024) NULL,
	[MostOnlineUserCount] [int] NOT NULL,
	[MostOnlined] [datetime] NOT NULL,
	[CssText] [ntext] NULL,
	[EnableUserRegistration] [bit] NOT NULL,
	[DefaultUrl] [nvarchar](1024) NULL,
 CONSTRAINT [PK_Portals] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO


/****** Object:  Table [dbo].[dna_WebPages]    Script Date: 08/19/2010 11:51:28 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[dna_WebPages](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[Path] [nvarchar](1024) NOT NULL,
	[Title] [nvarchar](255) NULL,
	[Description] [ntext] NULL,
	[ViewData] [ntext] NULL,
	[ViewName] [nvarchar](255) NULL,
	[IsStatic] [bit] NOT NULL,
	[ShowInMenu] [bit] NOT NULL,
	[IsShared] [bit] NOT NULL,
	[AllowAnonymous] [bit] NOT NULL,
	[Pos] [int] NOT NULL,
	[ParentID] [int] NOT NULL,
	[Target] [nvarchar](50) NOT NULL,
	[LastModified] [datetime] NOT NULL,
	[Created] [datetime] NOT NULL,
	[Owner] [nvarchar](255) NOT NULL,
	[LinkUrl] [nvarchar](1024) NULL,
	[Personalizable] [bit] NOT NULL,
 CONSTRAINT [PK_WebPages] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO


/****** Object:  Table [dbo].[dna_PermissionSets]    Script Date: 08/19/2010 11:51:28 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[dna_PermissionSets](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[Name] [nvarchar](100) NOT NULL,
	[Title] [nvarchar](255) NULL,
	[Description] [ntext] NULL,
 CONSTRAINT [PK_PermissionSets] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

/****** Object:  Table [dbo].[dna_Permissions]    Script Date: 08/19/2010 11:51:28 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[dna_Permissions](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[Controller] [nvarchar](255) NOT NULL,
	[Action] [nvarchar](255) NOT NULL,
	[PermissionSetID] [int] NOT NULL,
	[Title] [nvarchar](255) NULL,
	[Description] [ntext] NULL,
	[Assembly] [nvarchar](1024) NOT NULL,
 CONSTRAINT [PK_Permissions] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

/****** Object:  Table [dbo].[dna_WidgetDescriptors]    Script Date: 08/19/2010 11:51:28 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[dna_WidgetDescriptors](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[CatID] [int] NOT NULL,
	[PackageID] [int] NOT NULL,
	[Title] [nvarchar](50) NULL,
	[Url] [nvarchar](1024) NULL,
	[Action] [nvarchar](255) NULL,
	[Defaults] [ntext] NULL,
	[IsClosable] [bit] NULL,
	[IsDeletable] [bit] NULL,
	[ShowHeader] [bit] NULL,
	[Version] [nvarchar](50) NULL,
	[ImageUrl] [nvarchar](1024) NULL,
	[Description] [ntext] NULL,
	[Controller] [nvarchar](255) NULL,
	[IconUrl] [nvarchar](1024) NULL,
	[ShowBorder] [bit] NOT NULL,
 CONSTRAINT [PK_WidgetMetas] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO

/****** Object:  Table [dbo].[dna_WebPageRoles]    Script Date: 08/19/2010 11:51:28 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[dna_WebPageRoles](
	[RoleName] [nvarchar](256) NOT NULL,
	[PageID] [int] NOT NULL,
 CONSTRAINT [PK_dna_WebPageRoles] PRIMARY KEY CLUSTERED 
(
	[RoleName] ASC,
	[PageID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO


/****** Object:  Table [dbo].[dna_PermsInRoles]    Script Date: 08/19/2010 11:51:28 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[dna_PermsInRoles](
	[PermID] [int] NOT NULL,
	[RoleName] [nvarchar](50) NOT NULL,
 CONSTRAINT [PK_PermsInRoles] PRIMARY KEY CLUSTERED 
(
	[PermID] ASC,
	[RoleName] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[dna_Widgets]    Script Date: 08/19/2010 11:51:28 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
CREATE TABLE [dbo].[dna_Widgets](
	[ID] [uniqueidentifier] NOT NULL,
	[Title] [nvarchar](255) NULL,
	[TitleLinkUrl] [nvarchar](1024) NULL,
	[IconUrl] [nvarchar](1024) NULL,
	[ShowHeader] [bit] NOT NULL,
	[ShowBorder] [bit] NOT NULL,
	[IsDeletable] [bit] NOT NULL,
	[IsClosable] [bit] NOT NULL,
	[IsExpanded] [bit] NOT NULL,
	[Pos] [int] NOT NULL,
	[Data] [varbinary](max) NULL,
	[Url] [nvarchar](1024) NULL,
	[Action] [nvarchar](255) NULL,
	[ZoneID] [nvarchar](255) NOT NULL,
	[PageID] [int] NOT NULL,
	[DescriptorID] [int] NOT NULL,
	[Controller] [nvarchar](255) NULL,
	[BackgroundColor] [nvarchar](10) NULL,
	[ForeColor] [nvarchar](10) NULL,
 CONSTRAINT [PK_Widgets] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
SET ANSI_PADDING OFF
GO


/****** Object:  Default [DF_dna_Log_IsAnonymous]    Script Date: 08/19/2010 11:51:28 ******/
ALTER TABLE [dbo].[dna_EventLog] ADD  CONSTRAINT [DF_dna_Log_IsAnonymous]  DEFAULT ((1)) FOR [IsAnonymous]
GO
/****** Object:  Default [DF_Packages_IconHeight]    Script Date: 08/19/2010 11:51:28 ******/
ALTER TABLE [dbo].[dna_PackageInfos] ADD  CONSTRAINT [DF_Packages_IconHeight]  DEFAULT ((16)) FOR [IconHeight]
GO
/****** Object:  Default [DF_Packages_IconWidth]    Script Date: 08/19/2010 11:51:28 ******/
ALTER TABLE [dbo].[dna_PackageInfos] ADD  CONSTRAINT [DF_Packages_IconWidth]  DEFAULT ((16)) FOR [IconWidth]
GO
/****** Object:  Default [DF_Packages_Version]    Script Date: 08/19/2010 11:51:28 ******/
ALTER TABLE [dbo].[dna_PackageInfos] ADD  CONSTRAINT [DF_Packages_Version]  DEFAULT (N'v1.0.0.0') FOR [Version]
GO
/****** Object:  Default [DF_Packages_LastUpdated]    Script Date: 08/19/2010 11:51:28 ******/
ALTER TABLE [dbo].[dna_PackageInfos] ADD  CONSTRAINT [DF_Packages_LastUpdated]  DEFAULT (getdate()) FOR [Installed]
GO
/****** Object:  Default [DF_dna_WebPages_IsStatic]    Script Date: 08/19/2010 11:51:28 ******/
ALTER TABLE [dbo].[dna_WebPages] ADD  CONSTRAINT [DF_dna_WebPages_IsStatic]  DEFAULT ((0)) FOR [IsStatic]
GO
/****** Object:  Default [DF_WebPages_ShowInMenu]    Script Date: 08/19/2010 11:51:28 ******/
ALTER TABLE [dbo].[dna_WebPages] ADD  CONSTRAINT [DF_WebPages_ShowInMenu]  DEFAULT ((0)) FOR [ShowInMenu]
GO
/****** Object:  Default [DF_dna_WebPages_IsShared]    Script Date: 08/19/2010 11:51:28 ******/
ALTER TABLE [dbo].[dna_WebPages] ADD  CONSTRAINT [DF_dna_WebPages_IsShared]  DEFAULT ((1)) FOR [IsShared]
GO
/****** Object:  Default [DF_dna_WebPages_AllowAnonymous]    Script Date: 08/19/2010 11:51:28 ******/
ALTER TABLE [dbo].[dna_WebPages] ADD  CONSTRAINT [DF_dna_WebPages_AllowAnonymous]  DEFAULT ((1)) FOR [AllowAnonymous]
GO
/****** Object:  Default [DF_WebPages_Pos]    Script Date: 08/19/2010 11:51:28 ******/
ALTER TABLE [dbo].[dna_WebPages] ADD  CONSTRAINT [DF_WebPages_Pos]  DEFAULT ((0)) FOR [Pos]
GO
/****** Object:  Default [DF_dna_WebPages_ParentID]    Script Date: 08/19/2010 11:51:28 ******/
ALTER TABLE [dbo].[dna_WebPages] ADD  CONSTRAINT [DF_dna_WebPages_ParentID]  DEFAULT ((-1)) FOR [ParentID]
GO
/****** Object:  Default [DF_WebPages_Target]    Script Date: 08/19/2010 11:51:28 ******/
ALTER TABLE [dbo].[dna_WebPages] ADD  CONSTRAINT [DF_WebPages_Target]  DEFAULT ('_self') FOR [Target]
GO
/****** Object:  Default [DF_dna_WebPages_LastModified]    Script Date: 08/19/2010 11:51:28 ******/
ALTER TABLE [dbo].[dna_WebPages] ADD  CONSTRAINT [DF_dna_WebPages_LastModified]  DEFAULT (getdate()) FOR [LastModified]
GO
/****** Object:  Default [DF_dna_WebPages_Created]    Script Date: 08/19/2010 11:51:28 ******/
ALTER TABLE [dbo].[dna_WebPages] ADD  CONSTRAINT [DF_dna_WebPages_Created]  DEFAULT (getdate()) FOR [Created]
GO
/****** Object:  Default [DF_dna_WebPages_Owner]    Script Date: 08/19/2010 11:51:28 ******/
ALTER TABLE [dbo].[dna_WebPages] ADD  CONSTRAINT [DF_dna_WebPages_Owner]  DEFAULT (N'') FOR [Owner]
GO
/****** Object:  Default [DF_dna_WebPages_Personalizable]    Script Date: 08/19/2010 11:51:28 ******/
ALTER TABLE [dbo].[dna_WebPages] ADD  CONSTRAINT [DF_dna_WebPages_Personalizable]  DEFAULT ((0)) FOR [Personalizable]
GO
/****** Object:  Default [DF_dna_WebSettings_MaximumFileSize]    Script Date: 08/19/2010 11:51:28 ******/
ALTER TABLE [dbo].[dna_WebSettings] ADD  CONSTRAINT [DF_dna_WebSettings_MaximumFileSize]  DEFAULT ((1024000000)) FOR [MaximumFileSize]
GO
/****** Object:  Default [DF_dna_WebSettings_SMTPPort]    Script Date: 08/19/2010 11:51:28 ******/
ALTER TABLE [dbo].[dna_WebSettings] ADD  CONSTRAINT [DF_dna_WebSettings_SMTPPort]  DEFAULT ((25)) FOR [SMTPPort]
GO
/****** Object:  Default [DF_dna_WebSettings_SMTPUsedDefaultCredentials]    Script Date: 08/19/2010 11:51:28 ******/
ALTER TABLE [dbo].[dna_WebSettings] ADD  CONSTRAINT [DF_dna_WebSettings_SMTPUsedDefaultCredentials]  DEFAULT ((1)) FOR [SMTPUsedDefaultCredentials]
GO
/****** Object:  Default [DF_dna_WebSettings_MostOnlineUserCount]    Script Date: 08/19/2010 11:51:28 ******/
ALTER TABLE [dbo].[dna_WebSettings] ADD  CONSTRAINT [DF_dna_WebSettings_MostOnlineUserCount]  DEFAULT ((0)) FOR [MostOnlineUserCount]
GO
/****** Object:  Default [DF_dna_WebSettings_MostOnlined]    Script Date: 08/19/2010 11:51:28 ******/
ALTER TABLE [dbo].[dna_WebSettings] ADD  CONSTRAINT [DF_dna_WebSettings_MostOnlined]  DEFAULT (getdate()) FOR [MostOnlined]
GO
/****** Object:  Default [DF_WidgetMetas_IsClosable]    Script Date: 08/19/2010 11:51:28 ******/
ALTER TABLE [dbo].[dna_WidgetDescriptors] ADD  CONSTRAINT [DF_WidgetMetas_IsClosable]  DEFAULT ((1)) FOR [IsClosable]
GO
/****** Object:  Default [DF_WidgetMetas_IsDeletable]    Script Date: 08/19/2010 11:51:28 ******/
ALTER TABLE [dbo].[dna_WidgetDescriptors] ADD  CONSTRAINT [DF_WidgetMetas_IsDeletable]  DEFAULT ((1)) FOR [IsDeletable]
GO
/****** Object:  Default [DF_WidgetMetas_ShowHeader]    Script Date: 08/19/2010 11:51:28 ******/
ALTER TABLE [dbo].[dna_WidgetDescriptors] ADD  CONSTRAINT [DF_WidgetMetas_ShowHeader]  DEFAULT ((1)) FOR [ShowHeader]
GO
/****** Object:  Default [DF_WidgetMetas_Version]    Script Date: 08/19/2010 11:51:28 ******/
ALTER TABLE [dbo].[dna_WidgetDescriptors] ADD  CONSTRAINT [DF_WidgetMetas_Version]  DEFAULT (N'v1.0') FOR [Version]
GO
/****** Object:  Default [DF_dna_WidgetDescriptors_ShowBorder]    Script Date: 08/19/2010 11:51:28 ******/
ALTER TABLE [dbo].[dna_WidgetDescriptors] ADD  CONSTRAINT [DF_dna_WidgetDescriptors_ShowBorder]  DEFAULT ((1)) FOR [ShowBorder]
GO
/****** Object:  Default [DF_Widgets_ID]    Script Date: 08/19/2010 11:51:28 ******/
ALTER TABLE [dbo].[dna_Widgets] ADD  CONSTRAINT [DF_Widgets_ID]  DEFAULT (newid()) FOR [ID]
GO
/****** Object:  Default [DF_Widgets_ShowHeader]    Script Date: 08/19/2010 11:51:28 ******/
ALTER TABLE [dbo].[dna_Widgets] ADD  CONSTRAINT [DF_Widgets_ShowHeader]  DEFAULT ((1)) FOR [ShowHeader]
GO
/****** Object:  Default [DF_dna_Widgets_ShowBorder]    Script Date: 08/19/2010 11:51:28 ******/
ALTER TABLE [dbo].[dna_Widgets] ADD  CONSTRAINT [DF_dna_Widgets_ShowBorder]  DEFAULT ((1)) FOR [ShowBorder]
GO
/****** Object:  Default [DF_Widgets_IsDeletable]    Script Date: 08/19/2010 11:51:28 ******/
ALTER TABLE [dbo].[dna_Widgets] ADD  CONSTRAINT [DF_Widgets_IsDeletable]  DEFAULT ((1)) FOR [IsDeletable]
GO
/****** Object:  Default [DF_Widgets_IsClosable]    Script Date: 08/19/2010 11:51:28 ******/
ALTER TABLE [dbo].[dna_Widgets] ADD  CONSTRAINT [DF_Widgets_IsClosable]  DEFAULT ((1)) FOR [IsClosable]
GO
/****** Object:  Default [DF_Widgets_IsExpanded]    Script Date: 08/19/2010 11:51:28 ******/
ALTER TABLE [dbo].[dna_Widgets] ADD  CONSTRAINT [DF_Widgets_IsExpanded]  DEFAULT ((1)) FOR [IsExpanded]
GO
/****** Object:  Default [DF_Widgets_Pos]    Script Date: 08/19/2010 11:51:28 ******/
ALTER TABLE [dbo].[dna_Widgets] ADD  CONSTRAINT [DF_Widgets_Pos]  DEFAULT ((0)) FOR [Pos]
GO
/****** Object:  Default [DF_Widgets_ZoneID]    Script Date: 08/19/2010 11:51:28 ******/
ALTER TABLE [dbo].[dna_Widgets] ADD  CONSTRAINT [DF_Widgets_ZoneID]  DEFAULT ('zone1') FOR [ZoneID]
GO


/****** Object:  ForeignKey [FK_Permissions_PermissionSets]    Script Date: 08/19/2010 11:51:28 ******/
ALTER TABLE [dbo].[dna_Permissions]  WITH CHECK ADD  CONSTRAINT [FK_Permissions_PermissionSets] FOREIGN KEY([PermissionSetID])
REFERENCES [dbo].[dna_PermissionSets] ([ID])
GO
ALTER TABLE [dbo].[dna_Permissions] CHECK CONSTRAINT [FK_Permissions_PermissionSets]
GO
/****** Object:  ForeignKey [FK_PermsInRoles_Permissions]    Script Date: 08/19/2010 11:51:28 ******/
ALTER TABLE [dbo].[dna_PermsInRoles]  WITH CHECK ADD  CONSTRAINT [FK_PermsInRoles_Permissions] FOREIGN KEY([PermID])
REFERENCES [dbo].[dna_Permissions] ([ID])
GO
ALTER TABLE [dbo].[dna_PermsInRoles] CHECK CONSTRAINT [FK_PermsInRoles_Permissions]
GO
/****** Object:  ForeignKey [FK_PermsInRoles_PermsInRoles]    Script Date: 08/19/2010 11:51:28 ******/
ALTER TABLE [dbo].[dna_PermsInRoles]  WITH CHECK ADD  CONSTRAINT [FK_PermsInRoles_PermsInRoles] FOREIGN KEY([PermID], [RoleName])
REFERENCES [dbo].[dna_PermsInRoles] ([PermID], [RoleName])
GO
ALTER TABLE [dbo].[dna_PermsInRoles] CHECK CONSTRAINT [FK_PermsInRoles_PermsInRoles]
GO

/****** Object:  ForeignKey [FK_dna_WebPageRoles_dna_WebPages]    Script Date: 08/19/2010 11:51:28 ******/
ALTER TABLE [dbo].[dna_WebPageRoles]  WITH CHECK ADD  CONSTRAINT [FK_dna_WebPageRoles_dna_WebPages] FOREIGN KEY([PageID])
REFERENCES [dbo].[dna_WebPages] ([ID])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[dna_WebPageRoles] CHECK CONSTRAINT [FK_dna_WebPageRoles_dna_WebPages]
GO
/****** Object:  ForeignKey [FK_dna_WidgetDescriptor_dna_PackageInfos]    Script Date: 08/19/2010 11:51:28 ******/
ALTER TABLE [dbo].[dna_WidgetDescriptors]  WITH CHECK ADD  CONSTRAINT [FK_dna_WidgetDescriptor_dna_PackageInfos] FOREIGN KEY([PackageID])
REFERENCES [dbo].[dna_PackageInfos] ([ID])
GO
ALTER TABLE [dbo].[dna_WidgetDescriptors] CHECK CONSTRAINT [FK_dna_WidgetDescriptor_dna_PackageInfos]
GO
/****** Object:  ForeignKey [FK_WidgetMetas_Categories]    Script Date: 08/19/2010 11:51:28 ******/
ALTER TABLE [dbo].[dna_WidgetDescriptors]  WITH CHECK ADD  CONSTRAINT [FK_WidgetMetas_Categories] FOREIGN KEY([CatID])
REFERENCES [dbo].[dna_WidgetCategories] ([Id])
GO
ALTER TABLE [dbo].[dna_WidgetDescriptors] CHECK CONSTRAINT [FK_WidgetMetas_Categories]
GO
/****** Object:  ForeignKey [FK_dna_Widgets_dna_WidgetDescriptors]    Script Date: 08/19/2010 11:51:28 ******/
ALTER TABLE [dbo].[dna_Widgets]  WITH CHECK ADD  CONSTRAINT [FK_dna_Widgets_dna_WidgetDescriptors] FOREIGN KEY([DescriptorID])
REFERENCES [dbo].[dna_WidgetDescriptors] ([ID])
GO
ALTER TABLE [dbo].[dna_Widgets] CHECK CONSTRAINT [FK_dna_Widgets_dna_WidgetDescriptors]
GO
/****** Object:  ForeignKey [FK_Widgets_WebPages]    Script Date: 08/19/2010 11:51:28 ******/
ALTER TABLE [dbo].[dna_Widgets]  WITH CHECK ADD  CONSTRAINT [FK_Widgets_WebPages] FOREIGN KEY([PageID])
REFERENCES [dbo].[dna_WebPages] ([ID])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[dna_Widgets] CHECK CONSTRAINT [FK_Widgets_WebPages]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- ===========================================
-- Author:		<Ray liang>
-- Create date: <2010-9-2>
-- Description:	<This sql script file use to get the statistics object>
-- Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
-- Dual licensed under the MIT and GPL licenses:
-- http://www.opensource.org/licenses/mit-license.php
-- http://www.gnu.org/licenses/gpl.html
-- ============================================

CREATE PROCEDURE [dbo].[dna_statistics]
@interval int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

DECLARE @mostUserCount int,
        @mostOnlined datetime
        
SELECT TOP 1 @mostUserCount=MostOnlineUserCount,
             @mostOnlined=MostOnlined 
FROM [dbo].[dna_websettings]

SELECT Count(distinct clientAddress) AS Visits,
       Count(clientAddress) AS PageView,
       RegistedUserCount = (SELECT Count(UserID)FROM [aspnet_Membership]),
       OnlineGuests=(select Count(distinct userName)FROM [dna_eventlog] WHERE IsAnonymous=1 AND(Logged Between DateAdd(MINUTE,-@interval,GetDate()) AND GetDate())),
       OnlineRegisters=(select Count(distinct userName)FROM [dna_eventlog] WHERE IsAnonymous=0 AND(Logged Between DateAdd(MINUTE,-@interval,GetDate()) AND GetDate())),
       MostOnlineCount=@mostUserCount,
       MostOnlined=@mostOnlined
FROM [dna_eventlog]
WHERE DatePart(YYYY,logged)=DatePart(YYYY,GetDate()) AND
      DatePart(MM,logged)=DatePart(MM,GetDate()) AND
      DatePart(dd,logged)=DatePart(dd,GetDate())
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Ray Liang>
-- Create date: <2010-9-2>
-- Description:	<Description,This procedure use to get the online users list>
-- Modified: <2010-9-6>
--Changed log: fix this procedure could not select the users bugs.
-- =============================================
CREATE PROCEDURE [dbo].[dna_getOnlineUsers]
@isAnonymous bit,
@interval int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
SELECT distinct userName 
FROM [dna_eventlog]
WHERE IsAnonymous=@isAnonymous AND
      (Logged Between DateAdd(MINUTE,-@interval,GetDate()) AND GetDate())
END
GO


-- ==============================================================================
-- Author:		<Ray liang>
-- Create date: <2010-8-30>
-- Description:	<This sql script file use to create the tables,views and storeproduces for Publishing application plugin>
-- Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
-- Dual licensed under the MIT and GPL licenses:
-- http://www.opensource.org/licenses/mit-license.php
-- http://www.gnu.org/licenses/gpl.html
-- ===============================================================================

/****** Object:  Table [dbo].[Publishing_Category]    Script Date: 08/26/2010 22:57:15 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Publishing_Category](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[Title] [nvarchar](50) NOT NULL,
	[Description] [ntext] NULL,
	[Url] [nvarchar](1024) NULL,
	[ParentID] [int] NOT NULL,
	[IsModerated] [bit] NOT NULL,
	[EnableVersioning] [bit] NOT NULL,
	[EnableComments] [bit] NOT NULL,
	[ArticleType] [int] NULL,
	[TotalPosts] [int] NOT NULL,
	[LastPosted] [datetime] NULL,
	[Path] [nvarchar](1024) NULL,
	[Pos] [int] NOT NULL,
	[AllowAnonymousPostComment] [bit] NOT NULL,
 CONSTRAINT [PK_ArticleCategories] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO

ALTER TABLE [dbo].[Publishing_Category] ADD  CONSTRAINT [DF_ArticleCategories_IsModerated]  DEFAULT ((0)) FOR [IsModerated]
GO

ALTER TABLE [dbo].[Publishing_Category] ADD  CONSTRAINT [DF_ArticleCategories_EnableVersioning]  DEFAULT ((1)) FOR [EnableVersioning]
GO

ALTER TABLE [dbo].[Publishing_Category] ADD  CONSTRAINT [DF_ArticleCategories_EnableComments]  DEFAULT ((1)) FOR [EnableComments]
GO

ALTER TABLE [dbo].[Publishing_Category] ADD  CONSTRAINT [DF_ArticleCategories_ArticleType]  DEFAULT ((0)) FOR [ArticleType]
GO

ALTER TABLE [dbo].[Publishing_Category] ADD  CONSTRAINT [DF_ArticleCategories_TotalPosts]  DEFAULT ((0)) FOR [TotalPosts]
GO

ALTER TABLE [dbo].[Publishing_Category] ADD  CONSTRAINT [DF_Publishing_Category_Pos]  DEFAULT ((0)) FOR [Pos]
GO

ALTER TABLE [dbo].[Publishing_Category] ADD  CONSTRAINT [DF_Publishing_Category_AllowAnonymousPostComment]  DEFAULT ((0)) FOR [AllowAnonymousPostComment]
GO

/****** Object:  Table [dbo].[Publishing_Articles]    Script Date: 08/30/2010 00:35:30 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Publishing_Articles](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[Title] [nvarchar](255) NOT NULL,
	[Summary] [ntext] NULL,
	[Body] [ntext] NULL,
	[Tags] [nvarchar](255) NULL,
	[Reads] [int] NOT NULL,
	[Rating] [float] NOT NULL,
	[LastModified] [datetime] NOT NULL,
	[Posted] [datetime] NOT NULL,
	[UserName] [nvarchar](50) NULL,
	[ParentID] [int] NULL,
	[Version] [int] NOT NULL,
	[CategoryID] [int] NOT NULL,
	[IsPublished] [bit] NOT NULL,
	[IsAppoved] [bit] NOT NULL,
	[ContentFormat] [int] NOT NULL,
	[TotalRatings] [int] NOT NULL,
	[TotalComments] [int] NOT NULL,
	[Language] [nvarchar](50) NULL,
	[ReferenceUrl] [nvarchar](1024) NULL,
	[Pos] [int] NOT NULL,
	[Path] [nvarchar](1024) NULL,
 CONSTRAINT [PK_Articles] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO

ALTER TABLE [dbo].[Publishing_Articles]  WITH CHECK ADD  CONSTRAINT [FK_Articles_ArticleCategories] FOREIGN KEY([CategoryID])
REFERENCES [dbo].[Publishing_Category] ([ID])
ON DELETE CASCADE
GO

ALTER TABLE [dbo].[Publishing_Articles] CHECK CONSTRAINT [FK_Articles_ArticleCategories]
GO

ALTER TABLE [dbo].[Publishing_Articles] ADD  CONSTRAINT [DF_icontent_Articles_Reads]  DEFAULT ((0)) FOR [Reads]
GO

ALTER TABLE [dbo].[Publishing_Articles] ADD  CONSTRAINT [DF_icontent_Articles_Rating]  DEFAULT ((0)) FOR [Rating]
GO

ALTER TABLE [dbo].[Publishing_Articles] ADD  CONSTRAINT [DF_icontent_Articles_LastModified]  DEFAULT (getdate()) FOR [LastModified]
GO

ALTER TABLE [dbo].[Publishing_Articles] ADD  CONSTRAINT [DF_icontent_Articles_Posted]  DEFAULT (getdate()) FOR [Posted]
GO

ALTER TABLE [dbo].[Publishing_Articles] ADD  CONSTRAINT [DF_icontent_Articles_Version]  DEFAULT ((0)) FOR [Version]
GO

ALTER TABLE [dbo].[Publishing_Articles] ADD  CONSTRAINT [DF_icontent_Articles_IsPublished]  DEFAULT ((1)) FOR [IsPublished]
GO

ALTER TABLE [dbo].[Publishing_Articles] ADD  CONSTRAINT [DF_icontent_Articles_IsAppoved]  DEFAULT ((1)) FOR [IsAppoved]
GO

ALTER TABLE [dbo].[Publishing_Articles] ADD  CONSTRAINT [DF_Publishing_Articles_ContentFormat]  DEFAULT ((1)) FOR [ContentFormat]
GO

ALTER TABLE [dbo].[Publishing_Articles] ADD  CONSTRAINT [DF_Articles_TotalRatings]  DEFAULT ((0)) FOR [TotalRatings]
GO

ALTER TABLE [dbo].[Publishing_Articles] ADD  CONSTRAINT [DF_Articles_TotalComments]  DEFAULT ((0)) FOR [TotalComments]
GO

ALTER TABLE [dbo].[Publishing_Articles] ADD  CONSTRAINT [DF_icontent_Articles_Pos]  DEFAULT ((0)) FOR [Pos]
GO

/****** Object:  Table [dbo].[Publishing_Comments]    Script Date: 08/24/2010 14:26:06 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Publishing_Comments](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[ArticleID] [int] NOT NULL,
	[UserName] [nvarchar](50) NULL,
	[Posted] [datetime] NOT NULL,
	[IP] [nvarchar](50) NOT NULL,
	[Body] [ntext] NULL,
	[Email] [nvarchar](1024) NULL,
	[WebSite] [nvarchar](1024) NULL,
 CONSTRAINT [PK_Comments] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO

ALTER TABLE [dbo].[Publishing_Comments]  WITH CHECK ADD  CONSTRAINT [FK_Comments_Articles] FOREIGN KEY([ArticleID])
REFERENCES [dbo].[Publishing_Articles] ([ID])
ON DELETE CASCADE
GO

ALTER TABLE [dbo].[Publishing_Comments] CHECK CONSTRAINT [FK_Comments_Articles]
GO

ALTER TABLE [dbo].[Publishing_Comments] ADD  CONSTRAINT [DF_icontent_Comments_Posted]  DEFAULT (getdate()) FOR [Posted]
GO

/****** Object:  Table [dbo].[Publishing_Ratings]    Script Date: 08/24/2010 14:26:16 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Publishing_Ratings](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[IP] [nvarchar](50) NULL,
	[Rating] [int] NOT NULL,
	[ArticleID] [int] NOT NULL,
 CONSTRAINT [PK_ArticleRatings] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

ALTER TABLE [dbo].[Publishing_Ratings]  WITH CHECK ADD  CONSTRAINT [FK_ArticleRatings_Articles] FOREIGN KEY([ArticleID])
REFERENCES [dbo].[Publishing_Articles] ([ID])
ON DELETE CASCADE
GO

ALTER TABLE [dbo].[Publishing_Ratings] CHECK CONSTRAINT [FK_ArticleRatings_Articles]
GO


/****** Object:  Table [dbo].[Publishing_TranslatedCopy]    Script Date: 08/30/2010 00:37:08 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Publishing_TranslatedCopy](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[ArticleID] [int] NOT NULL,
	[Body] [ntext] NULL,
	[Title] [nvarchar](255) NULL,
	[Summary] [ntext] NULL,
	[Language] [nvarchar](50) NULL,
	[ContentFormat] [int] NOT NULL,
 CONSTRAINT [PK_TranslatedCopy] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO

ALTER TABLE [dbo].[Publishing_TranslatedCopy]  WITH CHECK ADD  CONSTRAINT [FK_TranslatedCopy_Articles] FOREIGN KEY([ArticleID])
REFERENCES [dbo].[Publishing_Articles] ([ID])
ON DELETE CASCADE
GO

ALTER TABLE [dbo].[Publishing_TranslatedCopy] CHECK CONSTRAINT [FK_TranslatedCopy_Articles]
GO

ALTER TABLE [dbo].[Publishing_TranslatedCopy] ADD  CONSTRAINT [DF_Publishing_TranslatedCopy_ContentFormat]  DEFAULT ((1)) FOR [ContentFormat]
GO



/****** Object:  Table [dbo].[Publishing_Versions]    Script Date: 08/24/2010 14:26:36 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Publishing_Versions](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[Body] [ntext] NULL,
	[LastModified] [datetime] NOT NULL,
	[Version] [int] NULL,
	[ArticleID] [int] NOT NULL,
	[Modified] [nvarchar](50) NULL,
 CONSTRAINT [PK_ArticleVersions] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO

ALTER TABLE [dbo].[Publishing_Versions]  WITH CHECK ADD  CONSTRAINT [FK_icontent_Versions_icontent_Articles] FOREIGN KEY([ArticleID])
REFERENCES [dbo].[Publishing_Articles] ([ID])
ON DELETE CASCADE
GO

ALTER TABLE [dbo].[Publishing_Versions] CHECK CONSTRAINT [FK_icontent_Versions_icontent_Articles]
GO

ALTER TABLE [dbo].[Publishing_Versions] ADD  CONSTRAINT [DF_icontent_Versions_LastModified]  DEFAULT (getdate()) FOR [LastModified]
GO

/****** Object:  StoredProcedure [dbo].[Publishing_archives]    Script Date: 08/24/2010 14:26:57 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Ray
-- Create date: 2010-8-22
-- Description:	Get the dates of articles
-- =============================================
CREATE PROCEDURE [dbo].[Publishing_archives]
@catID int,
@username nvarchar(50)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

IF (@catID=0)BEGIN

    IF (@username='')
		SELECT distinct RTRIM(LTRIM(STR(DatePart(YYYY,[Posted]))))+'/'+
						RTRIM(LTRIM(STR(DatePart(MM,[Posted])))) AS DisplayText,
						DatePart(YYYY,[Posted])AS [Year],
						DatePart(MM,[Posted])AS [Month]
		FROM [dbo].[Publishing_Articles]
		ORDER BY [Year],[Month]
    ELSE
		SELECT distinct RTRIM(LTRIM(STR(DatePart(YYYY,[Posted]))))+'/'+
						RTRIM(LTRIM(STR(DatePart(MM,[Posted])))) AS DisplayText,
						DatePart(YYYY,[Posted])AS [Year],
						DatePart(MM,[Posted])AS [Month]
		FROM [dbo].[Publishing_Articles]
		WHERE UserName=@username
		ORDER BY [Year],[Month]
    
END    
ELSE
BEGIN
    IF (@username='')
		SELECT distinct RTRIM(LTRIM(STR(DatePart(YYYY,[Posted]))))+'/'+
						RTRIM(LTRIM(STR(DatePart(MM,[Posted])))) AS DisplayText,
						DatePart(YYYY,[Posted])AS [Year],
						DatePart(MM,[Posted])AS [Month]
		FROM [dbo].[Publishing_Articles]
		WHERE CategoryID=@catID
		ORDER BY [Year],[Month]
    ELSE
		SELECT distinct RTRIM(LTRIM(STR(DatePart(YYYY,[Posted]))))+'/'+
						RTRIM(LTRIM(STR(DatePart(MM,[Posted])))) AS DisplayText,
						DatePart(YYYY,[Posted])AS [Year],
						DatePart(MM,[Posted])AS [Month]
		FROM [dbo].[Publishing_Articles]
		WHERE CategoryID=@catID AND UserName=@username
		ORDER BY [Year],[Month]
    
END

END

GO


-- =======================================================================
-- Author:		<Ray liang>
-- Create date: <2010-8-30>
-- Description:	<This sql script file use to create the tables,views and storeproduces for Community application plugin>
-- Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
-- Dual licensed under the MIT and GPL licenses:
-- http://www.opensource.org/licenses/mit-license.php
-- http://www.gnu.org/licenses/gpl.html
-- =======================================================================

/****** Object:  Table [dbo].[community_Forums]    Script Date: 08/30/2010 15:48:02 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[community_Forums](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[Title] [nvarchar](255) NOT NULL,
	[Description] [ntext] NULL,
	[IsGroup] [bit] NOT NULL,
	[ParentID] [int] NOT NULL,
	[IsModerated] [bit] NOT NULL,
	[TotalPosts] [int] NOT NULL,
	[TotalThreads] [int] NOT NULL,
	[LastPostID] [int] NULL,
	[LastPostedUser] [nvarchar](50) NULL,
	[LastPosted] [datetime] NULL,
	[Theme] [nvarchar](255) NULL,
	[IsLock] [bit] NOT NULL,
	[Pos] [int] NOT NULL,
	[AllowAttachment] [bit] NOT NULL,
	[AllowAnonymous] [bit] NOT NULL,
 CONSTRAINT [PK_Forums] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[community_Ranks]    Script Date: 08/30/2010 15:48:02 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[community_Ranks](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[Name] [nvarchar](255) NOT NULL,
	[IsStart] [bit] NOT NULL,
	[MinimumPosts] [int] NOT NULL,
	[ImageUrl] [nvarchar](1024) NULL,
 CONSTRAINT [PK_iforum_Ranks] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[community_Moderators]    Script Date: 08/30/2010 15:48:02 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[community_Moderators](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[Moderator] [nvarchar](50) NOT NULL,
	[ForumID] [int] NOT NULL,
 CONSTRAINT [PK_Moderators] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[community_Threads]    Script Date: 08/30/2010 15:48:02 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[community_Threads](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[Title] [nvarchar](255) NOT NULL,
	[Author] [nvarchar](50) NOT NULL,
	[IsPinned] [bit] NOT NULL,
	[TotalReads] [int] NOT NULL,
	[TotalPosts] [int] NOT NULL,
	[Posted] [datetime] NOT NULL,
	[LastPosted] [datetime] NOT NULL,
	[LastPostUser] [nvarchar](50) NOT NULL,
	[LastPostID] [int] NULL,
	[ForumID] [int] NOT NULL,
	[ThreadType] [int] NOT NULL,
	[IsLocked] [bit] NOT NULL,
	[Appoved] [datetime] NULL,
	[Moderator] [nvarchar](50) NULL,
	[IsAppoved] [bit] NOT NULL,
	[LinkTo] [nvarchar](1024) NULL,
 CONSTRAINT [PK_Threads] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[community_Posts]    Script Date: 08/30/2010 15:48:02 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[community_Posts](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[UserName] [nvarchar](50) NOT NULL,
	[Title] [nvarchar](255) NULL,
	[Body] [ntext] NULL,
	[IsThread] [bit] NOT NULL,
	[Posted] [datetime] NOT NULL,
	[LastModified] [datetime] NOT NULL,
	[Reads] [int] NOT NULL,
	[Ratings] [int] NOT NULL,
	[IsAppoved] [bit] NOT NULL,
	[Pos] [int] NOT NULL,
	[ForumID] [int] NOT NULL,
	[ThreadID] [int] NOT NULL,
	[ParentID] [int] NULL,
	[IsLocked] [bit] NOT NULL,
	[IP] [nvarchar](50) NULL,
	[Appoved] [datetime] NULL,
	[Moderator] [nvarchar](50) NULL,
	[IsDeleted] [bit] NOT NULL,
	[DeletedReason] [ntext] NULL,
	[Deleted] [date] NULL,
	[DeleteBy] [nvarchar](50) NULL,
 CONSTRAINT [PK_Posts] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  StoredProcedure [dbo].[community_thread_UpdateStates]    Script Date: 08/30/2010 15:47:55 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Ray liang>
-- Create date: <2010-8-16>
-- Description:	<This store procedure use to update the thread state>
-- Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
-- Dual licensed under the MIT and GPL licenses:
-- http://www.opensource.org/licenses/mit-license.php
-- http://www.gnu.org/licenses/gpl.html
-- =============================================
CREATE PROCEDURE [dbo].[community_thread_UpdateStates]
@id int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    DECLARE @totalPosts int,
            @lastPostUser nvarchar(50),   
            @lastPosted datetime,
            @lastPostID int  
   
   
    SELECT @lastPostUser=NULL
    
    SELECT @totalPosts=(SELECT COUNT([ID]) FROM community_Posts WHERE ThreadID=@id)

    IF (@totalPosts>0)
    BEGIN
      SELECT @lastPostID=(SELECT TOP 1 [ID]
                          FROM community_Posts
                          WHERE ThreadID=@id 
                          ORDER BY Posted desc)
      
      SELECT @lastPosted=Posted,
             @lastPostUser=UserName
      FROM community_Posts
      WHERE ID=@lastPostID                    
      
    END                      
    ELSE BEGIN
      SELECT @lastPostID=NULL,
             @lastPostUser=NULL,
             @lastPosted=NULL
    END
                            
    UPDATE community_Threads
    SET TotalPosts=@totalPosts,
        LastPosted=@lastPosted,
        LastPostID=@lastPostID,
        LastPostUser=@lastPostUser
    WHERE ID=@id
    
END
GO
/****** Object:  StoredProcedure [dbo].[community_statistics]    Script Date: 08/30/2010 20:57:57 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Ray liang>
-- Create date: <2010-8-30>
-- Description:	<This store procedure use to get the forums statistics>
-- Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
-- Dual licensed under the MIT and GPL licenses:
-- http://www.opensource.org/licenses/mit-license.php
-- http://www.gnu.org/licenses/gpl.html
-- =============================================
CREATE PROCEDURE [dbo].[community_statistics]
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	SELECT TotalThreads=(SELECT COUNT(ID) FROM community_Threads),
	       TotalPosts=(SELECT COUNT(ID) FROM community_Posts WHERE IsDeleted<>1),
	       TodayPosts=(SELECT COUNT(ID) FROM community_Posts WHERE IsDeleted<>1 AND DATEPART(YYYY,Posted)=DATEPART(YYYY,GETDATE()) AND DATEPART(M,Posted)=DATEPART(M,GETDATE()) AND DATEPART(D,Posted)=DATEPART(D,GETDATE())),
	       TodayThreads=(SELECT COUNT(ID) FROM community_Threads WHERE DATEPART(YYYY,Posted)=DATEPART(YYYY,GETDATE()) AND DATEPART(M,Posted)=DATEPART(M,GETDATE()) AND DATEPART(D,Posted)=DATEPART(D,GETDATE()))
END
GO

/****** Object:  StoredProcedure [dbo].[community_forum_UpdateStates]    Script Date: 08/30/2010 15:47:55 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Ray liang>
-- Create date: <2010-8-16>
-- Description:	<This store procedure use to update the forum state>
-- Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
-- Dual licensed under the MIT and GPL licenses:
-- http://www.opensource.org/licenses/mit-license.php
-- http://www.gnu.org/licenses/gpl.html
-- =============================================
CREATE PROCEDURE [dbo].[community_forum_UpdateStates]
@id int
AS
BEGIN
	SET NOCOUNT ON;
    DECLARE @totalPosts int,
            @lastPostUser nvarchar(50),   
            @lastPosted datetime,
            @lastPostID int  
   
   
    SELECT @lastPostUser=NULL
    
    SELECT @totalPosts=(SELECT COUNT([ID]) FROM community_Posts WHERE ForumID=@id AND IsAppoved=1)

    IF (@totalPosts>0)
    BEGIN
      SELECT @lastPostID=(SELECT TOP 1 [ID]
                          FROM community_Posts
                          WHERE ForumID=@id AND IsAppoved=1
                          ORDER BY Posted desc)
      
      SELECT @lastPosted=Posted,
             @lastPostUser=UserName
      FROM community_Posts
      WHERE ID=@lastPostID                    
      
    END                      
    ELSE BEGIN
      SELECT @lastPostID=NULL,
             @lastPostUser=NULL,
             @lastPosted=NULL
    END
                            
    UPDATE community_Forums
    SET TotalPosts=@totalPosts,
        TotalThreads=(SELECT COUNT([ID]) FROM community_Threads WHERE ForumID=@id AND IsAppoved=1),
        LastPosted=@lastPosted,
        LastPostID=@lastPostID,
        LastPostedUser=@lastPostUser
    WHERE ID=@id
    
END
GO
/****** Object:  Table [dbo].[community_attachments]    Script Date: 08/30/2010 15:48:02 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[community_attachments](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[FileName] [nvarchar](1024) NOT NULL,
	[PostID] [int] NOT NULL,
	[ContentType] [nvarchar](50) NULL,
 CONSTRAINT [PK_community_attachments] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Default [DF_iforum_Forums_IsGroup]    Script Date: 08/30/2010 15:48:02 ******/
ALTER TABLE [dbo].[community_Forums] ADD  CONSTRAINT [DF_iforum_Forums_IsGroup]  DEFAULT ((0)) FOR [IsGroup]
GO
/****** Object:  Default [DF_iforum_Forums_ParentID]    Script Date: 08/30/2010 15:48:02 ******/
ALTER TABLE [dbo].[community_Forums] ADD  CONSTRAINT [DF_iforum_Forums_ParentID]  DEFAULT ((0)) FOR [ParentID]
GO
/****** Object:  Default [DF_iforum_Forums_IsModerated]    Script Date: 08/30/2010 15:48:02 ******/
ALTER TABLE [dbo].[community_Forums] ADD  CONSTRAINT [DF_iforum_Forums_IsModerated]  DEFAULT ((0)) FOR [IsModerated]
GO
/****** Object:  Default [DF_iforum_Forums_TotalPosts]    Script Date: 08/30/2010 15:48:02 ******/
ALTER TABLE [dbo].[community_Forums] ADD  CONSTRAINT [DF_iforum_Forums_TotalPosts]  DEFAULT ((0)) FOR [TotalPosts]
GO
/****** Object:  Default [DF_iforum_Forums_TotalThreads]    Script Date: 08/30/2010 15:48:02 ******/
ALTER TABLE [dbo].[community_Forums] ADD  CONSTRAINT [DF_iforum_Forums_TotalThreads]  DEFAULT ((0)) FOR [TotalThreads]
GO
/****** Object:  Default [DF_iforum_Forums_LastPostID]    Script Date: 08/30/2010 15:48:02 ******/
ALTER TABLE [dbo].[community_Forums] ADD  CONSTRAINT [DF_iforum_Forums_LastPostID]  DEFAULT ((0)) FOR [LastPostID]
GO
/****** Object:  Default [DF_iforum_Forums_IsLock]    Script Date: 08/30/2010 15:48:02 ******/
ALTER TABLE [dbo].[community_Forums] ADD  CONSTRAINT [DF_iforum_Forums_IsLock]  DEFAULT ((0)) FOR [IsLock]
GO
/****** Object:  Default [DF_community_Forums_Pos]    Script Date: 08/30/2010 15:48:02 ******/
ALTER TABLE [dbo].[community_Forums] ADD  CONSTRAINT [DF_community_Forums_Pos]  DEFAULT ((0)) FOR [Pos]
GO
/****** Object:  Default [DF_community_Forums_AllowAttachment]    Script Date: 08/30/2010 15:48:02 ******/
ALTER TABLE [dbo].[community_Forums] ADD  CONSTRAINT [DF_community_Forums_AllowAttachment]  DEFAULT ((1)) FOR [AllowAttachment]
GO
/****** Object:  Default [DF_community_Forums_AllowAnonymous]    Script Date: 08/30/2010 15:48:02 ******/
ALTER TABLE [dbo].[community_Forums] ADD  CONSTRAINT [DF_community_Forums_AllowAnonymous]  DEFAULT ((1)) FOR [AllowAnonymous]
GO
/****** Object:  Default [DF_iforum_Posts_IsThread]    Script Date: 08/30/2010 15:48:02 ******/
ALTER TABLE [dbo].[community_Posts] ADD  CONSTRAINT [DF_iforum_Posts_IsThread]  DEFAULT ((0)) FOR [IsThread]
GO
/****** Object:  Default [DF_iforum_Posts_Posted]    Script Date: 08/30/2010 15:48:02 ******/
ALTER TABLE [dbo].[community_Posts] ADD  CONSTRAINT [DF_iforum_Posts_Posted]  DEFAULT (getdate()) FOR [Posted]
GO
/****** Object:  Default [DF_iforum_Posts_LastModified]    Script Date: 08/30/2010 15:48:02 ******/
ALTER TABLE [dbo].[community_Posts] ADD  CONSTRAINT [DF_iforum_Posts_LastModified]  DEFAULT (getdate()) FOR [LastModified]
GO
/****** Object:  Default [DF_iforum_Posts_Reads]    Script Date: 08/30/2010 15:48:02 ******/
ALTER TABLE [dbo].[community_Posts] ADD  CONSTRAINT [DF_iforum_Posts_Reads]  DEFAULT ((0)) FOR [Reads]
GO
/****** Object:  Default [DF_iforum_Posts_Reating]    Script Date: 08/30/2010 15:48:02 ******/
ALTER TABLE [dbo].[community_Posts] ADD  CONSTRAINT [DF_iforum_Posts_Reating]  DEFAULT ((0)) FOR [Ratings]
GO
/****** Object:  Default [DF_iforum_Posts_IsModerated]    Script Date: 08/30/2010 15:48:02 ******/
ALTER TABLE [dbo].[community_Posts] ADD  CONSTRAINT [DF_iforum_Posts_IsModerated]  DEFAULT ((0)) FOR [IsAppoved]
GO
/****** Object:  Default [DF_iforum_Posts_Pos]    Script Date: 08/30/2010 15:48:02 ******/
ALTER TABLE [dbo].[community_Posts] ADD  CONSTRAINT [DF_iforum_Posts_Pos]  DEFAULT ((0)) FOR [Pos]
GO
/****** Object:  Default [DF_iforum_Posts_IsLocked]    Script Date: 08/30/2010 15:48:02 ******/
ALTER TABLE [dbo].[community_Posts] ADD  CONSTRAINT [DF_iforum_Posts_IsLocked]  DEFAULT ((0)) FOR [IsLocked]
GO
/****** Object:  Default [DF_community_Posts_IsDeleted]    Script Date: 08/30/2010 15:48:02 ******/
ALTER TABLE [dbo].[community_Posts] ADD  CONSTRAINT [DF_community_Posts_IsDeleted]  DEFAULT ((0)) FOR [IsDeleted]
GO
/****** Object:  Default [DF_iforum_Ranks_IsStart]    Script Date: 08/30/2010 15:48:02 ******/
ALTER TABLE [dbo].[community_Ranks] ADD  CONSTRAINT [DF_iforum_Ranks_IsStart]  DEFAULT ((0)) FOR [IsStart]
GO
/****** Object:  Default [DF_iforum_Ranks_MinimumPosts]    Script Date: 08/30/2010 15:48:02 ******/
ALTER TABLE [dbo].[community_Ranks] ADD  CONSTRAINT [DF_iforum_Ranks_MinimumPosts]  DEFAULT ((0)) FOR [MinimumPosts]
GO
/****** Object:  Default [DF_iforum_Threads_IsPinned]    Script Date: 08/30/2010 15:48:02 ******/
ALTER TABLE [dbo].[community_Threads] ADD  CONSTRAINT [DF_iforum_Threads_IsPinned]  DEFAULT ((0)) FOR [IsPinned]
GO
/****** Object:  Default [DF_iforum_Threads_TotalReads]    Script Date: 08/30/2010 15:48:02 ******/
ALTER TABLE [dbo].[community_Threads] ADD  CONSTRAINT [DF_iforum_Threads_TotalReads]  DEFAULT ((0)) FOR [TotalReads]
GO
/****** Object:  Default [DF_iforum_Threads_TotalPosts]    Script Date: 08/30/2010 15:48:02 ******/
ALTER TABLE [dbo].[community_Threads] ADD  CONSTRAINT [DF_iforum_Threads_TotalPosts]  DEFAULT ((0)) FOR [TotalPosts]
GO
/****** Object:  Default [DF_iforum_Threads_Posted]    Script Date: 08/30/2010 15:48:02 ******/
ALTER TABLE [dbo].[community_Threads] ADD  CONSTRAINT [DF_iforum_Threads_Posted]  DEFAULT (getdate()) FOR [Posted]
GO
/****** Object:  Default [DF_iforum_Threads_LastPosted]    Script Date: 08/30/2010 15:48:02 ******/
ALTER TABLE [dbo].[community_Threads] ADD  CONSTRAINT [DF_iforum_Threads_LastPosted]  DEFAULT (getdate()) FOR [LastPosted]
GO
/****** Object:  Default [DF_iforum_Threads_IsLocked]    Script Date: 08/30/2010 15:48:02 ******/
ALTER TABLE [dbo].[community_Threads] ADD  CONSTRAINT [DF_iforum_Threads_IsLocked]  DEFAULT ((0)) FOR [IsLocked]
GO
/****** Object:  Default [DF_community_Threads_IsModerated]    Script Date: 08/30/2010 15:48:02 ******/
ALTER TABLE [dbo].[community_Threads] ADD  CONSTRAINT [DF_community_Threads_IsModerated]  DEFAULT ((0)) FOR [IsAppoved]
GO
/****** Object:  ForeignKey [FK_community_attachments_community_Posts]    Script Date: 08/30/2010 15:48:02 ******/
ALTER TABLE [dbo].[community_attachments]  WITH CHECK ADD  CONSTRAINT [FK_community_attachments_community_Posts] FOREIGN KEY([PostID])
REFERENCES [dbo].[community_Posts] ([ID])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[community_attachments] CHECK CONSTRAINT [FK_community_attachments_community_Posts]
GO
/****** Object:  ForeignKey [FK_Moderators_Moderators]    Script Date: 08/30/2010 15:48:02 ******/
ALTER TABLE [dbo].[community_Moderators]  WITH CHECK ADD  CONSTRAINT [FK_Moderators_Moderators] FOREIGN KEY([ForumID])
REFERENCES [dbo].[community_Forums] ([ID])
ON UPDATE CASCADE
GO
ALTER TABLE [dbo].[community_Moderators] CHECK CONSTRAINT [FK_Moderators_Moderators]
GO
/****** Object:  ForeignKey [FK_Posts_Forums]    Script Date: 08/30/2010 15:48:02 ******/
ALTER TABLE [dbo].[community_Posts]  WITH CHECK ADD  CONSTRAINT [FK_Posts_Forums] FOREIGN KEY([ForumID])
REFERENCES [dbo].[community_Forums] ([ID])
GO
ALTER TABLE [dbo].[community_Posts] CHECK CONSTRAINT [FK_Posts_Forums]
GO
/****** Object:  ForeignKey [FK_Posts_Threads]    Script Date: 08/30/2010 15:48:02 ******/
ALTER TABLE [dbo].[community_Posts]  WITH CHECK ADD  CONSTRAINT [FK_Posts_Threads] FOREIGN KEY([ThreadID])
REFERENCES [dbo].[community_Threads] ([ID])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[community_Posts] CHECK CONSTRAINT [FK_Posts_Threads]
GO
/****** Object:  ForeignKey [FK_Threads_Forums]    Script Date: 08/30/2010 15:48:02 ******/
ALTER TABLE [dbo].[community_Threads]  WITH CHECK ADD  CONSTRAINT [FK_Threads_Forums] FOREIGN KEY([ForumID])
REFERENCES [dbo].[community_Forums] ([ID])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[community_Threads] CHECK CONSTRAINT [FK_Threads_Forums]
GO
