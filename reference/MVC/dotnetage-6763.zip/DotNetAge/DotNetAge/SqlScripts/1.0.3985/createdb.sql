﻿-- =============================================
-- Author:		<Ray liang>
-- Create date: <2010-8-30>
-- Description:	<This sql script file use to create the database for DotNetAge>
-- Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
-- Dual licensed under the MIT and GPL licenses:
-- http://www.opensource.org/licenses/mit-license.php
-- http://www.gnu.org/licenses/gpl.html
-- =============================================

USE [master]
GO

/****** Object:  Database [PlaceholderForDbName]    Script Date: 08/19/2010 11:53:17 ******/
CREATE DATABASE [PlaceholderForDbName] 
GO

ALTER DATABASE [PlaceholderForDbName] SET COMPATIBILITY_LEVEL = 90
GO

IF (1 = FULLTEXTSERVICEPROPERTY('IsFullTextInstalled'))
begin
EXEC [PlaceholderForDbName].[dbo].[sp_fulltext_database] @action = 'enable'
end
GO

ALTER DATABASE [PlaceholderForDbName] SET ANSI_NULL_DEFAULT OFF 
GO

ALTER DATABASE [PlaceholderForDbName] SET ANSI_NULLS OFF 
GO

ALTER DATABASE [PlaceholderForDbName] SET ANSI_PADDING OFF 
GO

ALTER DATABASE [PlaceholderForDbName] SET ANSI_WARNINGS OFF 
GO

ALTER DATABASE [PlaceholderForDbName] SET ARITHABORT OFF 
GO

ALTER DATABASE [PlaceholderForDbName] SET AUTO_CLOSE ON 
GO

ALTER DATABASE [PlaceholderForDbName] SET AUTO_CREATE_STATISTICS ON 
GO

ALTER DATABASE [PlaceholderForDbName] SET AUTO_SHRINK ON 
GO

ALTER DATABASE [PlaceholderForDbName] SET AUTO_UPDATE_STATISTICS ON 
GO

ALTER DATABASE [PlaceholderForDbName] SET CURSOR_CLOSE_ON_COMMIT OFF 
GO

ALTER DATABASE [PlaceholderForDbName] SET CURSOR_DEFAULT  GLOBAL 
GO

ALTER DATABASE [PlaceholderForDbName] SET CONCAT_NULL_YIELDS_NULL OFF 
GO

ALTER DATABASE [PlaceholderForDbName] SET NUMERIC_ROUNDABORT OFF 
GO

ALTER DATABASE [PlaceholderForDbName] SET QUOTED_IDENTIFIER OFF 
GO

ALTER DATABASE [PlaceholderForDbName] SET RECURSIVE_TRIGGERS OFF 
GO

ALTER DATABASE [PlaceholderForDbName] SET  DISABLE_BROKER 
GO

ALTER DATABASE [PlaceholderForDbName] SET AUTO_UPDATE_STATISTICS_ASYNC OFF 
GO

ALTER DATABASE [PlaceholderForDbName] SET DATE_CORRELATION_OPTIMIZATION OFF 
GO

ALTER DATABASE [PlaceholderForDbName] SET TRUSTWORTHY OFF 
GO

ALTER DATABASE [PlaceholderForDbName] SET ALLOW_SNAPSHOT_ISOLATION OFF 
GO

ALTER DATABASE [PlaceholderForDbName] SET PARAMETERIZATION SIMPLE 
GO

ALTER DATABASE [PlaceholderForDbName] SET READ_COMMITTED_SNAPSHOT OFF 
GO

ALTER DATABASE [PlaceholderForDbName] SET HONOR_BROKER_PRIORITY OFF 
GO

ALTER DATABASE [PlaceholderForDbName] SET  READ_WRITE 
GO

ALTER DATABASE [PlaceholderForDbName] SET RECOVERY SIMPLE 
GO

ALTER DATABASE [PlaceholderForDbName] SET  MULTI_USER 
GO

ALTER DATABASE [PlaceholderForDbName] SET PAGE_VERIFY CHECKSUM  
GO

ALTER DATABASE [PlaceholderForDbName] SET DB_CHAINING OFF 
GO

