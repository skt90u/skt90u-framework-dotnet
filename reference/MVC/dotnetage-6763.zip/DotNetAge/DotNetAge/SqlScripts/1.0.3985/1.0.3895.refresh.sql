﻿/****** Object:  StoredProcedure [dbo].[dna_getOnlineUsers]    Script Date: 09/06/2010 21:16:06 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Ray Liang>
-- Create date: <2010-9-2>
-- Description:	<Description,This procedure use to get the online users list>
-- Modified: <2010-9-6>
--Changed log: fix this procedure could not select the users bugs.
-- =============================================
ALTER PROCEDURE [dbo].[dna_getOnlineUsers]
@isAnonymous bit,
@interval int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
SELECT distinct userName 
FROM [dna_eventlog]
WHERE IsAnonymous=@isAnonymous AND
      (Logged Between DateAdd(MINUTE,-@interval,GetDate()) AND GetDate())
END
GO

/****** Object:  StoredProcedure [dbo].[dna_statistics]    Script Date: 09/06/2010 21:17:13 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Ray Liang>
-- Create date: <2010-9-2>
-- Modified:<2010-9-6>
-- Description:	<Description,This procedure use to get web site statistics>
-- =============================================
ALTER PROCEDURE [dbo].[dna_statistics]
@interval int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

DECLARE @mostUserCount int,
        @mostOnlined datetime
        
SELECT TOP 1 @mostUserCount=MostOnlineUserCount,
             @mostOnlined=MostOnlined 
FROM [dbo].[dna_websettings]

SELECT Count(distinct clientAddress) AS Visits,
       Count(clientAddress) AS PageView,
       RegistedUserCount = (SELECT Count(UserID)FROM [aspnet_Membership]),
       OnlineGuests=(select Count(distinct userName)FROM [dna_eventlog] WHERE IsAnonymous=1 AND(Logged Between DateAdd(MINUTE,-@interval,GetDate()) AND GetDate())),
       OnlineRegisters=(select Count(distinct userName)FROM [dna_eventlog] WHERE IsAnonymous=0 AND(Logged Between DateAdd(MINUTE,-@interval,GetDate()) AND GetDate())),
       MostOnlineCount=@mostUserCount,
       MostOnlined=@mostOnlined
FROM [dna_eventlog]
WHERE DatePart(YYYY,logged)=DatePart(YYYY,GetDate()) AND
      DatePart(MM,logged)=DatePart(MM,GetDate()) AND
      DatePart(dd,logged)=DatePart(dd,GetDate())
END
GO