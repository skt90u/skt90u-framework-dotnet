﻿-- ===============================================================================
-- Author:		<Ray liang>
-- Create date: <2010-10-21>
-- Description:	<Install the tables and storeprocedures for DotNetAge community application plugin.>
-- Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
-- Dual licensed under the MIT and GPL licenses:
-- http://www.opensource.org/licenses/mit-license.php
-- http://www.gnu.org/licenses/gpl.html
-- ===============================================================================


USE [PlaceholderForDbName]
GO
/****** Object:  Table [dbo].[community_Forums]    Script Date: 10/21/2010 21:35:03 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[community_Forums]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[community_Forums](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[Title] [nvarchar](255) NOT NULL,
	[Description] [ntext] NULL,
	[IsGroup] [bit] NOT NULL,
	[ParentID] [int] NOT NULL,
	[IsModerated] [bit] NOT NULL,
	[TotalPosts] [int] NOT NULL,
	[TotalThreads] [int] NOT NULL,
	[LastPostID] [int] NULL,
	[LastPostedUser] [nvarchar](50) NULL,
	[LastPosted] [datetime] NULL,
	[Theme] [nvarchar](255) NULL,
	[IsLock] [bit] NOT NULL,
	[Pos] [int] NOT NULL,
	[AllowAttachment] [bit] NOT NULL,
	[AllowAnonymous] [bit] NOT NULL,
 CONSTRAINT [PK_Forums] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[community_Ranks]    Script Date: 10/21/2010 21:35:03 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[community_Ranks]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[community_Ranks](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[Name] [nvarchar](255) NOT NULL,
	[IsStart] [bit] NOT NULL,
	[MinimumPosts] [int] NOT NULL,
	[ImageUrl] [nvarchar](1024) NULL,
 CONSTRAINT [PK_iforum_Ranks] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[community_Moderators]    Script Date: 10/21/2010 21:35:03 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[community_Moderators]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[community_Moderators](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[Moderator] [nvarchar](50) NOT NULL,
	[ForumID] [int] NOT NULL,
 CONSTRAINT [PK_Moderators] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[community_Threads]    Script Date: 10/21/2010 21:35:03 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[community_Threads]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[community_Threads](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[Title] [nvarchar](255) NOT NULL,
	[Author] [nvarchar](50) NOT NULL,
	[IsPinned] [bit] NOT NULL,
	[TotalReads] [int] NOT NULL,
	[TotalPosts] [int] NOT NULL,
	[Posted] [datetime] NOT NULL,
	[LastPosted] [datetime] NOT NULL,
	[LastPostUser] [nvarchar](50) NOT NULL,
	[LastPostID] [int] NULL,
	[ForumID] [int] NOT NULL,
	[ThreadType] [int] NOT NULL,
	[IsLocked] [bit] NOT NULL,
	[Appoved] [datetime] NULL,
	[Moderator] [nvarchar](50) NULL,
	[IsAppoved] [bit] NOT NULL,
	[LinkTo] [nvarchar](1024) NULL,
 CONSTRAINT [PK_Threads] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[community_Posts]    Script Date: 10/21/2010 21:35:03 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[community_Posts]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[community_Posts](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[UserName] [nvarchar](50) NOT NULL,
	[Title] [nvarchar](255) NULL,
	[Body] [ntext] NULL,
	[IsThread] [bit] NOT NULL,
	[Posted] [datetime] NOT NULL,
	[LastModified] [datetime] NOT NULL,
	[Reads] [int] NOT NULL,
	[Ratings] [int] NOT NULL,
	[IsAppoved] [bit] NOT NULL,
	[Pos] [int] NOT NULL,
	[ForumID] [int] NOT NULL,
	[ThreadID] [int] NOT NULL,
	[ParentID] [int] NULL,
	[IsLocked] [bit] NOT NULL,
	[IP] [nvarchar](50) NULL,
	[Appoved] [datetime] NULL,
	[Moderator] [nvarchar](50) NULL,
	[IsDeleted] [bit] NOT NULL,
	[DeletedReason] [ntext] NULL,
	[Deleted] [date] NULL,
	[DeleteBy] [nvarchar](50) NULL,
 CONSTRAINT [PK_Posts] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
END
GO
/****** Object:  StoredProcedure [dbo].[community_thread_UpdateStates]    Script Date: 10/21/2010 21:35:03 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[community_thread_UpdateStates]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'
-- =============================================
-- Author:		<Ray liang>
-- Create date: <2010-8-16>
-- Description:	<This store procedure use to update the thread state>
-- Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
-- Dual licensed under the MIT and GPL licenses:
-- http://www.opensource.org/licenses/mit-license.php
-- http://www.gnu.org/licenses/gpl.html
-- =============================================
CREATE PROCEDURE [dbo].[community_thread_UpdateStates]
@id int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    DECLARE @totalPosts int,
            @lastPostUser nvarchar(50),   
            @lastPosted datetime,
            @lastPostID int  
   
   
    SELECT @lastPostUser=NULL
    
    SELECT @totalPosts=(SELECT COUNT([ID]) FROM community_Posts WHERE ThreadID=@id)

    IF (@totalPosts>0)
    BEGIN
      SELECT @lastPostID=(SELECT TOP 1 [ID]
                          FROM community_Posts
                          WHERE ThreadID=@id 
                          ORDER BY Posted desc)
      
      SELECT @lastPosted=Posted,
             @lastPostUser=UserName
      FROM community_Posts
      WHERE ID=@lastPostID                    
      
    END                      
    ELSE BEGIN
      SELECT @lastPostID=NULL,
             @lastPostUser=NULL,
             @lastPosted=NULL
    END
                            
    UPDATE community_Threads
    SET TotalPosts=@totalPosts,
        LastPosted=@lastPosted,
        LastPostID=@lastPostID,
        LastPostUser=@lastPostUser
    WHERE ID=@id
    
END

' 
END
GO
/****** Object:  StoredProcedure [dbo].[community_statistics]    Script Date: 10/21/2010 21:35:03 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[community_statistics]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'CREATE PROCEDURE [dbo].[community_statistics]
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	SELECT TotalThreads=(SELECT COUNT(ID) FROM community_Threads),
	       TotalPosts=(SELECT COUNT(ID) FROM community_Posts WHERE IsDeleted<>1),
	       TodayPosts=(SELECT COUNT(ID) FROM community_Posts WHERE IsDeleted<>1 AND DATEPART(YYYY,Posted)=DATEPART(YYYY,GETDATE()) AND DATEPART(M,Posted)=DATEPART(M,GETDATE()) AND DATEPART(D,Posted)=DATEPART(D,GETDATE())),
	       TodayThreads=(SELECT COUNT(ID) FROM community_Threads WHERE DATEPART(YYYY,Posted)=DATEPART(YYYY,GETDATE()) AND DATEPART(M,Posted)=DATEPART(M,GETDATE()) AND DATEPART(D,Posted)=DATEPART(D,GETDATE()))
END
' 
END
GO
/****** Object:  StoredProcedure [dbo].[community_forum_UpdateStates]    Script Date: 10/21/2010 21:35:03 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[community_forum_UpdateStates]') AND type in (N'P', N'PC'))
BEGIN
EXEC dbo.sp_executesql @statement = N'
-- Batch submitted through debugger: SQLQuery7.sql|7|0|C:\Users\Ray\AppData\Local\Temp\~vs7AA1.sql
-- =============================================
-- Author:		<Ray liang>
-- Create date: <2010-8-16>
-- Description:	<This store procedure use to update the forum state>
-- Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
-- Dual licensed under the MIT and GPL licenses:
-- http://www.opensource.org/licenses/mit-license.php
-- http://www.gnu.org/licenses/gpl.html
-- =============================================
CREATE PROCEDURE [dbo].[community_forum_UpdateStates]
@id int
AS
BEGIN
	SET NOCOUNT ON;
    DECLARE @totalPosts int,
            @lastPostUser nvarchar(50),   
            @lastPosted datetime,
            @lastPostID int  
   
   
    SELECT @lastPostUser=NULL
    
    SELECT @totalPosts=(SELECT COUNT([ID]) FROM community_Posts WHERE ForumID=@id AND IsAppoved=1)

    IF (@totalPosts>0)
    BEGIN
      SELECT @lastPostID=(SELECT TOP 1 [ID]
                          FROM community_Posts
                          WHERE ForumID=@id AND IsAppoved=1
                          ORDER BY Posted desc)
      
      SELECT @lastPosted=Posted,
             @lastPostUser=UserName
      FROM community_Posts
      WHERE ID=@lastPostID                    
      
    END                      
    ELSE BEGIN
      SELECT @lastPostID=NULL,
             @lastPostUser=NULL,
             @lastPosted=NULL
    END
                            
    UPDATE community_Forums
    SET TotalPosts=@totalPosts,
        TotalThreads=(SELECT COUNT([ID]) FROM community_Threads WHERE ForumID=@id AND IsAppoved=1),
        LastPosted=@lastPosted,
        LastPostID=@lastPostID,
        LastPostedUser=@lastPostUser
    WHERE ID=@id
    
END

' 
END
GO
/****** Object:  Table [dbo].[community_attachments]    Script Date: 10/21/2010 21:35:03 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[community_attachments]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[community_attachments](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[FileName] [nvarchar](1024) NOT NULL,
	[PostID] [int] NOT NULL,
	[ContentType] [nvarchar](50) NULL,
 CONSTRAINT [PK_community_attachments] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
/****** Object:  Default [DF_iforum_Forums_IsGroup]    Script Date: 10/21/2010 21:35:03 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_iforum_Forums_IsGroup]') AND parent_object_id = OBJECT_ID(N'[dbo].[community_Forums]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_iforum_Forums_IsGroup]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[community_Forums] ADD  CONSTRAINT [DF_iforum_Forums_IsGroup]  DEFAULT ((0)) FOR [IsGroup]
END


End
GO
/****** Object:  Default [DF_iforum_Forums_ParentID]    Script Date: 10/21/2010 21:35:03 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_iforum_Forums_ParentID]') AND parent_object_id = OBJECT_ID(N'[dbo].[community_Forums]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_iforum_Forums_ParentID]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[community_Forums] ADD  CONSTRAINT [DF_iforum_Forums_ParentID]  DEFAULT ((0)) FOR [ParentID]
END


End
GO
/****** Object:  Default [DF_iforum_Forums_IsModerated]    Script Date: 10/21/2010 21:35:03 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_iforum_Forums_IsModerated]') AND parent_object_id = OBJECT_ID(N'[dbo].[community_Forums]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_iforum_Forums_IsModerated]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[community_Forums] ADD  CONSTRAINT [DF_iforum_Forums_IsModerated]  DEFAULT ((0)) FOR [IsModerated]
END


End
GO
/****** Object:  Default [DF_iforum_Forums_TotalPosts]    Script Date: 10/21/2010 21:35:03 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_iforum_Forums_TotalPosts]') AND parent_object_id = OBJECT_ID(N'[dbo].[community_Forums]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_iforum_Forums_TotalPosts]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[community_Forums] ADD  CONSTRAINT [DF_iforum_Forums_TotalPosts]  DEFAULT ((0)) FOR [TotalPosts]
END


End
GO
/****** Object:  Default [DF_iforum_Forums_TotalThreads]    Script Date: 10/21/2010 21:35:03 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_iforum_Forums_TotalThreads]') AND parent_object_id = OBJECT_ID(N'[dbo].[community_Forums]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_iforum_Forums_TotalThreads]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[community_Forums] ADD  CONSTRAINT [DF_iforum_Forums_TotalThreads]  DEFAULT ((0)) FOR [TotalThreads]
END


End
GO
/****** Object:  Default [DF_iforum_Forums_LastPostID]    Script Date: 10/21/2010 21:35:03 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_iforum_Forums_LastPostID]') AND parent_object_id = OBJECT_ID(N'[dbo].[community_Forums]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_iforum_Forums_LastPostID]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[community_Forums] ADD  CONSTRAINT [DF_iforum_Forums_LastPostID]  DEFAULT ((0)) FOR [LastPostID]
END


End
GO
/****** Object:  Default [DF_iforum_Forums_IsLock]    Script Date: 10/21/2010 21:35:03 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_iforum_Forums_IsLock]') AND parent_object_id = OBJECT_ID(N'[dbo].[community_Forums]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_iforum_Forums_IsLock]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[community_Forums] ADD  CONSTRAINT [DF_iforum_Forums_IsLock]  DEFAULT ((0)) FOR [IsLock]
END


End
GO
/****** Object:  Default [DF_community_Forums_Pos]    Script Date: 10/21/2010 21:35:03 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_community_Forums_Pos]') AND parent_object_id = OBJECT_ID(N'[dbo].[community_Forums]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_community_Forums_Pos]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[community_Forums] ADD  CONSTRAINT [DF_community_Forums_Pos]  DEFAULT ((0)) FOR [Pos]
END


End
GO
/****** Object:  Default [DF_community_Forums_AllowAttachment]    Script Date: 10/21/2010 21:35:03 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_community_Forums_AllowAttachment]') AND parent_object_id = OBJECT_ID(N'[dbo].[community_Forums]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_community_Forums_AllowAttachment]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[community_Forums] ADD  CONSTRAINT [DF_community_Forums_AllowAttachment]  DEFAULT ((1)) FOR [AllowAttachment]
END


End
GO
/****** Object:  Default [DF_community_Forums_AllowAnonymous]    Script Date: 10/21/2010 21:35:03 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_community_Forums_AllowAnonymous]') AND parent_object_id = OBJECT_ID(N'[dbo].[community_Forums]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_community_Forums_AllowAnonymous]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[community_Forums] ADD  CONSTRAINT [DF_community_Forums_AllowAnonymous]  DEFAULT ((1)) FOR [AllowAnonymous]
END


End
GO
/****** Object:  Default [DF_iforum_Posts_IsThread]    Script Date: 10/21/2010 21:35:03 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_iforum_Posts_IsThread]') AND parent_object_id = OBJECT_ID(N'[dbo].[community_Posts]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_iforum_Posts_IsThread]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[community_Posts] ADD  CONSTRAINT [DF_iforum_Posts_IsThread]  DEFAULT ((0)) FOR [IsThread]
END


End
GO
/****** Object:  Default [DF_iforum_Posts_Posted]    Script Date: 10/21/2010 21:35:03 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_iforum_Posts_Posted]') AND parent_object_id = OBJECT_ID(N'[dbo].[community_Posts]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_iforum_Posts_Posted]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[community_Posts] ADD  CONSTRAINT [DF_iforum_Posts_Posted]  DEFAULT (getdate()) FOR [Posted]
END


End
GO
/****** Object:  Default [DF_iforum_Posts_LastModified]    Script Date: 10/21/2010 21:35:03 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_iforum_Posts_LastModified]') AND parent_object_id = OBJECT_ID(N'[dbo].[community_Posts]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_iforum_Posts_LastModified]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[community_Posts] ADD  CONSTRAINT [DF_iforum_Posts_LastModified]  DEFAULT (getdate()) FOR [LastModified]
END


End
GO
/****** Object:  Default [DF_iforum_Posts_Reads]    Script Date: 10/21/2010 21:35:03 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_iforum_Posts_Reads]') AND parent_object_id = OBJECT_ID(N'[dbo].[community_Posts]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_iforum_Posts_Reads]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[community_Posts] ADD  CONSTRAINT [DF_iforum_Posts_Reads]  DEFAULT ((0)) FOR [Reads]
END


End
GO
/****** Object:  Default [DF_iforum_Posts_Reating]    Script Date: 10/21/2010 21:35:03 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_iforum_Posts_Reating]') AND parent_object_id = OBJECT_ID(N'[dbo].[community_Posts]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_iforum_Posts_Reating]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[community_Posts] ADD  CONSTRAINT [DF_iforum_Posts_Reating]  DEFAULT ((0)) FOR [Ratings]
END


End
GO
/****** Object:  Default [DF_iforum_Posts_IsModerated]    Script Date: 10/21/2010 21:35:03 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_iforum_Posts_IsModerated]') AND parent_object_id = OBJECT_ID(N'[dbo].[community_Posts]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_iforum_Posts_IsModerated]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[community_Posts] ADD  CONSTRAINT [DF_iforum_Posts_IsModerated]  DEFAULT ((0)) FOR [IsAppoved]
END


End
GO
/****** Object:  Default [DF_iforum_Posts_Pos]    Script Date: 10/21/2010 21:35:03 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_iforum_Posts_Pos]') AND parent_object_id = OBJECT_ID(N'[dbo].[community_Posts]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_iforum_Posts_Pos]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[community_Posts] ADD  CONSTRAINT [DF_iforum_Posts_Pos]  DEFAULT ((0)) FOR [Pos]
END


End
GO
/****** Object:  Default [DF_iforum_Posts_IsLocked]    Script Date: 10/21/2010 21:35:03 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_iforum_Posts_IsLocked]') AND parent_object_id = OBJECT_ID(N'[dbo].[community_Posts]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_iforum_Posts_IsLocked]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[community_Posts] ADD  CONSTRAINT [DF_iforum_Posts_IsLocked]  DEFAULT ((0)) FOR [IsLocked]
END


End
GO
/****** Object:  Default [DF_community_Posts_IsDeleted]    Script Date: 10/21/2010 21:35:03 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_community_Posts_IsDeleted]') AND parent_object_id = OBJECT_ID(N'[dbo].[community_Posts]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_community_Posts_IsDeleted]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[community_Posts] ADD  CONSTRAINT [DF_community_Posts_IsDeleted]  DEFAULT ((0)) FOR [IsDeleted]
END


End
GO
/****** Object:  Default [DF_iforum_Ranks_IsStart]    Script Date: 10/21/2010 21:35:03 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_iforum_Ranks_IsStart]') AND parent_object_id = OBJECT_ID(N'[dbo].[community_Ranks]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_iforum_Ranks_IsStart]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[community_Ranks] ADD  CONSTRAINT [DF_iforum_Ranks_IsStart]  DEFAULT ((0)) FOR [IsStart]
END


End
GO
/****** Object:  Default [DF_iforum_Ranks_MinimumPosts]    Script Date: 10/21/2010 21:35:03 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_iforum_Ranks_MinimumPosts]') AND parent_object_id = OBJECT_ID(N'[dbo].[community_Ranks]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_iforum_Ranks_MinimumPosts]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[community_Ranks] ADD  CONSTRAINT [DF_iforum_Ranks_MinimumPosts]  DEFAULT ((0)) FOR [MinimumPosts]
END


End
GO
/****** Object:  Default [DF_iforum_Threads_IsPinned]    Script Date: 10/21/2010 21:35:03 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_iforum_Threads_IsPinned]') AND parent_object_id = OBJECT_ID(N'[dbo].[community_Threads]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_iforum_Threads_IsPinned]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[community_Threads] ADD  CONSTRAINT [DF_iforum_Threads_IsPinned]  DEFAULT ((0)) FOR [IsPinned]
END


End
GO
/****** Object:  Default [DF_iforum_Threads_TotalReads]    Script Date: 10/21/2010 21:35:03 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_iforum_Threads_TotalReads]') AND parent_object_id = OBJECT_ID(N'[dbo].[community_Threads]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_iforum_Threads_TotalReads]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[community_Threads] ADD  CONSTRAINT [DF_iforum_Threads_TotalReads]  DEFAULT ((0)) FOR [TotalReads]
END


End
GO
/****** Object:  Default [DF_iforum_Threads_TotalPosts]    Script Date: 10/21/2010 21:35:03 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_iforum_Threads_TotalPosts]') AND parent_object_id = OBJECT_ID(N'[dbo].[community_Threads]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_iforum_Threads_TotalPosts]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[community_Threads] ADD  CONSTRAINT [DF_iforum_Threads_TotalPosts]  DEFAULT ((0)) FOR [TotalPosts]
END


End
GO
/****** Object:  Default [DF_iforum_Threads_Posted]    Script Date: 10/21/2010 21:35:03 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_iforum_Threads_Posted]') AND parent_object_id = OBJECT_ID(N'[dbo].[community_Threads]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_iforum_Threads_Posted]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[community_Threads] ADD  CONSTRAINT [DF_iforum_Threads_Posted]  DEFAULT (getdate()) FOR [Posted]
END


End
GO
/****** Object:  Default [DF_iforum_Threads_LastPosted]    Script Date: 10/21/2010 21:35:03 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_iforum_Threads_LastPosted]') AND parent_object_id = OBJECT_ID(N'[dbo].[community_Threads]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_iforum_Threads_LastPosted]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[community_Threads] ADD  CONSTRAINT [DF_iforum_Threads_LastPosted]  DEFAULT (getdate()) FOR [LastPosted]
END


End
GO
/****** Object:  Default [DF_iforum_Threads_IsLocked]    Script Date: 10/21/2010 21:35:03 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_iforum_Threads_IsLocked]') AND parent_object_id = OBJECT_ID(N'[dbo].[community_Threads]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_iforum_Threads_IsLocked]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[community_Threads] ADD  CONSTRAINT [DF_iforum_Threads_IsLocked]  DEFAULT ((0)) FOR [IsLocked]
END


End
GO
/****** Object:  Default [DF_community_Threads_IsModerated]    Script Date: 10/21/2010 21:35:03 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_community_Threads_IsModerated]') AND parent_object_id = OBJECT_ID(N'[dbo].[community_Threads]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_community_Threads_IsModerated]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[community_Threads] ADD  CONSTRAINT [DF_community_Threads_IsModerated]  DEFAULT ((0)) FOR [IsAppoved]
END


End
GO
/****** Object:  ForeignKey [FK_community_attachments_community_Posts]    Script Date: 10/21/2010 21:35:03 ******/
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_community_attachments_community_Posts]') AND parent_object_id = OBJECT_ID(N'[dbo].[community_attachments]'))
ALTER TABLE [dbo].[community_attachments]  WITH CHECK ADD  CONSTRAINT [FK_community_attachments_community_Posts] FOREIGN KEY([PostID])
REFERENCES [dbo].[community_Posts] ([ID])
ON DELETE CASCADE
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_community_attachments_community_Posts]') AND parent_object_id = OBJECT_ID(N'[dbo].[community_attachments]'))
ALTER TABLE [dbo].[community_attachments] CHECK CONSTRAINT [FK_community_attachments_community_Posts]
GO
/****** Object:  ForeignKey [FK_Moderators_Moderators]    Script Date: 10/21/2010 21:35:03 ******/
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Moderators_Moderators]') AND parent_object_id = OBJECT_ID(N'[dbo].[community_Moderators]'))
ALTER TABLE [dbo].[community_Moderators]  WITH CHECK ADD  CONSTRAINT [FK_Moderators_Moderators] FOREIGN KEY([ForumID])
REFERENCES [dbo].[community_Forums] ([ID])
ON UPDATE CASCADE
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Moderators_Moderators]') AND parent_object_id = OBJECT_ID(N'[dbo].[community_Moderators]'))
ALTER TABLE [dbo].[community_Moderators] CHECK CONSTRAINT [FK_Moderators_Moderators]
GO
/****** Object:  ForeignKey [FK_Posts_Forums]    Script Date: 10/21/2010 21:35:03 ******/
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Posts_Forums]') AND parent_object_id = OBJECT_ID(N'[dbo].[community_Posts]'))
ALTER TABLE [dbo].[community_Posts]  WITH CHECK ADD  CONSTRAINT [FK_Posts_Forums] FOREIGN KEY([ForumID])
REFERENCES [dbo].[community_Forums] ([ID])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Posts_Forums]') AND parent_object_id = OBJECT_ID(N'[dbo].[community_Posts]'))
ALTER TABLE [dbo].[community_Posts] CHECK CONSTRAINT [FK_Posts_Forums]
GO
/****** Object:  ForeignKey [FK_Posts_Threads]    Script Date: 10/21/2010 21:35:03 ******/
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Posts_Threads]') AND parent_object_id = OBJECT_ID(N'[dbo].[community_Posts]'))
ALTER TABLE [dbo].[community_Posts]  WITH CHECK ADD  CONSTRAINT [FK_Posts_Threads] FOREIGN KEY([ThreadID])
REFERENCES [dbo].[community_Threads] ([ID])
ON DELETE CASCADE
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Posts_Threads]') AND parent_object_id = OBJECT_ID(N'[dbo].[community_Posts]'))
ALTER TABLE [dbo].[community_Posts] CHECK CONSTRAINT [FK_Posts_Threads]
GO
/****** Object:  ForeignKey [FK_Threads_Forums]    Script Date: 10/21/2010 21:35:03 ******/
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Threads_Forums]') AND parent_object_id = OBJECT_ID(N'[dbo].[community_Threads]'))
ALTER TABLE [dbo].[community_Threads]  WITH CHECK ADD  CONSTRAINT [FK_Threads_Forums] FOREIGN KEY([ForumID])
REFERENCES [dbo].[community_Forums] ([ID])
ON DELETE CASCADE
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Threads_Forums]') AND parent_object_id = OBJECT_ID(N'[dbo].[community_Threads]'))
ALTER TABLE [dbo].[community_Threads] CHECK CONSTRAINT [FK_Threads_Forums]
GO
