﻿-- ===============================================================================
-- Author:		<Ray liang>
-- Create date: <2010-10-21>
-- Description:	<Install the tables and storeprocedures for DotNetAge publishing application plugin>
-- Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
-- Dual licensed under the MIT and GPL licenses:
-- http://www.opensource.org/licenses/mit-license.php
-- http://www.gnu.org/licenses/gpl.html
-- ===============================================================================

USE [PlaceholderForDbName]
GO
/****** Object:  Table [dbo].[publishing_Category]    Script Date: 10/21/2010 21:37:13 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[publishing_Category]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[publishing_Category](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[Title] [nvarchar](50) NOT NULL,
	[Description] [ntext] NULL,
	[Url] [nvarchar](1024) NULL,
	[ParentID] [int] NULL,
	[IsModerated] [bit] NOT NULL,
	[EnableVersioning] [bit] NOT NULL,
	[ArticleType] [int] NULL,
	[TotalPosts] [int] NOT NULL,
	[LastPosted] [datetime] NULL,
	[Path] [nvarchar](1024) NULL,
	[Pos] [int] NOT NULL,
	[AllowAnonymousPostComment] [bit] NOT NULL,
 CONSTRAINT [PK_ArticleCategories] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[publishing_Articles]    Script Date: 10/21/2010 21:37:13 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[publishing_Articles]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[publishing_Articles](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[Title] [nvarchar](255) NOT NULL,
	[Summary] [ntext] NULL,
	[Body] [ntext] NULL,
	[Tags] [nvarchar](255) NULL,
	[Reads] [int] NOT NULL,
	[Rating] [float] NOT NULL,
	[LastModified] [datetime] NOT NULL,
	[Posted] [datetime] NOT NULL,
	[UserName] [nvarchar](50) NULL,
	[ParentID] [int] NULL,
	[Version] [int] NOT NULL,
	[CategoryID] [int] NOT NULL,
	[IsPublished] [bit] NOT NULL,
	[IsAppoved] [bit] NOT NULL,
	[ContentFormat] [int] NOT NULL,
	[TotalRatings] [int] NOT NULL,
	[TotalComments] [int] NOT NULL,
	[Language] [nvarchar](50) NULL,
	[PingUrls] [ntext] NULL,
	[Pos] [int] NOT NULL,
	[Path] [nvarchar](1024) NULL,
	[AllowPingback] [bit] NOT NULL,
	[IsPrivate] [bit] NOT NULL,
	[PermaLink] [nvarchar](1024) NULL,
	[AllowComments] [bit] NOT NULL,
	[Categories] [nvarchar](1024) NULL,
	[SendTrackbackUrls] [ntext] NULL,
	[Slug] [nvarchar](1024) NULL,
	[RelatedPosts] [nvarchar](1024) NULL,
	[Password] [nvarchar](50) NULL,
 CONSTRAINT [PK_Articles] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[publishing_ArticleTracks]    Script Date: 10/21/2010 21:37:13 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[publishing_ArticleTracks]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[publishing_ArticleTracks](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[HasRead] [datetime] NOT NULL,
	[UserName] [nvarchar](1024) NULL,
	[IPAddress] [nchar](50) NULL,
	[ArticleID] [int] NOT NULL,
	[UserAgent] [nvarchar](1024) NULL,
 CONSTRAINT [PK_authoring_articlereads] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[publishing_Versions]    Script Date: 10/21/2010 21:37:13 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[publishing_Versions]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[publishing_Versions](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[Body] [ntext] NULL,
	[LastModified] [datetime] NOT NULL,
	[Version] [int] NULL,
	[ArticleID] [int] NOT NULL,
	[Modified] [nvarchar](50) NULL,
 CONSTRAINT [PK_ArticleVersions] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[publishing_TranslatedCopy]    Script Date: 10/21/2010 21:37:13 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[publishing_TranslatedCopy]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[publishing_TranslatedCopy](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[ArticleID] [int] NOT NULL,
	[Body] [ntext] NULL,
	[Title] [nvarchar](255) NULL,
	[Summary] [ntext] NULL,
	[Language] [nvarchar](50) NULL,
	[ContentFormat] [int] NOT NULL,
 CONSTRAINT [PK_TranslatedCopy] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[publishing_Ratings]    Script Date: 10/21/2010 21:37:13 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[publishing_Ratings]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[publishing_Ratings](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[IP] [nvarchar](50) NULL,
	[Rating] [int] NOT NULL,
	[ArticleID] [int] NOT NULL,
 CONSTRAINT [PK_ArticleRatings] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[publishing_Comments]    Script Date: 10/21/2010 21:37:13 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[publishing_Comments]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[publishing_Comments](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[ArticleID] [int] NOT NULL,
	[UserName] [nvarchar](50) NULL,
	[Posted] [datetime] NOT NULL,
	[IP] [nvarchar](50) NOT NULL,
	[Body] [ntext] NULL,
	[Email] [nvarchar](1024) NULL,
	[WebSite] [nvarchar](1024) NULL,
	[Title] [nvarchar](1024) NULL,
	[IsPingback] [bit] NOT NULL,
	[IsTrackback] [bit] NOT NULL,
 CONSTRAINT [PK_Comments] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
END
GO
/****** Object:  Default [DF_icontent_Articles_Reads]    Script Date: 10/21/2010 21:37:13 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_icontent_Articles_Reads]') AND parent_object_id = OBJECT_ID(N'[dbo].[publishing_Articles]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_icontent_Articles_Reads]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[publishing_Articles] ADD  CONSTRAINT [DF_icontent_Articles_Reads]  DEFAULT ((0)) FOR [Reads]
END


End
GO
/****** Object:  Default [DF_icontent_Articles_Rating]    Script Date: 10/21/2010 21:37:13 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_icontent_Articles_Rating]') AND parent_object_id = OBJECT_ID(N'[dbo].[publishing_Articles]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_icontent_Articles_Rating]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[publishing_Articles] ADD  CONSTRAINT [DF_icontent_Articles_Rating]  DEFAULT ((0)) FOR [Rating]
END


End
GO
/****** Object:  Default [DF_icontent_Articles_LastModified]    Script Date: 10/21/2010 21:37:13 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_icontent_Articles_LastModified]') AND parent_object_id = OBJECT_ID(N'[dbo].[publishing_Articles]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_icontent_Articles_LastModified]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[publishing_Articles] ADD  CONSTRAINT [DF_icontent_Articles_LastModified]  DEFAULT (getdate()) FOR [LastModified]
END


End
GO
/****** Object:  Default [DF_icontent_Articles_Posted]    Script Date: 10/21/2010 21:37:13 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_icontent_Articles_Posted]') AND parent_object_id = OBJECT_ID(N'[dbo].[publishing_Articles]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_icontent_Articles_Posted]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[publishing_Articles] ADD  CONSTRAINT [DF_icontent_Articles_Posted]  DEFAULT (getdate()) FOR [Posted]
END


End
GO
/****** Object:  Default [DF_icontent_Articles_Version]    Script Date: 10/21/2010 21:37:13 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_icontent_Articles_Version]') AND parent_object_id = OBJECT_ID(N'[dbo].[publishing_Articles]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_icontent_Articles_Version]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[publishing_Articles] ADD  CONSTRAINT [DF_icontent_Articles_Version]  DEFAULT ((0)) FOR [Version]
END


End
GO
/****** Object:  Default [DF_icontent_Articles_IsPublished]    Script Date: 10/21/2010 21:37:13 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_icontent_Articles_IsPublished]') AND parent_object_id = OBJECT_ID(N'[dbo].[publishing_Articles]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_icontent_Articles_IsPublished]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[publishing_Articles] ADD  CONSTRAINT [DF_icontent_Articles_IsPublished]  DEFAULT ((1)) FOR [IsPublished]
END


End
GO
/****** Object:  Default [DF_icontent_Articles_IsAppoved]    Script Date: 10/21/2010 21:37:13 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_icontent_Articles_IsAppoved]') AND parent_object_id = OBJECT_ID(N'[dbo].[publishing_Articles]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_icontent_Articles_IsAppoved]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[publishing_Articles] ADD  CONSTRAINT [DF_icontent_Articles_IsAppoved]  DEFAULT ((1)) FOR [IsAppoved]
END


End
GO
/****** Object:  Default [DF_authoring_Articles_ContentFormat]    Script Date: 10/21/2010 21:37:13 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_authoring_Articles_ContentFormat]') AND parent_object_id = OBJECT_ID(N'[dbo].[publishing_Articles]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_authoring_Articles_ContentFormat]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[publishing_Articles] ADD  CONSTRAINT [DF_authoring_Articles_ContentFormat]  DEFAULT ((1)) FOR [ContentFormat]
END


End
GO
/****** Object:  Default [DF_Articles_TotalRatings]    Script Date: 10/21/2010 21:37:13 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_Articles_TotalRatings]') AND parent_object_id = OBJECT_ID(N'[dbo].[publishing_Articles]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_Articles_TotalRatings]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[publishing_Articles] ADD  CONSTRAINT [DF_Articles_TotalRatings]  DEFAULT ((0)) FOR [TotalRatings]
END


End
GO
/****** Object:  Default [DF_Articles_TotalComments]    Script Date: 10/21/2010 21:37:13 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_Articles_TotalComments]') AND parent_object_id = OBJECT_ID(N'[dbo].[publishing_Articles]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_Articles_TotalComments]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[publishing_Articles] ADD  CONSTRAINT [DF_Articles_TotalComments]  DEFAULT ((0)) FOR [TotalComments]
END


End
GO
/****** Object:  Default [DF_icontent_Articles_Pos]    Script Date: 10/21/2010 21:37:13 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_icontent_Articles_Pos]') AND parent_object_id = OBJECT_ID(N'[dbo].[publishing_Articles]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_icontent_Articles_Pos]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[publishing_Articles] ADD  CONSTRAINT [DF_icontent_Articles_Pos]  DEFAULT ((0)) FOR [Pos]
END


End
GO
/****** Object:  Default [DF_authoring_Articles_AllowPingback]    Script Date: 10/21/2010 21:37:13 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_authoring_Articles_AllowPingback]') AND parent_object_id = OBJECT_ID(N'[dbo].[publishing_Articles]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_authoring_Articles_AllowPingback]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[publishing_Articles] ADD  CONSTRAINT [DF_authoring_Articles_AllowPingback]  DEFAULT ((1)) FOR [AllowPingback]
END


End
GO
/****** Object:  Default [DF_authoring_Articles_IsPrivate]    Script Date: 10/21/2010 21:37:13 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_authoring_Articles_IsPrivate]') AND parent_object_id = OBJECT_ID(N'[dbo].[publishing_Articles]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_authoring_Articles_IsPrivate]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[publishing_Articles] ADD  CONSTRAINT [DF_authoring_Articles_IsPrivate]  DEFAULT ((0)) FOR [IsPrivate]
END


End
GO
/****** Object:  Default [DF_authoring_Articles_AllowComments]    Script Date: 10/21/2010 21:37:13 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_authoring_Articles_AllowComments]') AND parent_object_id = OBJECT_ID(N'[dbo].[publishing_Articles]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_authoring_Articles_AllowComments]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[publishing_Articles] ADD  CONSTRAINT [DF_authoring_Articles_AllowComments]  DEFAULT ((1)) FOR [AllowComments]
END


End
GO
/****** Object:  Default [DF_authoring_articlereads_HasRead]    Script Date: 10/21/2010 21:37:13 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_authoring_articlereads_HasRead]') AND parent_object_id = OBJECT_ID(N'[dbo].[publishing_ArticleTracks]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_authoring_articlereads_HasRead]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[publishing_ArticleTracks] ADD  CONSTRAINT [DF_authoring_articlereads_HasRead]  DEFAULT (getdate()) FOR [HasRead]
END


End
GO
/****** Object:  Default [DF_ArticleCategories_IsModerated]    Script Date: 10/21/2010 21:37:13 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_ArticleCategories_IsModerated]') AND parent_object_id = OBJECT_ID(N'[dbo].[publishing_Category]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_ArticleCategories_IsModerated]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[publishing_Category] ADD  CONSTRAINT [DF_ArticleCategories_IsModerated]  DEFAULT ((0)) FOR [IsModerated]
END


End
GO
/****** Object:  Default [DF_ArticleCategories_EnableVersioning]    Script Date: 10/21/2010 21:37:13 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_ArticleCategories_EnableVersioning]') AND parent_object_id = OBJECT_ID(N'[dbo].[publishing_Category]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_ArticleCategories_EnableVersioning]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[publishing_Category] ADD  CONSTRAINT [DF_ArticleCategories_EnableVersioning]  DEFAULT ((1)) FOR [EnableVersioning]
END


End
GO
/****** Object:  Default [DF_ArticleCategories_ArticleType]    Script Date: 10/21/2010 21:37:13 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_ArticleCategories_ArticleType]') AND parent_object_id = OBJECT_ID(N'[dbo].[publishing_Category]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_ArticleCategories_ArticleType]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[publishing_Category] ADD  CONSTRAINT [DF_ArticleCategories_ArticleType]  DEFAULT ((0)) FOR [ArticleType]
END


End
GO
/****** Object:  Default [DF_ArticleCategories_TotalPosts]    Script Date: 10/21/2010 21:37:13 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_ArticleCategories_TotalPosts]') AND parent_object_id = OBJECT_ID(N'[dbo].[publishing_Category]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_ArticleCategories_TotalPosts]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[publishing_Category] ADD  CONSTRAINT [DF_ArticleCategories_TotalPosts]  DEFAULT ((0)) FOR [TotalPosts]
END


End
GO
/****** Object:  Default [DF_authoring_Category_Pos]    Script Date: 10/21/2010 21:37:13 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_authoring_Category_Pos]') AND parent_object_id = OBJECT_ID(N'[dbo].[publishing_Category]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_authoring_Category_Pos]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[publishing_Category] ADD  CONSTRAINT [DF_authoring_Category_Pos]  DEFAULT ((0)) FOR [Pos]
END


End
GO
/****** Object:  Default [DF_authoring_Category_AllowAnonymousPostComment]    Script Date: 10/21/2010 21:37:13 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_authoring_Category_AllowAnonymousPostComment]') AND parent_object_id = OBJECT_ID(N'[dbo].[publishing_Category]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_authoring_Category_AllowAnonymousPostComment]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[publishing_Category] ADD  CONSTRAINT [DF_authoring_Category_AllowAnonymousPostComment]  DEFAULT ((0)) FOR [AllowAnonymousPostComment]
END


End
GO
/****** Object:  Default [DF_icontent_Comments_Posted]    Script Date: 10/21/2010 21:37:13 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_icontent_Comments_Posted]') AND parent_object_id = OBJECT_ID(N'[dbo].[publishing_Comments]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_icontent_Comments_Posted]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[publishing_Comments] ADD  CONSTRAINT [DF_icontent_Comments_Posted]  DEFAULT (getdate()) FOR [Posted]
END


End
GO
/****** Object:  Default [DF_authoring_Comments_IsPingback]    Script Date: 10/21/2010 21:37:13 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_authoring_Comments_IsPingback]') AND parent_object_id = OBJECT_ID(N'[dbo].[publishing_Comments]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_authoring_Comments_IsPingback]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[publishing_Comments] ADD  CONSTRAINT [DF_authoring_Comments_IsPingback]  DEFAULT ((0)) FOR [IsPingback]
END


End
GO
/****** Object:  Default [DF_authoring_Comments_IsTrackback]    Script Date: 10/21/2010 21:37:13 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_authoring_Comments_IsTrackback]') AND parent_object_id = OBJECT_ID(N'[dbo].[publishing_Comments]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_authoring_Comments_IsTrackback]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[publishing_Comments] ADD  CONSTRAINT [DF_authoring_Comments_IsTrackback]  DEFAULT ((0)) FOR [IsTrackback]
END


End
GO
/****** Object:  Default [DF_authoring_TranslatedCopy_ContentFormat]    Script Date: 10/21/2010 21:37:13 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_authoring_TranslatedCopy_ContentFormat]') AND parent_object_id = OBJECT_ID(N'[dbo].[publishing_TranslatedCopy]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_authoring_TranslatedCopy_ContentFormat]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[publishing_TranslatedCopy] ADD  CONSTRAINT [DF_authoring_TranslatedCopy_ContentFormat]  DEFAULT ((0)) FOR [ContentFormat]
END


End
GO
/****** Object:  Default [DF_icontent_Versions_LastModified]    Script Date: 10/21/2010 21:37:13 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_icontent_Versions_LastModified]') AND parent_object_id = OBJECT_ID(N'[dbo].[publishing_Versions]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_icontent_Versions_LastModified]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[publishing_Versions] ADD  CONSTRAINT [DF_icontent_Versions_LastModified]  DEFAULT (getdate()) FOR [LastModified]
END


End
GO
/****** Object:  ForeignKey [FK_Articles_ArticleCategories]    Script Date: 10/21/2010 21:37:13 ******/
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Articles_ArticleCategories]') AND parent_object_id = OBJECT_ID(N'[dbo].[publishing_Articles]'))
ALTER TABLE [dbo].[publishing_Articles]  WITH CHECK ADD  CONSTRAINT [FK_Articles_ArticleCategories] FOREIGN KEY([CategoryID])
REFERENCES [dbo].[publishing_Category] ([ID])
ON DELETE CASCADE
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Articles_ArticleCategories]') AND parent_object_id = OBJECT_ID(N'[dbo].[publishing_Articles]'))
ALTER TABLE [dbo].[publishing_Articles] CHECK CONSTRAINT [FK_Articles_ArticleCategories]
GO
/****** Object:  ForeignKey [FK_authoring_ArticleTracks_authoring_Articles]    Script Date: 10/21/2010 21:37:13 ******/
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_authoring_ArticleTracks_authoring_Articles]') AND parent_object_id = OBJECT_ID(N'[dbo].[publishing_ArticleTracks]'))
ALTER TABLE [dbo].[publishing_ArticleTracks]  WITH CHECK ADD  CONSTRAINT [FK_authoring_ArticleTracks_authoring_Articles] FOREIGN KEY([ArticleID])
REFERENCES [dbo].[publishing_Articles] ([ID])
ON DELETE CASCADE
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_authoring_ArticleTracks_authoring_Articles]') AND parent_object_id = OBJECT_ID(N'[dbo].[publishing_ArticleTracks]'))
ALTER TABLE [dbo].[publishing_ArticleTracks] CHECK CONSTRAINT [FK_authoring_ArticleTracks_authoring_Articles]
GO
/****** Object:  ForeignKey [FK_Comments_Articles]    Script Date: 10/21/2010 21:37:13 ******/
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Comments_Articles]') AND parent_object_id = OBJECT_ID(N'[dbo].[publishing_Comments]'))
ALTER TABLE [dbo].[publishing_Comments]  WITH CHECK ADD  CONSTRAINT [FK_Comments_Articles] FOREIGN KEY([ArticleID])
REFERENCES [dbo].[publishing_Articles] ([ID])
ON DELETE CASCADE
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Comments_Articles]') AND parent_object_id = OBJECT_ID(N'[dbo].[publishing_Comments]'))
ALTER TABLE [dbo].[publishing_Comments] CHECK CONSTRAINT [FK_Comments_Articles]
GO
/****** Object:  ForeignKey [FK_ArticleRatings_Articles]    Script Date: 10/21/2010 21:37:13 ******/
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_ArticleRatings_Articles]') AND parent_object_id = OBJECT_ID(N'[dbo].[publishing_Ratings]'))
ALTER TABLE [dbo].[publishing_Ratings]  WITH CHECK ADD  CONSTRAINT [FK_ArticleRatings_Articles] FOREIGN KEY([ArticleID])
REFERENCES [dbo].[publishing_Articles] ([ID])
ON DELETE CASCADE
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_ArticleRatings_Articles]') AND parent_object_id = OBJECT_ID(N'[dbo].[publishing_Ratings]'))
ALTER TABLE [dbo].[publishing_Ratings] CHECK CONSTRAINT [FK_ArticleRatings_Articles]
GO
/****** Object:  ForeignKey [FK_TranslatedCopy_Articles]    Script Date: 10/21/2010 21:37:13 ******/
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_TranslatedCopy_Articles]') AND parent_object_id = OBJECT_ID(N'[dbo].[publishing_TranslatedCopy]'))
ALTER TABLE [dbo].[publishing_TranslatedCopy]  WITH CHECK ADD  CONSTRAINT [FK_TranslatedCopy_Articles] FOREIGN KEY([ArticleID])
REFERENCES [dbo].[publishing_Articles] ([ID])
ON DELETE CASCADE
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_TranslatedCopy_Articles]') AND parent_object_id = OBJECT_ID(N'[dbo].[publishing_TranslatedCopy]'))
ALTER TABLE [dbo].[publishing_TranslatedCopy] CHECK CONSTRAINT [FK_TranslatedCopy_Articles]
GO
/****** Object:  ForeignKey [FK_icontent_Versions_icontent_Articles]    Script Date: 10/21/2010 21:37:13 ******/
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_icontent_Versions_icontent_Articles]') AND parent_object_id = OBJECT_ID(N'[dbo].[publishing_Versions]'))
ALTER TABLE [dbo].[publishing_Versions]  WITH CHECK ADD  CONSTRAINT [FK_icontent_Versions_icontent_Articles] FOREIGN KEY([ArticleID])
REFERENCES [dbo].[publishing_Articles] ([ID])
ON DELETE CASCADE
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_icontent_Versions_icontent_Articles]') AND parent_object_id = OBJECT_ID(N'[dbo].[publishing_Versions]'))
ALTER TABLE [dbo].[publishing_Versions] CHECK CONSTRAINT [FK_icontent_Versions_icontent_Articles]
GO
