﻿/*=============================================
 Author:		<Ray liang>
 Create date: <2010-10-21>
 Description:	<This sql script file use to insert the base data DotNetAge>
 Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
 Dual licensed under the MIT and GPL licenses:
 http://www.opensource.org/licenses/mit-license.php
 http://www.gnu.org/licenses/gpl.html
 =============================================*/

INSERT [dbo].[aspnet_Applications] ([ApplicationName], [LoweredApplicationName], [ApplicationId], [Description]) 
VALUES (N'/', N'/', N'54055bdc-62a7-4e91-a566-c48ea0b6db7a', NULL)

INSERT [dbo].[aspnet_Users] ([ApplicationId], [UserId], [UserName], [LoweredUserName], [MobileAlias], [IsAnonymous], [LastActivityDate]) 
VALUES (N'54055bdc-62a7-4e91-a566-c48ea0b6db7a', N'58aa2873-cee6-49c3-8d8c-987f1f7e747d', N'administrator', N'administrator', 
NULL, 0, CAST(0x00009DCE00A961E3 AS DateTime))

INSERT [dbo].[aspnet_Membership] ([ApplicationId], [UserId], [Password], [PasswordFormat], [PasswordSalt], [MobilePIN], [Email], 
[LoweredEmail], [PasswordQuestion], [PasswordAnswer], [IsApproved], [IsLockedOut], [CreateDate], [LastLoginDate], [LastPasswordChangedDate], 
[LastLockoutDate], [FailedPasswordAttemptCount], [FailedPasswordAttemptWindowStart], [FailedPasswordAnswerAttemptCount], 
[FailedPasswordAnswerAttemptWindowStart], [Comment]) 
VALUES (N'54055bdc-62a7-4e91-a566-c48ea0b6db7a', N'58aa2873-cee6-49c3-8d8c-987f1f7e747d', N'yWwj7L0rsktv0ZYMZZRILINPCBU=', 1,
 N'39V0EeTVoWRGbGO5CGQUgA==', NULL, N'administrator@localhost.com', N'administrator@localhost.com', NULL, NULL, 1, 0, 
 CAST(0x00009DCE00836B5C AS DateTime), CAST(0x00009DCE00A961E3 AS DateTime), CAST(0x00009DCE00836B5C AS DateTime), 
 CAST(0xFFFF2FB300000000 AS DateTime), 0, CAST(0xFFFF2FB300000000 AS DateTime), 0, CAST(0xFFFF2FB300000000 AS DateTime), NULL)

INSERT [dbo].[aspnet_Roles] ([ApplicationId], [RoleId], [RoleName], [LoweredRoleName], [Description])
 VALUES (N'54055bdc-62a7-4e91-a566-c48ea0b6db7a', N'dab90a5e-ecd6-4e7f-9232-e96546b56a52', N'administrators', N'administrators', NULL)

INSERT [dbo].[aspnet_Roles] ([ApplicationId], [RoleId], [RoleName], [LoweredRoleName], [Description]) 
VALUES (N'54055bdc-62a7-4e91-a566-c48ea0b6db7a', N'3924cf1c-2282-4b60-825b-10d08db04d52', N'guests', N'guests', NULL)

INSERT [dbo].[aspnet_UsersInRoles] ([UserId], [RoleId]) VALUES (N'58aa2873-cee6-49c3-8d8c-987f1f7e747d', N'3924cf1c-2282-4b60-825b-10d08db04d52')
INSERT [dbo].[aspnet_UsersInRoles] ([UserId], [RoleId]) VALUES (N'58aa2873-cee6-49c3-8d8c-987f1f7e747d', N'dab90a5e-ecd6-4e7f-9232-e96546b56a52')

IF NOT EXISTS(SELECT ID FROM [dbo].[Publishing_Category] WHERE [Title]='{site}') BEGIN
		   INSERT INTO [dbo].[Publishing_Category]
				   ([Title]
				   ,[Description]
				   ,[Url]
				   ,[ParentID]
				   ,[IsModerated]
				   ,[EnableVersioning]
				   ,[ArticleType]
				   ,[TotalPosts]
				   ,[LastPosted]
				   ,[Path]
				   ,[Pos]
				   ,[AllowAnonymousPostComment])
			 VALUES
				   ('{site}','','',0,0,0,
					0,0,GETDATE(),
				   '{site}',
				   0,1)
END

IF NOT EXISTS(SELECT ID FROM [dbo].[Publishing_Category] WHERE [Title]='{blogs}') BEGIN
			   INSERT INTO [dbo].[Publishing_Category]
					([Title]
					,[Description]
					,[Url]
					,[ParentID]
					,[IsModerated]
					,[EnableVersioning]
					,[ArticleType]
					,[TotalPosts]
					,[LastPosted]
					,[Path]
					,[Pos]
					,[AllowAnonymousPostComment])
				VALUES
					('{blogs}','','',0,0,0,
					1,0,GETDATE(),
					'{blogs}',
					0,1)
END


SET IDENTITY_INSERT [dbo].[dna_WidgetCategories] ON
INSERT [dbo].[dna_WidgetCategories] ([Id], [Title], [Description]) VALUES (1, N'Shared', NULL)
INSERT [dbo].[dna_WidgetCategories] ([Id], [Title], [Description]) VALUES (2, N'Publishing', NULL)
INSERT [dbo].[dna_WidgetCategories] ([Id], [Title], [Description]) VALUES (3, N'Community', NULL)
SET IDENTITY_INSERT [dbo].[dna_WidgetCategories] OFF

SET IDENTITY_INSERT [dbo].[dna_PackageInfos] ON
INSERT [dbo].[dna_PackageInfos] ([ID], [Name], [ShortName], [Description], [AuthorName], [AuthorWebSite], [AuthorEmail], [Organization], [IconUrl], [IconHeight], [IconWidth], [ReleaseNotes], [Version], [Installed], [Published], [LicensesXML], [FileList], [HelpLink], [SupportLink], [AssemblyName], [AssemblyFullName]) VALUES (1, N'XML-RPC.NET', NULL, N'Requires .NET 2.0 or later', N'', N'', N'', N'Cook Computing', NULL, NULL, NULL, NULL, N'2.5.0.0', CAST(0x00009E19016A7008 AS DateTime), CAST(0x00009E1700B6FB8E AS DateTime), NULL, NULL, NULL, NULL, N'CookComputing.XmlRpcV2', N'CookComputing.XmlRpcV2, Version=2.5.0.0, Culture=neutral, PublicKeyToken=a7d6e17aa302004d')
INSERT [dbo].[dna_PackageInfos] ([ID], [Name], [ShortName], [Description], [AuthorName], [AuthorWebSite], [AuthorEmail], [Organization], [IconUrl], [IconHeight], [IconWidth], [ReleaseNotes], [Version], [Installed], [Published], [LicensesXML], [FileList], [HelpLink], [SupportLink], [AssemblyName], [AssemblyFullName]) VALUES (2, N'CSharpFormat', NULL, N'An extensible framework for generating color-coded HTML 4.01 from source code.', N'', N'', N'', N'manoli.net', NULL, NULL, NULL, NULL, N'2.5.3417.41446', CAST(0x00009E19016A702B AS DateTime), CAST(0x00009E1700B6FB8E AS DateTime), NULL, NULL, NULL, NULL, N'CSharpFormat', N'CSharpFormat, Version=2.5.3417.41446, Culture=neutral, PublicKeyToken=null')
INSERT [dbo].[dna_PackageInfos] ([ID], [Name], [ShortName], [Description], [AuthorName], [AuthorWebSite], [AuthorEmail], [Organization], [IconUrl], [IconHeight], [IconWidth], [ReleaseNotes], [Version], [Installed], [Published], [LicensesXML], [FileList], [HelpLink], [SupportLink], [AssemblyName], [AssemblyFullName]) VALUES (3, N'DotNetAge', NULL, N'The content management system (CMS) base on Mvc & jQuery technique.', N'Ray', N'http://www.dotnetage.com', N'csharp2002@hotmail.com', N'DotNetAge.com', NULL, NULL, NULL, NULL, N'1.1.0.39572', CAST(0x00009E19016A702F AS DateTime), CAST(0x00009E1700B6FB92 AS DateTime), NULL, NULL, NULL, NULL, N'DNA.Mvc', N'DNA.Mvc, Version=1.1.0.39572, Culture=neutral, PublicKeyToken=null')
INSERT [dbo].[dna_PackageInfos] ([ID], [Name], [ShortName], [Description], [AuthorName], [AuthorWebSite], [AuthorEmail], [Organization], [IconUrl], [IconHeight], [IconWidth], [ReleaseNotes], [Version], [Installed], [Published], [LicensesXML], [FileList], [HelpLink], [SupportLink], [AssemblyName], [AssemblyFullName]) VALUES (4, N'DotNetAge jQuery Mvc Extensions', NULL, N'The DotNetAge Mvc Extensions for jQuery ', N'', N'', N'', N'http://www.DotNetAge.com', NULL, NULL, NULL, NULL, N'1.0.4.39571', CAST(0x00009E19016A7103 AS DateTime), CAST(0x00009E1700B6F9BD AS DateTime), NULL, NULL, NULL, NULL, N'DNA.Mvc.jQuery', N'DNA.Mvc.jQuery, Version=1.0.4.39571, Culture=neutral, PublicKeyToken=null')
INSERT [dbo].[dna_PackageInfos] ([ID], [Name], [ShortName], [Description], [AuthorName], [AuthorWebSite], [AuthorEmail], [Organization], [IconUrl], [IconHeight], [IconWidth], [ReleaseNotes], [Version], [Installed], [Published], [LicensesXML], [FileList], [HelpLink], [SupportLink], [AssemblyName], [AssemblyFullName]) VALUES (5, N'ICSharpCode.SharpZipLibrary', NULL, N'A free C# compression library', N'', N'', N'', N'', NULL, NULL, NULL, NULL, N'0.81.0.1407', CAST(0x00009E19016A7106 AS DateTime), CAST(0x00009E1700B6FB8E AS DateTime), NULL, NULL, NULL, NULL, N'SharpZipLib', N'SharpZipLib, Version=0.81.0.1407, Culture=neutral, PublicKeyToken=null')
INSERT [dbo].[dna_PackageInfos] ([ID], [Name], [ShortName], [Description], [AuthorName], [AuthorWebSite], [AuthorEmail], [Organization], [IconUrl], [IconHeight], [IconWidth], [ReleaseNotes], [Version], [Installed], [Published], [LicensesXML], [FileList], [HelpLink], [SupportLink], [AssemblyName], [AssemblyFullName]) VALUES (6, N'System.Web.Mvc.dll', NULL, N'System.Web.Mvc.dll', N'', N'', N'', N'Microsoft Corporation', NULL, NULL, NULL, NULL, N'2.0.0.0', CAST(0x00009E19016A7109 AS DateTime), CAST(0x00009E1700B6FB8E AS DateTime), NULL, NULL, NULL, NULL, N'System.Web.Mvc', N'System.Web.Mvc, Version=2.0.0.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35')
SET IDENTITY_INSERT [dbo].[dna_PackageInfos] OFF

SET IDENTITY_INSERT [dbo].[dna_WidgetDescriptors] ON
INSERT [dbo].[dna_WidgetDescriptors] ([ID], [CatID], [PackageID], [Title], [Url], [Action], [Defaults], [IsClosable], [ShowHeader], [Version], [ImageUrl], [Description], [Controller], [IconUrl], [ShowBorder], [Scopes], [IsDeletable]) VALUES (1, 1, 3, N'Flash', N'', N'Flash', N'{"Width":100,"Url":"","Quality":"high","Height":100,"FlashVars":null,"BackgroundColor":"#ffffff","WMODE":"opaque"}', 1, 0, NULL, N'~/Content/Images/Widgets/flash.png', N'Embedded the Flash object in the widget.', N'Widget', N'~/Content/Images/Widgets/flash_16.png', 0, 0, 1)
INSERT [dbo].[dna_WidgetDescriptors] ([ID], [CatID], [PackageID], [Title], [Url], [Action], [Defaults], [IsClosable], [ShowHeader], [Version], [ImageUrl], [Description], [Controller], [IconUrl], [ShowBorder], [Scopes], [IsDeletable]) VALUES (2, 1, 3, N'Favorites', N'', N'Favorites', N'{"LinkList":null}', 1, 1, NULL, N'~/Content/Images/Widgets/favorite.png', N'Gerenate the a link list for favorites', N'Widget', N'~/Content/Images/Widgets/favorite_16.png', 1, 0, 1)
INSERT [dbo].[dna_WidgetDescriptors] ([ID], [CatID], [PackageID], [Title], [Url], [Action], [Defaults], [IsClosable], [ShowHeader], [Version], [ImageUrl], [Description], [Controller], [IconUrl], [ShowBorder], [Scopes], [IsDeletable]) VALUES (3, 1, 3, N'Donation', N'', N'Donation', N'{"Business":"Example@dotnetage.com","Summary":"If you like this site please buy me a beer.","ReturnUrl":null,"ItemName":"Example donation","Amount":10,"ItemNumber":"2010"}', 1, 1, NULL, N'~/Content/Images/Widgets/heart.png', N'The PayPal donate widget.Post the donate information to the paypal.', N'Widget', N'~/Content/Images/Widgets/heart_16.png', 1, 0, 1)
INSERT [dbo].[dna_WidgetDescriptors] ([ID], [CatID], [PackageID], [Title], [Url], [Action], [Defaults], [IsClosable], [ShowHeader], [Version], [ImageUrl], [Description], [Controller], [IconUrl], [ShowBorder], [Scopes], [IsDeletable]) VALUES (4, 1, 3, N'ImageLink', N'', N'ImageLink', N'{"ImageWidth":null,"ImageHeight":null,"Target":"_blank","Alignment":"center","ImageUrl":null,"LinkUrl":null}', 1, 0, NULL, N'~/Content/Images/Widgets/link.png', N'Display the image by specified url.', N'Widget', N'~/Content/Images/Widgets/link_16.png', 0, 0, 1)
INSERT [dbo].[dna_WidgetDescriptors] ([ID], [CatID], [PackageID], [Title], [Url], [Action], [Defaults], [IsClosable], [ShowHeader], [Version], [ImageUrl], [Description], [Controller], [IconUrl], [ShowBorder], [Scopes], [IsDeletable]) VALUES (5, 1, 3, N'SimpleHtml', N'', N'SimpleHtml', N'{"Text":null}', 1, 0, NULL, N'~/Content/Images/Widgets/markup.png', N'This widget allows you editing the html on the page in WYSAWYG mode.', N'Widget', NULL, 0, 0, 1)
INSERT [dbo].[dna_WidgetDescriptors] ([ID], [CatID], [PackageID], [Title], [Url], [Action], [Defaults], [IsClosable], [ShowHeader], [Version], [ImageUrl], [Description], [Controller], [IconUrl], [ShowBorder], [Scopes], [IsDeletable]) VALUES (6, 1, 3, N'UserInfo', N'', N'UserInfo', N'{}', 1, 1, NULL, N'~/Content/Images/Widgets/user.png', N'Display current user public information.', N'Widget', N'~/Content/Images/Widgets/user_16.png', 1, 0, 1)
INSERT [dbo].[dna_WidgetDescriptors] ([ID], [CatID], [PackageID], [Title], [Url], [Action], [Defaults], [IsClosable], [ShowHeader], [Version], [ImageUrl], [Description], [Controller], [IconUrl], [ShowBorder], [Scopes], [IsDeletable]) VALUES (7, 1, 3, N'WhoIsOnline', N'', N'WhoIsOnline', N'{"Minutes":20}', 1, 1, NULL, N'~/Content/Images/Widgets/users.png', N'Display the statistics information of the website.', N'Widget', N'~/Content/Images/Widgets/users_16.png', 1, 0, 1)
INSERT [dbo].[dna_WidgetDescriptors] ([ID], [CatID], [PackageID], [Title], [Url], [Action], [Defaults], [IsClosable], [ShowHeader], [Version], [ImageUrl], [Description], [Controller], [IconUrl], [ShowBorder], [Scopes], [IsDeletable]) VALUES (8, 1, 3, N'Referring', N'', N'Referring', N'{}', 1, 1, NULL, N'~/Content/Images/Widgets/icon_referrer.png', N'Display which site refer to this website.', N'Widget', N'~/Content/Images/Widgets/icon_referrer_16.png', 1, 0, 1)
INSERT [dbo].[dna_WidgetDescriptors] ([ID], [CatID], [PackageID], [Title], [Url], [Action], [Defaults], [IsClosable], [ShowHeader], [Version], [ImageUrl], [Description], [Controller], [IconUrl], [ShowBorder], [Scopes], [IsDeletable]) VALUES (9, 1, 3, N'WikiViewer', N'', N'WikiViewer', N'{"FileUrl":null}', 1, 0, NULL, N'~/Content/Images/Widgets/wikiviewer.png', N'This widget can display the widget format file.', N'Widget', N'~/Content/Images/Widgets/wikiviewer_16.png', 0, 0, 1)
INSERT [dbo].[dna_WidgetDescriptors] ([ID], [CatID], [PackageID], [Title], [Url], [Action], [Defaults], [IsClosable], [ShowHeader], [Version], [ImageUrl], [Description], [Controller], [IconUrl], [ShowBorder], [Scopes], [IsDeletable]) VALUES (10, 1, 3, N'Wiki', N'', N'Wiki', N'{"Body":""}', 1, 1, NULL, N'~/Content/Images/Widgets/wiki.png', N'The Wiki widget allows you write the article in wiki format.', N'Widget', N'~/Content/Images/Widgets/wiki_16.png', 1, 0, 1)
INSERT [dbo].[dna_WidgetDescriptors] ([ID], [CatID], [PackageID], [Title], [Url], [Action], [Defaults], [IsClosable], [ShowHeader], [Version], [ImageUrl], [Description], [Controller], [IconUrl], [ShowBorder], [Scopes], [IsDeletable]) VALUES (11, 1, 3, N'ContactCard', N'', N'ContactCard', N'{"Address":null,"Fax":null,"Email":null,"WebSite":null,"Company":null,"PostCode":null,"Phone":null,"Mobile":null,"Contact":null}', 1, 1, NULL, N'~/Content/Images/Widgets/contact.png', N'Display the contact info to clients', N'Widget', N'~/Content/Images/Widgets/contact_16.png', 1, 0, 1)
INSERT [dbo].[dna_WidgetDescriptors] ([ID], [CatID], [PackageID], [Title], [Url], [Action], [Defaults], [IsClosable], [ShowHeader], [Version], [ImageUrl], [Description], [Controller], [IconUrl], [ShowBorder], [Scopes], [IsDeletable]) VALUES (12, 1, 3, N'AdSense', N'', N'AdSense', N'{"AdWidth":300,"AdHeight":250,"SlotID":"","ClientCode":""}', 1, 0, NULL, N'~/Content/Images/Widgets/icon_google_36.png', N'Google Ad sense', N'Widget', N'~/Content/Images/Widgets/icon_google_16.png', 0, 0, 1)
INSERT [dbo].[dna_WidgetDescriptors] ([ID], [CatID], [PackageID], [Title], [Url], [Action], [Defaults], [IsClosable], [ShowHeader], [Version], [ImageUrl], [Description], [Controller], [IconUrl], [ShowBorder], [Scopes], [IsDeletable]) VALUES (13, 1, 3, N'BidVertister', N'', N'BidVertister', N'{"BID":"","AdHeight":250,"PID":""}', 1, 1, NULL, NULL, N'BidVertister Ad', N'Widget', NULL, 1, 0, 1)
INSERT [dbo].[dna_WidgetDescriptors] ([ID], [CatID], [PackageID], [Title], [Url], [Action], [Defaults], [IsClosable], [ShowHeader], [Version], [ImageUrl], [Description], [Controller], [IconUrl], [ShowBorder], [Scopes], [IsDeletable]) VALUES (14, 1, 3, N'SendMail', N'', N'SendMail', N'{"Receiver":null,"Subject":null}', 1, 1, NULL, N'~/Content/Images/Widgets/mail_send.png', N'Provides the form to get user info and send to the site admin', N'Widget', N'~/Content/Images/Widgets/mail_send_16.png', 1, 0, 1)
INSERT [dbo].[dna_WidgetDescriptors] ([ID], [CatID], [PackageID], [Title], [Url], [Action], [Defaults], [IsClosable], [ShowHeader], [Version], [ImageUrl], [Description], [Controller], [IconUrl], [ShowBorder], [Scopes], [IsDeletable]) VALUES (15, 2, 3, N'Categories', N'Publishing', N'CategoryNav', N'{}', 1, 1, NULL, N'~/Content/Images/Widgets/cat.png', N'Display all children categories as a link list', N'Category', N'~/Content/Images/Widgets/cat_16.png', 1, 0, 1)
INSERT [dbo].[dna_WidgetDescriptors] ([ID], [CatID], [PackageID], [Title], [Url], [Action], [Defaults], [IsClosable], [ShowHeader], [Version], [ImageUrl], [Description], [Controller], [IconUrl], [ShowBorder], [Scopes], [IsDeletable]) VALUES (16, 3, 3, N'TodayThreads', N'Community', N'TodayThreads', N'{}', 1, 1, NULL, N'~/Content/Images/Widgets/todaypost.png', N'Display a thread list of community for today.', N'Post', N'~/Content/Images/Widgets/todaypost_16.png', 1, 0, 1)
INSERT [dbo].[dna_WidgetDescriptors] ([ID], [CatID], [PackageID], [Title], [Url], [Action], [Defaults], [IsClosable], [ShowHeader], [Version], [ImageUrl], [Description], [Controller], [IconUrl], [ShowBorder], [Scopes], [IsDeletable]) VALUES (17, 3, 3, N'HotThreads', N'Community', N'HotThreads', N'{"MinimizeReads":50}', 1, 1, NULL, N'~/Content/Images/Widgets/hot.png', N'Display a thread list of community for most popular.', N'Post', N'~/Content/Images/Widgets/hot_16.png', 1, 0, 1)
INSERT [dbo].[dna_WidgetDescriptors] ([ID], [CatID], [PackageID], [Title], [Url], [Action], [Defaults], [IsClosable], [ShowHeader], [Version], [ImageUrl], [Description], [Controller], [IconUrl], [ShowBorder], [Scopes], [IsDeletable]) VALUES (18, 2, 3, N'Archives', N'Publishing', N'Archives', N'{"CategoryID":0}', 1, 1, NULL, N'~/Content/Images/Widgets/calendar.png', N'Display an archive list of the current web.', N'Article', N'~/Content/Images/Widgets/calendar_16.png', 1, 0, 1)
INSERT [dbo].[dna_WidgetDescriptors] ([ID], [CatID], [PackageID], [Title], [Url], [Action], [Defaults], [IsClosable], [ShowHeader], [Version], [ImageUrl], [Description], [Controller], [IconUrl], [ShowBorder], [Scopes], [IsDeletable]) VALUES (19, 2, 3, N'TagCloud', N'Publishing', N'TagCloud', N'{"MaximumTags":-1}', 1, 1, NULL, N'~/Content/Images/Widgets/tag.png', N'Display the tag cloud of current web.', N'Article', N'~/Content/Images/Widgets/tag_16.png', 1, 0, 1)
INSERT [dbo].[dna_WidgetDescriptors] ([ID], [CatID], [PackageID], [Title], [Url], [Action], [Defaults], [IsClosable], [ShowHeader], [Version], [ImageUrl], [Description], [Controller], [IconUrl], [ShowBorder], [Scopes], [IsDeletable]) VALUES (20, 2, 3, N'Headlines', N'Publishing', N'HeadLines', N'{"ShowAuthor":true,"ShowDate":true,"CategoryID":0,"TextLen":-1,"Rows":20}', 1, 1, NULL, N'~/Content/Images/Widgets/headline.png', N'Display recent articles title link list of specified category.You can use this widget to display the headline news.', N'Article', N'~/Content/Images/Widgets/headline_16.png', 1, 0, 1)
INSERT [dbo].[dna_WidgetDescriptors] ([ID], [CatID], [PackageID], [Title], [Url], [Action], [Defaults], [IsClosable], [ShowHeader], [Version], [ImageUrl], [Description], [Controller], [IconUrl], [ShowBorder], [Scopes], [IsDeletable]) VALUES (21, 2, 3, N'MultiHeadLines', N'Publishing', N'MultiHeadLines', N'{"ShowDate":true,"CategoryID":0,"TextLen":-1,"Rows":10,"ShowAuthor":true}', 1, 1, NULL, N'~/Content/Images/Widgets/multiheadlines.png', N'Display a multi tab head lines ui.This Widget will load the children categories of specified cateogry and show them in to multi tabs.', N'Article', N'~/Content/Images/Widgets/multiheadlines_16.png', 1, 0, 1)
INSERT [dbo].[dna_WidgetDescriptors] ([ID], [CatID], [PackageID], [Title], [Url], [Action], [Defaults], [IsClosable], [ShowHeader], [Version], [ImageUrl], [Description], [Controller], [IconUrl], [ShowBorder], [Scopes], [IsDeletable]) VALUES (22, 2, 3, N'HotReads', N'Publishing', N'HotReads', N'{"Rows":10}', 1, 1, NULL, NULL, N'HotReads is a widget that search the most reads article/blog post of the web site and display in a link list.', N'Article', NULL, 1, 0, 1)
INSERT [dbo].[dna_WidgetDescriptors] ([ID], [CatID], [PackageID], [Title], [Url], [Action], [Defaults], [IsClosable], [ShowHeader], [Version], [ImageUrl], [Description], [Controller], [IconUrl], [ShowBorder], [Scopes], [IsDeletable]) VALUES (23, 2, 3, N'RecentBlogPost', N'Publishing', N'RecentBlogPost', N'{"TextLen":-1,"Rows":10,"ShowAuthor":true,"ShowDate":true}', 1, 1, NULL, NULL, N'Display the recent blog posts of current website in a title link list.', N'Article', NULL, 1, 1, 1)
INSERT [dbo].[dna_WidgetDescriptors] ([ID], [CatID], [PackageID], [Title], [Url], [Action], [Defaults], [IsClosable], [ShowHeader], [Version], [ImageUrl], [Description], [Controller], [IconUrl], [ShowBorder], [Scopes], [IsDeletable]) VALUES (24, 2, 3, N'BlogRoll', N'Publishing', N'BlogRoll', N'{"Rows":10}', 1, 1, NULL, NULL, N'BlogRoll is a widget that display a list contains the most actively bloggers.', N'Article', NULL, 1, 0, 1)
INSERT [dbo].[dna_WidgetDescriptors] ([ID], [CatID], [PackageID], [Title], [Url], [Action], [Defaults], [IsClosable], [ShowHeader], [Version], [ImageUrl], [Description], [Controller], [IconUrl], [ShowBorder], [Scopes], [IsDeletable]) VALUES (25, 2, 3, N'RecentComments', N'Publishing', N'RecentComments', N'{"Rows":10}', 1, 1, NULL, N'~/Content/Images/Widgets/comment.png', N'Display the recent comments of current web.', N'Article', N'~/Content/Images/Widgets/comment_16.png', 1, 0, 1)
INSERT [dbo].[dna_WidgetDescriptors] ([ID], [CatID], [PackageID], [Title], [Url], [Action], [Defaults], [IsClosable], [ShowHeader], [Version], [ImageUrl], [Description], [Controller], [IconUrl], [ShowBorder], [Scopes], [IsDeletable]) VALUES (26, 2, 3, N'SummaryView', N'Publishing', N'SummaryView', N'{"Rows":10,"CategoryID":0,"IncludeSubCategory":false}', 1, 0, NULL, NULL, NULL, N'Article', NULL, 0, 0, 1)
INSERT [dbo].[dna_WidgetDescriptors] ([ID], [CatID], [PackageID], [Title], [Url], [Action], [Defaults], [IsClosable], [ShowHeader], [Version], [ImageUrl], [Description], [Controller], [IconUrl], [ShowBorder], [Scopes], [IsDeletable]) VALUES (27, 2, 3, N'ArticleMenu', N'Publishing', N'Navigator', N'{"CategoryID":0,"TextLen":-1}', 1, 0, NULL, N'~/Content/Images/Widgets/articlemenu.png', NULL, N'Article', N'~/Content/Images/Widgets/articlemenu_16.png', 1, 0, 1)
INSERT [dbo].[dna_WidgetDescriptors] ([ID], [CatID], [PackageID], [Title], [Url], [Action], [Defaults], [IsClosable], [ShowHeader], [Version], [ImageUrl], [Description], [Controller], [IconUrl], [ShowBorder], [Scopes], [IsDeletable]) VALUES (28, 2, 3, N'MyActions', N'Publishing', N'MyActions', N'{}', 1, 1, NULL, NULL, N'Auto search actions for current user.', N'Article', NULL, 1, 0, 1)
INSERT [dbo].[dna_WidgetDescriptors] ([ID], [CatID], [PackageID], [Title], [Url], [Action], [Defaults], [IsClosable], [ShowHeader], [Version], [ImageUrl], [Description], [Controller], [IconUrl], [ShowBorder], [Scopes], [IsDeletable]) VALUES (29, 2, 3, N'PostRoll', N'Publishing', N'PostRoll', N'{"Rows":10,"ShowAuthorInfo":true}', 1, 0, NULL, NULL, N'PostRoll is a widget that search and display the latest post and show all the post content in a list.Place this widget on 
top site it will search all the blogger posts in web, when place in your personal web site it just search the posts in your web.', N'Article', NULL, 0, 0, 1)
INSERT [dbo].[dna_WidgetDescriptors] ([ID], [CatID], [PackageID], [Title], [Url], [Action], [Defaults], [IsClosable], [ShowHeader], [Version], [ImageUrl], [Description], [Controller], [IconUrl], [ShowBorder], [Scopes], [IsDeletable]) VALUES (30, 3, 3, N'Stat.', N'Community', N'Statistics', N'{}', 1, 1, NULL, N'~/Content/Images/Widgets/stat.png', N'Display the statistics for community', N'Forum', N'~/Content/Images/Widgets/stat_16.png', 1, 0, 1)
INSERT [dbo].[dna_WidgetDescriptors] ([ID], [CatID], [PackageID], [Title], [Url], [Action], [Defaults], [IsClosable], [ShowHeader], [Version], [ImageUrl], [Description], [Controller], [IconUrl], [ShowBorder], [Scopes], [IsDeletable]) VALUES (31, 1, 3, N'Feeds', N'', N'Feeds', N'{"Rows":5,"Url":"http://www.cnblogs.com/sunrack/category/74529.html/rss","ShowFeedInfo":true}', 1, 1, NULL, N'~/Content/Images/Widgets/rss.png', N'Feeds is a widget that allows you subscript rss feed or atom feed.', N'AsyncWidget', N'~/Content/Images/Widgets/rss_16.png', 1, 0, 1)
SET IDENTITY_INSERT [dbo].[dna_WidgetDescriptors] OFF
GO