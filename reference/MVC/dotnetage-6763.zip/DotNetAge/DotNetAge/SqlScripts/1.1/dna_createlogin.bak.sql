﻿/**Create login and users**/
USE [master]
GO

IF NOT EXISTS(SELECT * FROM sys.server_principals WHERE [name]=N'IIS APPPOOL\DefaultAppPool')
  CREATE LOGIN [IIS APPPOOL\DefaultAppPool] FROM WINDOWS WITH DEFAULT_DATABASE=[PlaceholderForDbName]
GO

USE [PlaceholderForDbName]
GO

IF EXISTS( SELECT * FROM sys.database_principals WHERE [name]=N'IIS APPPOOL\DefaultAppPool')
  DROP USER [IIS APPPOOL\DefaultAppPool]

CREATE USER [IIS APPPOOL\DefaultAppPool] FOR LOGIN [IIS APPPOOL\DefaultAppPool]
GO

EXEC sp_addrolemember N'db_owner', N'IIS APPPOOL\DefaultAppPool'
GO