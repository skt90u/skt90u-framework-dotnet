﻿-- ===============================================================================
-- Author:		<Ray liang>
-- Create date: <2010-10-21>
-- Description:	<Install the tables and storeprocedures for DotNetAge core.>
-- Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
-- Dual licensed under the MIT and GPL licenses:
-- http://www.opensource.org/licenses/mit-license.php
-- http://www.gnu.org/licenses/gpl.html
-- ===============================================================================


USE [PlaceholderForDbName]
GO
/*
IF EXISTS( SELECT * FROM sys.database_principals WHERE [name]=N'IIS APPPOOL\DefaultAppPool')
  DROP USER [IIS APPPOOL\DefaultAppPool]

CREATE USER [IIS APPPOOL\DefaultAppPool] FOR LOGIN [IIS APPPOOL\DefaultAppPool]
GO

EXEC sp_addrolemember N'db_owner', N'IIS APPPOOL\DefaultAppPool'
GO
*/
/****** Object:  Table [dbo].[dna_PermissionSets]    Script Date: 10/21/2010 21:20:55 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dna_PermissionSets]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[dna_PermissionSets](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[Name] [nvarchar](100) NOT NULL,
	[Title] [nvarchar](255) NULL,
	[Description] [ntext] NULL,
 CONSTRAINT [PK_PermissionSets] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[dna_EventLog]    Script Date: 10/21/2010 21:20:55 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dna_EventLog]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[dna_EventLog](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[ClientAddress] [nvarchar](255) NOT NULL,
	[Controller] [nvarchar](255) NOT NULL,
	[Action] [nvarchar](255) NOT NULL,
	[UserName] [nvarchar](255) NULL,
	[IsAnonymous] [bit] NOT NULL,
	[Logged] [datetime] NOT NULL,
	[Browser] [nvarchar](50) NOT NULL,
	[Version] [nvarchar](1024) NOT NULL,
	[Host] [nvarchar](1024) NOT NULL,
	[RawUrl] [nvarchar](2048) NOT NULL,
	[UserAgent] [nvarchar](1024) NOT NULL,
	[UrlRefer] [nvarchar](2048) NULL,
	[WebName] [nvarchar](1024) NULL,
	[HttpMethod] [nvarchar](50) NULL,
	[QueryString] [nvarchar](2048) NULL,
	[Cookies] [nvarchar](2048) NULL,
	[Bytes] [int] NULL,
 CONSTRAINT [PK_dna_Log] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[dna_PackageInfos]    Script Date: 10/21/2010 21:20:55 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dna_PackageInfos]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[dna_PackageInfos](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[Name] [nvarchar](50) NOT NULL,
	[ShortName] [nvarchar](50) NULL,
	[Description] [ntext] NULL,
	[AuthorName] [nvarchar](50) NULL,
	[AuthorWebSite] [nvarchar](1024) NULL,
	[AuthorEmail] [nvarchar](1024) NULL,
	[Organization] [nvarchar](255) NULL,
	[IconUrl] [nvarchar](1024) NULL,
	[IconHeight] [int] NULL,
	[IconWidth] [int] NULL,
	[ReleaseNotes] [ntext] NULL,
	[Version] [nvarchar](50) NULL,
	[Installed] [datetime] NULL,
	[Published] [datetime] NULL,
	[LicensesXML] [ntext] NULL,
	[FileList] [ntext] NULL,
	[HelpLink] [nvarchar](50) NULL,
	[SupportLink] [nvarchar](50) NULL,
	[AssemblyName] [nvarchar](255) NULL,
	[AssemblyFullName] [nvarchar](1024) NULL,
 CONSTRAINT [PK_Packages] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[dna_WidgetCategories]    Script Date: 10/21/2010 21:20:55 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dna_WidgetCategories]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[dna_WidgetCategories](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Title] [nvarchar](50) NULL,
	[Description] [ntext] NULL,
 CONSTRAINT [PK_Categories] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[dna_WebSettings]    Script Date: 10/21/2010 21:20:55 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dna_WebSettings]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[dna_WebSettings](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Title] [nvarchar](50) NULL,
	[Description] [ntext] NULL,
	[LogoImageUrl] [nvarchar](1024) NULL,
	[SearchKeywords] [ntext] NULL,
	[TimeZone] [nvarchar](255) NULL,
	[Theme] [nvarchar](255) NULL,
	[Copyright] [ntext] NULL,
	[DefaultLanguage] [nvarchar](50) NULL,
	[ShortcutIconUrl] [nvarchar](1024) NULL,
	[Layout] [nvarchar](1024) NULL,
	[Data] [ntext] NULL,
	[AllowExtensions] [ntext] NULL,
	[MaximumFileSize] [int] NOT NULL,
	[MasterName] [nvarchar](1024) NULL,
	[SMTPHost] [nvarchar](1024) NULL,
	[SMTPPassword] [nvarchar](255) NULL,
	[SMTPUserName] [nvarchar](255) NULL,
	[SMTPPort] [int] NOT NULL,
	[SMTPUsedDefaultCredentials] [bit] NOT NULL,
	[SiteMailAccount] [nvarchar](1024) NULL,
	[MostOnlineUserCount] [int] NOT NULL,
	[MostOnlined] [datetime] NOT NULL,
	[CssText] [ntext] NULL,
	[EnableUserRegistration] [bit] NOT NULL,
	[DefaultUrl] [nvarchar](1024) NULL,
	[Name] [nvarchar](1024) NOT NULL,
	[Owner] [nvarchar](256) NOT NULL,
	[Created] [datetime] NOT NULL,
	[IsEnabled] [bit] NOT NULL,
	[CacheDuration] [int] NOT NULL,
	[Type] [int] NOT NULL,
 CONSTRAINT [PK_Portals] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[dna_WebPages]    Script Date: 10/21/2010 21:20:55 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dna_WebPages]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[dna_WebPages](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[Path] [nvarchar](1024) NOT NULL,
	[Title] [nvarchar](255) NULL,
	[Description] [ntext] NULL,
	[ViewData] [ntext] NULL,
	[ViewName] [nvarchar](255) NULL,
	[IsStatic] [bit] NOT NULL,
	[ShowInMenu] [bit] NOT NULL,
	[IsShared] [bit] NOT NULL,
	[AllowAnonymous] [bit] NOT NULL,
	[Pos] [int] NOT NULL,
	[ParentID] [int] NOT NULL,
	[Target] [nvarchar](50) NOT NULL,
	[LastModified] [datetime] NOT NULL,
	[Created] [datetime] NOT NULL,
	[Owner] [nvarchar](255) NOT NULL,
	[LinkUrl] [nvarchar](1024) NULL,
	[WebID] [int] NOT NULL,
 CONSTRAINT [PK_WebPages] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
END
GO

/****** Object:  StoredProcedure [dbo].[dna_getOnlineUsers]    Script Date: 10/21/2010 21:20:54 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF EXISTS(SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dna_getOnlineUsers]') AND type in (N'P', N'PC')) BEGIN
   DROP PROCEDURE [dbo].[dna_statistics]
END
GO

CREATE PROCEDURE [dbo].[dna_getOnlineUsers]
@webName nvarchar(1024),
@isAnonymous bit,
@interval int
AS
BEGIN
SET NOCOUNT ON;
SELECT distinct userName 
FROM [dna_eventlog]
WHERE IsAnonymous=@isAnonymous AND
      (Logged Between DateAdd(MINUTE,-@interval,GetDate()) AND GetDate()) AND
      [dna_EventLog].[WebName]=@webName
END

GO

/****** Object:  Table [dbo].[dna_Permissions]    Script Date: 10/21/2010 21:20:55 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dna_Permissions]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[dna_Permissions](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[Controller] [nvarchar](255) NOT NULL,
	[Action] [nvarchar](255) NOT NULL,
	[PermissionSetID] [int] NOT NULL,
	[Title] [nvarchar](255) NULL,
	[Description] [ntext] NULL,
	[Assembly] [nvarchar](1024) NOT NULL,
 CONSTRAINT [PK_Permissions] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[dna_WidgetDescriptors]    Script Date: 10/21/2010 21:20:55 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dna_WidgetDescriptors]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[dna_WidgetDescriptors](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[CatID] [int] NOT NULL,
	[PackageID] [int] NOT NULL,
	[Title] [nvarchar](50) NULL,
	[Url] [nvarchar](1024) NULL,
	[Action] [nvarchar](255) NULL,
	[Defaults] [ntext] NULL,
	[IsClosable] [bit] NULL,
	[ShowHeader] [bit] NULL,
	[Version] [nvarchar](50) NULL,
	[ImageUrl] [nvarchar](1024) NULL,
	[Description] [ntext] NULL,
	[Controller] [nvarchar](255) NULL,
	[IconUrl] [nvarchar](1024) NULL,
	[ShowBorder] [bit] NOT NULL,
	[Scopes] [int] NOT NULL,
	[IsDeletable] [bit] NULL,
 CONSTRAINT [PK_WidgetMetas] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[dna_Widgets]    Script Date: 10/21/2010 21:20:55 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dna_Widgets]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[dna_Widgets](
	[ID] [uniqueidentifier] NOT NULL,
	[Title] [nvarchar](255) NULL,
	[TitleLinkUrl] [nvarchar](1024) NULL,
	[IconUrl] [nvarchar](1024) NULL,
	[ShowHeader] [bit] NOT NULL,
	[ShowBorder] [bit] NOT NULL,
	[IsDeletable] [bit] NOT NULL,
	[IsClosable] [bit] NOT NULL,
	[IsExpanded] [bit] NOT NULL,
	[Pos] [int] NOT NULL,
	[Data] [varbinary](max) NULL,
	[Url] [nvarchar](1024) NULL,
	[Action] [nvarchar](255) NULL,
	[ZoneID] [nvarchar](255) NOT NULL,
	[PageID] [int] NOT NULL,
	[DescriptorID] [int] NOT NULL,
	[Controller] [nvarchar](255) NULL,
	[BackgroundColor] [nvarchar](10) NULL,
	[ForeColor] [nvarchar](10) NULL,
	[Scope] [int] NOT NULL,
	[IsStatic] [bit] NULL,
 CONSTRAINT [PK_Widgets] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
/****** Object:  Table [dbo].[dna_PermsInRoles]    Script Date: 10/21/2010 21:20:55 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dna_PermsInRoles]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[dna_PermsInRoles](
	[PermID] [int] NOT NULL,
	[RoleName] [nvarchar](50) NOT NULL,
 CONSTRAINT [PK_PermsInRoles] PRIMARY KEY CLUSTERED 
(
	[PermID] ASC,
	[RoleName] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO
/****** Object:  Table [dbo].[dna_WebPageRoles]    Script Date: 10/21/2010 21:20:55 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dna_WebPageRoles]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[dna_WebPageRoles](
	[RoleName] [nvarchar](256) NOT NULL,
	[PageID] [int] NOT NULL,
 CONSTRAINT [PK_dna_WebPageRoles] PRIMARY KEY CLUSTERED 
(
	[RoleName] ASC,
	[PageID] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]
END
GO

/****** Object:  StoredProcedure [dbo].[dna_statistics]    Script Date: 10/21/2010 21:20:54 ******/

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF EXISTS(SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dna_statistics]') AND type in (N'P', N'PC')) BEGIN
   DROP PROCEDURE [dbo].[dna_statistics]
END
GO

CREATE PROCEDURE [dbo].[dna_statistics]
@webName nvarchar(1024),
@interval int
AS
BEGIN
	SET NOCOUNT ON;

DECLARE @mostUserCount int,
        @mostOnlined datetime

SELECT distinct ClientAddress,CONVERT(varchar(30),Logged,101) as loggedstr
INTO #tmp
FROM [dbo].[dna_eventlog]
WHERE [WebName] = @webName
ORDER BY loggedstr

SELECT TOP 1 COUNT(ClientAddress) AS AccessCount,
       LoggedStr AS Logged
INTO #a
FROM  #tmp
GROUP BY loggedstr
ORDER BY AccessCount DESC


SELECT @mostUserCount=a.AccessCount,
       @mostOnlined=CONVERT(datetime,a.Logged)
FROM #a a

DROP TABLE #a
DROP TABLE #tmp

IF @mostUserCount IS NULL  SET @mostUserCount=0
IF @mostOnlined IS NULL  SET @mostOnlined=CONVERT(datetime,GETDATE())

SELECT Count(distinct clientAddress) AS Visits,
       Count(clientAddress) AS PageView,
       RegistedUserCount = (SELECT Count(UserID)FROM [aspnet_Membership]),
       OnlineGuests=(select Count(distinct userName)FROM [dna_eventlog] WHERE IsAnonymous=1 AND(Logged Between DateAdd(MINUTE,-@interval,GetDate()) AND GetDate()) AND [dna_EventLog].[WebName]=@webName),
       OnlineRegisters=(select Count(distinct userName)FROM [dna_eventlog] WHERE IsAnonymous=0 AND(Logged Between DateAdd(MINUTE,-@interval,GetDate()) AND GetDate()) AND [dna_EventLog].[WebName]=@webName),
       MostOnlineCount=@mostUserCount,
       MostOnlined=@mostOnlined
FROM [dna_eventlog]
WHERE DatePart(YYYY,logged)=DatePart(YYYY,GetDate()) AND
      DatePart(MM,logged)=DatePart(MM,GetDate()) AND
      DatePart(dd,logged)=DatePart(dd,GetDate())AND
      [dna_EventLog].[WebName]=@webName
END
GO

/****** Object:  Default [DF_Packages_IconHeight]    Script Date: 10/21/2010 21:20:55 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_Packages_IconHeight]') AND parent_object_id = OBJECT_ID(N'[dbo].[dna_PackageInfos]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_Packages_IconHeight]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[dna_PackageInfos] ADD  CONSTRAINT [DF_Packages_IconHeight]  DEFAULT ((16)) FOR [IconHeight]
END


End
GO
/****** Object:  Default [DF_Packages_IconWidth]    Script Date: 10/21/2010 21:20:55 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_Packages_IconWidth]') AND parent_object_id = OBJECT_ID(N'[dbo].[dna_PackageInfos]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_Packages_IconWidth]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[dna_PackageInfos] ADD  CONSTRAINT [DF_Packages_IconWidth]  DEFAULT ((16)) FOR [IconWidth]
END


End
GO
/****** Object:  Default [DF_Packages_Version]    Script Date: 10/21/2010 21:20:55 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_Packages_Version]') AND parent_object_id = OBJECT_ID(N'[dbo].[dna_PackageInfos]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_Packages_Version]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[dna_PackageInfos] ADD  CONSTRAINT [DF_Packages_Version]  DEFAULT (N'v1.0.0.0') FOR [Version]
END


End
GO
/****** Object:  Default [DF_Packages_LastUpdated]    Script Date: 10/21/2010 21:20:55 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_Packages_LastUpdated]') AND parent_object_id = OBJECT_ID(N'[dbo].[dna_PackageInfos]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_Packages_LastUpdated]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[dna_PackageInfos] ADD  CONSTRAINT [DF_Packages_LastUpdated]  DEFAULT (getdate()) FOR [Installed]
END


End
GO
/****** Object:  Default [DF_dna_Log_IsAnonymous]    Script Date: 10/21/2010 21:20:55 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_dna_Log_IsAnonymous]') AND parent_object_id = OBJECT_ID(N'[dbo].[dna_EventLog]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_dna_Log_IsAnonymous]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[dna_EventLog] ADD  CONSTRAINT [DF_dna_Log_IsAnonymous]  DEFAULT ((1)) FOR [IsAnonymous]
END


End
GO
/****** Object:  Default [DF_dna_WebPages_IsStatic]    Script Date: 10/21/2010 21:20:55 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_dna_WebPages_IsStatic]') AND parent_object_id = OBJECT_ID(N'[dbo].[dna_WebPages]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_dna_WebPages_IsStatic]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[dna_WebPages] ADD  CONSTRAINT [DF_dna_WebPages_IsStatic]  DEFAULT ((0)) FOR [IsStatic]
END


End
GO
/****** Object:  Default [DF_WebPages_ShowInMenu]    Script Date: 10/21/2010 21:20:55 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_WebPages_ShowInMenu]') AND parent_object_id = OBJECT_ID(N'[dbo].[dna_WebPages]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_WebPages_ShowInMenu]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[dna_WebPages] ADD  CONSTRAINT [DF_WebPages_ShowInMenu]  DEFAULT ((0)) FOR [ShowInMenu]
END


End
GO
/****** Object:  Default [DF_dna_WebPages_IsShared]    Script Date: 10/21/2010 21:20:55 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_dna_WebPages_IsShared]') AND parent_object_id = OBJECT_ID(N'[dbo].[dna_WebPages]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_dna_WebPages_IsShared]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[dna_WebPages] ADD  CONSTRAINT [DF_dna_WebPages_IsShared]  DEFAULT ((1)) FOR [IsShared]
END


End
GO
/****** Object:  Default [DF_dna_WebPages_AllowAnonymous]    Script Date: 10/21/2010 21:20:55 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_dna_WebPages_AllowAnonymous]') AND parent_object_id = OBJECT_ID(N'[dbo].[dna_WebPages]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_dna_WebPages_AllowAnonymous]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[dna_WebPages] ADD  CONSTRAINT [DF_dna_WebPages_AllowAnonymous]  DEFAULT ((1)) FOR [AllowAnonymous]
END


End
GO
/****** Object:  Default [DF_WebPages_Pos]    Script Date: 10/21/2010 21:20:55 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_WebPages_Pos]') AND parent_object_id = OBJECT_ID(N'[dbo].[dna_WebPages]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_WebPages_Pos]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[dna_WebPages] ADD  CONSTRAINT [DF_WebPages_Pos]  DEFAULT ((0)) FOR [Pos]
END


End
GO
/****** Object:  Default [DF_dna_WebPages_ParentID]    Script Date: 10/21/2010 21:20:55 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_dna_WebPages_ParentID]') AND parent_object_id = OBJECT_ID(N'[dbo].[dna_WebPages]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_dna_WebPages_ParentID]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[dna_WebPages] ADD  CONSTRAINT [DF_dna_WebPages_ParentID]  DEFAULT ((-1)) FOR [ParentID]
END


End
GO
/****** Object:  Default [DF_WebPages_Target]    Script Date: 10/21/2010 21:20:55 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_WebPages_Target]') AND parent_object_id = OBJECT_ID(N'[dbo].[dna_WebPages]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_WebPages_Target]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[dna_WebPages] ADD  CONSTRAINT [DF_WebPages_Target]  DEFAULT ('_self') FOR [Target]
END


End
GO
/****** Object:  Default [DF_dna_WebPages_LastModified]    Script Date: 10/21/2010 21:20:55 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_dna_WebPages_LastModified]') AND parent_object_id = OBJECT_ID(N'[dbo].[dna_WebPages]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_dna_WebPages_LastModified]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[dna_WebPages] ADD  CONSTRAINT [DF_dna_WebPages_LastModified]  DEFAULT (getdate()) FOR [LastModified]
END


End
GO
/****** Object:  Default [DF_dna_WebPages_Created]    Script Date: 10/21/2010 21:20:55 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_dna_WebPages_Created]') AND parent_object_id = OBJECT_ID(N'[dbo].[dna_WebPages]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_dna_WebPages_Created]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[dna_WebPages] ADD  CONSTRAINT [DF_dna_WebPages_Created]  DEFAULT (getdate()) FOR [Created]
END


End
GO
/****** Object:  Default [DF_dna_WebPages_Owner]    Script Date: 10/21/2010 21:20:55 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_dna_WebPages_Owner]') AND parent_object_id = OBJECT_ID(N'[dbo].[dna_WebPages]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_dna_WebPages_Owner]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[dna_WebPages] ADD  CONSTRAINT [DF_dna_WebPages_Owner]  DEFAULT (N'') FOR [Owner]
END


End
GO
/****** Object:  Default [DF_dna_WebSettings_MaximumFileSize]    Script Date: 10/21/2010 21:20:55 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_dna_WebSettings_MaximumFileSize]') AND parent_object_id = OBJECT_ID(N'[dbo].[dna_WebSettings]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_dna_WebSettings_MaximumFileSize]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[dna_WebSettings] ADD  CONSTRAINT [DF_dna_WebSettings_MaximumFileSize]  DEFAULT ((1024000000)) FOR [MaximumFileSize]
END


End
GO
/****** Object:  Default [DF_dna_WebSettings_SMTPPort]    Script Date: 10/21/2010 21:20:55 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_dna_WebSettings_SMTPPort]') AND parent_object_id = OBJECT_ID(N'[dbo].[dna_WebSettings]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_dna_WebSettings_SMTPPort]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[dna_WebSettings] ADD  CONSTRAINT [DF_dna_WebSettings_SMTPPort]  DEFAULT ((25)) FOR [SMTPPort]
END


End
GO
/****** Object:  Default [DF_dna_WebSettings_SMTPUsedDefaultCredentials]    Script Date: 10/21/2010 21:20:55 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_dna_WebSettings_SMTPUsedDefaultCredentials]') AND parent_object_id = OBJECT_ID(N'[dbo].[dna_WebSettings]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_dna_WebSettings_SMTPUsedDefaultCredentials]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[dna_WebSettings] ADD  CONSTRAINT [DF_dna_WebSettings_SMTPUsedDefaultCredentials]  DEFAULT ((1)) FOR [SMTPUsedDefaultCredentials]
END


End
GO
/****** Object:  Default [DF_dna_WebSettings_MostOnlineUserCount]    Script Date: 10/21/2010 21:20:55 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_dna_WebSettings_MostOnlineUserCount]') AND parent_object_id = OBJECT_ID(N'[dbo].[dna_WebSettings]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_dna_WebSettings_MostOnlineUserCount]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[dna_WebSettings] ADD  CONSTRAINT [DF_dna_WebSettings_MostOnlineUserCount]  DEFAULT ((0)) FOR [MostOnlineUserCount]
END


End
GO
/****** Object:  Default [DF_dna_WebSettings_MostOnlined]    Script Date: 10/21/2010 21:20:55 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_dna_WebSettings_MostOnlined]') AND parent_object_id = OBJECT_ID(N'[dbo].[dna_WebSettings]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_dna_WebSettings_MostOnlined]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[dna_WebSettings] ADD  CONSTRAINT [DF_dna_WebSettings_MostOnlined]  DEFAULT (getdate()) FOR [MostOnlined]
END


End
GO
/****** Object:  Default [DF_dna_WebSettings_Created]    Script Date: 10/21/2010 21:20:55 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_dna_WebSettings_Created]') AND parent_object_id = OBJECT_ID(N'[dbo].[dna_WebSettings]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_dna_WebSettings_Created]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[dna_WebSettings] ADD  CONSTRAINT [DF_dna_WebSettings_Created]  DEFAULT (getdate()) FOR [Created]
END


End
GO
/****** Object:  Default [DF_dna_WebSettings_IsEnabled]    Script Date: 10/21/2010 21:20:55 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_dna_WebSettings_IsEnabled]') AND parent_object_id = OBJECT_ID(N'[dbo].[dna_WebSettings]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_dna_WebSettings_IsEnabled]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[dna_WebSettings] ADD  CONSTRAINT [DF_dna_WebSettings_IsEnabled]  DEFAULT ((1)) FOR [IsEnabled]
END


End
GO
/****** Object:  Default [DF_dna_WebSettings_CacheDuration]    Script Date: 10/21/2010 21:20:55 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_dna_WebSettings_CacheDuration]') AND parent_object_id = OBJECT_ID(N'[dbo].[dna_WebSettings]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_dna_WebSettings_CacheDuration]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[dna_WebSettings] ADD  CONSTRAINT [DF_dna_WebSettings_CacheDuration]  DEFAULT ((0)) FOR [CacheDuration]
END


End
GO
/****** Object:  Default [DF_dna_WebSettings_Type]    Script Date: 10/21/2010 21:20:55 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_dna_WebSettings_Type]') AND parent_object_id = OBJECT_ID(N'[dbo].[dna_WebSettings]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_dna_WebSettings_Type]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[dna_WebSettings] ADD  CONSTRAINT [DF_dna_WebSettings_Type]  DEFAULT ((0)) FOR [Type]
END


End
GO
/****** Object:  Default [DF_WidgetMetas_IsClosable]    Script Date: 10/21/2010 21:20:55 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_WidgetMetas_IsClosable]') AND parent_object_id = OBJECT_ID(N'[dbo].[dna_WidgetDescriptors]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_WidgetMetas_IsClosable]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[dna_WidgetDescriptors] ADD  CONSTRAINT [DF_WidgetMetas_IsClosable]  DEFAULT ((1)) FOR [IsClosable]
END


End
GO
/****** Object:  Default [DF_WidgetMetas_ShowHeader]    Script Date: 10/21/2010 21:20:55 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_WidgetMetas_ShowHeader]') AND parent_object_id = OBJECT_ID(N'[dbo].[dna_WidgetDescriptors]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_WidgetMetas_ShowHeader]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[dna_WidgetDescriptors] ADD  CONSTRAINT [DF_WidgetMetas_ShowHeader]  DEFAULT ((1)) FOR [ShowHeader]
END


End
GO
/****** Object:  Default [DF_WidgetMetas_Version]    Script Date: 10/21/2010 21:20:55 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_WidgetMetas_Version]') AND parent_object_id = OBJECT_ID(N'[dbo].[dna_WidgetDescriptors]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_WidgetMetas_Version]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[dna_WidgetDescriptors] ADD  CONSTRAINT [DF_WidgetMetas_Version]  DEFAULT (N'v1.0') FOR [Version]
END


End
GO
/****** Object:  Default [DF_dna_WidgetDescriptors_ShowBorder]    Script Date: 10/21/2010 21:20:55 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_dna_WidgetDescriptors_ShowBorder]') AND parent_object_id = OBJECT_ID(N'[dbo].[dna_WidgetDescriptors]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_dna_WidgetDescriptors_ShowBorder]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[dna_WidgetDescriptors] ADD  CONSTRAINT [DF_dna_WidgetDescriptors_ShowBorder]  DEFAULT ((1)) FOR [ShowBorder]
END


End
GO
/****** Object:  Default [DF_dna_WidgetDescriptors_Scopes]    Script Date: 10/21/2010 21:20:55 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_dna_WidgetDescriptors_Scopes]') AND parent_object_id = OBJECT_ID(N'[dbo].[dna_WidgetDescriptors]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_dna_WidgetDescriptors_Scopes]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[dna_WidgetDescriptors] ADD  CONSTRAINT [DF_dna_WidgetDescriptors_Scopes]  DEFAULT ((0)) FOR [Scopes]
END


End
GO
/****** Object:  Default [DF_dna_WidgetDescriptors_IsDeletable]    Script Date: 10/21/2010 21:20:55 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_dna_WidgetDescriptors_IsDeletable]') AND parent_object_id = OBJECT_ID(N'[dbo].[dna_WidgetDescriptors]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_dna_WidgetDescriptors_IsDeletable]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[dna_WidgetDescriptors] ADD  CONSTRAINT [DF_dna_WidgetDescriptors_IsDeletable]  DEFAULT ((1)) FOR [IsDeletable]
END


End
GO
/****** Object:  Default [DF_Widgets_ID]    Script Date: 10/21/2010 21:20:55 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_Widgets_ID]') AND parent_object_id = OBJECT_ID(N'[dbo].[dna_Widgets]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_Widgets_ID]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[dna_Widgets] ADD  CONSTRAINT [DF_Widgets_ID]  DEFAULT (newid()) FOR [ID]
END


End
GO
/****** Object:  Default [DF_Widgets_ShowHeader]    Script Date: 10/21/2010 21:20:55 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_Widgets_ShowHeader]') AND parent_object_id = OBJECT_ID(N'[dbo].[dna_Widgets]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_Widgets_ShowHeader]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[dna_Widgets] ADD  CONSTRAINT [DF_Widgets_ShowHeader]  DEFAULT ((1)) FOR [ShowHeader]
END


End
GO
/****** Object:  Default [DF_dna_Widgets_ShowBorder]    Script Date: 10/21/2010 21:20:55 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_dna_Widgets_ShowBorder]') AND parent_object_id = OBJECT_ID(N'[dbo].[dna_Widgets]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_dna_Widgets_ShowBorder]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[dna_Widgets] ADD  CONSTRAINT [DF_dna_Widgets_ShowBorder]  DEFAULT ((1)) FOR [ShowBorder]
END


End
GO
/****** Object:  Default [DF_Widgets_IsDeletable]    Script Date: 10/21/2010 21:20:55 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_Widgets_IsDeletable]') AND parent_object_id = OBJECT_ID(N'[dbo].[dna_Widgets]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_Widgets_IsDeletable]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[dna_Widgets] ADD  CONSTRAINT [DF_Widgets_IsDeletable]  DEFAULT ((1)) FOR [IsDeletable]
END


End
GO
/****** Object:  Default [DF_Widgets_IsClosable]    Script Date: 10/21/2010 21:20:55 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_Widgets_IsClosable]') AND parent_object_id = OBJECT_ID(N'[dbo].[dna_Widgets]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_Widgets_IsClosable]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[dna_Widgets] ADD  CONSTRAINT [DF_Widgets_IsClosable]  DEFAULT ((1)) FOR [IsClosable]
END


End
GO
/****** Object:  Default [DF_Widgets_IsExpanded]    Script Date: 10/21/2010 21:20:55 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_Widgets_IsExpanded]') AND parent_object_id = OBJECT_ID(N'[dbo].[dna_Widgets]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_Widgets_IsExpanded]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[dna_Widgets] ADD  CONSTRAINT [DF_Widgets_IsExpanded]  DEFAULT ((1)) FOR [IsExpanded]
END


End
GO
/****** Object:  Default [DF_Widgets_Pos]    Script Date: 10/21/2010 21:20:55 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_Widgets_Pos]') AND parent_object_id = OBJECT_ID(N'[dbo].[dna_Widgets]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_Widgets_Pos]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[dna_Widgets] ADD  CONSTRAINT [DF_Widgets_Pos]  DEFAULT ((0)) FOR [Pos]
END


End
GO
/****** Object:  Default [DF_Widgets_ZoneID]    Script Date: 10/21/2010 21:20:55 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_Widgets_ZoneID]') AND parent_object_id = OBJECT_ID(N'[dbo].[dna_Widgets]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_Widgets_ZoneID]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[dna_Widgets] ADD  CONSTRAINT [DF_Widgets_ZoneID]  DEFAULT ('zone1') FOR [ZoneID]
END


End
GO
/****** Object:  Default [DF_dna_Widgets_Scopes]    Script Date: 10/21/2010 21:20:55 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_dna_Widgets_Scopes]') AND parent_object_id = OBJECT_ID(N'[dbo].[dna_Widgets]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_dna_Widgets_Scopes]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[dna_Widgets] ADD  CONSTRAINT [DF_dna_Widgets_Scopes]  DEFAULT ((0)) FOR [Scope]
END


End
GO
/****** Object:  Default [DF_dna_Widgets_IsStatic]    Script Date: 10/21/2010 21:20:55 ******/
IF Not EXISTS (SELECT * FROM sys.default_constraints WHERE object_id = OBJECT_ID(N'[dbo].[DF_dna_Widgets_IsStatic]') AND parent_object_id = OBJECT_ID(N'[dbo].[dna_Widgets]'))
Begin
IF NOT EXISTS (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[DF_dna_Widgets_IsStatic]') AND type = 'D')
BEGIN
ALTER TABLE [dbo].[dna_Widgets] ADD  CONSTRAINT [DF_dna_Widgets_IsStatic]  DEFAULT ((0)) FOR [IsStatic]
END


End
GO
/****** Object:  ForeignKey [FK_Permissions_PermissionSets]    Script Date: 10/21/2010 21:20:55 ******/
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Permissions_PermissionSets]') AND parent_object_id = OBJECT_ID(N'[dbo].[dna_Permissions]'))
ALTER TABLE [dbo].[dna_Permissions]  WITH CHECK ADD  CONSTRAINT [FK_Permissions_PermissionSets] FOREIGN KEY([PermissionSetID])
REFERENCES [dbo].[dna_PermissionSets] ([ID])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Permissions_PermissionSets]') AND parent_object_id = OBJECT_ID(N'[dbo].[dna_Permissions]'))
ALTER TABLE [dbo].[dna_Permissions] CHECK CONSTRAINT [FK_Permissions_PermissionSets]
GO
/****** Object:  ForeignKey [FK_PermsInRoles_Permissions]    Script Date: 10/21/2010 21:20:55 ******/
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_PermsInRoles_Permissions]') AND parent_object_id = OBJECT_ID(N'[dbo].[dna_PermsInRoles]'))
ALTER TABLE [dbo].[dna_PermsInRoles]  WITH CHECK ADD  CONSTRAINT [FK_PermsInRoles_Permissions] FOREIGN KEY([PermID])
REFERENCES [dbo].[dna_Permissions] ([ID])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_PermsInRoles_Permissions]') AND parent_object_id = OBJECT_ID(N'[dbo].[dna_PermsInRoles]'))
ALTER TABLE [dbo].[dna_PermsInRoles] CHECK CONSTRAINT [FK_PermsInRoles_Permissions]
GO
/****** Object:  ForeignKey [FK_PermsInRoles_PermsInRoles]    Script Date: 10/21/2010 21:20:55 ******/
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_PermsInRoles_PermsInRoles]') AND parent_object_id = OBJECT_ID(N'[dbo].[dna_PermsInRoles]'))
ALTER TABLE [dbo].[dna_PermsInRoles]  WITH CHECK ADD  CONSTRAINT [FK_PermsInRoles_PermsInRoles] FOREIGN KEY([PermID], [RoleName])
REFERENCES [dbo].[dna_PermsInRoles] ([PermID], [RoleName])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_PermsInRoles_PermsInRoles]') AND parent_object_id = OBJECT_ID(N'[dbo].[dna_PermsInRoles]'))
ALTER TABLE [dbo].[dna_PermsInRoles] CHECK CONSTRAINT [FK_PermsInRoles_PermsInRoles]
GO
/****** Object:  ForeignKey [FK_dna_WebPageRoles_dna_WebPages]    Script Date: 10/21/2010 21:20:55 ******/
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_dna_WebPageRoles_dna_WebPages]') AND parent_object_id = OBJECT_ID(N'[dbo].[dna_WebPageRoles]'))
ALTER TABLE [dbo].[dna_WebPageRoles]  WITH CHECK ADD  CONSTRAINT [FK_dna_WebPageRoles_dna_WebPages] FOREIGN KEY([PageID])
REFERENCES [dbo].[dna_WebPages] ([ID])
ON DELETE CASCADE
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_dna_WebPageRoles_dna_WebPages]') AND parent_object_id = OBJECT_ID(N'[dbo].[dna_WebPageRoles]'))
ALTER TABLE [dbo].[dna_WebPageRoles] CHECK CONSTRAINT [FK_dna_WebPageRoles_dna_WebPages]
GO
/****** Object:  ForeignKey [FK_dna_Web_dna_WebPages]    Script Date: 10/21/2010 21:20:55 ******/
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_dna_Web_dna_WebPages]') AND parent_object_id = OBJECT_ID(N'[dbo].[dna_WebPages]'))
ALTER TABLE [dbo].[dna_WebPages]  WITH CHECK ADD  CONSTRAINT [FK_dna_Web_dna_WebPages] FOREIGN KEY([WebID])
REFERENCES [dbo].[dna_WebSettings] ([Id])
ON DELETE CASCADE
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_dna_Web_dna_WebPages]') AND parent_object_id = OBJECT_ID(N'[dbo].[dna_WebPages]'))
ALTER TABLE [dbo].[dna_WebPages] CHECK CONSTRAINT [FK_dna_Web_dna_WebPages]
GO
/****** Object:  ForeignKey [FK_dna_WidgetDescriptor_dna_PackageInfos]    Script Date: 10/21/2010 21:20:55 ******/
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_dna_WidgetDescriptor_dna_PackageInfos]') AND parent_object_id = OBJECT_ID(N'[dbo].[dna_WidgetDescriptors]'))
ALTER TABLE [dbo].[dna_WidgetDescriptors]  WITH CHECK ADD  CONSTRAINT [FK_dna_WidgetDescriptor_dna_PackageInfos] FOREIGN KEY([PackageID])
REFERENCES [dbo].[dna_PackageInfos] ([ID])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_dna_WidgetDescriptor_dna_PackageInfos]') AND parent_object_id = OBJECT_ID(N'[dbo].[dna_WidgetDescriptors]'))
ALTER TABLE [dbo].[dna_WidgetDescriptors] CHECK CONSTRAINT [FK_dna_WidgetDescriptor_dna_PackageInfos]
GO
/****** Object:  ForeignKey [FK_WidgetMetas_Categories]    Script Date: 10/21/2010 21:20:55 ******/
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_WidgetMetas_Categories]') AND parent_object_id = OBJECT_ID(N'[dbo].[dna_WidgetDescriptors]'))
ALTER TABLE [dbo].[dna_WidgetDescriptors]  WITH CHECK ADD  CONSTRAINT [FK_WidgetMetas_Categories] FOREIGN KEY([CatID])
REFERENCES [dbo].[dna_WidgetCategories] ([Id])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_WidgetMetas_Categories]') AND parent_object_id = OBJECT_ID(N'[dbo].[dna_WidgetDescriptors]'))
ALTER TABLE [dbo].[dna_WidgetDescriptors] CHECK CONSTRAINT [FK_WidgetMetas_Categories]
GO
/****** Object:  ForeignKey [FK_dna_Widgets_dna_WidgetDescriptors]    Script Date: 10/21/2010 21:20:55 ******/
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_dna_Widgets_dna_WidgetDescriptors]') AND parent_object_id = OBJECT_ID(N'[dbo].[dna_Widgets]'))
ALTER TABLE [dbo].[dna_Widgets]  WITH CHECK ADD  CONSTRAINT [FK_dna_Widgets_dna_WidgetDescriptors] FOREIGN KEY([DescriptorID])
REFERENCES [dbo].[dna_WidgetDescriptors] ([ID])
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_dna_Widgets_dna_WidgetDescriptors]') AND parent_object_id = OBJECT_ID(N'[dbo].[dna_Widgets]'))
ALTER TABLE [dbo].[dna_Widgets] CHECK CONSTRAINT [FK_dna_Widgets_dna_WidgetDescriptors]
GO
/****** Object:  ForeignKey [FK_Widgets_WebPages]    Script Date: 10/21/2010 21:20:55 ******/
IF NOT EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Widgets_WebPages]') AND parent_object_id = OBJECT_ID(N'[dbo].[dna_Widgets]'))
ALTER TABLE [dbo].[dna_Widgets]  WITH CHECK ADD  CONSTRAINT [FK_Widgets_WebPages] FOREIGN KEY([PageID])
REFERENCES [dbo].[dna_WebPages] ([ID])
ON DELETE CASCADE
GO
IF  EXISTS (SELECT * FROM sys.foreign_keys WHERE object_id = OBJECT_ID(N'[dbo].[FK_Widgets_WebPages]') AND parent_object_id = OBJECT_ID(N'[dbo].[dna_Widgets]'))
ALTER TABLE [dbo].[dna_Widgets] CHECK CONSTRAINT [FK_Widgets_WebPages]
GO
