﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using DNA.Mvc;
using System.Resources;
using System;

[assembly: AssemblyTitle("DotNetAge")]
[assembly: AssemblyDescription("The content management system (CMS) base on Mvc & jQuery technique.")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("DotNetAge.com")]
[assembly: AssemblyProduct("DotNetAge")]
[assembly: AssemblyCopyright("Copyright ©  2011 Ray Liang (http://www.dotnetage.com)")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: Guid("bea4120b-adc7-4e68-948f-4e46de67c8b6")]
[assembly: AssemblyVersion("2.0.0.*")]
[assembly: AssemblyFileVersion("2.0.0.*")]
[assembly: AssemblyAuthorInfo("Ray", "csharp2002@hotmail.com","http://www.dotnetage.com")]
[assembly: AssemblyLicenseInfo("GPLv2", "GNU GENERAL PUBLIC LICENSE", "http://www.gnu.org/licenses/gpl.html")]
[assembly: AssemblyLicenseInfo("MIT", "The MIT License(MIT)", "http://www.opensource.org/licenses/mit-license.php")]
[assembly: AssemblyHelpLink("HelpLink", "http://www.dotnetage.com/sites/home/lean.html")]
[assembly: AssemblyHelpLink("SupportLink", "http://www.dotnetage.com/community/forum")]
[assembly:NeutralResourcesLanguage("en-US")]
[assembly:CLSCompliant(true)]