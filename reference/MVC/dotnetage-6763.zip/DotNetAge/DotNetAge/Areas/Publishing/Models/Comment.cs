﻿//  Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.ComponentModel;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Globalization;
using System.ComponentModel.DataAnnotations;

namespace DNA.Mvc.Areas.Publishing.Models
{
    [MetadataType(typeof(CommentMeta))]
    public partial class Comment
    {
        public class CommentMeta
        {
            [Required]
            public string UserName { get; set; }
            
            [Required]
            [DataType(DataType.EmailAddress)]
            public string Email { get; set; }

            [Required]
            public string Body { get; set; }
        }
    }
}