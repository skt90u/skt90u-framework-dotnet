﻿//  Copyright (c) 2011 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;

namespace DNA.Mvc.Areas.Publishing.Models
{
    public partial class Category : IHierarchicalEnumerable,IHierarchyData
    {
        IHierarchyData IHierarchicalEnumerable.GetHierarchyData(object enumeratedItem)
        {
            return (Category)enumeratedItem;
        }

        System.Collections.IEnumerator System.Collections.IEnumerable.GetEnumerator()
        {
            var children = this.Children();
            if (children != null)
                return children.GetEnumerator();
            return null;
        }

        IHierarchicalEnumerable IHierarchyData.GetChildren()
        {
            return this;
        }

        IHierarchyData IHierarchyData.GetParent()
        {
            return this.GetParent();
        }

        bool IHierarchyData.HasChildren
        {
            get {
                return this.HasChildren();
            }
        }

        object IHierarchyData.Item
        {
            get { return this; }
        }

        string IHierarchyData.Path
        {
            get { return this.Path; }
        }

        string IHierarchyData.Type
        {
            get {
                return this.GetType().ToString();
            }
        }
    }
}