﻿//  Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using DNA.Mvc.OpenAPI.Rss;
using DNA.Mvc.OpenAPI.Atom;

namespace DNA.Mvc.Areas.Publishing.Models
{
    /// <summary>
    /// The helper class to extend the Category model
    /// </summary>
    public static class CategoryExtensions
    {
        private static IPublishing service;

        private static IPublishing Service
        {
            get
            {
                if (service == null)
                    service = WebSite.GetService<IPublishing>("Publishing");
                return service;
            }
        }

        /// <summary>
        /// Save the changes to database
        /// </summary>
        /// <param name="category">The Category object</param>
        public static void Update(this Category category)
        {
            if (category.ID > 0)
                Service.EditCategory(category);
            else
                Service.AddCategory(category.ParentID, category);
        }

        /// <summary>
        /// Delete this category
        /// </summary>
        /// <param name="category">The Category object</param>
        public static void Delete(this Category category)
        {
            Service.DeleteCategory(category.ID);
        }

        /// <summary>
        /// Move this category to new position
        /// </summary>
        /// <param name="category">The Category object</param>
        /// <param name="parentID">Specified the parent category id to move</param>
        /// <param name="position">Specified the new position to move.</param>
        public static void Move(this Category category, int parentID, int position)
        {
            Service.MoveCategory(parentID, category.ID, position);
        }

        /// <summary>
        /// Gerenate the RssChannel for this category and articles
        /// </summary>
        /// <param name="category">The Category object</param>
        /// <returns>A RssChannel object for this category</returns>
        public static RssDocument GetRssFeed(this Category category)
        {
            var doc = new RssDocument();
            var channel = new RssChannel()
            {
                Title = category.Title,
                Description = category.Description,
                Link = "",
                Generator = "DotNetAge " + System.Reflection.Assembly.GetExecutingAssembly().GetName().Version.ToString()
            };

            var children = category.GetChildrenArticles();
            channel.Items = new List<RssItem>();
            foreach (var article in children)
            {
                channel.Items.Add(new RssItem()
                {
                    Title = article.Title,
                    Author = System.Web.Security.Membership.GetUser(article.UserName).Email,
                    Description = article.Summary,
                    Link = article.GetPermaLinkUrl(),
                    PubDate = article.Posted.ToUniversalTime().ToString("r")
                });
            }
            doc.Channel = channel;
            return doc;
        }

        public static AtomFeed GetAtomFeed(this Category category)
        {
            var feed = new AtomFeed()
            {
                CopyRight = WebSite.Open().Copyright,
                Generator = new AtomGenerator()
                {
                    Text = "DotNetAge",
                    Version = System.Reflection.Assembly.GetExecutingAssembly().GetName().Version.ToString(),
                    NavigateUrl = "http://www.dotnetage.com"
                },
                Title = category.Title,
                Icon = WebContext.Current.Web.ShortcutIconUrl,
                Logo = WebContext.Current.Web.LogoImageUrl,
                Updated = category.LastPosted.HasValue ? category.LastPosted.Value : DateTime.Now
            };
            var children = category.GetChildrenArticles();

            Func<string, IEnumerable<AtomLink>> addLink = delegate(string url)
            {
                var link = new AtomLink() { NavigateUrl = url };
                var links = new List<AtomLink>();
                links.Add(link);
                return links;
            };

            Func<Article, List<AtomCategory>> populateCategories = delegate(Article article)
            {
                var atomCats = new List<AtomCategory>();
                var cats = article.GetCategories();
                foreach (var cat in cats)
                {
                    atomCats.Add(new AtomCategory()
                    {
                        Text = cat.Title,
                        Scheme = cat.GetPermalinkUrl().ToString(),
                        Term = cat.Title
                    });
                }
                return atomCats;
            };
            feed.Entries = new List<AtomEntry>();
            foreach (var article in children)
            {
                feed.Entries.Add(new AtomEntry()
                {
                    ID = article.GetPermaLinkUrl(),
                    Summary = article.Summary,
                    Categories = populateCategories.Invoke(article),
                    Published = article.Posted,
                    Title = article.Title,
                    Content = new AtomContent()
                    {
                        ContentType = "text/html",
                        Text = article.Body,
                        SourceUrl = article.GetPermaLinkUrl(),
                    },
                    Links = new List<AtomLink>(addLink.Invoke(article.GetPermaLinkUrl())),
                    Author = new AtomPersonConstruct()
                    {
                        Name = article.UserName,
                        Email = System.Web.Security.Membership.GetUser(article.UserName).Email,
                    },
                    Updated = article.LastModified,
                });
            }
            return feed;
        }

        /// <summary>
        /// Get all descendant articles of this category.
        /// </summary>
        /// <param name="category">The Category object</param>
        /// <returns>A collection contains all descendant articles of this category</returns>
        public static IEnumerable<Article> GetDescendantArticles(this Category category)
        {
            return Service.GetArticles(new SearchOption()
            {
                IncludingDescendant = true,
                CategoryID = category.ID
            });
        }

        /// <summary>
        /// Get all descendant categories of this category
        /// </summary>
        /// <param name="category">The Category object</param>
        /// <returns>A collection contains descendant categories</returns>
        public static IEnumerable<Category> GetDescendants(this Category category)
        {
            return Service.GetDescendantCategories(category.ID);
        }
        /// <summary>
        /// The helper method ensure the children article of this category has been loaded.
        /// </summary>
        /// <param name="category">The Category object</param>
        public static IEnumerable<Article> GetChildrenArticles(this Category category)
        {
            return Service.GetArticles(new SearchOption() { CategoryID = category.ID, IncludingDescendant = false });
        }

        public static IEnumerable<Article> GetChildrenArticles(this Category category, int rows)
        {
            return Service.GetArticles(new SearchOption() { CategoryID = category.ID, IncludingDescendant = false, PageIndex = 1, PageSize = rows });
        }

        public static IEnumerable<Article> GetDescendantArticles(this Category category, int rows)
        {
            return Service.GetArticles(new SearchOption() { CategoryID = category.ID, IncludingDescendant = true, PageIndex = 1, PageSize = rows });
        }

        public static int GetArticleCount(this Category category)
        {
            return Service.ArticleCount(category.ID);
        }

        public static Category FindCategory(this Category category, string path)
        {
            if (string.IsNullOrEmpty(path))
                throw new ArgumentNullException("path");
            string pathForSearch = path.ToLower();

            if (!pathForSearch.StartsWith(category.Path, StringComparison.OrdinalIgnoreCase))
            {
                if (path.StartsWith("/"))
                    pathForSearch = category.Path + path;
                else
                    pathForSearch = category.Path + "/" + path;
            }

            return Service.FindCategory(pathForSearch);
        }

        public static Uri GetPermalinkUrl(this Category category)
        {
            Uri uri = null;
            string appPath = WebContext.Current.ApplicationPath + "/publishing";
            string url = category.Path;
            string[] parts = url.Split('/');

            if (url.StartsWith("{site}", StringComparison.OrdinalIgnoreCase)) //The home site
            {
                url = appPath + "/home/category";
                if (parts.Length > 1)
                {
                    for (int i = 1; i < parts.Length; i++)
                        url = url + "/" + parts[i];
                }
            }
            else //My site.
            {
                url = appPath + "/" + parts[1] + "/category"; ///i.e : path="{blog}/ray"
                if (parts.Length > 2)
                {
                    for (int i = 2; i < parts.Length; i++)
                        url = url + "/" + parts[i];
                }
            }
           
            Uri.TryCreate(url, UriKind.Absolute, out uri);
            return uri;
        }

        /// <summary>
        /// Gets whether this category has children categories.
        /// </summary>
        /// <param name="category">The Category object</param>
        /// <returns>Boolean</returns>
        public static bool HasChildren(this Category category)
        {
            return Service.GetCategoryChildrenCount(category.ID) > 0;
        }

        /// <summary>
        /// Get recent comments of specified category id
        /// </summary>
        /// <param name="category">The Category object</param>
        /// <param name="returnRows">Specified how many rows will return</param>
        /// <returns>A collection of comment</returns>
        public static IEnumerable<Comment> GetRecentComments(this Category category, int returnRows)
        {
            return Service.GetRecentComments(category.ID, returnRows);
        }


        /// <summary>
        /// Gets whether the category has articles.
        /// </summary>
        /// <param name="category">The Category object</param>
        /// <returns>Boolean</returns>
        public static bool HasArticles(this Category category)
        {
            return category.GetArticleCount() > 0;
        }

        /// <summary>
        /// Gets the descendant categories of this category.
        /// </summary>
        /// <param name="category">The Category object</param>
        /// <returns>A collection contains all descendant categories of this category</returns>
        public static IEnumerable<Category> Descendants(this Category category)
        {
            return Service.GetDescendantCategories(category.ID);
        }

        /// <summary>
        /// Get children category of this category.
        /// </summary>
        /// <param name="category">The Category object</param>
        /// <returns>A collection contains the children category of this category</returns>
        public static IEnumerable<Category> Children(this Category category)
        {
            return Service.GetCategories(category.ID);
        }

        /// <summary>
        /// Gets the recent articles of this category.This method will search all descendant article of this 
        /// category.
        /// </summary>
        /// <param name="category">The Category object</param>
        /// <param name="rows">Specified how many rows will be return</param>
        /// <returns>A article collection for recent posts.</returns>
        public static IEnumerable<Article> GetRecentArticles(this Category category, int rows)
        {
            return Service.GetArticles(new SearchOption()
            {
                IncludingDescendant = true,
                CategoryID = category.ID,
                Sortby = ArticleSorts.PostDate,
                SortOrder = ArticleOrders.Desc,
                PageIndex = 1,
                PageSize = rows
            });
        }

        public static Category GetParent(this Category category)
        {
            return Service.GetCategory(category.ParentID);
        }

        public static IEnumerable<Article> GetPublicRecentArticles(this Category category, int rows)
        {
            return Service.GetArticles(new SearchOption()
            {
                IncludingDescendant = true,
                CategoryID = category.ID,
                Sortby = ArticleSorts.PostDate,
                SortOrder = ArticleOrders.Desc,
                IsPrivate=false,
                PageIndex = 1,
                PageSize = rows
            });
        }

        /// <summary>
        /// Get the articles belongs this category with paging options.
        /// </summary>
        /// <param name="category">The Category object</param>
        /// <param name="pageIndex">Specified the page index (1 base)</param>
        /// <param name="pageSize">Specified the page size</param>
        /// <param name="totalRecords">The total article count.</param>
        /// <returns>A article collection for paging</returns>
        public static IEnumerable<Article> GetChildrenArticles(this Category category, int pageIndex, int pageSize, out int totalRecords)
        {
            var options = new SearchOption()
            {
                CategoryID = category.ID,
                IncludingDescendant = false,
                PageIndex = pageIndex,
                PageSize = pageSize,
                Sortby = ArticleSorts.PostDate,
                SortOrder = ArticleOrders.Desc
            };
            var articles = Service.GetArticles(options);
            totalRecords = options.TotalRecords.Value;
            return articles;
        }


        /// <summary>
        /// Add sub category to this category
        /// </summary>
        /// <param name="web">The Category object</param>
        /// <param name="category">The new category object</param>
        public static Category AddChildren(this Category category, Category child)
        {
            return Service.AddCategory(category.ID, child);
        }

        /// <summary>
        /// Create an article for this category.
        /// </summary>
        /// <param name="category">The Category object</param>
        /// <param name="article">The article object to create.</param>
        /// <returns>A an article which has been created.</returns>
        public static Article CreateArticle(this Category category, Article article)
        {
            if (article == null)
                throw new ArgumentNullException("article");
            article.CategoryID = category.ID;
            article.Update();
            return Service.GetArticle(article.ID);
            //return Service.NewArticle(article);
        }

        /// <summary>
        /// Get article by sepcified article id.
        /// </summary>
        /// <param name="category">The Category object</param>
        /// <param name="id">Specified the aticle id</param>
        /// <returns>A article instance.</returns>
        public static Article FindArticle(this Category category, int id)
        {
            if (id <= 0)
                throw new ArgumentOutOfRangeException("id");
            return Service.GetArticle(id);
        }

        /// <summary>
        /// Gets whether this category is root category.
        /// </summary>
        /// <param name="category">The Category object</param>
        /// <returns>Boolean</returns>
        public static bool IsRoot(this Category category)
        {
            return category.ParentID == 0;
        }
    }
}