﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using DNA.Mvc.Text;
using System.Globalization;
using System.Web.Security;
using System.ComponentModel.DataAnnotations;

namespace DNA.Mvc.Areas.Publishing.Models
{
    [MetadataType(typeof(ArticleMeta))]
    public partial class Article
    {
        private GlobalizationContent _content = null;
        private Uri _permalinkUrl = null;

        /// <summary>
        /// Gets the globalization content.
        /// </summary>
        /// <returns></returns>
        public GlobalizationContent GetGlobalizationContent()
        {
            return GetGlobalizationContent(HtmlUIExtensions.GetCultureInfo());
        }

        /// <summary>
        /// Gets the globalization content by specified CultureInfo.
        /// </summary>
        /// <param name="culture">The cultureinfo.</param>
        /// <returns></returns>
        public GlobalizationContent GetGlobalizationContent(CultureInfo culture)
        {
            if (_content == null)
                _content = new GlobalizationContent();
            else
            {
                if (_content.Culture.Equals(culture))
                    return _content;
            }

            if (culture.Name != this.Language)
            {
                // if (!this.TranslatedCopies.IsLoaded) this.TranslatedCopies.Load();
                var copy = this.GetTranslatedCopy(culture.Name);
                //this.TranslatedCopies.FirstOrDefault(t => t.Language == culture.Name);
                if (copy != null)
                {
                    _content.Culture = culture;
                    _content.Title = copy.Title;
                    _content.Summary = copy.Summary;
                    _content.Body = copy.Body;
                    return _content;
                }
            }

            _content.Title = this.Title;
            _content.Summary = this.Summary;
            _content.Body = this.Body;
            _content.Culture = culture;
            return _content;
        }

        /// <summary>
        /// Gets the article author object.
        /// </summary>
        public MembershipUser Author
        {
            get
            {
                return Membership.GetUser(UserName);
            }
        }

        /// <summary>
        /// Gets the permalink url of the article.
        /// </summary>
        public Uri PermalinkUrl
        {
            get
            {
                if (_permalinkUrl == null)
                    Uri.TryCreate(this.GetPermaLinkUrl(), UriKind.Absolute, out _permalinkUrl);

                return _permalinkUrl;
            }
        }

        public class ArticleMeta
        {
            [Required(ErrorMessage="The title field is required")]
            [StringLength(1024,MinimumLength=6,ErrorMessage="Your article title is too short,please supply the title over 6 charaters.")]
            public string Title { get; set; }

            [Required(ErrorMessage="The body field is required.")]
            public string Body { get; set; }
        }
    }
    
    public class GlobalizationContent
    {
        /// <summary>
        /// Gets/Sets the culture to use.
        /// </summary>
        public CultureInfo Culture { get; set; }
        
        /// <summary>
        ///  Gets/Sets the globalization content title.
        /// </summary>
        public string Title { get; set; }

        /// <summary>
        /// Gets/Sets the globalization content summary.
        /// </summary>
        public string Summary { get; set; }

        /// <summary>
        /// Gets/Sets the globalization content body.
        /// </summary>
        public string Body { get; set; }
    }
}
