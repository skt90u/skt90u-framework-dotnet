﻿//  Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using DNA.Mvc.Text;
using DNA.Mvc.jQuery;
using System.Web.Mvc;
using System.Data.EntityClient;
using System.Data.Objects;

namespace DNA.Mvc.Areas.Publishing.Models
{
    /// <summary>
    /// Implatement the IPublishing 
    /// </summary>
    public class PublishingService : IPublishing
    {
        // private static EntityConnection entityConnection;
        private static readonly Func<PubDBEntities, int, Category> s_compiledGetCategory = CompiledQuery.Compile<PubDBEntities, int, Category>((db, id) => (from Category cat in db.Categories where cat.ID == id select cat).SingleOrDefault());
        private static readonly Func<PubDBEntities, int, IEnumerable<Category>> s_compiledGetCategories = CompiledQuery.Compile<PubDBEntities, int, IEnumerable<Category>>((db, parentID) => (from Category cat in db.Categories where cat.ParentID == parentID select cat));
        private static readonly Func<PubDBEntities, int, Article> s_compiledGetArticle = CompiledQuery.Compile<PubDBEntities, int, Article>((db, id) => (from Article art in db.Articles where art.ID == id select art).SingleOrDefault());
        private static readonly Func<PubDBEntities, string, Article> s_compiledGetArticleByPermalink = CompiledQuery.Compile<PubDBEntities, string, Article>((db, permalink) => (from a in db.Articles where a.PermaLink.Equals(permalink, StringComparison.OrdinalIgnoreCase) select a).FirstOrDefault());
        private static readonly Func<PubDBEntities, int, int> s_compiledGetCategoryChildrenCount = CompiledQuery.Compile<PubDBEntities, int, int>((db, categoryID) => (from cat in db.Categories where cat.ParentID == categoryID select cat.ID).Count());
        private static readonly Func<PubDBEntities, int, string, TranslatedCopy> s_compiledGetTranslatedCopy = CompiledQuery.Compile<PubDBEntities, int, string, TranslatedCopy>((db, articleID, lang) => (from t in db.TranslatedCopies where t.ArticleID == articleID && t.Language.Equals(lang, StringComparison.OrdinalIgnoreCase) select t).SingleOrDefault());
        private static readonly Func<PubDBEntities, int, IEnumerable<TranslatedCopy>> s_compiledGetTranslatedCopies = CompiledQuery.Compile<PubDBEntities, int, IEnumerable<TranslatedCopy>>((db, articleID) => (from t in db.TranslatedCopies where t.ArticleID == articleID select t));
        private static readonly Func<PubDBEntities, int, IEnumerable<Comment>> s_compiledGetComments = CompiledQuery.Compile<PubDBEntities, int, IEnumerable<Comment>>((db, articleID) => (from c in db.Comments where c.ArticleID == articleID select c));
        private static readonly Func<PubDBEntities, int, int> s_compiledGetTotalComments = CompiledQuery.Compile<PubDBEntities, int, int>((db, articleID) => (from c in db.Comments where c.ArticleID == articleID select c.ID).Count());
        private IList<Category> _rootCategories;

        private static readonly Func<PubDBEntities, int, int> s_compiledArticleCount =
            CompiledQuery.Compile<PubDBEntities, int, int>((db, categoyID) => ((from a in db.Articles where a.CategoryID == categoyID select a.ID).Count()));

        public int ArticleCount(int categoyID)
        {
            using (var db = ConnMan.Instance())
            {
                return s_compiledArticleCount.Invoke(db, categoyID);
            }
        }

        public IEnumerable<Article> GetArticles(int[] articlesIDs)
        {
            if (articlesIDs == null)
                throw new ArgumentNullException("articlesIDs");

            if (articlesIDs.Length == 0)
                throw new ArgumentOutOfRangeException("articlesIDs");

            using (var db = ConnMan.Instance())
            {
                return (from a in db.Articles
                        where articlesIDs.Contains(a.ID) &&
                        a.IsPublished && (!a.IsPrivate)
                        select a).ToList();
            }
        }

        /// <summary>
        /// Get the blogs of the sites
        /// </summary>
        /// <param name="returnRows">Specified how many rows will be return</param>
        /// <returns>A collection contains blog instances</returns>
        public IEnumerable<Blog> GetBlogs(int returnRows)
        {
            using (var db = ConnMan.Instance())
            {
                //IEnumerable<Category> cats;
                //if (returnRows > 0)
                //    cats = db.Categories
                //                                 .Where(c => c.ParentID == Blogger.ID)
                //                                 .OrderByDescending(b => b.TotalPosts)
                //                                 .Take(returnRows);
                //else
                //    cats = db.Categories
                //                                 .Where(c => c.ParentID == Blogger.ID)
                //                                 .OrderByDescending(b => b.TotalPosts);
                var _users = from a in db.Articles
                             where !a.PermaLink.StartsWith("/home")
                             group a by a.UserName into g
                             orderby g.Sum(a => a.Reads) descending, g.Count() descending
                             select new
                             {
                                 name = g.Key,
                                 count = g.Count(),
                                 reads = g.Sum(a => a.Reads)
                             };

                if (returnRows > 0)
                    _users = _users.Take(returnRows);

                var blogs = new List<Blog>();
                foreach (var user in _users)
                    blogs.Add(new Blog(user.name));
                return blogs;
            }
        }

        #region Article methods

        public void Translate(TranslatedCopy copy)
        {
            if (copy.ArticleID <= 0)
                throw new ArgumentOutOfRangeException("TranslatedCopy.ArticleID");

            using (var db = ConnMan.Instance())
            {
                var article = s_compiledGetArticle.Invoke(db, copy.ArticleID);

                if (article == null)
                    throw new ArgumentNullException("Article not found");

                db.TranslatedCopies.AddObject(copy);
                db.SaveChanges();
            }
        }

        public void EditTranslatedCopy(TranslatedCopy copy)
        {
            using (var db = ConnMan.Instance())
            {
                var orginal = db.TranslatedCopies.SingleOrDefault(t => t.ID == copy.ID);
                db.TranslatedCopies.ApplyCurrentValues(copy);
                db.SaveChanges();
            }
        }

        public TranslatedCopy GetTranslatedCopy(int articleID, string lang)
        {
            using (var db = ConnMan.Instance())
            {
                return s_compiledGetTranslatedCopy.Invoke(db, articleID, lang);
            }
        }

        public IEnumerable<TranslatedCopy> GetTranslatedCopies(int articleID)
        {
            using (var db = ConnMan.Instance())
            {
                return s_compiledGetTranslatedCopies(db, articleID);
            }
        }

        public Track AddTrack(Track track)
        {
            using (var db = ConnMan.Instance())
            {
                try
                {
                    var article = s_compiledGetArticle.Invoke(db, track.ArticleID);
                    if (article == null) throw new ArgumentOutOfRangeException("Track.ArticleID =" + track.ID + " not exists");
                    article.Reads = compiedGetTotalReads.Invoke(db, article.ID) + 1;
                    db.Tracks.AddObject(track);
                    db.SaveChanges();
                    return track;
                }
                catch { return null; }
            }
        }

        private static readonly Func<PubDBEntities, int, IEnumerable<Track>> compiledGetTracks =
            CompiledQuery.Compile<PubDBEntities, int, IEnumerable<Track>>((db, articleID) => (from t in db.Tracks where t.ArticleID == articleID select t));
        private static readonly Func<PubDBEntities, int, int> compiedGetTotalReads =
            CompiledQuery.Compile<PubDBEntities, int, int>((db, articleID) => (from t in db.Tracks where t.ArticleID == articleID select t).Count());

        public IEnumerable<Track> GetTracks(int articleID, DateTime start, DateTime end)
        {
            using (var db = ConnMan.Instance())
            {
                var tracks = compiledGetTracks.Invoke(db, articleID);
                tracks = tracks.Where(t => (t.HasRead > start && t.HasRead < end));
                return tracks.ToList();
            }
        }

        public int GetArticleTotalReads(int articleID)
        {
            using (var db = ConnMan.Instance())
            {
                return compiedGetTotalReads(db, articleID);
            }
        }

        /// <summary>
        /// Movet the article to new position or attach to another parent category.
        /// </summary>
        /// <param name="articleID">Specified the article id which to move.</param>
        /// <param name="pos">Specified the new position to move to.</param>
        /// <param name="categoryID">Specified the parent category id of the article.</param>
        public void Move(int articleID, int pos, int categoryID)
        {
            using (var db = ConnMan.Instance())
            {
                var article = s_compiledGetArticle(db, articleID);
                var articles = (from a in db.Articles
                                where a.CategoryID == article.CategoryID && a.ID != article.ID
                                orderby a.Pos
                                select a);

                if ((article.CategoryID == categoryID) || (categoryID == -1))
                {
                    if (article.Pos == pos)
                        return;

                    if (pos == 0)
                    {
                        if (articles.Count() > 0)
                        {
                            article.Pos = 0;
                            foreach (var a in articles)
                                a.Pos++;
                            db.SaveChanges();
                        }
                    }
                    else
                    {
                        var alist = articles.ToList();
                        var j = pos;
                        while (j < alist.Count)
                        {
                            alist[j].Pos++;
                            db.Articles.ApplyCurrentValues(alist[j]);
                            j++;
                        }
                        article.Pos = pos + 1;
                        db.SaveChanges();
                    }
                }
                else
                {
                    var alist = articles.ToList();
                    for (int i = 0; i < alist.Count; i++)
                        alist[i].Pos = i;
                    var count = db.Articles.Count(a => a.CategoryID == categoryID);
                    article.CategoryID = categoryID;
                    article.Pos = count;
                    db.SaveChanges();
                }
            }
        }

        /// <summary>
        /// Vote the specified article.
        /// </summary>
        /// <param name="articleID">Specified the article id to vote.</param>
        /// <param name="value">Specified the rating value.</param>
        /// <param name="totalRatings"></param>
        /// <returns></returns>
        public double Rating(int articleID, int value, out int totalRatings)
        {
            using (var db = ConnMan.Instance())
            {
                Article article = s_compiledGetArticle(db, articleID);
                article.Ratings.Load();
                Ratings rating = article.Ratings.FirstOrDefault(r => r.IP == HttpContext.Current.Request.UserHostAddress);
                if (rating != null)
                {
                    totalRatings = article.TotalRatings;
                    return article.Rating;
                }
                else
                {
                    rating = new Ratings()
                    {
                        IP = HttpContext.Current.Request.UserHostAddress,
                        Rating = value
                    };
                    article.Ratings.Add(rating);
                    db.SaveChanges();
                    double avg = (from r in article.Ratings select r.Rating).Average();
                    article.Rating = avg;
                    article.TotalRatings++;
                    db.SaveChanges();
                    totalRatings = article.TotalRatings;
                    return avg;
                }
            }
        }

        /// <summary>
        /// Search the articles by specified SearchOption object
        /// </summary>
        /// <param name="option">Specified the search options.</param>
        /// <returns>A collection contains the article search result</returns>
        public IEnumerable<Article> GetArticles(SearchOption option)
        {
            using (var db = ConnMan.Instance())
            {
                IQueryable<Article> query = db.Articles.AsQueryable<Article>();

                if (option.CategoryID.HasValue)
                {
                    if (option.IncludingDescendant)
                    {
                        var descendant = GetDescendantCategories(option.CategoryID.Value);
                        if (descendant.Count() > 0)
                        {
                            var _ids = descendant.Select(d => d.ID).ToList();
                            _ids.Add(option.CategoryID.Value);
                            var ids = _ids.ToArray();
                            query = query.Where(a => ids.Contains(a.CategoryID));
                        }
                        else
                            query = query.Where(a => a.CategoryID == option.CategoryID.Value);
                    }
                    else
                    {
                        query = query.Where(a => a.CategoryID == option.CategoryID.Value);
                    }
                }

                if (option.IsPublished.HasValue)
                    query = query.Where(a => a.IsPublished == option.IsPublished.Value);

                if (option.IsAppoved.HasValue)
                    query = query.Where(a => a.IsAppoved == option.IsAppoved.Value);
                
                if (option.IsPrivate.HasValue)
                    query = query.Where(a => a.IsPrivate == option.IsPrivate.Value);

                if (!string.IsNullOrEmpty(option.SearchText))
                    query = query.Where(a => (a.Title.Contains(option.SearchText) || a.Summary.Contains(option.SearchText) || a.Body.Contains(option.SearchText) || a.Tags.Contains(option.SearchText)));

                if (!string.IsNullOrEmpty(option.Archive))
                {
                    var archive = option.GetArchive();
                    if (archive != null)
                        query = query.Where(a => ((a.Posted.Year == archive.Year) && (a.Posted.Month == archive.Month)));
                }

                if (!string.IsNullOrEmpty(option.TagName))
                    query = query.Where(a => (a.Title.Contains(option.TagName) || a.Summary.Contains(option.TagName) || a.Body.Contains(option.TagName) || a.Tags.Contains(option.TagName)));

                switch (option.Sortby)
                {
                    case ArticleSorts.PostDate:
                        if (option.SortOrder == ArticleOrders.Asc)
                            query = query.OrderBy(a => a.Posted);
                        else
                            query = query.OrderByDescending(a => a.Posted);
                        break;
                    case ArticleSorts.Ratings:
                        if (option.SortOrder == ArticleOrders.Asc)
                            query = query.OrderBy(a => a.Rating);
                        else
                            query = query.OrderByDescending(a => a.Rating);
                        break;
                    case ArticleSorts.Reads:
                        if (option.SortOrder == ArticleOrders.Asc)
                            query = query.OrderBy(a => a.Reads);
                        else
                            query = query.OrderByDescending(a => a.Reads);
                        break;
                    case ArticleSorts.Position:
                        if (option.SortOrder == ArticleOrders.Asc)
                            query = query.OrderBy(a => a.Pos);
                        else
                            query = query.OrderByDescending(a => a.Pos);
                        break;
                }


                if (option.PageIndex.HasValue && option.PageSize.HasValue)
                {
                    int pageIndex = option.PageIndex.HasValue ? option.PageIndex.Value : 1;
                    int pageSize = option.PageSize.HasValue ? option.PageSize.Value : 20;
                    option.TotalRecords = query.Select(a => a.ID).Count();
                    query = query.Skip((pageIndex - 1) * pageSize).Take(pageSize);
                }

                return query.ToList();
            }
        }

        /// <summary>
        /// Gets the category children count
        /// </summary>
        /// <param name="categoryID">Specified the category id.</param>
        /// <returns>Total children category count</returns>
        public int GetCategoryChildrenCount(int categoryID)
        {
            using (var db = ConnMan.Instance())
            {
                return s_compiledGetCategoryChildrenCount.Invoke(db, categoryID);
            }
        }

        private static readonly Func<PubDBEntities, int, int> s_ArticleCountOfCategory = CompiledQuery.Compile<PubDBEntities, int, int>((db, catID) => (from a in db.Articles where a.CategoryID == catID select a.ID).Count());
        private static readonly Func<PubDBEntities, int, int> s_GetArticlePosition = CompiledQuery.Compile<PubDBEntities, int, int>((db, catID) => (from a in db.Articles where a.CategoryID == catID select a.Pos).Max());

        /// <summary>
        /// Create a new article 
        /// </summary>
        /// <param name="article">Specified a new article object.</param>
        /// <returns>The article has been saved.</returns>
        public Article NewArticle(Article article)
        {
            if (article.CategoryID <= 0)
                throw new ArgumentOutOfRangeException("article.CategoryID");

            using (var db = ConnMan.Instance())
            {
                Category cat = s_compiledGetCategory(db, article.CategoryID);

                if (cat == null)
                    throw new ArgumentNullException("category not found.");

                string userName = HttpContext.Current.User.Identity.Name;

                if (string.IsNullOrEmpty(article.UserName))
                    article.UserName = userName;

                article.LastModified = DateTime.Now;
                int _count = s_ArticleCountOfCategory.Invoke(db, cat.ID);

                //int pos = cat.Articles.Count == 0 ? -1 : cat.Articles.Max(a => a.Pos);
                int pos = _count == 0 ? 0 : s_GetArticlePosition.Invoke(db, cat.ID);

                if (string.IsNullOrEmpty(article.Slug))
                    article.Slug = TextUtility.Slug(article.Title);

                article.Posted = DateTime.Now;
                article.Version = 0;
                article.Rating = 0;
                article.Reads = 0;
                article.Pos = pos;

                cat.TotalPosts = cat.GetArticleCount() + 1;
                db.Articles.AddObject(article);
                db.SaveChanges();

                if (cat.ArticleType.Value == (int)ArticleTypes.Personal)
                    EnsuarePermaLink(article.UserName, article);
                else
                    EnsuarePermaLink("", article);

                db.SaveChanges();
                return article;
            }
        }

        private void EnsuarePermaLink(string webName, Article article)
        {
            if (string.IsNullOrEmpty(article.PermaLink))
            {
                string formattedTitle = article.Slug;
                // TextUtility.Slug(article.Title);
                string dateStr = article.Posted.ToString("yyyy/MM/dd");
                article.PermaLink = "/" + (string.IsNullOrEmpty(webName) ? "home" : webName) + "/" + dateStr + "/" + article.ID.ToString() + "/" + formattedTitle + ".html";
            }
        }

        /// <summary>
        /// Apply the changes to database by specified the article object.
        /// </summary>
        /// <param name="article">Specified the article object contains the changes.</param>
        /// <returns>Boolean</returns>
        public bool EditArticle(Article article)
        {
            using (var db = ConnMan.Instance())
            {
                article.LastModified = DateTime.Now;
                var orignal = s_compiledGetArticle(db, article.ID);
                Category cat = s_compiledGetCategory(db, article.CategoryID);

                if (string.IsNullOrEmpty(article.Slug))
                    article.Slug = TextUtility.Slug(article.Title);

                if (cat.ArticleType.Value == (int)ArticleTypes.Personal)
                    EnsuarePermaLink(article.UserName, article);
                else
                    EnsuarePermaLink("", article);



                if (cat.EnableVersioning)
                {
                    article.Version++;
                    History version = new History()
                    {
                        Version = article.Version,
                        Body = article.Body,
                        LastModified = DateTime.Now,
                        Modified = HttpContext.Current.User.Identity.Name
                    };
                    article.Versions.Add(version);
                }
                article.TotalComments = s_compiledGetTotalComments(db, article.ID);
                db.Articles.ApplyCurrentValues(article);
                db.SaveChanges();
                return true;
            }
        }

        /// <summary>
        /// Get the article by specified id.
        /// </summary>
        /// <param name="id">Specified the article id.</param>
        /// <returns>An article instance or null</returns>
        public Article GetArticle(int id)
        {
            using (var db = ConnMan.Instance())
            {
                var article = s_compiledGetArticle.Invoke(db, id);
                if (article != null)
                {
                    if (!article.CategoryReference.IsLoaded) article.CategoryReference.Load();
                    return article;
                }
                return null;
            }
        }

        public Article GetArticleByPermalink(Uri url)
        {
            using (var db = ConnMan.Instance())
            {
                string path = url.LocalPath.ToLower().Replace("/publishing", "");
                var article = s_compiledGetArticleByPermalink.Invoke(db, path);
                return article;
            }
        }

        /// <summary>
        /// Delete the article by specified article id.
        /// </summary>
        /// <param name="id">Specified the article id to delete</param>
        public void DeleteArticle(int id)
        {
            using (var db = ConnMan.Instance())
            {
                Article article = s_compiledGetArticle.Invoke(db, id);
                var parentCat = s_compiledGetCategory.Invoke(db, article.CategoryID);
                parentCat.TotalPosts--;
                db.DeleteObject(article);
                db.SaveChanges();
            }
        }

        public IEnumerable<Archive> GetArchives(int categoryID)
        {
            using (var db = ConnMan.Instance())
            {
                var cats = GetDescendantCategories(categoryID).ToList();
                cats.Add(s_compiledGetCategory(db, categoryID));
                var catKeys = cats.Select(c => c.ID);
                var _archives = (from a in db.Articles
                                 where catKeys.Contains(a.CategoryID)
                                 select new Archive()
                                 {
                                     Year = a.Posted.Year,
                                     Month = a.Posted.Month
                                 })
                                 .Distinct()
                                 .ToList();
                return _archives;
            }
        }

        public IEnumerable<Tag> GetTags(int categoryID, out int count)
        {
            using (var db = ConnMan.Instance())
            {
                var cats = GetDescendantCategories(categoryID).ToList();
                cats.Add(s_compiledGetCategory(db, categoryID));
                var catKeys = cats.Select(c => c.ID);

                var tagStr = db.Articles.Where(a => (!string.IsNullOrEmpty(a.Tags) && catKeys.Contains(a.CategoryID)))
                                                    .Select(a => a.Tags)
                                                    .ToArray();
                string fullTags = "";
                if (tagStr.Length > 0)
                    fullTags = string.Join(",", tagStr);
                var tagArgs = fullTags.Split(new char[] { ',' });
                var tagList = new List<Tag>();

                foreach (var tag in tagArgs)
                {
                    var _tag = tagList.FirstOrDefault(t => t.Name.Equals(tag, StringComparison.OrdinalIgnoreCase));
                    if (_tag == null)
                        tagList.Add(new Tag() { Name = tag, Count = 1 });
                    else
                        _tag.Count++;
                }
                count = tagStr.Length;
                return tagList;
            }
        }

        /// <summary>
        /// Create and comment object.
        /// </summary>
        /// <param name="comment">The new comment object</param>
        public void AddComment(Comment comment)
        {
            using (var db = ConnMan.Instance())
            {
                Article article = s_compiledGetArticle.Invoke(db, comment.ArticleID);

                if (article == null)
                    throw new ArgumentOutOfRangeException("comment.ArticleID");

                comment.Posted = DateTime.Now;
                db.Comments.AddObject(comment);
                article.TotalComments = article.Comments.Count();
                db.SaveChanges();
            }
        }

        public IEnumerable<Comment> GetComments(int articleID)
        {
            if (articleID <= 0)
                throw new ArgumentOutOfRangeException("articleID");

            using (var db = ConnMan.Instance())
            {
                return s_compiledGetComments.Invoke(db, articleID).ToList();
            }
        }

        /// <summary>
        /// Get recent comments of specified category id
        /// </summary>
        ///<param name="categoryID">Specified the parent category id.</param>
        /// <param name="returnRows">Specified how many rows will return</param>
        /// <returns>A collection of comment</returns>
        public IEnumerable<Comment> GetRecentComments(int categoryID, int returnRows)
        {
            using (var db = ConnMan.Instance())
            {
                var articles = GetArticles(new SearchOption() { IncludingDescendant = true, CategoryID = categoryID });
                if (articles != null)
                {
                    var ids = articles.Select(a => a.ID).ToArray();
                    return db.Comments.Where(c => ids.Contains(c.ArticleID)).OrderByDescending(c => c.Posted).Take(returnRows).ToList();
                }
                return new List<Comment>();
            }
        }

        #endregion

        #region Category Members

        public IEnumerable<Category> GetDescendantCategories(int categoryID)
        {
            using (var db = ConnMan.Instance())
            {
                var allCats = db.Categories.ToList();
                var result = new List<Category>();
                var rootCat = allCats.Single(c => c.ID == categoryID);
                if (rootCat == null)
                    throw new ArgumentOutOfRangeException("categoryID");
                GetCategoryRecursive(allCats, result, rootCat.ID);
                return result;
            }
        }

        private void GetCategoryRecursive(List<Category> source, List<Category> container, int cid)
        {
            var children = source.Where(c => c.ParentID == cid);
            foreach (var c in children)
            {
                GetCategoryRecursive(source, container, c.ID);
                container.Add(c);
            }
        }

        /// <summary>
        /// Get the category for web
        /// </summary>
        /// <remarks>In DNA every web has their web category</remarks>
        /// <param name="name">Specified the web name</param>
        /// <returns>A category object of web</returns>
        public Category GetWebCategory(string name)
        {
            if (name.Equals("home", StringComparison.OrdinalIgnoreCase))
                return Site;
            else
                return Blogger.Children().SingleOrDefault(c => c.Title.Equals(name, StringComparison.OrdinalIgnoreCase));
        }

        /// <summary>
        /// Delete the category  by specified id.
        /// </summary>
        /// <param name="id">Specified the category id.</param>
        public void DeleteCategory(int id)
        {
            using (var db = ConnMan.Instance())
            {
                Category cat = s_compiledGetCategory.Invoke(db, id);
                db.DeleteObject(cat);
                var children = s_compiledGetCategories(db, id);
                if (children.Count() > 0)
                {
                    foreach (var c in children)
                    {
                        c.ParentID = 0;
                        c.Pos = c.Pos + 2000;
                    }
                    Reindex(0);
                }
                db.SaveChanges();
            }
        }

        /// <summary>
        /// Move the category to a new position.
        /// </summary>
        /// <param name="parentID">Specified the parent category id to move to.</param>
        /// <param name="id">Specified the category id to be move.</param>
        /// <param name="pos">Specified the new position to move to.</param>
        public void MoveCategory(int parentID, int id, int pos)
        {
            using (var db = ConnMan.Instance())
            {
                var cat = s_compiledGetCategory.Invoke(db, id);// DataEntities.Categories.FirstOrDefault(f => f.ID == id);
                if (cat == null)
                    throw new ArgumentNullException("Category not found");
                if ((parentID < 1) || (cat.ParentID == parentID))
                {
                    int _from = cat.Pos;
                    int _to = pos;

                    if ((_to != 0) && (_from != 0))  //move up
                    {
                        cat.Pos = _to;
                        var target = (from t in db.Categories
                                      where (t.ParentID == cat.ParentID) && (t.Pos == pos)
                                      select t).FirstOrDefault();

                        //If the target is null that means the node is drag to root
                        if (target != null)
                            target.Pos = _from;
                        db.SaveChanges();

                        Reindex(cat.ParentID);
                        return;
                    }

                    if (_to == 0)
                    {
                        cat.Pos = 0;
                        var targets = (from t in db.Categories
                                       where (t.ParentID == cat.ParentID) && (t.ID != id)
                                       select t);
                        foreach (var w in targets)
                            w.Pos++;
                        db.SaveChanges();
                        Reindex(cat.ParentID);
                        return;
                    }

                    if (_from == 0)
                    {
                        cat.Pos = _to;
                        var targets = (from t in db.Categories
                                       where (t.ParentID == cat.ParentID) && (t.ID != id)
                                       select t);
                        foreach (var w in targets)
                            w.Pos--;
                        db.SaveChanges();
                        Reindex(cat.ParentID);
                        return;
                    }
                }

                if (cat.ParentID != parentID)
                {
                    int orgParent = cat.ParentID;
                    cat.Pos = pos;
                    cat.ParentID = parentID;
                    db.SaveChanges();

                    Reindex(orgParent);

                    var ws = (from w in db.Categories
                              where ((w.ParentID == parentID) && (w.ID != id) && (w.Pos >= pos))
                              orderby w.Pos
                              select w).ToList();

                    if (ws.Count > 0)
                    {
                        foreach (var _nw in ws)
                            _nw.Pos++;
                        db.SaveChanges();
                    }

                    Reindex(parentID);
                }
            }
        }

        /// <summary>
        /// Gets the category by specified category id .
        /// </summary>
        /// <param name="id">Specified the category id .</param>
        /// <returns>A category instance.</returns>
        public Category GetCategory(int id)
        {
            using (var db = ConnMan.Instance())
            {
                return s_compiledGetCategory.Invoke(db, id);
            }
        }

        /// <summary>
        /// Create a category 
        /// </summary>
        /// <param name="parentID">Specified the category parent id.</param>
        /// <param name="category">Specified the category instance.</param>
        public Category AddCategory(int parentID, Category category)
        {
            if (parentID <= 0)
                throw new ArgumentOutOfRangeException("parentID must > 0");

            using (var db = ConnMan.Instance())
            {
                var parent = s_compiledGetCategory.Invoke(db, parentID);// GetCategory(parentID);
                category.ParentID = parentID;
                string _slug = TextUtility.Slug(category.Title);

                if (parent != null)
                {
                    category.Path = parent.Path + "/" + _slug;
                    if (!category.ArticleType.HasValue)
                        category.ArticleType = (int)parent.ArticleType;
                }

                if (parent != null)
                {
                    var count = s_compiledGetCategoryChildrenCount(db, parentID);

                    if (count > 0)
                        category.Pos = s_compiledGetCategoryPos.Invoke(db, parentID) + 1;
                    //category.Pos = db.Categories.Where(c => c.ParentID == parentID).Select(c => c.Pos).Max() + 1;
                    else
                        category.Pos = 0;
                }
                else
                {
                    if (db.Categories.Count() > 0)
                        category.Pos = s_compiledGetCategoryPos.Invoke(db, 0) + 1;
                    // db.Categories.Where(c => c.ParentID == 0).Select(c => c.Pos).Max() + 1;
                    else
                        category.Pos = 0;
                }
                db.Categories.AddObject(category);
                db.SaveChanges();
                return category;
            }
        }
        private static readonly Func<PubDBEntities, int, int> s_compiledGetCategoryPos = CompiledQuery.Compile<PubDBEntities, int, int>((db, catID) => (from c in db.Categories where c.ParentID == catID select c.Pos).Max());
        private static readonly Func<PubDBEntities, string, Category> s_compiledFindCategory = CompiledQuery.Compile<PubDBEntities, string, Category>((db, path) => (from c in db.Categories where c.Path.Equals(path, StringComparison.OrdinalIgnoreCase) select c).FirstOrDefault());

        public Category FindCategory(string path)
        {
            if (string.IsNullOrEmpty(path))
                throw new ArgumentNullException("path");

            using (var db = ConnMan.Instance())
            {
                return s_compiledFindCategory.Invoke(db, path);
            }
        }

        /// <summary>
        /// Save the changes of the specified category.
        /// </summary>
        /// <param name="category">Specified the categoty instance to save.</param>
        public void EditCategory(Category category)
        {
            if (category == null)
                throw new ArgumentNullException("category");

            using (var db = ConnMan.Instance())
            {
                var original = s_compiledGetCategory(db, category.ID);
                if (original != null)
                {
                    db.Categories.ApplyCurrentValues(category);
                    db.SaveChanges();
                }
            }
        }

        /// <summary>
        /// Gets the categories of specified parent category id.
        /// </summary>
        /// <param name="parentID">Specified the parent category id.</param>
        /// <returns>A collection of the category instances.</returns>
        public IEnumerable<Category> GetCategories(int parentID)
        {
            using (var db = ConnMan.Instance())
            {
                return s_compiledGetCategories.Invoke(db, parentID).ToList();
            }
        }

        public IEnumerable<Category> GetCategories(int[] ids)
        {
            using (var db = ConnMan.Instance())
            {
                return (from c in db.Categories where ids.Contains(c.ID) select c).ToList();
                //return s_compiledGetCategorieInIds.Invoke(db,ids).ToList();
            }
        }

        private static readonly Func<PubDBEntities, int[], IEnumerable<Category>> s_compiledGetCategorieInIds =
            CompiledQuery.Compile<PubDBEntities, int[], IEnumerable<Category>>((db, ids) => (from c in db.Categories where ids.Contains(c.ID) select c));
        #endregion

        #region Helper methods

        private IList<Category> RootCategories
        {
            get
            {
                if (_rootCategories == null)
                {
                    using (var db = ConnMan.Instance())
                    {
                        _rootCategories = s_compiledGetCategories(db, 0).ToList();
                        // DataEntities.Categories.Where(c => c.ParentID == 0).ToList();
                    }
                }
                return _rootCategories;
            }
        }

        private Category Site
        {
            get
            {
                return RootCategories.Single(c => c.Title == "{site}");
            }
        }

        private Category Blogger
        {
            get
            {
                return RootCategories.Single(c => c.Title == "{blogs}");
            }
        }

        private void Reindex(int parentID)
        {
            using (var db = ConnMan.Instance())
            {
                //var cats = (from p in db.Categories
                //            where p.ParentID == parentID
                //            orderby p.Pos
                //            select p).ToList();
                var cats = s_GetCategoriesAndSort.Invoke(db, parentID).ToList();

                for (int i = 0; i < cats.Count; i++)
                    cats[i].Pos = i;
                db.SaveChanges();
            }
        }
        private static readonly Func<PubDBEntities, int, IEnumerable<Category>> s_GetCategoriesAndSort = CompiledQuery.Compile<PubDBEntities, int, IEnumerable<Category>>((db, catID) => (from c in db.Categories orderby c.Pos where c.ParentID == catID select c));

        private bool HasChildren(List<Category> cats, int parentID)
        {
            return cats.Exists(p => p.ParentID == parentID);
        }
        #endregion

        public IEnumerable<Article> GetChildrenArticles(int articleID)
        {
            using (var db = ConnMan.Instance())
            {
                return s_GetArticleChildrenArticles.Invoke(db, articleID).ToList();
                //return db.Articles.Where(a => a.ParentID == articleID).ToList();
            }
        }

        public bool HasChildrenArticles(int articleID)
        {
            using (var db = ConnMan.Instance())
            {
                return s_HasChildrenArticles.Invoke(db, articleID);
                //return db.Articles.Count(a => a.ParentID == articleID) > 0;
            }
        }
        private static readonly Func<PubDBEntities, int, bool> s_HasChildrenArticles = CompiledQuery.Compile<PubDBEntities, int, bool>((db, parentID) => (from a in db.Articles where a.ParentID == parentID select a.ID).Count() > 0);
        private static readonly Func<PubDBEntities, int, IEnumerable<Article>> s_GetArticleChildrenArticles = CompiledQuery.Compile<PubDBEntities, int, IEnumerable<Article>>((db, parentID) => (from a in db.Articles where a.ParentID == parentID select a));
    }
}