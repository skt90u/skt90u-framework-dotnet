﻿//  Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using DNA.Mvc.DynamicUI;
using DNA.Mvc.Models;
using DNA.Mvc.OpenAPI.Rss;
using System.Net;
using DNA.Mvc.OpenAPI.Ping;
using DNA.Mvc.OpenAPI.Atom;

namespace DNA.Mvc.Areas.Publishing.Models
{
    /// <summary>
    /// Extends the Article object model.
    /// </summary>
    public static class ArticleExtensions
    {
        private static IPublishing service;

        private static IPublishing Service
        {
            get
            {
                if (service == null)
                    service = WebSite.GetService<IPublishing>("Publishing");
                return service;
            }
        }

        /// <summary>
        /// Delete this article.
        /// </summary>
        /// <param name="article">The Article object</param>
        public static void Delete(this Article article)
        {
            Service.DeleteArticle(article.ID);
        }

        /// <summary>
        /// Determine the specified user is article owner.
        /// </summary>
        /// <param name="article">The Article object to extends.</param>
        /// <param name="username">The user name.</param>
        /// <returns></returns>
        public static bool IsOwner(this Article article, string username)
        {
            return article.UserName.Equals(username, StringComparison.OrdinalIgnoreCase);
        }

        /// <summary>
        ///  Determine the current request user is article owner.
        /// </summary>
        /// <param name="article">The Article object to extends.</param>
        /// <returns></returns>
        public static bool IsOwner(this Article article)
        { 
            if (HttpContext.Current.Request.IsAuthenticated)
                return article.IsOwner(HttpContext.Current.User.Identity.Name);
            return false;
        }

        /// <summary>
        ///  Get the permalink url for article.
        /// </summary>
        /// <param name="article">The Article object to extends.</param>
        /// <returns></returns>
        public static string GetPermaLinkUrl(this Article article)
        {
            //if (string.IsNullOrEmpty(article.PermaLink))
            //    article.Update();
            ///TODO:Please remove the "publishing"
            return WebSite.Open().GetFullUrl() + "/publishing" + article.PermaLink;
        }

        /// <summary>
        /// Gets the related articles 
        /// </summary>
        /// <param name="article"></param>
        /// <returns></returns>
        public static IEnumerable<Article> GetRelatedArticles(this Article article)
        {
            if (!string.IsNullOrEmpty(article.RelatedPosts))
            {
                var ids = article.RelatedPosts.Split(',').Select(id => int.Parse(id)).ToArray();
                return Service.GetArticles(ids);
            }
            return null;
        }

        /// <summary>
        /// Add relativate article by specified article id.
        /// </summary>
        /// <param name="article">The Article object to extends.</param>
        /// <param name="articleID">The article id to relate.</param>
        public static void AddRelatedPost(this Article article, int articleID)
        {
            if (!string.IsNullOrEmpty(article.RelatedPosts))
            {
                var ids = article.RelatedPosts.Split(',').Select(id => int.Parse(id)).ToArray();
                if (!ids.Contains(articleID))
                    article.RelatedPosts += "," + articleID;
                else
                    return;
            }
            else
                article.RelatedPosts = articleID.ToString();

            Service.EditArticle(article);
        }

        /// <summary>
        /// Save the changes to database.
        /// </summary>
        /// <param name="article">The Article object</param>
        public static void Update(this Article article)
        {
            if (article.ID > 0)
            {
                if ((article.IsPublished) && (!article.IsPrivate))
                {
                    var needTrackback = false;
                    var diffUrls = new List<Uri>();
                    if (article.AllowPingback)
                    {
                        var orginal = Service.GetArticle(article.ID);
                        if (orginal == null)
                            throw new ArgumentOutOfRangeException("Article.ID=" + article.ID.ToString());

                        if (!string.IsNullOrEmpty(article.SendTrackbackUrls))
                        {
                            #region Check the send trackbackurls was changed?
                            //if ((string.IsNullOrEmpty(orginal.SendTrackbackUrls)) ||
                            //    (!orginal.SendTrackbackUrls.Equals(article.SendTrackbackUrls, StringComparison.OrdinalIgnoreCase)))
                            if (orginal.IsPublished == false) 
                                needTrackback = true;
                            #endregion
                        }
                        #region Check the body was changed?

                        var orgPingUrls = orginal.GetPingUrls();
                        var currentPingUrls = article.GetLinkUrlsInContent();

                        if (currentPingUrls.Count > 0)
                        {
                            foreach (var uri in currentPingUrls)
                            {
                                if (orginal.IsPublished)
                                {
                                    if (orgPingUrls.Count > 0)
                                    {
                                        if (orgPingUrls.Contains(uri))
                                            continue;
                                    }
                                }
                                diffUrls.Add(uri);
                            }
                        }
                        #endregion
                    }
                    if (diffUrls.Count > 0)
                        article.PingUrls = String.Join(" ", diffUrls.Select(u => u.ToString()).ToArray());
                    Service.EditArticle(article);
                    if (diffUrls.Count > 0) PingOnBackground(article, diffUrls);
                    if (needTrackback) SendTrackbackOnBackground(article);
                }
                else
                    Service.EditArticle(article);
            }
            else
            {
                if (article.CategoryID <= 0)
                    throw new ArgumentOutOfRangeException("The article must belong to a category.");

                article.ID=Service.NewArticle(article).ID;

                if ((article.IsPublished) && (!article.IsPrivate))
                {
                    if (!string.IsNullOrEmpty(article.SendTrackbackUrls))
                        SendTrackbackOnBackground(article);

                    if (article.AllowPingback)
                    {
                        var urls = article.GetLinkUrlsInContent();
                        if (urls.Count > 0)
                        {
                            article.PingUrls = String.Join(" ", urls.Select(u => u.ToString()).ToArray());
                            Service.EditArticle(article);
                            PingOnBackground(article, urls);
                        }
                    }
                }
            }
        }

        private static void SendTrackbackOnBackground(Article article)
        {
            //Send trackback on async call
            var tb_trackbacks = article.GetSendTrackbackUrls();
            foreach (var _trackbackUri in tb_trackbacks)
            {
                if (_trackbackUri.ToString().Equals(article.GetPermaLinkUrl(), StringComparison.OrdinalIgnoreCase))
                    continue;
                
                ////Means the trackback uri is in same same application
                //if (_trackbackUri.Authority.Equals(WebSite.AppUrl.Authority))
                //{

                //    continue;
                //}

                var _trackbackmsg = GetTrackbackMessage(article, _trackbackUri);
                sendTrackbackAction.BeginInvoke(_trackbackmsg, null, null);
            }
        }

        private static readonly Action<TrackbackMessage> sendTrackbackAction =
            new Action<TrackbackMessage>(t => { TrackbackSender.Send(t); });

        private static TrackbackMessage GetTrackbackMessage(Article article, Uri uri)
        {
            string excerpt = article.Summary;
            if (string.IsNullOrEmpty(excerpt))
            {
                excerpt = TextUtility.ClearHtml(article.Body);
                if (excerpt.Length > 100)
                {
                    excerpt = excerpt.Substring(0, 100);
                }
            }

            return new TrackbackMessage()
            {
                BlogTitle = WebSite.Open(article.UserName).Title,
                DestinationUrl = uri,
                Excerpt = excerpt,
                Title = article.Title,
                UrlToNotifyTrackback = new Uri(article.GetPermaLinkUrl())
            };
        }

        /// <summary>
        /// Get all link urls from this article content body.
        /// </summary>
        /// <param name="article">The Article object</param>
        /// <returns>A uri list contains urls which this article refers to.</returns>
        public static List<Uri> GetLinkUrlsInContent(this Article article)
        {
            var urls = new List<Uri>();
            if (!string.IsNullOrEmpty(article.Body))
            {
                string content = article.Body;
                if (article.ContentFormat == (int)DNA.Mvc.Text.TextFormats.WiKi)
                    content = DNA.Mvc.Text.MarkupExtensions.ConvertWikiToHtml(article.Body);
                content = HttpContext.Current.Server.HtmlDecode(content);
                var urlList = UrlUtility.GetUrlsFromContent(content);
                if (urlList.Count() > 0)
                    urls.AddRange(urlList);
            }
            return urls;
        }

        private static void PingOnBackground(Article article, List<Uri> urls)
        {
            foreach (var url in urls)
            {
                try
                {
                    var request = (HttpWebRequest)WebRequest.Create(url);
                    request.Headers["Accept-Encoding"] = "gzip";
                    request.Headers["Accept-Language"] = "en-us";
                    request.Credentials = CredentialCache.DefaultNetworkCredentials;
                    request.AutomaticDecompression = DecompressionMethods.GZip;
                    var state = new Dictionary<string, object>();
                    state.Add("request", request);
                    state.Add("permalink", article.GetPermaLinkUrl());
                    state.Add("msg", GetTrackbackMessage(article, url));
                    request.BeginGetResponse(new AsyncCallback(AsyncPingback), state);
                }
                catch { continue; }
            }
        }

        private static void AsyncPingback(IAsyncResult result)
        {
            try
            {
                var state = (Dictionary<string, object>)result.AsyncState;
                var request = (HttpWebRequest)state["request"];
                var permalink = (string)state["permalink"];
                var trackbackmsg = (TrackbackMessage)state["msg"];
                var response = request.EndGetResponse(result);

                using (var reader = new System.IO.StreamReader(response.GetResponseStream()))
                {
                    string content = reader.ReadToEnd();
                    string contentType = response.ContentType;
                    Uri uri = null;

                    #region check the target uri is pingable
                    var pingUrlKeyIndex = Array.FindIndex(response.Headers.AllKeys,
                                delegate(string k)
                                {
                                    return k.Equals("x-pingback", StringComparison.OrdinalIgnoreCase) ||
                                           k.Equals("pingback", StringComparison.OrdinalIgnoreCase);
                                });

                    if (pingUrlKeyIndex != -1)
                        Uri.TryCreate(response.Headers[pingUrlKeyIndex], UriKind.Absolute, out uri);
                    //If the resource is resource ping enabled
                    if (uri != null)
                    {
                        PingbackSender.Send(new Uri(permalink), request.RequestUri, uri);
                        return;
                    }

                    #endregion

                    if (contentType.StartsWith("image", StringComparison.OrdinalIgnoreCase) ||
    contentType.StartsWith("media", StringComparison.OrdinalIgnoreCase))
                        return;

                    #region Test
                    //uri = UrlUtility.GetPingbackUrlFromContent(content);
                    //if (uri != null)
                    //    PingbackSender.Send(new Uri(permalink), request.RequestUri, uri);
                    #endregion
                    uri = UrlUtility.GetTrackBackUrlFromContent(content);
                    if (uri != null)
                    {
                        if (!uri.ToString().Equals(permalink, StringComparison.OrdinalIgnoreCase))
                        {
                            trackbackmsg.DestinationUrl = uri;
                            TrackbackSender.Send(trackbackmsg);
                        }
                    }
                    else
                    {
                        uri = UrlUtility.GetPingbackUrlFromContent(content);
                        if (uri != null)
                            PingbackSender.Send(new Uri(permalink), request.RequestUri, uri);
                    }
                }
            }
            catch { }

        }


        /// <summary>
        /// Add Pingback comment.
        /// </summary>
        /// <param name="article">The Article object</param>
        /// <param name="from">Specified the uri where ping back from</param>
        /// <returns></returns>
        public static bool AddPingbackComment(this Article article, string ip, Uri from)
        {
            article.AddComment(new Comment()
            {
                //Body = excerpt,
                Title = "Ping back from:" + from.ToString(),
                IP = ip,
                Posted = DateTime.Now,
                UserName = ip,
                WebSite = from.ToString(),
                IsPingback = true,
                IsTrackback = false,
            });
            return true;
        }

        /// <summary>
        /// Add the trackback comment
        /// </summary>
        /// <param name="article">The Article object</param>
        /// <param name="blog_name">Specified the trackback blog name.</param>
        /// <param name="title">Specified the trackback title </param>
        /// <param name="url">Specified the trackback from url</param>
        /// <param name="excerpt">Specified the summary of the comment</param>
        /// <param name="ip">Specified the IP address of the trackback request.</param>
        /// <returns>Boolean</returns>
        public static bool AddTrackbackComment(this Article article, string blog_name, string title, Uri url, string excerpt, string ip)
        {
            article.AddComment(new Comment()
           {
               Title = title,
               Body = HttpContext.Current.Server.HtmlEncode(excerpt),
               IP = HttpContext.Current.Request.UserHostAddress,
               Posted = DateTime.Now,
               UserName = blog_name,
               WebSite = url.ToString(),
               IsTrackback = true,
               IsPingback = false,
           });
            return true;
        }

        /// <summary>
        /// Add comment object
        /// </summary>
        /// <param name="article">The Article object</param>
        /// <param name="comment">Specified the comment object to add.</param>
        public static void AddComment(this Article article, Comment comment)
        {
            if (comment == null)
                throw new ArgumentNullException("comment");

            comment.ArticleID = article.ID;
            Service.AddComment(comment);
        }

        /// <summary>
        /// Get article comments.
        /// </summary>
        /// <param name="article">The Article object to extends.</param>
        /// <returns></returns>
        public static IEnumerable<Comment> GetComments(this Article article)
        {
            return Service.GetComments(article.ID);
        }

        /// <summary>
        /// Audit this article.
        /// </summary>
        /// <param name="article">The Article object</param>
        /// <returns>Boolean</returns>
        public static bool Audit(this Article article)
        {
            article.IsAppoved = true;
            article.Update();
            //Service.AuditArticle(article.ID);
            return true;
        }

        /// <summary>
        /// Move the article to specified position.
        /// </summary>
        /// <param name="article">The Article object</param>
        /// <param name="position">Specified the new position to move to.</param>
        public static void Move(this Article article, int position)
        {
            article.Move(article.CategoryID, position);
        }

        /// <summary>
        /// Gets the track back urls as string array.
        /// </summary>
        /// <param name="article">The Article object</param>
        /// <returns>A string array contains track back urls.</returns>
        public static List<Uri> GetSendTrackbackUrls(this Article article)
        {
            var urlList = new List<Uri>();
            if (!string.IsNullOrEmpty(article.SendTrackbackUrls))
            {
                var urls = article.SendTrackbackUrls.Split(new char[] { ' ' });
                foreach (var url in urls)
                {
                    Uri uri = null;
                    if (Uri.TryCreate(url, UriKind.Absolute, out uri))
                    {
                        urlList.Add(uri);
                    }
                }
            }
            return urlList;
        }

        /// <summary>
        /// Gets the urls that already send ping back request by server.
        /// </summary>
        /// <param name="article">The Article object</param>
        /// <returns>A string array contains ping urls.</returns>
        public static List<Uri> GetPingUrls(this Article article)
        {
            var urlList = new List<Uri>();
            if (!string.IsNullOrEmpty(article.PingUrls))
            {
                var urls = article.PingUrls.Split(new char[] { ' ' });
                foreach (var url in urls)
                {
                    Uri uri = null;
                    if (Uri.TryCreate(url, UriKind.Absolute, out uri))
                    {
                        urlList.Add(uri);
                    }
                }
            }
            return urlList;
        }

        ///// <summary>
        ///// Set a ping urls list to article PingUrls property.
        ///// </summary>
        ///// <param name="article">The Article object</param>
        ///// <param name="pingUrls">A list contains the urls was ping</param>
        //public static void SetPingUrls(this Article article, List<string> pingUrls)
        //{
        //    if (pingUrls.Count == 0)
        //        article.PingUrls = "";
        //    else
        //        article.PingUrls = String.Join(" ", pingUrls.ToArray());
        //}

        /// <summary>
        /// Move the article to new parent category and new postion
        /// </summary>
        /// <param name="article">The Article object</param>
        /// <param name="categoryID">Specified the new parent category id.</param>
        /// <param name="position">Specified the new position to move to.</param>
        public static void Move(this Article article, int categoryID, int position)
        {
            Service.Move(article.ID, position, categoryID);
        }

        /// <summary>
        /// Vote this article.
        /// </summary>
        /// <param name="article">The Article object</param>
        /// <param name="value">The vote value</param>
        /// <param name="totalRatings"></param>
        /// <returns></returns>
        public static double Vote(this Article article, int value, out int totalRatings)
        {
            int total = 0;
            double result = Service.Rating(article.ID, value, out total);
            totalRatings = total;
            return result;
        }

        /// <summary>
        /// Gets the relation categories of this articles,but not include the parent category.
        /// </summary>
        /// <param name="article">The article object.</param>
        /// <returns>A collection of the relation categories instance.</returns>
        public static IEnumerable<Category> GetCategories(this Article article)
        {
            var cats = new List<Category>();
            //cats.Add(article.GetParent());
            if (!string.IsNullOrEmpty(article.Categories))
            {
                int[] ids = article.Categories.Split(new char[] { ',' }).Select(f => int.Parse(f)).ToArray();
                return Service.GetCategories(ids);
            }
            return cats;
        }
        /// <summary>
        /// Mark and increase reads for current user.
        /// </summary>
        /// <param name="article">The Article object</param>
        public static void Read(this Article article)
        {
            var start = DateTime.Now.AddHours(-1);
            var end = DateTime.Now;
            var tracks = Service.GetTracks(article.ID, start, end);
            string clientAddress = HttpContext.Current.Request.UserHostAddress;

            if (tracks.Count() > 0)
            {
                if (tracks.FirstOrDefault(t => t.IPAddress.Equals(clientAddress, StringComparison.OrdinalIgnoreCase)) != null)
                    return;
            }

            Service.AddTrack(new Track()
            {
                ArticleID = article.ID,
                HasRead = DateTime.Now,
                IPAddress = clientAddress,
                UserAgent = HttpContext.Current.Request.UserAgent,
                UserName = HttpContext.Current.Request.IsAuthenticated ? HttpContext.Current.User.Identity.Name : clientAddress
            });
        }

        /// <summary>
        /// Get silbing articles
        /// </summary>
        /// <param name="article">The Article object</param>
        /// <returns>A collection contains the sibling articles</returns>
        public static IEnumerable<Article> GetSilbings(this Article article)
        {
            if (article.Category != null)
                return article.Category.GetChildrenArticles();
            return null;
        }

        /// <summary>
        /// Get the previous silbing article
        /// </summary>
        /// <param name="article">The Article object</param>
        /// <returns>When previous sibling article exists it will be return overwrise returns null.</returns>
        public static Article GetPreviousSibling(this Article article)
        {
            var articles = article.GetSilbings();
            if (articles != null)
            {
                var arts = articles.OrderBy(a => a.Pos).ToList();
                for (int i = 0; i < arts.Count; i++)
                {
                    if (arts[i].ID == article.ID)
                    {
                        if ((i - 1) >= 0)
                        {
                            return arts[i - 1];
                        }
                    }
                }
            }
            return null;
        }

        /// <summary>
        /// Get the next silbing article
        /// </summary>
        /// <param name="article">The Article object</param>
        /// <returns>When next sibling article exists it will be return overwrise returns null.</returns>
        public static Article GetNextSibling(this Article article)
        {
            var articles = article.GetSilbings();
            if (articles != null)
            {
                var arts = articles.OrderBy(a => a.Pos).ToList();
                for (int i = 0; i < arts.Count; i++)
                {
                    if (arts[i].ID == article.ID)
                    {
                        if ((i + 1) < arts.Count)
                        {
                            return arts[i + 1];
                        }
                    }
                }
            }
            return null;
        }

        /// <summary>
        /// Get the parent category of this article.
        /// </summary>
        /// <param name="article">The Article object</param>
        /// <returns></returns>
        public static Category GetParent(this Article article)
        {
            //if (article.Category == null)
            return Service.GetCategory(article.CategoryID);
            //else
            //return article.Category;
        }

        /// <summary>
        /// Get the trackback url of the article.
        /// </summary>
        /// <param name="article">The Article object to extends.</param>
        /// <returns></returns>
        public static string GetTrackbackUrl(this Article article)
        {
            var Url = UrlUtility.CreateUrlHelper();
            return WebSite.Open().GetFullUrl() + "/openapi/trackback/" + article.ID; //Url.Action("Trackback", "OpenAPI", new { Area = "", id = article.ID });
        }

        /// <summary>
        /// Save the changes to database.
        /// </summary>
        /// <param name="copy">The TranslatedCopy objec to extends.</param>
        public static void Update(this TranslatedCopy copy)
        {
            if (copy.ID <= 0)
                Service.Translate(copy);
            else
                Service.EditTranslatedCopy(copy);
        }

        /// <summary>
        ///  Get TranslatedCopy collection.
        /// </summary>
        /// <param name="article">The Article object to extends.</param>
        /// <returns></returns>
        public static IEnumerable<TranslatedCopy> GetTranslatedCopies(this Article article)
        {
            return Service.GetTranslatedCopies(article.ID);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="article">The Article object to extends.</param>
        /// <param name="lang"></param>
        /// <returns></returns>
        public static TranslatedCopy GetTranslatedCopy(this Article article, string lang)
        {
            return Service.GetTranslatedCopy(article.ID, lang);
        }

        /// <summary>
        /// Get the Rss feed document instance.
        /// </summary>
        /// <param name="article">The Article object to extends.</param>
        /// <returns></returns>
        public static RssDocument GetCommentsRssFeed(this Article article)
        {
            var doc = new RssDocument();
            var channel = new RssChannel()
            {
                Title = article.Title,
                Description = article.Summary,
                Generator = "DotNetAge " + System.Reflection.Assembly.GetExecutingAssembly().GetName().Version.ToString(),
                Link = article.GetPermaLinkUrl(),
                Language = article.Language,
                LastBuildDate = article.LastModified.ToString("r"),
                PubDate = article.Posted.ToString("r"),
                DocUrl = article.GetPermaLinkUrl()
            };
            var comments = article.GetComments();
            channel.Items = new List<RssItem>();
            foreach (var c in comments)
            {
                channel.Items.Add(new RssItem()
                {
                    Title = c.Title,
                    Author = c.UserName,
                    Description = c.Body,
                    Link = article.GetPermaLinkUrl(),
                    PubDate = c.Posted.ToString("r")
                });
            }
            doc.Channel = channel;
            return doc;
        }

        /// <summary>
        /// Get the atom feed document instance.
        /// </summary>
        /// <param name="article">The Article object to extends.</param>
        /// <returns></returns>
        public static AtomFeed GetCommentsAtomFeed(this Article article)
        {
            var feed = new AtomFeed()
            {
                Generator = new AtomGenerator()
                {
                    Text = "DotNetAge",
                    NavigateUrl = "http://www.dotnetage.com",
                    Version = System.Reflection.Assembly.GetExecutingAssembly().GetName().Version.ToString(),
                },
                ID = article.GetPermaLinkUrl(),
                CopyRight = WebSite.Open().Copyright,
                Title = article.Title,
                Updated = article.LastModified
            };
            var comments = article.GetComments();
            feed.Entries = new List<AtomEntry>();
            foreach (var c in comments)
            {
                feed.Entries.Add(new AtomEntry()
                    {
                        Author = new AtomPersonConstruct()
                        {
                            Name = c.UserName,
                            Email = c.Email,
                            Uri = c.WebSite
                        },
                        Content = new AtomContent()
                        {
                            ContentType = "text/html",
                            Text = c.Body,
                            SourceUrl = article.GetPermaLinkUrl()
                        },
                        ID = article.GetPermaLinkUrl()+"#"+c.ID.ToString(),
                        Title = c.Title,
                        Updated = c.Posted
                    });
            }
            return feed;
        }

        /// <summary>
        /// Get the parent article.
        /// </summary>
        /// <param name="comment">The Comment object to extends.</param>
        /// <returns></returns>
        public static Article GetParent(this Comment comment)
        {
            return Service.GetArticle(comment.ArticleID);
        }

        /// <summary>
        /// Get the children articles
        /// </summary>
        /// <param name="article">The Article object to extends.</param>
        /// <returns></returns>
        public static IEnumerable<Article> GetChildren(this Article article)
        {
            return Service.GetChildrenArticles(article.ID);
        }

        /// <summary>
        /// Gets the  article wheather has children articles.
        /// </summary>
        /// <param name="article">The Article object to extends.</param>
        /// <returns></returns>
        public static bool HasChildren(this Article article)
        {
            return Service.HasChildrenArticles(article.ID);
        }
    }
}