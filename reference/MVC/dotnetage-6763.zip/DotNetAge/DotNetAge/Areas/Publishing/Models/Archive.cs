﻿//  Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.ComponentModel;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Globalization;

namespace DNA.Mvc.Areas.Publishing.Models
{
    /// <summary>
    /// Defines the user archive.
    /// </summary>
    public class Archive
    {
        private string displayText;

        /// <summary>
        /// Gets / Sets the display text of the archive.
        /// </summary>
        public string DisplayText
        {
            get 
            {
                if (string.IsNullOrEmpty(displayText))
                    return Year.ToString() + "/" + Month.ToString();
                return displayText; 
            }
            set { displayText = value; }
        }

        /// <summary>
        /// Gets/Sets the year.
        /// </summary>
        public int Year { get; set; }

        /// <summary>
        /// Gets/Sets the month.
        /// </summary>
        public int Month { get; set; }
        
        /// <summary>
        /// Gets the month display name.
        /// </summary>
        public string MonthName
        {
            get
            {
                return DateTimeFormatInfo.CurrentInfo.GetMonthName(Month);
            }
        }
    }
}