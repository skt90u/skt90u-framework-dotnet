﻿//  Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using DNA.Mvc.DynamicUI;
using DNA.Mvc.Models;
using DNA.Mvc.OpenAPI.Opml;

namespace DNA.Mvc.Areas.Publishing.Models
{
    /// <summary>
    /// The Web object helper class that extends the Web obejct as a model entance of the Publishing.
    /// </summary>
    public static class WebExtensions
    {
        private static IPublishing service;

        private static IPublishing Service
        {
            get
            {
                if (service == null)
                    service = WebSite.GetService<IPublishing>("Publishing");
                return service;
            }
        }

        public static IEnumerable<Blog> GetBlogs(this Web web, int returnRows)
        {
            if (web.IsRoot)
                return Service.GetBlogs(returnRows);
            return new List<Blog>();
        }

        /// <summary>
        /// Get all descendant categories for this web.
        /// </summary>
        /// <param name="web">The Web object</param>
        /// <returns>A category collection object.</returns>
        public static IEnumerable<Category> GetCategories(this Web web)
        {
            return Service.GetDescendantCategories(web.DefaultCategory().ID);
        }

        /// <summary>
        /// Get the root category for this web.
        /// </summary>
        /// <param name="web">The Web object</param>
        /// <returns>A category for this web.</returns>
        public static Category DefaultCategory(this Web web)
        {
            return Service.GetWebCategory(web.Name);
        }

        /// <summary>
        /// Add a category object to the parent category by specified parent category id.
        /// </summary>
        /// <param name="web">The Web object</param>
        /// <param name="parentID">Specified the parent category id</param>
        /// <param name="category">The new category object</param>
        public static void AddCategory(this Web web, int parentID, Category category)
        {
            Service.AddCategory(parentID, category);
        }

        /// <summary>
        /// Find category by category id.
        /// </summary>
        /// <param name="web">The Web object</param>
        /// <param name="id">Specified the category id to find.</param>
        /// <returns>A category instance or null</returns>
        public static Category FindCategory(this Web web, int id)
        {
            return Service.GetCategory(id);
        }

        /// <summary>
        /// Find article object by id.
        /// </summary>
        /// <param name="web">The Web object</param>
        /// <param name="id">Sepcified the article id.</param>
        /// <returns>An article instance or null</returns>
        public static Article FindArticle(this Web web, int id)
        {
            if (id <= 0)
                throw new ArgumentOutOfRangeException("id");
            return Service.GetArticle(id);
        }

        /// <summary>
        /// Gets the article by permalink
        /// </summary>
        /// <param name="web">The Web Object</param>
        /// <param name="permalink">Specified the permalink to find</param>
        /// <returns>An article instance will be return or null value when article not found.</returns>
        public static Article FindArticle(this Web web, Uri permalink)
        {
            if (permalink == null) throw new ArgumentNullException("permalink");
            return Service.GetArticleByPermalink(permalink);
        }

        /// <summary>
        /// Get the recent articles of this web.
        /// </summary>
        /// <param name="web">The Web object</param>
        /// <param name="top">Specified how many articles will be return.</param>
        /// <returns>A collection of recent article</returns>
        public static IEnumerable<Article> GetRecentArticles(this Web web, int top)
        {
            return web.DefaultCategory().GetRecentArticles(top);
        }

        public static IEnumerable<Tag> GetTags(this Web web, out int totalTags)
        {
            int total = 0;
            var tags = Service.GetTags(web.DefaultCategory().ID, out total);
            totalTags = total;
            return tags;
        }

        /// <summary>
        /// Get archives of this web.
        /// </summary>
        /// <param name="web">The Web object</param>
        /// <returns>A collection of the archive.</returns>
        public static IEnumerable<Archive> GetArchives(this Web web)
        {
            return Service.GetArchives(web.DefaultCategory().ID);
        }

        public static IEnumerable<Article> SearchArticles(this Web web, SearchOption option)
        {
            if (!option.CategoryID.HasValue)
            {
                option.CategoryID = web.DefaultCategory().ID;
                option.IncludingDescendant = true;
            }
            return Service.GetArticles(option);
        }

        public static IEnumerable<Article> GetHotArticlesOfSite(this Web web, int returnRows)
        {
            return Service.GetArticles(new SearchOption()
            {
                Sortby = ArticleSorts.Reads,
                SortOrder = ArticleOrders.Desc,
                PageIndex = 1,
                PageSize = returnRows,
                IsPublished = true
            });
        }

        public static IEnumerable<Article> GetHotArticles(this Web web, int returnRows)
        {
            return Service.GetArticles(new SearchOption()
             {
                 CategoryID = web.DefaultCategory().ID,
                 IncludingDescendant = true,
                 Sortby = ArticleSorts.Reads,
                 SortOrder = ArticleOrders.Desc,
                 PageIndex = 1,
                 PageSize = returnRows,
                 IsPublished = true
             });
        }

        /// <summary>
        /// Gets the recent blog posts.
        /// </summary>
        /// <remarks>
        /// When the web is top web this method will return all blogger's posts.
        /// </remarks>
        /// <param name="web">The web object.</param>
        /// <param name="returnRows">Specified the how many rows will be returns.</param>
        /// <returns></returns>
        public static IEnumerable<Article> GetRecentBlogPosts(this Web web, int returnRows)
        {
            if ((web.IsRoot) && (WebHost.EnablePersonalWeb))
            {
                var blogCat = Service.FindCategory("{blogs}");
                //if (HttpContext.Current.User.IsWebOwner())
                //    return blogCat.GetRecentArticles(returnRows);
                //else
                    return blogCat.GetPublicRecentArticles(returnRows);
            }
            else
            {
                if (HttpContext.Current.User.IsWebOwner())
                    return web.DefaultCategory().GetRecentArticles(returnRows);
                else
                    return web.DefaultCategory().GetPublicRecentArticles(returnRows);
            }
        }

        /// <summary>
        /// Gets the Opml document instance.
        /// </summary>
        /// <param name="web">The web instance to extends.</param>
        /// <returns></returns>
        public static OpmlDocument GetOpmlDocument(this Web web)
        {
            var member = System.Web.Security.Membership.GetUser(web.Owner);
            var opmlDoc = new OpmlDocument()
            {
                Head = new OpmlHead()
                {
                    Created = DateTime.UtcNow,
                    Modified = DateTime.UtcNow,
                    Title = web.Title,
                    OwnerName = member.GetDisplayName(),
                    OwnerID = member.UserName,
                    OwnerEmail = member.Email,
                    VertScrollState = 1,
                    WindowRight=800,
                    WindowBottom=600
                },
                Body = new OpmlBody()
                {
                    Outlines = new List<OpmlOutline>()
                }
            };
            var _children = web.DefaultCategory().Children();

            foreach (var cat in _children)
            {
                var _outline=PopuplateOutline(web,cat);
                opmlDoc.Body.Outlines.Add(_outline);
                if (cat.HasChildren())
                    AddChildrenOutline(web,_outline, cat);
            }
            return opmlDoc;
        }
        
        private static void AddChildrenOutline(Web web,OpmlOutline parent,Category category)
        {
            var _cats = category.Children();
            foreach (var cat in _cats)
            {
                var _outline = PopuplateOutline(web,cat);
                if (parent.Outlines == null)
                    parent.Outlines = new List<OpmlOutline>();
                parent.Outlines.Add(_outline);
                if (cat.HasChildren())
                    AddChildrenOutline(web,_outline, cat);
            }
        }

        private static OpmlOutline PopuplateOutline(Web web, Category cat)
        {
            return new OpmlOutline()
                 {
                     Title = cat.Title,
                     Description = HttpContext.Current.Server.HtmlEncode(cat.Description),
                     HtmlUrl = cat.GetPermalinkUrl().ToString(),
                     XmlUrl =web.GetFullUrl()+ UrlUtility.CreateUrlHelper().Action("RssFeed", "Category", new { Area = "Publishing", id = cat.ID }),
                     Language = "en-US",
                     Text = cat.Title,
                     Version = "RSS2",
                     Type = "rss"
                 };
        }
    }
}