﻿//  Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DNA.Mvc.Areas.Publishing.Models
{
    /// <summary>
    /// Defines the options for search the articles
    /// </summary>
    public class SearchOption
    {
        private bool includingDescendant = false;
        private int categoryID = 0;
        private ArticleSorts sortby = ArticleSorts.PostDate;
        private ArticleOrders order = ArticleOrders.Asc;

        public ArticleOrders SortOrder
        {
            get { return order; }
            set { order = value; }
        }

        public ArticleSorts Sortby
        {
            get { return sortby; }
            set { sortby = value; }
        }

        /// <summary>
        /// Gets/Sets the search text for article
        /// </summary>
        public string SearchText { get; set; }

        /// <summary>
        /// Gets/Sets the search tag name for article
        /// </summary>
        public string TagName { get; set; }

        /// <summary>
        /// Gets/Sets which archive for search
        /// </summary>
        public string Archive { get; set; }

        /// <summary>
        /// Gets/Sets the page index of search result.
        /// </summary>
        public int? PageIndex { get; set; }

        /// <summary>
        /// Gets/Sets the page size of the search result.
        /// </summary>
        public int? PageSize { get; set; }

        /// <summary>
        /// Gets/Sets the total records of the search result.
        /// </summary>
        public int? TotalRecords { get; set; }

        /// <summary>
        /// Gets/Sets whether gets the descendant articles of specified category.
        /// </summary>
        public bool IncludingDescendant
        {
            get { return includingDescendant; }
            set { includingDescendant = value; }
        }


        /// <summary>
        /// Gets/Sets the category id 
        /// </summary>
        public int? CategoryID { get; set; }

        public bool? IsPublished { get; set; }

        public bool? IsAppoved { get; set; }

        public bool? IsPrivate { get; set; }
        /// <summary>
        /// Gets the Archive object from archive string.
        /// </summary>
        /// <returns></returns>
        public Archive GetArchive()
        {
            if (!string.IsNullOrEmpty(this.Archive))
            {
                try
                {
                    var yms = this.Archive.Split(new char[] { '/' });
                    return (new Archive()
                    {
                        Year = int.Parse(yms[0]),
                        Month = int.Parse(yms[1]),
                        DisplayText = this.Archive
                    });
                }
                catch { return null; }
            }
            return null;
        }
    }

    public enum ArticleSorts
    { 
        PostDate,
        Position,
        Ratings,
        Reads
    }

    public enum ArticleOrders
    { 
        Asc,
        Desc,
    }
}