﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using DNA.Mvc.Text;
using DNA.Mvc.Areas.Publishing.Models;

namespace DNA.Mvc.Areas.Publishing
{
    public interface IPublishing
    {
        /// <summary>
        /// Get the blogs of the sites
        /// </summary>
        /// <param name="returnRows">Specified how many rows will be return</param>
        /// <returns>A collection contains blog instances</returns>
        IEnumerable<Blog> GetBlogs(int returnRows);

        /// <summary>
        /// Search the articles by specified SearchOption object
        /// </summary>
        /// <param name="option">Specified the search options.</param>
        /// <returns>A collection contains the article search result</returns>
        IEnumerable<Article> GetArticles(SearchOption option);

        /// <summary>
        /// Gets the articles in specified id value array.
        /// </summary>
        /// <param name="articlesIDs">The article id value array.</param>
        /// <returns>A article collection</returns>
        IEnumerable<Article> GetArticles(int[] articlesIDs);

        /// <summary>
        /// Gets the article count by specified category id.
        /// </summary>
        /// <param name="categoyID">The category id.</param>
        /// <returns>The integer value.</returns>
        int ArticleCount(int categoyID);

        /// <summary>
        /// Get all descendant categories by specified category id.
        /// </summary>
        /// <param name="categoryID">Specified the category id</param>
        /// <returns>A collection contains the descendant categories.</returns>
        IEnumerable<Category> GetDescendantCategories(int categoryID);

        /// <summary>
        /// Movet the article to new position or attach to another parent category.
        /// </summary>
        /// <param name="articleID">Specified the article id which to move.</param>
        /// <param name="pos">Specified the new position to move to.</param>
        /// <param name="categoryID">Specified the parent category id of the article.</param>
        void Move(int articleID, int pos, int categoryID);

        /// <summary>
        /// Vote the specified article.
        /// </summary>
        /// <param name="articleID">Specified the article id to vote.</param>
        /// <param name="value">Specified the rating value.</param>
        /// <param name="totalRatings"></param>
        /// <returns></returns>
        double Rating(int articleID, int value, out int totalRatings);

        /// <summary>
        /// Create a new article 
        /// </summary>
        /// <param name="article">Specified a new article object.</param>
        /// <returns>The article has been saved.</returns>
        Article NewArticle(Article article);

        /// <summary>
        /// Apply the changes to database by specified the article object.
        /// </summary>
        /// <param name="article">Specified the article object contains the changes.</param>
        /// <returns>Boolean</returns>
        bool EditArticle(Article article);

        /// <summary>
        /// Delete the article by specified article id.
        /// </summary>
        /// <param name="id">Specified the article id to delete</param>
        void DeleteArticle(int id);

        /// <summary>
        /// Get the article by specified id.
        /// </summary>
        /// <param name="id">Specified the article id.</param>
        /// <returns>An article instance or null</returns>
        Article GetArticle(int id);

        /// <summary>
        /// Get the article by specified permalink url.
        /// </summary>
        /// <param name="url">The permalink url.</param>
        /// <returns>An article instance or null</returns>
        Article GetArticleByPermalink(Uri url);

        /// <summary>
        /// Edit the translated copy.
        /// </summary>
        /// <param name="copy">The translated copy object.</param>
        void EditTranslatedCopy(TranslatedCopy copy);

        /// <summary>
        /// Add a new translated copy.
        /// </summary>
        /// <param name="copy">The translated copy object.</param>
        void Translate(TranslatedCopy copy);

        /// <summary>
        /// Get the TranslatedCopy object specified the article id and language.
        /// </summary>
        /// <param name="articleID">The article id.</param>
        /// <param name="lang">The language of article.</param>
        /// <returns>The TranslatedCopy object.</returns>
        TranslatedCopy GetTranslatedCopy(int articleID, string lang);

        /// <summary>
        ///  Get the TranslatedCopy collection by specified article id.
        /// </summary>
        /// <param name="articleID">The article id.</param>
        /// <returns>A collection of TranslatedCopy.</returns>
        IEnumerable<TranslatedCopy> GetTranslatedCopies(int articleID);

        /// <summary>
        ///  Gets the Tag collection by specified category id and return the tags count.
        /// </summary>
        /// <param name="categoryID">The category id.</param>
        /// <param name="count">The tag count.</param>
        /// <returns></returns>
        IEnumerable<Tag> GetTags(int categoryID,out int count);

        /// <summary>
        /// Gets a archive collection by specified category id .
        /// </summary>
        /// <param name="categoryID">The category id .</param>
        /// <returns></returns>
        IEnumerable<Archive> GetArchives(int categoryID);

        /// <summary>
        /// Gets the category children count
        /// </summary>
        /// <param name="categoryID">Specified the category id.</param>
        /// <returns>Total children category count</returns>
        int GetCategoryChildrenCount(int categoryID);

        /// <summary>
        /// Create and comment object.
        /// </summary>
        /// <param name="comment">The new comment object</param>
        void AddComment(Comment comment);

        /// <summary>
        /// Gets the comment collection by specifed article id .
        /// </summary>
        /// <param name="articleID">The article id.</param>
        /// <returns>The comment collection.</returns>
        IEnumerable<Comment> GetComments(int articleID);

        /// <summary>
        /// Get recent comments of specified category id
        /// </summary>
        ///<param name="categoryID">Specified the parent category id.</param>
        /// <param name="returnRows">Specified how many rows will return</param>
        /// <returns>A collection of comment</returns>
        IEnumerable<Comment> GetRecentComments(int categoryID, int returnRows);
        
        /// <summary>
        /// Get the category for web
        /// </summary>
        /// <remarks>In DNA every web has their web category</remarks>
        /// <param name="name">Specified the web name</param>
        /// <returns>A category object of web</returns>
        Category GetWebCategory(string name);

        /// <summary>
        /// Delete the category  by specified id.
        /// </summary>
        /// <param name="id">Specified the category id.</param>
        void DeleteCategory(int id);

        /// <summary>
        /// Create a category 
        /// </summary>
        /// <param name="parentID">Specified the category parent id.</param>
        /// <param name="category">Specified the category instance.</param>
        Category AddCategory(int parentID, Category category);

        /// <summary>
        /// Gets the category by specified category id .
        /// </summary>
        /// <param name="id">Specified the category id .</param>
        /// <returns>A category instance.</returns>
        Category GetCategory(int id);

        /// <summary>
        /// Find the category by specified the path.
        /// </summary>
        /// <param name="path">The category path.</param>
        /// <returns>The category instance.</returns>
        Category FindCategory(string path);

        /// <summary>
        /// Gets the category collection in specified id array.
        /// </summary>
        /// <param name="ids">The category id array.</param>
        /// <returns>The Category collection.</returns>
        IEnumerable<Category> GetCategories(int[] ids);

        /// <summary>
        /// Save the changes of the specified category.
        /// </summary>
        /// <param name="category">Specified the categoty instance to save.</param>
        void EditCategory(Category category);

        /// <summary>
        /// Move the category to a new position.
        /// </summary>
        /// <param name="parentID">Specified the parent category id to move to.</param>
        /// <param name="id">Specified the category id to be move.</param>
        /// <param name="pos">Specified the new position to move to.</param>
        void MoveCategory(int parentID, int id, int pos);

        /// <summary>
        /// Gets the categories of specified parent category id.
        /// </summary>
        /// <param name="parentID">Specified the parent category id.</param>
        /// <returns>A collection of the category instances.</returns>
        IEnumerable<Category> GetCategories(int parentID);

        /// <summary>
        /// Track the article when user read.
        /// </summary>
        /// <param name="track">The track object.</param>
        /// <returns>A new Track object.</returns>
        Track AddTrack(Track track);

        /// <summary>
        /// Gets the total read value by specfied article id.
        /// </summary>
        /// <param name="articleID">The article id. </param>
        /// <returns>The integer read value.</returns>
        int GetArticleTotalReads(int articleID);

        /// <summary>
        /// Get a track collection by specified article id ,start date time and end date time.
        /// </summary>
        /// <param name="articleID">The article id.</param>
        /// <param name="start">The start date time.</param>
        /// <param name="end">The end date time.</param>
        /// <returns></returns>
        IEnumerable<Track> GetTracks(int articleID,DateTime start,DateTime end);

        /// <summary>
        /// Get the children articles of specified article id.
        /// </summary>
        /// <param name="articleID">Specified the article id.</param>
        /// <returns></returns>
        IEnumerable<Article> GetChildrenArticles(int articleID);

        /// <summary>
        /// Gets the spaecified article wheather has children articles.
        /// </summary>
        /// <param name="articleID">The parent article id.</param>
        /// <returns></returns>
        bool HasChildrenArticles(int articleID);
    }
}
