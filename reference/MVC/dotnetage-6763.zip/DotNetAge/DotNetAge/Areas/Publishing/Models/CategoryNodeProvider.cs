﻿//  Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.EntityClient;
using System.Data.Objects;

namespace DNA.Mvc.Areas.Publishing.Models
{
    public class CategoryNodeProvider : HierarchicalNodeProviderBase
    {
        private HierarchicalNode _root;
        private Func<HierarchicalNode, bool> popuplateAction;
        private static readonly Func<PubDBEntities, int, Category> compiledGetCategory =
            CompiledQuery.Compile<PubDBEntities, int, Category>((db, id) => db.Categories.FirstOrDefault(c => c.ID == id));
        public CategoryNodeProvider() { }

        public CategoryNodeProvider(Func<HierarchicalNode, bool> expr)
        {
            popuplateAction = expr;
        }

        #region HierarchicalNodeProviderBase members
        private static readonly Func<PubDBEntities, int, IEnumerable<Category>> compiledGetChildren =
           CompiledQuery.Compile<PubDBEntities, int, IEnumerable<Category>>((db, parentID) => (from c in db.Categories orderby c.ID where c.ParentID == parentID select c));

        public override IEnumerable<HierarchicalNode> GetChildNodes(HierarchicalNode node)
        {
            if (node == null)
                throw new ArgumentNullException("node");
            var cat = node.Item as Category;
            int id = 0;
            if (cat != null)
                id = cat.ID;
            using (var db = ConnMan.Instance())
            {
                var _child =compiledGetChildren.Invoke(db,id);
                var nodes = new List<HierarchicalNode>();
                foreach (var _cat in _child)
                {
                    var childrenNode = PopulateNodeForCategory(_cat);
                    if (childrenNode != null)
                        nodes.Add(childrenNode);
                }
                return nodes;
            }
        }

        public override HierarchicalNode GetParentNode(HierarchicalNode node)
        {
            var cat = node.Item as Category;
            if ((cat == null) || (cat.ParentID == 0) || node.Equals(RootNode))
                return null;
            if (cat.ParentID.ToString() == RootNode.Key)
                return RootNode;
            using (var db = ConnMan.Instance())
            {
                return PopulateNodeForCategory(compiledGetCategory.Invoke(db, cat.ParentID));
            }
        }

        public override HierarchicalNode FindNodeFormKey(string key)
        {
            if (string.IsNullOrEmpty(key))
                throw new ArgumentNullException("key");
            int id = int.Parse(key);
            using (var db = ConnMan.Instance())
            {
                return PopulateNodeForCategory(compiledGetCategory.Invoke(db,id));
            }
        }

        private HierarchicalNode PopulateNodeForCategory(Category cat)
        {
            if (cat != null)
            {
                var _node = new HierarchicalNode(this)
                {
                    Title = cat.Title,
                    Description = cat.Description,
                    Key = cat.ID.ToString(),
                    Item = cat,
                    Attributes = ObjectHelper.ConvertObjectToDictionary(new { key = cat.ID.ToString() })
                };

                if (popuplateAction != null)
                {
                    if (!popuplateAction.Invoke(_node))
                        return null;
                }
                return _node;
            }
            return null;
        }

        public override HierarchicalNode RootNode
        {
            get
            {
                if (_root == null)
                {
                    var web = WebSite.CurrentWeb();
                    var cat = web.DefaultCategory();
                    _root = new HierarchicalNode(this)
                    {
                        Title = cat.Title,
                        Description = cat.Description,
                        Key = cat.ID.ToString(),
                        Item = cat,
                        Attributes = ObjectHelper.ConvertObjectToDictionary(new { key = cat.ID.ToString() })
                    };
                    _root.Title = web.Title;
                    if (popuplateAction != null)
                        popuplateAction.Invoke(_root);
                }
                return _root;
            }
            set
            {
                _root = value;
            }
        }

        #endregion
    }
}