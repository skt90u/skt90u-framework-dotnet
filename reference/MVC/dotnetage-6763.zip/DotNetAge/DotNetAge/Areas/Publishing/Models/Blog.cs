﻿//  Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using DNA.Mvc.Models;
using DNA.Mvc.OpenAPI.Rss;
using DNA.Mvc.OpenAPI.BlogML;

namespace DNA.Mvc.Areas.Publishing.Models
{
    /// <summary>
    /// Defines the class that access the user's blog.
    /// </summary>
    public class Blog
    {
        private Category _cat;
        private Web _web;
        private List<Archive> archives;
        private List<Tag> tags;
        private List<Category> categories;
        private Uri url = null;
        int totalPosts = -1;

        /// <summary>
        /// Initialize the blog by specified user identity.
        /// </summary>
        /// <param name="user">The user identity.</param>
        public Blog(System.Security.Principal.IIdentity user) : this(user.Name) { }

        /// <summary>
        /// Initialize the blog by specified blog name.
        /// </summary>
        /// <param name="name">The blog name.</param>
        public Blog(string name)
        {
            this.Name = name;
        }

        #region Properties

        /// <summary>
        /// Gets the blog name.
        /// </summary>
        public string Name { get; private set; }

        /// <summary>
        /// Gets the blog title.
        /// </summary>
        public string Title
        {
            get
            {
                return ParentWeb.Title;
            }
        }

        /// <summary>
        /// Gets the blog description.
        /// </summary>
        public string Description
        {
            get
            {
                return ParentWeb.Description;
            }
        }

        /// <summary>
        /// Gets the totoal post count of the blog.
        /// </summary>
        public int TotalPost
        {
            get
            {
                return DefaultCategory.TotalPosts;
            }
        }

        /// <summary>
        /// Gets the blog owner name.
        /// </summary>
        public string Owner
        {
            get
            {
                return ParentWeb.Owner;
            }
        }

        private System.Web.Security.MembershipUser ownerUser;

        /// <summary>
        /// Gets the owner membership user.
        /// </summary>
        public System.Web.Security.MembershipUser OwnerUser
        {
            get
            {
                if (ownerUser == null)
                    ownerUser = System.Web.Security.Membership.GetUser(Owner);
                return ownerUser;
            }
        }

        /// <summary>
        /// Gets the default category of the blog.
        /// </summary>
        public Category DefaultCategory
        {
            get
            {
                if (_cat == null)
                    _cat = ParentWeb.DefaultCategory();
                return _cat;
            }
        }

        private Web ParentWeb
        {
            get
            {
                if (_web == null)
                    _web = WebSite.Open(Name);
                return _web;
            }
        }

        /// <summary>
        /// Gets the total tags.
        /// </summary>
        public int TotalTags { get; private set; }

        /// <summary>
        /// Gets the tags that the blog in using.
        /// </summary>
        public List<Tag> Tags
        {
            get
            {
                if (tags == null)
                {
                    int total = 0;
                    tags = ParentWeb.GetTags(out total).ToList();
                    TotalTags = total;
                }
                return tags;
            }
        }

        /// <summary>
        /// Gets the archive collection of the blog.
        /// </summary>
        public List<Archive> Archives
        {
            get
            {
                if (archives == null)
                    archives = ParentWeb.GetArchives().ToList();
                return archives;
            }
        }

        /// <summary>
        /// Get children categories of the default category.
        /// </summary>
        public List<Category> Categories
        {
            get
            {
                if (categories == null)
                    categories = DefaultCategory.Children().ToList();
                return categories;
            }
        }

        /// <summary>
        /// Gets the rss feed document of this blog.
        /// </summary>
        public RssDocument RssChannel
        {
            get
            {
                return DefaultCategory.GetRssFeed();
            }
        }

        /// <summary>
        /// Gets the full url of the blog.
        /// </summary>
        public Uri Url
        {
            get
            {
                if (url == null)
                    url = System.Web.Security.Membership.GetUser(this.Owner).GetPermalinkUrl();
                return url;
            }
        }

        #endregion

        /// <summary>
        /// Gets the article instance by specified post id.
        /// </summary>
        /// <param name="id">The post id.</param>
        /// <returns></returns>
        public Article GetPost(int id)
        {
            return this.ParentWeb.FindArticle(id);
        }

        /// <summary>
        /// Create new article in this blog.
        /// </summary>
        /// <param name="article">The article object.</param>
        /// <returns>New article instance.</returns>
        public Article NewPost(Article article)
        {
            if (string.IsNullOrEmpty(article.Language))
                article.Language = ParentWeb.DefaultLanguage;

            return this.DefaultCategory.CreateArticle(article);
        }

        /// <summary>
        /// Create new post by specified the article object and parent category name.
        /// </summary>
        /// <param name="article">The article to new.</param>
        /// <param name="categoryName">The parent category name.</param>
        /// <returns>New article instance.</returns>
        public Article NewPost(Article article, string categoryName)
        {
            var cats = DefaultCategory.GetDescendants();
            if ((cats != null) && (cats.Count() > 0))
            {
                var cat = cats.FirstOrDefault(c => c.Title.Equals(categoryName, StringComparison.OrdinalIgnoreCase));
                if (cat != null)
                    return cat.CreateArticle(article);
            }
            return NewPost(article);
        }

        /// <summary>
        /// Create new post by specified the article object and category names.
        /// </summary>
        /// <param name="article">The article to new.</param>
        /// <param name="categoryNames">The category names.</param>
        /// <returns>New article instance.</returns>
        public Article NewPost(Article article, string[] categoryNames)
        {
            if (string.IsNullOrEmpty(article.Language))
                article.Language = ParentWeb.DefaultLanguage;

            if (categoryNames == null)
                return this.NewPost(article);

            if (categoryNames.Length == 1)
                return this.NewPost(article, categoryNames[0]);

            var cats = DefaultCategory.GetDescendants();
            if ((cats != null) && (cats.Count() > 0))
            {
                var _categories = cats.Where(c => categoryNames.Contains(c.Title));

                if ((_categories.Count() > 0) && (_categories != null))
                {
                    var _cats = _categories.ToList();
                    var primaryCategory = _cats[0];
                    if (_cats.Count > 1)
                        article.Categories = String.Join(",", _cats.Where(c => c.ID != primaryCategory.ID).Select(c => c.ID).ToArray());
                    return primaryCategory.CreateArticle(article);
                }
                else
                    return DefaultCategory.CreateArticle(article);
            }
            return NewPost(article);
        }

        /// <summary>
        /// Add new category to specfied parent category.
        /// </summary>
        /// <param name="category">The parent category</param>
        /// <returns>New category instance.</returns>
        public Category AddCategory(Category category)
        {
            return DefaultCategory.AddChildren(category);
        }

        /// <summary>
        /// Delete the category by specified category id.
        /// </summary>
        /// <param name="categoryID">The category id.</param>
        public void DeleteCategory(int categoryID)
        {
            var cat = ParentWeb.FindCategory(categoryID);
            if (cat != null)
                cat.Delete();
        }

        /// <summary>
        /// Get the recent posts of this blog.
        /// </summary>
        /// <returns></returns>
        public IEnumerable<Article> GetRecentPosts()
        {
            return GetRecentPosts(10);
        }

        /// <summary>
        /// Get the recent posts of this blog and limit the return rows.
        /// </summary>
        /// <param name="returnRows">Specified the return post rows.</param>
        /// <returns></returns>
        public IEnumerable<Article> GetRecentPosts(int returnRows)
        {
            return DefaultCategory.GetRecentArticles(returnRows);
        }

        /// <summary>
        /// Gets the most reads posts.
        /// </summary>
        /// <returns></returns>
        public IEnumerable<Article> GetHotPosts()
        {
            return GetHotPosts(10);
        }

        /// <summary>
        ///  Gets the most reads posts and  limit the return rows.
        /// </summary>
        /// <param name="returnRows">Specified the return post rows.</param>
        /// <returns></returns>
        public IEnumerable<Article> GetHotPosts(int returnRows)
        {
            return ParentWeb.GetHotArticles(returnRows);
        }

        /// <summary>
        /// Gets the recent post comments.
        /// </summary>
        /// <returns></returns>
        public IEnumerable<Comment> GetRecentComments()
        {
            return GetRecentComments(10);
        }

        /// <summary>
        /// Get all categories of this blog.
        /// </summary>
        /// <returns></returns>
        public IEnumerable<Category> GetAllCategories()
        {
            var descendants = DefaultCategory.GetDescendants();
            var cats = new List<Category>();
            cats.Add(DefaultCategory);
            if (cats.Count > 0)
                cats.AddRange(descendants);
            return cats;
        }

        /// <summary>
        /// Gets the recent post comments and limit the return rows.
        /// </summary>
        /// <param name="returnRows">Specified the return post rows.</param>
        /// <returns></returns>
        public IEnumerable<Comment> GetRecentComments(int returnRows)
        {
            return DefaultCategory.GetRecentComments(returnRows);
        }

        /// <summary>
        /// Gets the totoal posts of this blog.
        /// </summary>
        public int TotalPosts
        {
            get
            {
                if (totalPosts == -1)
                    totalPosts = DefaultCategory.GetDescendantArticles().Count();
                return totalPosts;
            }
        }

        /// <summary>
        /// Export the blog to BlogML format
        /// </summary>
        /// <returns></returns>
        public string ExportToXml()
        {
            var bmlBlog = new BlogMLBlog()
            {
                Title = this.Title,
                RootUrl = this.ParentWeb.GetFullUrl() + "/index.html",
                SubTitle = this.Description,
                DateCreated = this.ParentWeb.Created,
                Authors=new List<BlogMLAuthor>(),
                Categories=new List<BlogMLCategory>()
            };
            
            ///UNDONE:Export the post to BlogML
            bmlBlog.Authors.Add(new BlogMLAuthor() {
              Approved=OwnerUser.IsApproved,
              Email=OwnerUser.Email,
              ID=Owner,
              Title=OwnerUser.GetDisplayName(),
              DateModified=OwnerUser.LastActivityDate
            });

            var cats=DefaultCategory.GetDescendants();
            if (cats!=null) 
            {
                if (cats.SingleOrDefault(c => c.ID == DefaultCategory.ID)==null) 
                {
                    bmlBlog.Categories.Add(new BlogMLCategory()
                    {
                        Description = DefaultCategory.Description,
                        ID = DefaultCategory.ID.ToString(),
                        ParentRef = DefaultCategory.ParentID.ToString(),
                        Title = DefaultCategory.Title,
                        Approved=true,
                        DateCreated=DateTime.Now,
                        DateModified=DateTime.Now
                    });
                }

                foreach (var cat in cats){
                    bmlBlog.Categories.Add(new BlogMLCategory() { 
                     Description=cat.Description,
                     ID=cat.ID.ToString(),
                     ParentRef=cat.ParentID.ToString(),
                     Title=cat.Title,
                     Approved = true,
                     DateCreated = DateTime.Now,
                     DateModified = DateTime.Now
                    });
 
                }

                var posts = DefaultCategory.GetDescendantArticles();
                if ((posts != null) && (posts.Count() > 0))
                {
                    bmlBlog.Posts = new List<BlogMLPost>();
                    foreach (var post in posts)
                    {
                        var bmlPost = new BlogMLPost()
                        {
                            ID = post.ID.ToString(),
                            DateCreated = post.Posted,
                            DateModified = post.LastModified,
                            HasExcerpt = !string.IsNullOrEmpty(post.Summary),
                            Excerpt = new BlogMLContent()
                            {
                                Text = post.Summary
                            },
                            PostName = post.Title,
                            PostUrl = post.GetPermaLinkUrl(),
                            PostType=BlogPostTypes.Article,
                            Content = new BlogMLContent()
                            {
                                Text = post.Body
                            },
                            Approved = post.IsPublished,
                            Authors = new List<BlogMLAuthorRef>(),
                            Categories=new List<BlogMLCategoryRef>()
                        };

                        bmlBlog.Posts.Add(bmlPost);

                        /// Exporting categories
                        bmlPost.Categories.Add(new BlogMLCategoryRef() { Ref=post.CategoryID.ToString() });
                        if (!string.IsNullOrEmpty(post.Categories))
                        {
                            var postCats = post.Categories.Split(',');
                            foreach (var c in postCats)
                                bmlPost.Categories.Add(new BlogMLCategoryRef() { Ref=c });
                        }

                        #region Export comments and trackbacks
                        bmlPost.Authors.Add(new BlogMLAuthorRef() { Ref=post.UserName});
                        var comments = post.GetComments();
                        
                        if ((comments != null) && (comments.Count() > 0))
                        {
                            bmlPost.Trackbacks = new List<BlogMLTrackback>();
                            bmlPost.Comments = new List<BlogMLComment>();
                            foreach (var comm in comments)
                            {
                                if ((comm.IsPingback) || (comm.IsTrackback))
                                {
                                    bmlPost.Trackbacks.Add(new BlogMLTrackback()
                                    {
                                        Approved = true,
                                        DateCreated = comm.Posted,
                                        DateModified = comm.Posted,
                                        ID = comm.ID.ToString(),
                                        Title = comm.Title,
                                        Url = comm.WebSite
                                    });
                                }
                                else
                                {
                                    bmlPost.Comments.Add(new BlogMLComment()
                                    {
                                        ID = comm.ID.ToString(),
                                        Approved = true,
                                        Content = new BlogMLContent() { Text = comm.Body },
                                        DateCreated=comm.Posted,
                                        DateModified=comm.Posted,
                                        Title=comm.Title,
                                        UserEMail=comm.Email,
                                        UserName=comm.UserName,
                                        UserUrl=comm.WebSite
                                    });
                                }
                            }
                        }
                        #endregion 

                        ///TODO:Export the resource to attachments.
                    }
                }
            }
            return DNA.Utility.XmlSerializerUtility.SerializeToXml(typeof(BlogMLBlog), bmlBlog);
        }

        /// <summary>
        /// Import the blogML xml file
        /// </summary>
        /// <returns></returns>
        public void ImportFromXml(string xml)
        {
            if (string.IsNullOrEmpty(xml))
                throw new ArgumentNullException("xml");
            var _blog = (BlogMLBlog)DNA.Utility.XmlSerializerUtility.DeserializeFromXmlText(xml, typeof(BlogMLBlog));
            var rootChildren = DefaultCategory.Children();

            //if (_blog.Categories != null)
            //{
            //    var rootCategories = _blog.Categories.Where(c => c.ParentRef.Equals("0"));
            //    foreach (var cat in rootCategories)
            //    {
            //        if (rootChildren.Count() > 0)
            //        {
            //            var _existsCat=rootChildren.FirstOrDefault(c => c.Title.Equals(cat.Title, StringComparison.OrdinalIgnoreCase));
            //            if (_existsCat.)
            //        }
            //    }
            //}
        }
    }


}