﻿//  Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Objects;
using System.Data.Objects.DataClasses;
using System.Data.EntityClient;
using System.Data;
using System.Web.Caching;

namespace DNA.Mvc.Areas.Publishing.Models
{
    public static class ConnMan
    {
        public static EntityConnection CreateConnection()
        {
            string connString = System.Web.Configuration.WebConfigurationManager.ConnectionStrings["PubDBEntities"].ConnectionString;
            return new EntityConnection(connString);
        }

        public static EntityConnection Connection
        {
            get
            {
                Cache cache = HttpContext.Current.Cache;
                string key = "dna_webpub_connection";
                var connection = cache.Get(key);
                if (connection == null)
                {
                    connection = CreateConnection();
                    cache.Add(key, connection, null, Cache.NoAbsoluteExpiration, TimeSpan.FromMinutes(30), CacheItemPriority.High, null);
                }
                return (EntityConnection)connection;
            }
        }

        public static void KeepConnectionOpen()
        {
            try
            {
                if (Connection.State != ConnectionState.Open)
                {
                    Connection.Close();
                    Connection.StoreConnection.Close();

                    Connection.Open();
                    if (Connection.StoreConnection.State != ConnectionState.Open)
                        Connection.StoreConnection.Open();
                }
            }
            catch (Exception e) 
            {
                HttpContext.Current.Cache.Remove("dna_webpub_connection");
                DNA.Mvc.Installation.DeploymentHelper.RestartWeb();
                //Connection.Open();
            }
        }

        public static PubDBEntities Instance()
        {
            return Instance(true);
        }

        public static PubDBEntities Instance(bool keepConnectionOpen)
        {
            var db = new PubDBEntities(Connection);

            if (keepConnectionOpen)
                KeepConnectionOpen();

            return db;
        }
    }
}