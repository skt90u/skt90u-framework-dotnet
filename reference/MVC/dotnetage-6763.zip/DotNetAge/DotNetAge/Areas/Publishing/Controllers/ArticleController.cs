//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using System.Xml.Linq;
using DNA.Mvc.Areas.Publishing.Models;
using DNA.Mvc.DynamicUI;
using DNA.Mvc.Security;
using DNA.Mvc.jQuery;

namespace DNA.Mvc.Areas.Publishing.Controllers
{
    [Log]
    public partial class ArticleController : Controller
    {
        [SiteMapAction(Title = "Publishing")]
        public ActionResult Index()
        {
            int totalRecords = 0;
            ViewData.Model = this.CurrentWeb().GetRecentArticles(20);
            ViewData["TotalRecords"] = totalRecords;
            return View();
        }

        [OutputCache(Duration = 3600, VaryByParam = "*")]
        public ActionResult RssFeed(int id)
        {
            var channel = this.CurrentWeb().FindArticle(id).GetCommentsRssFeed();
            string xml = DNA.Utility.XmlSerializerUtility.SerializeToXml(typeof(DNA.Mvc.OpenAPI.Rss.RssChannel), channel);
            xml = xml.Replace("<?xml version=\"1.0\" encoding=\"utf-8\"?>", "<rss version=\"2.0\">");
            return Content(xml, "text/xml");
        }

        [OutputCache(Duration = 3600, VaryByParam = "*")]
        public ActionResult AtomFeed(int id)
        {
            var channel = this.CurrentWeb().FindArticle(id).GetCommentsAtomFeed();
            string xml = DNA.Utility.XmlSerializerUtility.SerializeToXml(typeof(DNA.Mvc.OpenAPI.Atom.AtomFeed), channel);
            return Content(xml, "text/xml");
        }

        [SiteMapAction(
            Title = "Articles",
            PersonalTitle = "Blog",
            IsShared = true,
            IgnoreRouteDataKeys = new string[] { "path" })]
        public ActionResult List(string path)
        {
            Category category = null;
            //Root
            if (string.IsNullOrEmpty(path))
            {
                category = WebContext.Current.Web.DefaultCategory();
                ViewData["Title"] = "Uncategorized";
            }
            else
            {
                category = WebContext.Current.Web.DefaultCategory().FindCategory(path);
                ViewData["Title"] = category.Title;
            }

            ViewData["Category"] = category;
            List<Article> posts = new List<Article>();

            posts = category.GetChildrenArticles().ToList();

            if (posts.Count > 0)
                return View(posts.OrderByDescending(p => p.Posted).ToList());
            ViewData.Model = posts;
            return View();
        }

        //[SiteMapAction(Title = "Blog",
        //    IsShared = true,
        //    IgnoreRouteDataKeys = new string[] { "id" })]
        //public ActionResult BlogPosts(int? id)
        //{
        //    List<Article> posts = new List<Article>();
        //    if (id.HasValue)
        //    {
        //        var cat = this.CurrentContext().Web.FindCategory(id.Value);

        //        //Internal use
        //        //WebContext.Current.SetCurrent(cat!=null ? cat : this.CurrentWeb().DefaultCategory());
        //        posts = cat != null ? cat.GetChildrenArticles().ToList() : this.CurrentWeb().DefaultCategory().GetChildrenArticles().ToList();
        //        ViewData["Title"] = cat.Title;
        //    }
        //    else
        //    {
        //        posts = this.CurrentWeb().DefaultCategory().GetChildrenArticles().ToList();
        //        ViewData["Title"] = "Uncategorized";
        //    }
        //    if (posts.Count > 0)
        //        return View(posts.OrderByDescending(p => p.Posted).ToList());
        //    ViewData.Model = posts;
        //    return View();
        //}

        [SiteMapAction(
            Title = "View article",
            PersonalTitle = "View post",
            IsShared = true,
            ShowInMenu = false,
            IgnoreRouteDataKeys = new string[] { "id", "year", "month", "day", "title" }
            )]
        [HttpGet]
        public ActionResult Details(int id)
        {
            var article = this.CurrentWeb().FindArticle(id);

            if ((!article.IsPublished) || (article.IsPrivate))
            {
                if (!article.IsOwner())
                    throw new PageNotFoundException();
            }

            ViewData.Model = article;

            //Internal use
            //WebContext.Current.SetCurrent(article);

            ViewData["Articles"] = article.Category.GetChildrenArticles();
            if (ControllerContext.HttpContext.Request.IsAuthenticated)
                if ((article.UserName.ToLower() != ControllerContext.HttpContext.User.Identity.Name.ToLower()))
                    return View();

            Uri uri = null;
            Uri.TryCreate(article.GetPermaLinkUrl(), UriKind.Absolute, out uri);
            //if (!HttpContext.Request.Url.Host.Equals(uri.Host, StringComparison.OrdinalIgnoreCase))
            if (article.IsPublished)
                article.Read();

            /*Set seo meta*/
            SEOHelper.SetTitle(article.Title);
            if (!string.IsNullOrEmpty(article.Summary))
                SEOHelper.SetDescription(article.Summary);
            else
            {
                if (!string.IsNullOrEmpty(article.Body))
                 SEOHelper.SetDescription(TextUtility.ClearHtml(article.Body).Substring(0,150));
            }
            var keywords=new List<string>();
            if (!string.IsNullOrEmpty(article.Tags))
                keywords.AddRange(article.Tags.Split(','));
            
            if (!string.IsNullOrEmpty(article.Categories))
                keywords.AddRange(article.Categories.Split(','));
            keywords.Add(article.Category.Title);
            SEOHelper.SetKeywords(string.Join(",", keywords.Distinct().ToArray()));
            return View();
        }

        public ActionResult WebLayout()
        {
            return View();
        }

        public ActionResult WebPreview()
        {
            return View();
        }

        [SecurityAction("Publishing", "Move article", "Allows user can change the article's position.")]
        public void Move(int id, int pos, int? categoryID)
        {
            var article = this.CurrentWeb().FindArticle(id);
            if (article == null)
                throw new ArgumentOutOfRangeException("id");
            article.Move((categoryID.HasValue ? categoryID.Value : -1), pos);
        }

        [SecurityAction("Publishing", "Write article", "Allows user go to the write article page.")]
        public ActionResult Create(int? format)
        {
            ViewData["Format"] = format.HasValue ? format.Value : (int)DNA.Mvc.Text.TextFormats.Xhtml;
            return View();
        }

        [HandleError]
        [SecurityAction("Publishing", "Post new article", "Allows user post a new article.")]
        [HttpPost]
        [ValidateInput(false)]
        [ValidateAntiForgeryToken]
        public ActionResult Create(Article article)
        {
            if (ModelState.IsValid)
            {
                article.IsAppoved = true;
                article.Language = this.CurrentWeb().DefaultLanguage;
                //article.Body = HttpContext.Server.HtmlEncode(article.Body);
                article.Update();
                return Redirect(article.GetPermaLinkUrl());
                //return RedirectToAction("Details", new { id = article.ID });
            }
            return View();
        }

        [HandleError]
        [SecurityAction("Publishing", "Delete article", "Allows user to delete the article")]
        public ActionResult Delete(int id)
        {
            var article = this.CurrentWeb().FindArticle(id);// Service.GetArticle(id);
            if (article == null)
                throw new ArgumentOutOfRangeException("Article not found");
            var catID = article.CategoryID;
            article.Delete();
            return RedirectToAction("List", new { id = catID });
        }

        [HandleError]
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        public ActionResult AddComment(int id, FormCollection form)
        {
            var article = this.CurrentWeb().FindArticle(id);
            if (article == null)
                throw new ArgumentOutOfRangeException("Article not found");

            //if (!article.CategoryReference.IsLoaded) article.CategoryReference.Load();

            if ((!HttpContext.Request.IsAuthenticated) && (!article.Category.AllowAnonymousPostComment))
                throw new ArgumentOutOfRangeException();

            var comment = new Comment();

            if (TryUpdateModel<Comment>(comment))
            {
                if ((article.Category.AllowAnonymousPostComment) && (!HttpContext.Request.IsAuthenticated))
                {
                    bool isExists = System.Web.Security.Membership.GetUser(comment.UserName) != null;
                    if (isExists)
                    {
                        ViewData.ModelState.AddModelError("UserName", "The user name is exists,please use another name or login first.");
                        return View();
                    }
                    else
                    {
                        isExists = !string.IsNullOrEmpty(System.Web.Security.Membership.GetUserNameByEmail(comment.Email));
                        if (isExists)
                        {
                            ViewData.ModelState.AddModelError("Email", "The email is exists ,please use another email address or login first.");
                            return View();
                        }
                    }
                }
                comment.Title = "Re:" + article.Title;
                comment.IP = HttpContext.Request.UserHostAddress;
                article.AddComment(comment);
                //Service.AddComment(id, comment);
                ViewData["Success"] = true;
            }

            return View();
        }

        public ActionResult AddComment(int id)
        {
            return View();
        }

        public ActionResult Comments(int id)
        {
            ViewData.Model = this.CurrentWeb().FindArticle(id);// Service.GetArticle(id);
            return View();
        }

        [HandleError]
        [SecurityAction("Publishing", "Article editing", "Allows user can edit the article.")]
        public ActionResult Edit(int id, int? format)
        {
            Article article = this.CurrentWeb().FindArticle(id);
            if (!article.IsOwner())
                throw new PageNotFoundException();
            ViewData.Model = article;
            ViewData["Format"] = format.HasValue ? format.Value : article.ContentFormat;
            return View();
        }

        [HandleError]
        [SecurityAction("Publishing", "Post article changed", "Allows user posts the changes of the article.")]
        [HttpPost]
        [ValidateInput(false)]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, FormCollection form)
        {
            var article = this.CurrentWeb().FindArticle(id);
            if (!article.IsOwner())
                throw new PageNotFoundException();

            if (TryUpdateModel<Article>(article))
            {
                //article.Body = HttpContext.Server.HtmlEncode(article.Body);
                article.Update();
                return Redirect(article.GetPermaLinkUrl());
                //return RedirectToAction("Details", new { id = article.ID });
            }

            ViewData.Model = article;
            return View();
        }

        [HandleError]
        [SecurityAction("Publishing", "Translate", "Allows user can go to the translate page.")]
        public ActionResult Translate(int id, string lang)
        {
            var article = this.CurrentWeb().FindArticle(id);
            var tcopy = article.GetTranslatedCopy(lang);
            if (tcopy != null)
                ViewData.Model = tcopy;
            ViewData["Article"] = article;
            var targetCulture = new System.Globalization.CultureInfo(lang);
            ViewData["TargetCulture"] = targetCulture;
            return View();
        }

        [HandleError]
        [SecurityAction("Publishing", "Post translate copy", "Allows user can post the translate copy of the article.")]
        [HttpPost]
        [ValidateAntiForgeryToken]
        [ValidateInput(false)]
        public ActionResult Translate(int id, string lang, FormCollection form)
        {
            var article = this.CurrentWeb().FindArticle(id);
            if (article == null)
                throw new ArgumentNullException("Article not found");
            var tcopy = article.GetTranslatedCopy(lang);
            if (tcopy == null)
                tcopy = new TranslatedCopy() { ArticleID = id };

            if (TryUpdateModel<TranslatedCopy>(tcopy, new string[] { "Title", "Body", "Summary" }))
            {
                tcopy.Language = lang;
                tcopy.ContentFormat = article.ContentFormat;
                tcopy.Update();
                return RedirectToAction("Details", new { id = id });
            }

            return RedirectToAction("Translate", new { id = id, lang = lang });
        }

        [HttpPost]
        public double Rating(int id, int value)
        {
            int total = 0;
            var article = this.CurrentWeb().FindArticle(id);
            return article.Vote(value, out total);
        }

        [HandleError]
        public ActionResult Search(SearchOption option)
        {
            ViewData.Model = this.CurrentWeb().SearchArticles(option);
            // Service.Search(option);
            ViewData["Option"] = option;
            return View();
        }

        [HandleError]
        public ActionResult Archive(int year, int month)
        {
            var option = new SearchOption()
            {
                Archive = year.ToString() + "/" + month.ToString(),
                Sortby = ArticleSorts.PostDate,
                SortOrder = ArticleOrders.Desc
            };
            ViewData.Model = this.CurrentWeb().SearchArticles(option);
            ViewData["Option"] = option;
            return View("Search");
        }

        public ActionResult History(int id)
        {
            Article article = this.CurrentWeb().FindArticle(id);
            //if (!article.Histories.IsLoaded)
            //     article.Histories.Load();
            ViewData.Model = article;
            return View();
        }

        public ActionResult ManageList()
        {
            return View();
            //var cat = this.CurrentWeb().FindCategory(id);
            ////if (!cat.Articles.IsLoaded) cat.Articles.Load();
            //var articles = cat.GetChildrenArticles().ToList();
            //if (articles.Count > 0)
            //    View(articles.OrderBy(a => a.Pos));
            //return View(articles);
        }

        /// <summary>
        /// Get articles by specified category id (new for DNA2)
        /// </summary>
        /// <param name="id"></param>
        /// <param name="_params"></param>
        /// <returns></returns>
        [Pagable]
        public ActionResult GetArticles(int id, QueryParams _params)
        {
            var cat = this.CurrentWeb().FindCategory(id);
            int total = 0;
            var articles = cat.GetChildrenArticles(_params.Index, _params.Size, out total);

            return View(new ModelWrapper<Article>()
            {
                Total = total,
                Model = articles
            });
        }

        public ActionResult GetLatestArticles(int? top=20)
        {
            
            return View(this.CurrentWeb().GetRecentArticles(top.Value));
        }
    }
}
