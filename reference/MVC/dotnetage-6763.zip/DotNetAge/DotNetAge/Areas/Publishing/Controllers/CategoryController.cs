﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using DNA.Mvc.Areas.Publishing.Models;
using DNA.Mvc.Security;
using DNA.Mvc.DynamicUI;
using DNA.Mvc.Models;
using System.IO;

namespace DNA.Mvc.Areas.Publishing.Controllers
{
    public class CategoryController : Controller
    {
        [SecurityAction("Publishing", "Edit category", "Can shows the  category editing ui to users. ")]
        public ActionResult Edit(int id)
        {
            ViewData.Model = this.CurrentWeb().FindCategory(id);
            return PartialView();
        }

        [SecurityAction("Publishing", "Save category", "Allows user to post the changes of the category.")]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, FormCollection forms)
        {
            var cat = this.CurrentWeb().FindCategory(id);
            if (TryUpdateModel<Category>(cat, "Category"))
            {
                if ((cat.Title.Equals("{blogs}", StringComparison.OrdinalIgnoreCase)) || (cat.Title.Equals("{site}", StringComparison.OrdinalIgnoreCase)))
                {
                    ModelState.AddModelError("", "Could not accept your category title.");
                    return View(cat);
                }
                cat.Update();
            }
            return View(cat);
        }

        [SecurityAction("Publishing", "Delete category", "Allows user can delete the categories.")]
        [HttpPost]
        public void Delete(int id)
        {
            if (id == 0)
                throw new ArgumentOutOfRangeException("id");
            var cat = this.CurrentWeb().FindCategory(id);
            //Service.DeleteCategory(id);
            if (cat == null)
                throw new CategoryNotFoundException();
            cat.Delete();
        }

        [SecurityAction("Publishing", "Create category", "Can show the category creating ui to users.")]
        public ActionResult Create(int id)
        {
            if (id > 0)
                ViewData.Model = this.CurrentWeb().FindCategory(id);// Service.GetCategory(id);
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [SecurityAction("Publishing", "Post new category", "Allows user post a new category.")]
        public ActionResult Create(int id, [Bind(Prefix = "Category")] Category cat)
        {
            if ((cat.Title.Equals("{blogs}", StringComparison.OrdinalIgnoreCase)) || (cat.Title.Equals("{site}", StringComparison.OrdinalIgnoreCase)))
                ModelState.AddModelError("", "Could not accept your category title.");

            if (ModelState.IsValid)
            {
                this.CurrentWeb().AddCategory(id, cat);
                //Service.AddCategory(id, cat);
                return View("CreateSuccess", cat);
                // RedirectToAction("Edit", new { id = cat.ID });
                //return Json(cat, JsonRequestBehavior.AllowGet);
            }
            return View();
        }

        [HttpPost]
        public int Add(int id, string title)
        {
            if (!HttpContext.Request.IsAuthenticated)
                throw new UnauthorizedAccessException();

            var web = this.CurrentWeb();

            if (web.IsRoot)
            {
                if (!this.IsAuthorize("Create"))
                    throw new UnauthorizedAccessException("Access defined.");
            }
            else
                if (!User.IsWebOwner()) throw new UnauthorizedAccessException("Access defined.");

            if (string.IsNullOrEmpty(title))
                throw new ArgumentNullException("title");

            var cat = web.FindCategory(id);
            var newCat = new Category()
            {
                Title = title,
                ArticleType = (int)(web.IsRoot ? ArticleTypes.Public : ArticleTypes.Personal),
                AllowAnonymousPostComment = false,
                IsModerated = false
            };
            cat.AddChildren(newCat);
            return newCat.ID;
        }

        public void Move(int id, int parentID, int pos)
        {
            if (id <= 0) throw new ArgumentOutOfRangeException("id");
            if (id == parentID) throw new ArgumentException("The parentID is point to itselft");
            var cat = this.CurrentWeb().FindCategory(id);
            if (cat == null)
                throw new CategoryNotFoundException();
            cat.Move(parentID, pos);
            //Service.MoveCategory(parentID, id, pos);
        }

        [SiteControlPanel("Publishing", Order = 6, ResBaseName = "publishing", ResKey = "publishing")]
        [MyControlPanel("Publishing", Order = 6, ResBaseName = "publishing", ResKey = "publishing", ShowInPersonalSiteOnly = true)]
        [SecurityAction("Publishing", "Publishing setting panel", "Allows user using the Publishing setting panel.")]
        public ActionResult Settings()
        {
            return PartialView();
        }

        public ActionResult CatRoot()
        {
            var web = WebSite.Open(RouteData);
            if (web.Properties.ContainsKey("PublishingRoot"))
                ViewData["Root"] = web.Properties["PublishingRoot"];
            return View();
        }

        [OutputCache(Duration = 3600, VaryByParam = "*")]
        public ActionResult RssFeed(int id)
        {
            var doc = this.CurrentWeb().FindCategory(id).GetRssFeed();
            string xml = DNA.Utility.XmlSerializerUtility.SerializeToXml(typeof(DNA.Mvc.OpenAPI.Rss.RssDocument), doc);
            return Content(xml, "text/xml");
        }

        [OutputCache(Duration = 3600, VaryByParam = "*")]
        public ActionResult AtomFeed(int id)
        {
            var channel = this.CurrentWeb().FindCategory(id).GetAtomFeed();
            string xml = DNA.Utility.XmlSerializerUtility.SerializeToXml(typeof(DNA.Mvc.OpenAPI.Atom.AtomFeed), channel);
            return Content(xml, "text/xml");
        }

        public ActionResult Opml()
        {
            var doc = this.CurrentWeb().GetOpmlDocument();
            string xml = DNA.Utility.XmlSerializerUtility.SerializeToXml(typeof(DNA.Mvc.OpenAPI.Opml.OpmlDocument), doc);
            return Content(xml,"text/xml");
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult CatRoot(string rootText)
        {
            if (!string.IsNullOrEmpty(rootText))
            {
                var web = this.CurrentWeb();
                if (!web.Properties.ContainsKey("PublishingRoot"))
                    web.Properties.Add("PublishingRoot", rootText);
                else
                    web.Properties["PublishingRoot"] = rootText;
                //WebSite.Update(web);
                web.Update();
                ViewData["Root"] = web.Properties["PublishingRoot"];
            }
            return View();
        }

        [Widget("Categories", "Display all children categories as a link list",
            Category = "Publishing",
            ShowBorder = true,
            ShowHeader = true,
            ImageUrl = "~/Content/Images/Widgets/cat.png",
            IconUrl = "~/Content/Images/Widgets/cat_16.png"
            )]
        [Property("CategoryID", ValueType = typeof(int), DefaultValue = 0)]
        [Property("ShowAsMenu",ValueType=typeof(bool),DefaultValue=false)]
        public ActionResult CategoryNav(int categoryID)
        {
            ViewData.Model= this.CurrentWeb().FindCategory(categoryID);
            return PartialView();
        }

        public ActionResult Export()
        {
            var blog = new Blog(this.CurrentWeb().Name);
             return Content(blog.ExportToXml(),"text/xml");
        }

        public ActionResult Import()
        {
            try
            {
                if (Request.Files.Count == 0)
                {
                    HttpContext.Response.StatusCode = 204;
                    return Content("No Content");
                }
                var blog = new Blog(this.CurrentWeb().Name);
                var file = Request.Files[0];
                var reader=new StreamReader(Request.Files[0].InputStream);
                string xml=reader.ReadToEnd();
                blog.ImportFromXml(xml);
                //var fileInfo = new FileInfo(file.FileName);
                //Web.SaveFile(file.FileName, FileUtilty.ReadStream(file.InputStream), HttpContext.Request.Url);
            }
            catch (Exception e)
            {
                HttpContext.Response.StatusCode = 424;
                return Content("Method Failure - " + e.Message);
            }

            HttpContext.Response.StatusCode = 201;
            return Content("OK");
        }
    }
}
