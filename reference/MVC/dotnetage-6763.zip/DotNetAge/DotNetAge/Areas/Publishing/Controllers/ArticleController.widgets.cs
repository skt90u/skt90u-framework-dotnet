﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using DNA.Mvc.DynamicUI;
using DNA.Mvc.Areas.Publishing.Models;

namespace DNA.Mvc.Areas.Publishing.Controllers
{
    [HandlePartialError]
    public partial class ArticleController
    {

        [Widget("Archives",
            "Display an archive list of the current web.",
            Category = "Publishing",
             ShowBorder = true,
             ShowHeader = true,
             ImageUrl = "~/Content/Images/Widgets/calendar.png",
             IconUrl = "~/Content/Images/Widgets/calendar_16.png"
            )]
        [Property("CategoryID", ValueType = typeof(int), DefaultValue = 0)]
        public ActionResult Archives(int categoryID)
        {
            ViewData.Model = this.CurrentWeb().GetArchives();
            return View();
        }

        [Widget("TagCloud", "Display the tag cloud of current web.",
            Category = "Publishing",
             ShowBorder = true,
             ShowHeader = true,
             ImageUrl = "~/Content/Images/Widgets/tag.png",
             IconUrl = "~/Content/Images/Widgets/tag_16.png")]
        [Property("MaximumTags", ValueType = typeof(int), DefaultValue = -1)]
        public ActionResult TagCloud()
        {
            int count = 0;
            ViewData.Model = this.CurrentWeb().GetTags(out count);
            ViewData["Count"] = count;
            return View();
        }


        [Widget("Headlines",
            Category = "Publishing",
            Description = "Display recent articles title link list of specified category.You can use this widget to display the headline news.",
            ShowBorder = true,
            ShowHeader = true,
            ImageUrl = "~/Content/Images/Widgets/headline.png",
            IconUrl = "~/Content/Images/Widgets/headline_16.png"
            )]
        [Property("CategoryID", ValueType = typeof(int), DefaultValue = 0)]
        [Property("TextLen", ValueType = typeof(int), DefaultValue = -1)]
        [Property("Rows", ValueType = typeof(int), DefaultValue = 20)]
        [Property("ShowAuthor", ValueType = typeof(bool), DefaultValue = true, PropertyControl = ControlTypes.Checkbox)]
        [Property("ShowDate", ValueType = typeof(bool), DefaultValue = true, PropertyControl = ControlTypes.Checkbox)]
        public ActionResult HeadLines(int categoryID, int rows, bool showAuthor, bool showDate)
        {
            var articles = categoryID > 0 ? WebContext.Current.Web.FindCategory(categoryID).GetRecentArticles(rows) :
                WebContext.Current.Web.DefaultCategory().GetRecentArticles(rows);
            //if (articles.Count() > 0)
            //    return View(articles.OrderByDescending(a => a.Posted).ToList());

            return View(articles);
        }

        [Widget("MultiHeadLines",
            Category = "Publishing",
            Description = "Display a multi tab head lines ui.This Widget will load the children categories of specified cateogry and show them in to multi tabs.",
            ShowBorder = true,
            ShowHeader = true,
            ImageUrl = "~/Content/Images/Widgets/multiheadlines.png",
            IconUrl = "~/Content/Images/Widgets/multiheadlines_16.png"
            )]
        [Property("CategoryID", ValueType = typeof(int), DefaultValue = 0)]
        [Property("TextLen", ValueType = typeof(int), DefaultValue = -1)]
        [Property("Rows", ValueType = typeof(int), DefaultValue = 10)]
        [Property("ShowAuthor", ValueType = typeof(bool), DefaultValue = true, PropertyControl = ControlTypes.Checkbox)]
        [Property("ShowDate", ValueType = typeof(bool), DefaultValue = true, PropertyControl = ControlTypes.Checkbox)]
        public ActionResult MultiHeadLines(int categoryID)
        {
            var cats = (categoryID <= 0) ? this.CurrentWeb().DefaultCategory().Children() : this.CurrentContext().Web.FindCategory(categoryID).Children();
            var children = new List<Category>();
            foreach (var c in cats)
            {
                if (c.HasArticles())
                    children.Add(c);
            }
            return View(children);
        }

        [Widget("HotReads",
            Category = "Publishing",
            Description = "HotReads is a widget that search the most reads article/blog post of the web site and display in a link list."
            )]
        [Property("Rows", ValueType = typeof(int), DefaultValue = 10)]
        public ActionResult HotReads(int rows)
        {
            var articles = this.CurrentWeb().GetHotArticlesOfSite(rows);
            return View(articles);
        }


        [Widget("RecentBlogPost",
                  Category = "Publishing",
                  Scope = Scopes.Personal,
                  Description = "Display the recent blog posts of current website in a title link list."
                  )]
        [Property("Rows", ValueType = typeof(int), DefaultValue = 10)]
        [Property("TextLen", ValueType = typeof(int), DefaultValue = -1)]
        [Property("ShowAuthor", ValueType = typeof(bool), DefaultValue = true, PropertyControl = ControlTypes.Checkbox)]
        [Property("ShowDate", ValueType = typeof(bool), DefaultValue = true, PropertyControl = ControlTypes.Checkbox)]
        public ActionResult RecentBlogPost(int rows)
        {
            //site only
            return View(this.CurrentWeb().GetRecentBlogPosts(rows));
        }

        [Widget("BlogRoll",
                  Category = "Publishing",
                  Description = "BlogRoll is a widget that display a list contains the most actively bloggers.")]
        [Property("Rows", ValueType = typeof(int), DefaultValue = 10)]
        public ActionResult BlogRoll(int rows)
        {
            return View(WebSite.Open().GetBlogs(rows));
        }

        [Widget("RecentComments",
            Description = "Display the recent comments of current web.",
            Category = "Publishing",
            ShowBorder = true,
            ShowHeader = true,
             ImageUrl = "~/Content/Images/Widgets/comment.png",
             IconUrl = "~/Content/Images/Widgets/comment_16.png"
            )]
        [Property("Rows", ValueType = typeof(int), DefaultValue = 10)]
        public ActionResult RecentComments(int rows)
        {
            var comments = this.CurrentWeb().DefaultCategory().GetRecentComments(rows);
            return View(comments);
        }

        [Widget("SummaryView",
            Category = "Publishing",
            ShowHeader = false,
            ShowBorder = false)]
        [Property("CategoryID", ValueType = typeof(int), DefaultValue = 0)]
        [Property("IncludeSubCategory", ValueType = typeof(bool), DefaultValue = false)]
        [Property("Rows", ValueType = typeof(int), DefaultValue = 10)]
        public ActionResult SummaryView(int categoryID, bool includeSubCategory,int rows)
        {
            var cat = this.CurrentWeb().FindCategory(categoryID);
            
            if (cat != null)
            {
                if (includeSubCategory)
                    return View(cat.GetDescendantArticles(rows).OrderByDescending(a => a.Posted).ToList());
                else
                    return View(cat.GetChildrenArticles(rows).OrderByDescending(a => a.Posted).ToList());
            }
            if (includeSubCategory)
                return View(WebContext.Current.Web.DefaultCategory().GetDescendantArticles(rows).ToList());
            else
                return View(WebContext.Current.Web.DefaultCategory().GetChildrenArticles(rows).ToList());
        }

        [Widget("ArticleMenu",
            Category = "Publishing",
            ImageUrl = "~/Content/Images/Widgets/articlemenu.png",
            IconUrl = "~/Content/Images/Widgets/articlemenu_16.png",
            ShowHeader = false,
            ShowBorder = true)]
        [Property("CategoryID", ValueType = typeof(int), DefaultValue = 0)]
        [Property("TextLen", ValueType = typeof(int), DefaultValue = -1)]
        public ActionResult Navigator(int categoryID)
        {
            var cat = this.CurrentWeb().FindCategory(categoryID);
            if (cat != null)
                return View(cat.GetChildrenArticles().OrderBy(a => a.Pos).ToList());
            return View(this.CurrentContext().Web.DefaultCategory().GetChildrenArticles().OrderBy(a => a.Pos).ToList());
        }

        [Widget("MyActions",
            Category = "Publishing",
            Description = "Auto search actions for current user."
         )]
        public ActionResult MyActions()
        {
            //var context = WebContext.Current;
            //if ((context.RouteData.Route != null) && (context.RouteData.Route != null))
            //{
            //    var route = (System.Web.Routing.Route)context.RouteData.Route;
            //    if (route.Url.Equals("publishing/{website}/{year}/{month}/{day}/{id}/{title}.html", StringComparison.OrdinalIgnoreCase))
            //    {
            //        var id = (int)context.RouteData.Values["id"];
            //        return View(context.Web.FindArticle(id));
            //    }

            //    if (route.Url.Equals("publishing/{website}/{category}/{*path}", StringComparison.OrdinalIgnoreCase))
            //    {
            //        var path = context.RouteData.Values["path"] as string;
            //        return View(string.IsNullOrEmpty(path) ? context.Web.DefaultCategory() : context.Web.DefaultCategory().FindCategory(path));
            //    }
            //}
            return View();
        }

        [Widget("PostRoll",
            Category = "Publishing",
            Description = @"PostRoll is a widget that search and display the latest post and show all the post content in a list.Place this widget on 
top site it will search all the blogger posts in web, when place in your personal web site it just search the posts in your web.",
            ShowHeader = false,
            ShowBorder = false
            )]
        [Property("ShowAuthorInfo", DisplayName = "Show author profile", ValueType = typeof(bool), DefaultValue = true, PropertyControl = ControlTypes.Checkbox)]
        [Property("Rows", ValueType = typeof(int), DefaultValue = 10)]
        public ActionResult PostRoll(int rows)
        {
            var web = this.CurrentWeb();
            ViewData.Model = web.GetRecentBlogPosts(rows);
            return View();
        }
    }
}