﻿//  Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using System.Xml.Linq;
using DNA.Mvc.Areas.Publishing.Models;
using DNA.Mvc.DynamicUI;
using DNA.Mvc.Security;

namespace DNA.Mvc.Areas.Publishing.Controllers
{
    public class LibraryController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult GetNodes(int id)
        {
            var web = WebSite.Open();
            Category category = null;
            if (id == 0)
                category = web.DefaultCategory();
            else
                category = web.FindCategory(id);

            var childrenCats = category.Children().OrderBy(c => c.Pos);
            var childrenArts = category.GetChildrenArticles().OrderBy(a => a.Pos);
            var nodes = new List<SelectableNode>();
            foreach (var cat in childrenCats)
            {
                nodes.Add(new SelectableNode()
                {
                    Text = cat.Title,
                    ImageUrl = Url.Content("~/Content/Images/dir.gif"),
                    NavigateUrl = !string.IsNullOrEmpty(cat.Url) ? Url.Content(cat.Url) : Url.Content("~/publishing/library/c/" + cat.ID.ToString() + ".html"),// Url.Action("ContentsTable", new { Area = "KB", id = cat.ID }),
                    Target = "contentWindow",
                    Value = Url.Action("GetNodes", new { Area = "Publishing", id = cat.ID })
                });
            }

            foreach (var art in childrenArts)
            {
                if (art.ParentID > 0)
                    continue;

                if ((art.IsPrivate) || (!art.IsPublished))
                {
                    if (!HttpContext.Request.IsAuthenticated)
                        continue;
                    if (!art.UserName.Equals(User.Identity.Name, StringComparison.OrdinalIgnoreCase))
                        continue;
                }
                var node = new SelectableNode()
                {
                    Text = art.Title,
                    Target = "contentWindow",
                    ImageUrl = art.IsPrivate ? (Url.Content("~/Content/Images/doc_private.gif")) : (art.IsPublished ? (art.HasChildren() ? Url.Content("~/Content/Images/posts.gif") : Url.Content("~/Content/Images/doc_content.gif")) :
                    (Url.Content("~/Content/Images/doc_draft.gif"))),
                    NavigateUrl = Url.Content("~/publishing/library/t/" + art.ID.ToString() + ".html"),
                };

                if (art.HasChildren())
                    node.Value = Url.Action("GetArticleNodes", new { Area = "Publishing", id = art.ID });
                else
                    node.Value = null;
                nodes.Add(node);
            }
            /*For json convertion*/
            var jsonNodes = from n in nodes
                            select new
                            {
                                title = n.Text,
                                url = n.NavigateUrl,
                                imgUrl = n.ImageUrl,
                                hasChildren = n.Value != null,
                                rel = n.Value as string
                            };

            return Json(jsonNodes.ToList(), JsonRequestBehavior.AllowGet);
        }

        public ActionResult GetArticleNodes(int id)
        {
            var web = WebSite.Open();
            var article = web.FindArticle(id);
            var childrenArts = article.GetChildren();
            var nodes = new List<SelectableNode>();

            foreach (var art in childrenArts)
            {
                if ((art.IsPrivate) || (!art.IsPublished))
                {
                    if (!HttpContext.Request.IsAuthenticated)
                        continue;
                    if (!art.UserName.Equals(User.Identity.Name, StringComparison.OrdinalIgnoreCase))
                        continue;
                }

                var node = new SelectableNode()
                {
                    Text = art.Title,
                    Target = "contentWindow",
                    ImageUrl = art.IsPrivate ? (Url.Content("~/Content/Images/doc_private.gif")) : (art.IsPublished ? (art.HasChildren() ? Url.Content("~/Content/Images/posts.gif") : Url.Content("~/Content/Images/doc_content.gif")) :
                    (Url.Content("~/Content/Images/doc_draft.gif"))),
                    NavigateUrl = Url.Content("~/publishing/library/t/" + art.ID.ToString() + ".html"),
                };

                if (art.HasChildren())
                    node.Value = Url.Action("GetArticleNodes", new { Area = "Publishing", id = art.ID });
                else
                    node.Value = null;

                nodes.Add(node);
            }
            //var builder = new NodeUIBuilder();
            //foreach (var node in nodes)
            //    builder.WriteNode(node, node.Properties);
            //return Content(builder.ToString());
            var jsonNodes = from n in nodes
                            select new
                            {
                                title = n.Text,
                                url = n.NavigateUrl,
                                imgUrl = n.ImageUrl,
                                hasChildren = n.Value != null,
                                rel = n.Value as string
                            };
            return Json(jsonNodes.ToList(), JsonRequestBehavior.AllowGet);
        }

        [Log]
        public ActionResult ContentsTable(int id)
        {
            return View(WebSite.Open().FindCategory(id));
        }

        [Log]
        public ActionResult Topic(int id)
        {
            var article = WebSite.Open().FindArticle(id);
            if (article != null)
            {
                if (article.IsPublished)
                    article.Read();
                return View(article);
            }
            else
                throw new PageNotFoundException();
        }

        public ActionResult Live(int id)
        {
            return View(id.ToString());
        }
    }
}
