﻿using System.Web.Mvc;
using System.Web.Routing;

namespace DNA.Mvc.Areas.Publishing
{
    public class PublishingAreaRegistration : AreaRegistration
    {
        public override string AreaName
        {
            get
            {
                return "Publishing";
            }
        }

        public override void RegisterArea(AreaRegistrationContext context)
        {
            context.MapRoute(
                "Publishing_ViewArticle",
                "Publishing/{website}/{year}/{month}/{day}/{id}/{title}.html",
                new
                {
                    website = "home",
                    action = "Details",
                    controller = "Article",
                    year = "2010",
                    month = "01",
                    day = "01",
                    id = "0",
                    title = "index"
                },
                new { httpMethod = new HttpMethodConstraint("GET"), year = @"^\d{4}", month = @"^\d{2}", day = @"^\d{2}", id = @"^\d+" }
                );

            context.MapRoute("Publishing_ViewTopic",
    "Publishing/{lib}/{topic}/{id}.html",
    new { controller = "Library", action = "Topic" },
    new { lib = "library", topic = "t" }
    );

            context.MapRoute("Publishing_ContentTable",
                "Publishing/{lib}/{topic}/{id}.html",
                new { controller = "Library", action = "ContentsTable" },
                new { lib = "library", topic = "c" }
                );

            context.MapRoute(
                "Publishing_Archives",
                "Publishing/{website}/archives/{year}/{month}",
                new { website = "home", action = "Archive", controller = "Article" },
                new { year = @"^\d{4}", month = @"^\d{2}" }
                );

            context.MapRoute(
                "Publishing_Category",
                "Publishing/{website}/{category}/{*path}",
                new { website = "home", action = "List", controller = "Article", path = "", },
                new { category = "category" }
                );

            context.MapRoute(
                "Publishing_sub",
                "Publishing/{website}-{controller}/{action}/{id}",
                new { id = UrlParameter.Optional }
            );

            context.MapRoute(
                 "Publishing_default",
                 "Publishing/{controller}/{action}/{id}",
                 new { action = "Index", id = UrlParameter.Optional }
             );
        }
    }
}
