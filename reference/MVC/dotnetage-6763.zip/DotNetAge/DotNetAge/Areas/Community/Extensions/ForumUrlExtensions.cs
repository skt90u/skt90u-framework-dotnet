﻿//  Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Profile;
using System.Web.Security;
using System.Web.Mvc;
using System.Text;
using DNA.Mvc.jQuery;
using DNA.Mvc.Areas.Community.Models;
using DNA.Mvc.Areas.Community.Services;

namespace DNA.Mvc.Areas.Community
{
    public static class ForumUrlExtensions
    {
        private static ForumUrlHelper _forumUrlHelper;

        private static ForumUrlHelper _ForumUrlHelper
        {
            get 
            {
                if (_forumUrlHelper == null)
                    _forumUrlHelper = new ForumUrlHelper();
                return _forumUrlHelper; 
            }
        }
        
        public static ForumUrlHelper ForumUrls(this UrlHelper helper)
        {
            _ForumUrlHelper.Url = helper;
            return _ForumUrlHelper;
        }
    }

    public class ForumUrlHelper
    {
        public UrlHelper Url { get; set; }

        public string Thread(Post post)
        {
            if (post.IsThread)
                return Thread(post.ThreadID);
            else
                return Thread(post.ThreadID) + "#" + post.ID.ToString();
        }

        public string Thread(Thread thread)
        {
            return Thread(thread.ID);
        }

        public string Thread(int id)
        {
            return Url.Action("Index", "Thread", new { Area = "Community", id = id });
        }
    }
}