﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Profile;
using System.Web.Security;
using System.Web.Mvc;
using System.Text;
using DNA.Mvc.jQuery;
using DNA.Mvc.Areas.Community.Models;
using DNA.Mvc.Areas.Community.Services;

namespace DNA.Mvc.Areas.Community
{
    public static class ForumExtensions
    {
        private static ForumService service;
        private static ForumService Service
        {
            get
            {
                if (service == null)
                    service = new ForumService();
                return service;
            }
        }

        public static MvcHtmlString ForumIcon(this HtmlHelper helper, Forum forum)
        {
            TagBuilder tag = new TagBuilder("div");
            string _class = "forum-icon forum-icon-forum";
            if (forum.IsLock || forum.IsModerated) _class += " forum-icon-forum-locked";
            else
            {
                if (Service.GetForums(forum.ID).Count() > 0)
                    _class += " forum-icon-forum-subforum";
                else
                    _class += " forum-icon-forum-read";
            }
            tag.AddCssClass(_class);
            return MvcHtmlString.Create(tag.ToString());
        }

        public static MvcHtmlString ThreadIcon(this HtmlHelper helper, Thread thread)
        {
            TagBuilder tag = new TagBuilder("div");
            if (thread.IsLocked)
            {
                if (thread.IsPinned)
                    tag.AddCssClass("forum-icon-thread forum-icon-thread-announce");
                else
                    tag.AddCssClass("forum-icon-thread forum-icon-thread-lock");
            }
            else
            {
                if (thread.IsPinned)
                    tag.AddCssClass("forum-icon-thread forum-icon-thread-pinned");
                else
                {
                    TimeSpan timeSpan =DateTime.Now - thread.LastPosted  ;
                    if (thread.TotalReads >= 100)
                    {
                        tag.AddCssClass("forum-icon-thread forum-icon-thread-hot");
                    }
                    else
                    {
                        if ((timeSpan.Days == 0) || (timeSpan.Days <= 1))
                            tag.AddCssClass("forum-icon-thread forum-icon-thread-new");
                        else
                            tag.AddCssClass("forum-icon-thread forum-icon-thread-default");
                    }
                }
            }
            return MvcHtmlString.Create(tag.ToString());
        }

        public static MvcHtmlString ForumMapPath(this AjaxHelper helper, int forumID)
        {
            return helper.Crumb(Service as IHierarchicalNodeProvider, forumID.ToString());
        }

        public static MvcHtmlString ForumTree(this AjaxHelper helper, string name, TreeViewOptions options)
        {

            return helper.TreeView(name, Service.RootNode.ChildNodes, options);
        }

        public static MvcHtmlString AttachmentLink(this AjaxHelper helper, Attachment attachment,object htmlAttributes)
        {
            var _url = new UrlHelper(helper.ViewContext.RequestContext);
            string path = WebSite.ApplicationPath + "/webshared/home/forums/attachments/" + attachment.PostID.ToString() + "/" + attachment.FileName;
            TagBuilder builder = new TagBuilder("a");
            if (htmlAttributes != null)
                builder.MergeAttributes<string, object>(ObjectHelper.ConvertObjectToDictionary(htmlAttributes));
            //builder.Attributes.Add("style","float:left;");
            builder.InnerHtml =attachment.FileName;
            builder.Attributes.Add("href", _url.Action("File", "FileSharing", new { Area = "", path = path }));
            return MvcHtmlString.Create(builder.ToString());
        }

        #region extend the thread entity
        public static Post LastPost(this Thread thread)
        {
            if (thread.LastPostID.HasValue)
            {
                if (!thread.Posts.IsLoaded) thread.Posts.Load();
                return thread.Posts.FirstOrDefault(p => p.ID == thread.LastPostID);
            }
            return thread.ThreadPost;
        }
        #endregion

        #region Extend the forum entity
        public static Forum Parent(this Forum forum)
        {
            return Service.GetForum(forum.ParentID);
        }

        /// <summary>
        /// Identity current user is moderator of this forum
        /// </summary>
        /// <param name="forum"></param>
        public static bool IsModerator(this Forum forum)
        {
            if (HttpContext.Current.Request.IsAuthenticated)
            {
                if (HttpContext.Current.User.IsInRole("administrators")) 
                    return true;
                if (!forum.Moderators.IsLoaded) forum.Moderators.Load();
                return forum.Moderators.FirstOrDefault(m => m.Moderator == HttpContext.Current.User.Identity.Name) != null;
            }
            return false;
        }

        public static int UnappoveThreads(this Forum forum)
        {
            return Service.GetTotalModeratedThreads(forum.ID);
        }

        public static int UnappovePosts(this Forum forum)
        {
            return Service.GetTotalModeratedPosts(forum.ID);
        }

        public static bool HasChildren(this Forum forum)
        {
            return Service.HasChildren(forum.ID);
        }

        public static Post LastPost(this Forum forum)
        {
            if (forum.LastPostID.HasValue)
            {
                if (!forum.Posts.IsLoaded) forum.Posts.Load();
                return forum.Posts.FirstOrDefault(p => p.ID == forum.LastPostID);
            }
            return null;
        }

        public static IEnumerable<Forum> SubForums(this Forum forum)
        {
            return Service.GetForums(forum.ID);
        }

        public static IEnumerable<ForumGroup> SubGroups(this Forum forum)
        {
            return Service.GetForumGroups(forum.ID);
        }
        #endregion
    }
}
