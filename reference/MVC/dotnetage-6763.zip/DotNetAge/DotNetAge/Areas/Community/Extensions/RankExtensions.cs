﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Profile;
using System.Web.Security;
using System.Web.Mvc;
using System.Text;
using DNA.Mvc.jQuery;
using DNA.Mvc.Areas.Community.Models;
using DNA.Mvc.Areas.Community.Services;

namespace DNA.Mvc.Areas.Community
{
    public static class RankExtensions
    {
        private static IRankService service;
        private static IRankService Service
        {
            get
            {
                if (service == null)
                    service = new RankService();
                return service;
            }
        }

        public static MvcHtmlString Rank(this HtmlHelper helper, ProfileBase profile)
        {
            ProfileGroupBase forumGroup = profile.GetProfileGroup("Forum");
            int totalPost = forumGroup["TotalPosts"] != null ? (int)forumGroup["TotalPosts"] : 0;
            string rankName = forumGroup["Rank"] != null ? forumGroup["Rank"].ToString() : "";
            Rank _rank = Service.GetRankByMinimumPosts(totalPost);

            if (!string.IsNullOrEmpty(rankName))
                _rank = Service.GetRank(rankName);

            if (_rank == null)
                return MvcHtmlString.Empty;

            if (!string.IsNullOrEmpty(_rank.ImageUrl))
            {
                TagBuilder tag = new TagBuilder("img");
                tag.Attributes.Add("alt", _rank.Name);
                tag.Attributes.Add("src", ((new UrlHelper(helper.ViewContext.RequestContext)).Content(_rank.ImageUrl)));
                return MvcHtmlString.Create(tag.ToString(TagRenderMode.SelfClosing));
            }
            //var rankText = new TagBuilder("span");
            //rankText.Attributes.Add("style","float:left;");
            return MvcHtmlString.Create(_rank.Name);
        }
    }
}