﻿//  Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Profile;
using DNA.Mvc.Areas.Community.Services;

namespace DNA.Mvc.Areas.Community.Models
{
    public class ForumGroup
    {
        public int ID { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public int ParentID { get; set; }
        public int Pos { get; set; }
        public ForumGroup() { }
        public ForumGroup(Forum forum)
        {
            this.ID = forum.ID;
            this.Title = forum.Title;
            this.ParentID = forum.ParentID;
            this.Description = forum.Description;
            this.Pos = forum.Pos;
        }
    }

    public static class ForumGroupExtensions
    {
        private static IForumService service;
        private static IForumService Service
        {
            get
            {
                if (service == null)
                    service = new ForumService();
                return service;
            }
        }

        public static bool HasChildren(this ForumGroup forumGroup)
        {
            return Service.HasChildren(forumGroup.ID);
        }

        public static IEnumerable<Forum> SubForums(this ForumGroup forumGroup)
        {
            return Service.GetForums(forumGroup.ID).Where(f => f.IsGroup == false).OrderByDescending(f=>f.Pos);
        }

        public static IEnumerable<ForumGroup> SubGroups(this ForumGroup forumGroup)
        {
            return Service.GetForumGroups(forumGroup.ID);
        }
    }

}