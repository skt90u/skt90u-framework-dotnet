﻿//  Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DNA.Mvc.Areas.Community.Models
{
    /// <summary>
    /// Define the forum statistics data model
    /// </summary>
    public class ForumStatistics
    {
        /// <summary>
        /// Gets/Sets the total threads of the forums.
        /// </summary>
        public int TotalThreads { get; set; }
        
        /// <summary>
        /// Get/Sets the total posts of the forums.
        /// </summary>
        public int TotalPosts { get; set; }

        /// <summary>
        /// Gets/Sets the total posts of today.
        /// </summary>
        public int TodayPosts { get; set; }

        /// <summary>
        /// Gets/Sets the total threads of today.
        /// </summary>
        public int TodayThreads { get; set; }
    }
}