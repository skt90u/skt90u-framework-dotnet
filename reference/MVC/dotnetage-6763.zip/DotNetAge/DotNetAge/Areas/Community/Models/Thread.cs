﻿//  Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Profile;
using System.ComponentModel.DataAnnotations;
using System.Web.Script.Serialization;

namespace DNA.Mvc.Areas.Community.Models
{
    public partial class Thread
    {
        [ScriptIgnore]
        public Post ThreadPost
        {
            get
            {
                if (!this.Posts.IsLoaded) this.Posts.Load();
                return this.Posts.FirstOrDefault(p => p.IsThread);
            }
        }
    }
}