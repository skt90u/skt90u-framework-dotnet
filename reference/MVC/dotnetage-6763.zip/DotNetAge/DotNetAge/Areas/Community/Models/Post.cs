﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Profile;
using System.ComponentModel.DataAnnotations;

namespace DNA.Mvc.Areas.Community.Models
{
    [MetadataType(typeof(PostMeta))]
    public partial class Post
    {
        public ProfileBase UserProfile
        {
            get
            {
                if (!string.IsNullOrEmpty(this.UserName))
                {
                    ProfileBase profile = new ProfileBase();
                    profile.Initialize(this.UserName, true);
                    return profile;
                }
                return null;
            }
        }

        public bool IsOwner()
        {
            var context = HttpContext.Current;
            if (context.Request.IsAuthenticated)
                return context.User.Identity.Name.Equals(this.UserName);
            return false;
        }

        public bool IsModerator()
        {
            var context = HttpContext.Current;
            if (context.Request.IsAuthenticated)
            {
                if (HttpContext.Current.User.IsInRole("administrators"))
                    return true;
                if (!this.ForumReference.IsLoaded) this.ForumReference.Load();
                if (!this.Forum.Moderators.IsLoaded) this.Forum.Moderators.Load();
                return this.Forum.Moderators.FirstOrDefault(m => m.Moderator == context.User.Identity.Name) != null;
            }
            return false;
        }

        public bool HasAttachment
        {
            get
            {
                if (!this.Attachments.IsLoaded) this.Attachments.Load();
                if (this.Attachments.Count() > 0)
                    return true;
                else
                    return false;
            }
        }

        public class PostMeta
        {
            [Required(AllowEmptyStrings = false, ErrorMessage = "The post title is required")]
            public string Title { get; set; }
            [Required(AllowEmptyStrings = false, ErrorMessage = "The post body is required")]
            public string Body { get; set; }
        }
    }
}
