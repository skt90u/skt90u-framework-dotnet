﻿//  Copyright (c) 2011 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using DNA.Mvc.Areas.Community.Models;

namespace DNA.Mvc.Areas.Community
{
    public interface ICommunity
    {
        #region Forums and Forum groups

        int GetTotalModeratedThreads(int forumID);

        int GetTotalModeratedPosts(int forumID);

        IEnumerable<Forum> GetModeratedForums(string userName);

        /// <summary>
        /// Gets all children of specified parent id including forums and forum groups.
        /// </summary>
        /// <param name="parentID">Specified the parent id.</param>
        /// <returns>The forum entity collection.</returns>
        IEnumerable<Forum> GetChildren(int parentID);

        /// <summary>
        /// Gets the forums for specified forum id.
        /// </summary>
        /// <param name="parentID">Specified the forum id.</param>
        /// <returns>The sub forum collection of the specified forum id.</returns>
        IEnumerable<Forum> GetForums(int parentID);

        /// <summary>
        /// Get the forum object by sepcified forum id.
        /// </summary>
        /// <param name="id">Specified the forum id</param>
        /// <returns>The forum object instance.</returns>
        Forum GetForum(int id);

        /// <summary>
        /// Get the sub forum group collection of secified forum id.
        /// </summary>
        /// <param name="parentID">Specified the parent forum / forum group id .</param>
        /// <returns>The forum group object colleciton.</returns>
        IEnumerable<ForumGroup> GetForumGroups(int parentID);

        /// <summary>
        /// Delete the forum / forum group object by specified id.
        /// </summary>
        /// <param name="id">Sepcified the forum / forum group id.</param>
        void DeleteForum(int id);

        /// <summary>
        /// Update the forum / forum group object.
        /// </summary>
        /// <param name="forum">The forum instance</param>
        void UpdateForum(Forum forum, string[] moderators);

        /// <summary>
        /// Move the forum / forum group to a new position.
        /// </summary>
        /// <param name="id">Specified the forum id to move.</param>
        /// <param name="parentID">Specified the parent id which the forum belongs to .</param>
        /// <param name="pos">Specified the position where the forum move to.</param>
        void MoveForum(int id, int parentID, int pos);

        bool HasChildren(int parentID);

        #endregion

        #region Posts

        IEnumerable<Post> GetThreadPosts(int threadID, int pageIndex, int pageSize, out int totalRecords);

        Post GetPost(int postID);

        void AddAttachment(Post post, HttpContextBase context);

        void ClearAttachments(Post post);

        Post ReplyPost(int postID, int parentID, string encodedBody, string userName);

        Post QuotePost(int postID, int quoteID, string encodedBody, string userName);

        Post EditPost(int postID, string encodedBody, string userName);

        void LockThread(int threadID, bool _lock);

        void PinThread(int threadID, bool _pinned);

        int AuditPost(int id, string moderator);

        void DeletePost(int id, string reason, bool keep);

        void ReadPost(int id);

        int GetUserTotalPosts(string userName);

        int GetUserTotalThreads(string userName);

        #endregion

        #region Threads
        
        Thread NewThread(int forumID, bool isPinned, bool isLocked, Post post);

        /// <summary>
        /// Get the threads for specified forum id.
        /// </summary>
        /// <param name="forumID">Specified the forum id.</param>
        /// <param name="pageIndex">Speicifed the page index</param>
        /// <param name="pageSize">Specified the page size</param>
        /// <param name="totalRecords">Specified the return total records count</param>
        /// <returns>The thread colleciton.</returns>
        IEnumerable<Thread> GetThreads(int forumID, int pageIndex, int pageSize, out int totalRecords);

        IEnumerable<Thread> GetModeratedThreads(int forumID, int pageIndex, int pageSize, out int totalRecords);

        IEnumerable<Thread> GetUserThreads(string userName, int pageIndex, int pageSize, out int totalRecords);

        IEnumerable<Thread> GetPinnedThreads(int forumID);

        IEnumerable<Thread> GetTodayThreads();

        IEnumerable<Thread> GetHotThreads(int minReads);

        Thread GetThread(int threadID);

        void MoveThread(int id, int forumID);
        #endregion

        #region Ranks

        Rank CreateRank(string name, bool isStart, int minimumPosts, string imageUrl);

        Rank EditRank(int id, string name, bool isStart, int minimumPosts, string imageUrl);

        Rank GetRank(int id);

        Rank GetRankByMinimumPosts(int posts);

        Rank GetRank(string name);

        #endregion
    }
}