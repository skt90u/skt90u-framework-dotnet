﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using DNA.Mvc.Areas.Community.Models;

namespace DNA.Mvc.Areas.Community.Services
{
    public class PostService : IPostService
    {
        iForumDBEntities forumDB;
        private iForumDBEntities ForumDB
        {
            get
            {
                if (forumDB == null)
                    forumDB = new iForumDBEntities();
                return forumDB;
            }
        }

        public string DefaultAttachmentPath
        {
            get
            {
                return WebSite.ApplicationPath + "/webshared/home/forums/attachments";
                // " webfile://root/forums/attachments";
            }
        }

        private Uri EnsureAttachmentPathForPost(Post post)
        {
            var fileSharing = WebSite.GetService<FileWebResourceService>("files"); //WebSite.GetService<FileSharingService>();
            var postUrl = new Uri(DefaultAttachmentPath + "/" + post.ID.ToString());
            var postPath = fileSharing.MapPath(postUrl);
            if (!System.IO.Directory.Exists(postPath))
                fileSharing.CreatePath(postUrl);
            return postUrl;
        }

        public void RemoveAttachments(Post post)
        {
            if (post.HasAttachment)
            {
                var attch = post.Attachments.First();
                post.Attachments.Remove(attch);
                ForumDB.Attachments.DeleteObject(attch);
                ForumDB.SaveChanges();
                WebResources.Delete(EnsureAttachmentPathForPost(post));
            }
        }

        public void AddAttachment(Post post, HttpContextBase context)
        {
            if (context.Request.Files.Count > 0)
            {
                var postUrl = EnsureAttachmentPathForPost(post);
                for (int i = 0; i < context.Request.Files.Count; i++)
                {
                    var file = context.Request.Files[i];
                    if (string.IsNullOrEmpty(file.FileName) || file.ContentLength == 0)
                        continue;
                    string fileName = System.IO.Path.GetFileName(file.FileName);
                    var attach = new Attachment()
                    {
                        FileName = fileName,
                        ContentType = file.ContentType
                    };
                    post.Attachments.Add(attach);
                    WebResources.SaveFile(file, postUrl);
                }
            }
            ForumDB.SaveChanges();
        }

        public int Audit(int id,string moderator) 
        {
            var post = GetPost(id);
            if (!post.IsAppoved)
            {
                post.IsAppoved = true;
                post.Appoved = DateTime.Now;
                post.Moderator = moderator;
                if (post.IsThread)
                {
                    var thread = GetThread(post.ThreadID);
                    thread.IsAppoved = true;
                    thread.Appoved = post.Appoved;
                    thread.Moderator = post.Moderator;
                }
                ForumDB.SaveChanges();

                UpdateForumState(post.ForumID);
                UpdateThreadState(post.ThreadID);
                return post.ThreadID;
            }
            return 0;
        }

        public void Move(int id, int forumID)
        {
            var thread = ForumDB.Threads.FirstOrDefault(t => t.ID == id);
            thread.ForumReference.Load();
            thread.Posts.Load();
            var orgForumID = thread.ForumID;
            Forum forum = ForumDB.Forums.First(f => f.ID == forumID);
            forum.Threads.Add(thread);
            foreach (var post in thread.Posts)
                forum.Posts.Add(post);
            ForumDB.SaveChanges();
            if (orgForumID != forumID)
                UpdateForumState(orgForumID);
            UpdateForumState(forumID);
            UpdateThreadState(thread.ID);
        }

        public IEnumerable<Thread> GetPinnedThreads(int forumID)
        {
            return (from thread in ForumDB.Forums.FirstOrDefault(f => f.ID == forumID).Threads.CreateSourceQuery()
                    orderby thread.LastPosted descending
                    where (thread.IsPinned == true)
                    select thread).ToList();
        }

        public int GetUserTotalPosts(string userName)
        {
            return (from p in ForumDB.Posts
                    where ((!p.IsThread) && (p.UserName == userName) && (p.IsAppoved))
                    select p.ID
                        ).Count();
        }

        public int GetUserTotalThreads(string userName)
        {
            return (from t in ForumDB.Threads
                    where ((t.Author == userName) && (t.IsAppoved))
                    select t.ID
                        ).Count();
        }

        public Thread GetThread(int threadID)
        {
            return ForumDB.Threads.FirstOrDefault(p => p.ID == threadID);
        }

        public IEnumerable<Thread> GetTodayThreads()
        {
            var today = DateTime.Now;
            var yesterday = DateTime.Today.AddDays(-1);
            return ForumDB.Threads
                                     .Where(t => t.LastPosted<=today)
                                     .Where(t=>t.LastPosted>yesterday)
                                     .Where(t => t.IsAppoved)
                                     .ToList();
        }

        public IEnumerable<Thread> GetHotThreads(int minReads)
        {
            return ForumDB.Threads
                                     .Where(t => t.TotalReads >= minReads)
                                     .Where(t=>t.IsAppoved)
                                     .ToList();
        }

        public IEnumerable<Thread> GetModeratedThreads(int forumID, int pageIndex, int pageSize, out int totalRecords)
        {
            var forum = ForumDB.Forums.First(f => f.ID == forumID);
            
            var unappovedThreads = forum.Threads.CreateSourceQuery().Where(t => !t.IsAppoved).ToList();
            var unappovedPostThreads = forum.Posts.CreateSourceQuery()
                                                                    .Where(p => !p.IsAppoved)
                                                                    .Where(p => !p.IsThread)
                                                                    .Select(p => ForumDB.Threads.FirstOrDefault(t => t.ID == p.ThreadID))
                                                                    .Distinct().ToList();

            var _threads = unappovedThreads.Union(unappovedPostThreads);
            totalRecords = _threads.Count();

            int skip = (pageIndex - 1) * pageSize;
            return _threads.OrderByDescending(t => t.Posted)
                                   .Skip(skip)
                                   .Take(pageSize)
                                   .ToList();
        }

        public IEnumerable<Thread> GetUserThreads(string userName, int pageIndex, int pageSize, out int totalRecords)
        {
            totalRecords = ForumDB.Threads.Count(t => t.LastPostUser == userName);
            int skip = (pageIndex - 1) * pageSize;
            return ForumDB.Threads
                .Where(t => t.LastPostUser == userName)
                .OrderByDescending(t => t.IsPinned)
                .ThenByDescending(t => t.TotalReads)
                .ThenByDescending(t => t.TotalPosts)
                .ThenByDescending(t => t.Posted)
                .Skip(skip)
                .Take(pageSize)
                .ToList();
        }

        public Post GetPost(int postID)
        {
            return ForumDB.Posts.FirstOrDefault(p => p.ID == postID);
        }

        public IEnumerable<Post> GetThreadPosts(int threadID, int pageIndex, int pageSize, out int totalRecords)
        {
            totalRecords = ForumDB.Threads.FirstOrDefault(t => t.ID == threadID).Posts.CreateSourceQuery().Count();
            int skip = (pageIndex - 1) * pageSize;
            return ForumDB.Threads.FirstOrDefault(t => t.ID == threadID).Posts.CreateSourceQuery().
                OrderBy(t => t.Posted).Skip(skip).Take(pageSize).ToList();
        }

        public void Read(int id)
        {
            Thread thread = GetThread(id);
            thread.TotalReads++;
            ForumDB.SaveChanges();
        }

        public Thread NewThread(int forumID, bool isPinned, bool isLocked, Post post)
        {
            Forum forum = ForumDB.Forums.FirstOrDefault(f => f.ID == forumID);
            post.Posted = DateTime.Now;
            post.LastModified = DateTime.Now;
            post.IsThread = true;
            post.IsAppoved = forum.IsModerated ? false : true;
            if (post.IsAppoved)
            {
                post.Appoved = DateTime.Now;
                post.Moderator = HttpContext.Current.User.Identity.Name;
            }
            post.IsLocked = isLocked;
            post.Reads = 0;
            post.Ratings = 0;
            post.Pos = 0;
            post.IP = HttpContext.Current.Request.UserHostAddress;
            forum.Posts.Add(post);

            Thread thread = new Thread()
            {
                Title = post.Title,
                IsPinned = isPinned,
                IsLocked = isLocked,
                LastPosted = post.Posted,
                LastPostUser = post.UserName,
                IsAppoved = post.IsAppoved,
                Appoved = post.Appoved,
                Moderator = post.Moderator,
                Author = post.UserName,
                Posted = post.Posted,
                TotalPosts = 1,
                TotalReads = 0
            };

            thread.Posts.Add(post);
            post.ParentID = post.ID;
            forum.Threads.Add(thread);
            ForumDB.SaveChanges();
            UpdateForumState(forum.ID);
            UpdateThreadState(thread.ID);
            return thread;
        }

        public Post Reply(int postID, int parentID, string encodedBody, string userName)
        {
            Post post = GetPost(postID);
            if (!post.ThreadReference.IsLoaded) post.ThreadReference.Load();
            if (!post.ForumReference.IsLoaded) post.ForumReference.Load();
            int _pos = 0;
            if (!post.Thread.Posts.IsLoaded) post.Thread.Posts.Load();
            _pos = post.Thread.Posts.Max(p => p.Pos) + 1;

            Post reply = new Post()
            {
                UserName = userName,
                Title = post.Title,
                Body = encodedBody,
                Posted = DateTime.Now,
                LastModified = DateTime.Now,
                IsThread = false,
                IsAppoved = post.Forum.IsModerated ? false : true,
                Moderator = post.Forum.IsModerated ? HttpContext.Current.User.Identity.Name : "",
                ParentID = parentID,
                Reads = 0,
                Ratings = 0,
                Pos = _pos,
                IP = HttpContext.Current.Request.UserHostAddress
            };

            if (reply.IsAppoved)
                reply.Appoved = DateTime.Now;

            post.Forum.Posts.Add(reply);
            post.Thread.Posts.Add(reply);
            ForumDB.SaveChanges();

            UpdateForumState(post.Forum.ID);
            UpdateThreadState(post.Thread.ID);
            return reply;
        }

        public void Lock(int threadID, bool _lock)
        {
            Thread thread = GetThread(threadID);
            thread.IsLocked = _lock;
            ForumDB.SaveChanges();
        }

        public void Pin(int threadID, bool _pinned)
        {
            Thread thread = GetThread(threadID);
            thread.IsPinned = _pinned;
            ForumDB.SaveChanges();
        }

        public Post Quote(int postID, int quoteID, string encodedBody, string userName)
        {
            Post post = GetPost(quoteID);
            string body = "<span>" + userName + " wrote:</span><blockquote>" + post.Body + "</blockquote><br>" + encodedBody;
            return Reply(postID, quoteID, body, userName);
        }

        public Post Edit(int postID, string encodedBody, string userName)
        {
            Post post = GetPost(postID);
            post.Body = encodedBody;
            post.LastModified = DateTime.Now;
            ForumDB.SaveChanges();
            return post;
        }

        public void Delete(int id, string reason, bool keep)
        {
            Post post = GetPost(id);
            if (!post.ForumReference.IsLoaded) post.ForumReference.Load();
            if (!post.ThreadReference.IsLoaded) post.ThreadReference.Load();
            Forum forum = post.Forum;
            if (!string.IsNullOrEmpty(reason)) { }

            if (keep)
            {
                post.IsDeleted = true;
                post.DeletedReason = reason;
                post.Deleted = DateTime.Now;
                post.DeleteBy = HttpContext.Current.User.Identity.Name;
                ForumDB.SaveChanges();
            }
            else
            {
                if (post.IsThread)
                {
                    ForumDB.DeleteObject(post.Thread);
                    ForumDB.DeleteObject(post);
                    ForumDB.SaveChanges();
                    UpdateForumState(forum.ID);

                }
                else
                {
                    var threadID = post.ThreadID;
                    ForumDB.DeleteObject(post);
                    ForumDB.SaveChanges();
                    UpdateForumState(forum.ID);
                    UpdateThreadState(threadID);
                }
            }
        }

        private void UpdateThreadState(int threadID)
        {
            System.Data.Common.DbCommand command = ((System.Data.EntityClient.EntityConnection)ForumDB.Connection).StoreConnection.CreateCommand();
            command.CommandType = System.Data.CommandType.StoredProcedure;
            command.CommandText = "community_thread_UpdateStates";
            command.Parameters.Add(new System.Data.SqlClient.SqlParameter("@id", System.Data.SqlDbType.Int) { Value = threadID });
            if (command.Connection.State == System.Data.ConnectionState.Closed) { command.Connection.Open(); }
            command.ExecuteNonQuery();
        }

        private void UpdateForumState(int forumID)
        {
            System.Data.Common.DbCommand command = ((System.Data.EntityClient.EntityConnection)ForumDB.Connection).StoreConnection.CreateCommand();
            command.CommandType = System.Data.CommandType.StoredProcedure;
            command.CommandText = "community_forum_UpdateStates";
            command.Parameters.Add(new System.Data.SqlClient.SqlParameter("@id", System.Data.SqlDbType.Int) { Value = forumID });
            if (command.Connection.State == System.Data.ConnectionState.Closed) { command.Connection.Open(); }
            command.ExecuteNonQuery();
        }
    }
}