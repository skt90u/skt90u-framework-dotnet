﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Mvc;
using DNA.Mvc.Areas.Community.Models;

namespace DNA.Mvc.Areas.Community.Services
{
    public interface IPostService
    {
        IEnumerable<Thread> GetModeratedThreads(int forumID,int pageIndex, int pageSize, out int totalRecords);

        IEnumerable<Thread> GetUserThreads(string userName, int pageIndex, int pageSize, out int totalRecords);

        IEnumerable<Thread> GetPinnedThreads(int forumID);
        
        IEnumerable<Thread> GetTodayThreads();

        IEnumerable<Thread> GetHotThreads(int minReads);

        Thread GetThread(int threadID);

        IEnumerable<Post> GetThreadPosts(int threadID, int pageIndex, int pageSize, out int totalRecords);

        Post GetPost(int postID);

        void AddAttachment(Post post, HttpContextBase context);

        void RemoveAttachments(Post post);

        Thread NewThread(int forumID, bool isPinned, bool isLocked, Post post);

        Post Reply(int postID, int parentID, string encodedBody, string userName);

        Post Quote(int postID, int quoteID, string encodedBody, string userName);

        Post Edit(int postID, string encodedBody, string userName);

        void Lock(int threadID, bool _lock);

        void Pin(int threadID, bool _pinned);

        int Audit(int id, string moderator);

        void Delete(int id, string reason, bool keep);

        void Read(int id);

        int GetUserTotalPosts(string userName);

        int GetUserTotalThreads(string userName);

        void Move(int id, int forumID);
    }
}
