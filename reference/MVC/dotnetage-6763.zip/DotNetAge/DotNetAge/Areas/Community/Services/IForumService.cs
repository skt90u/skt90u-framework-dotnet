﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DNA.Mvc.Areas.Community.Models;

namespace DNA.Mvc.Areas.Community.Services
{
    /// <summary>
    /// Defines the methods to control the forum/forum group entity.
    /// </summary>
    public interface IForumService
    {
        /// <summary>
        /// Get the threads for specified forum id.
        /// </summary>
        /// <param name="forumID">Specified the forum id.</param>
        /// <param name="pageIndex">Speicifed the page index</param>
        /// <param name="pageSize">Specified the page size</param>
        /// <param name="totalRecords">Specified the return total records count</param>
        /// <returns>The thread colleciton.</returns>
        IEnumerable<Thread> GetThreads(int forumID, int pageIndex, int pageSize, out int totalRecords);

        ForumStatistics Stat();

        int GetTotalModeratedThreads(int forumID);
        
        int GetTotalModeratedPosts(int forumID);

        IEnumerable<Forum> GetModeratedForums(string userName);

        /// <summary>
        /// Gets all children of specified parent id including forums and forum groups.
        /// </summary>
        /// <param name="parentID">Specified the parent id.</param>
        /// <returns>The forum entity collection.</returns>
        IEnumerable<Forum> GetChildren(int parentID);

        /// <summary>
        /// Gets the forums for specified forum id.
        /// </summary>
        /// <param name="parentID">Specified the forum id.</param>
        /// <returns>The sub forum collection of the specified forum id.</returns>
        IEnumerable<Forum> GetForums(int parentID);

        /// <summary>
        /// Get the forum object by sepcified forum id.
        /// </summary>
        /// <param name="id">Specified the forum id</param>
        /// <returns>The forum object instance.</returns>
        Forum GetForum(int id);

        /// <summary>
        /// Get the sub forum group collection of secified forum id.
        /// </summary>
        /// <param name="parentID">Specified the parent forum / forum group id .</param>
        /// <returns>The forum group object colleciton.</returns>
        IEnumerable<ForumGroup> GetForumGroups(int parentID);

        /// <summary>
        /// Delete the forum / forum group object by specified id.
        /// </summary>
        /// <param name="id">Sepcified the forum / forum group id.</param>
        void Delete(int id);

        /// <summary>
        /// Update the forum / forum group object.
        /// </summary>
        /// <param name="forum">The forum instance</param>
        void Update(Forum forum,string[] moderators);

        /// <summary>
        /// Move the forum / forum group to a new position.
        /// </summary>
        /// <param name="id">Specified the forum id to move.</param>
        /// <param name="parentID">Specified the parent id which the forum belongs to .</param>
        /// <param name="pos">Specified the position where the forum move to.</param>
        void Move(int id, int parentID, int pos);

        bool HasChildren(int parentID);
    }
}
