﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Profile;
using DNA.Mvc.Areas.Community.Models;

namespace DNA.Mvc.Areas.Community.Services
{

    public class ForumService : HierarchicalNodeProviderBase, IForumService
    {
        iForumDBEntities forumDB;
        private HierarchicalNode root;
        private iForumDBEntities ForumDB
        {
            get
            {
                if (forumDB == null)
                    forumDB = new iForumDBEntities();
                return forumDB;
            }
        }

        #region IForumService Members

        public IEnumerable<Forum> GetModeratedForums(string userName)
        {
            return (from f in ForumDB.Forums
                    where ((f.IsModerated) && (!f.IsGroup) &&
                    (ForumDB.ModeratorsSet.Where(m => m.Moderator == userName).Select(m => m.ForumID).Contains(f.ID)))
                    select f
                             ).ToList();
        }

        public ForumStatistics Stat()
        {
            return ForumDB.ExecuteStoreQuery<ForumStatistics>("community_statistics").Single();
        }

        public int GetTotalModeratedThreads(int forumID)
        {
            var forum = GetForum(forumID);
            var unappovedThreads = forum.Threads.CreateSourceQuery().Count(t => !t.IsAppoved);
            var unappovedPostThreads = forum.Posts.CreateSourceQuery()
                                                                    .Where(p => !p.IsAppoved)
                                                                    .Where(p => !p.IsThread)
                                                                    .Select(p => p.ThreadID)
                                                                    .Distinct()
                                                                    .Count();
            return unappovedPostThreads + unappovedThreads;
        }

        public int GetTotalModeratedPosts(int forumID)
        {
            var forum = GetForum(forumID);
            var unappovedPosts = forum.Posts.CreateSourceQuery()
                                                                  .Where(p => !p.IsAppoved)
                                                                  .Where(p => !p.IsThread)
                                                                  .Count();
            return unappovedPosts;
        }

        /// <summary>
        /// Update the forum / forum group object.
        /// </summary>
        /// <param name="forum">The forum instance</param>
        /// <remarks>
        /// If the forum id is zero this method will create a new forum object.
        /// </remarks>
        public void Update(Forum forum, string[] moderators)
        {
            if (forum.ID == 0)
            {
                ForumDB.Forums.AddObject(forum);
            }
            else
            {
                if (!forum.Moderators.IsLoaded) forum.Moderators.Load();
                foreach (var m in forum.Moderators.CreateSourceQuery())
                    ForumDB.ModeratorsSet.DeleteObject(m);
            }

            if (moderators != null)
            {
                foreach (var m in moderators)
                    forum.Moderators.Add(new Moderators() { Moderator = m });
            }

            ForumDB.SaveChanges();
        }

        /// <summary>
        /// Delete the forum / forum group object by specified id.
        /// </summary>
        /// <param name="id">Sepcified the forum / forum group id.</param>
        public void Delete(int id)
        {
            var forum = GetForum(id);
            if (forum != null)
            {
                ForumDB.DeleteObject(forum);
                ForumDB.SaveChanges();
            }

        }

        /// <summary>
        /// Get the threads for specified forum id.
        /// </summary>
        /// <param name="forumID">Specified the forum id.</param>
        /// <param name="pageIndex">Speicifed the page index</param>
        /// <param name="pageSize">Specified the page size</param>
        /// <param name="totalRecords">Specified the return total records count</param>
        /// <returns>The thread colleciton.</returns>
        public IEnumerable<Thread> GetThreads(int forumID, int pageIndex, int pageSize, out int totalRecords)
        {
            totalRecords = ForumDB.Forums.FirstOrDefault(f => f.ID == forumID).Threads.CreateSourceQuery().Where(t => t.IsAppoved).Count();
            int skip = (pageIndex - 1) * pageSize;
            return ForumDB.Forums.FirstOrDefault(f => f.ID == forumID).Threads
                .CreateSourceQuery()
                .Where(t => t.IsAppoved)
                .OrderByDescending(t => t.IsPinned)
                .ThenByDescending(t => t.Posted)
                .ThenByDescending(t => t.TotalReads)
                .ThenByDescending(t => t.TotalPosts)
                .Skip(skip)
                .Take(pageSize)
                .ToList();
        }

        /// <summary>
        /// Gets all children of specified parent id including forums and forum groups.
        /// </summary>
        /// <param name="parentID">Specified the parent id.</param>
        /// <returns>The forum entity collection.</returns>
        public IEnumerable<Forum> GetChildren(int parentID)
        {
            return ForumDB.Forums.Where(f => f.ParentID == parentID).OrderByDescending(f => f.Pos).ToList();
        }

        /// <summary>
        /// Gets the forums for specified forum id.
        /// </summary>
        /// <param name="parentID">Specified the forum id.</param>
        /// <returns>The sub forum collection of the specified forum id.</returns>
        public IEnumerable<Forum> GetForums(int parentID)
        {
            return (from fs in ForumDB.Forums
                    orderby fs.Pos descending
                    where ((fs.ParentID == parentID) && (fs.IsGroup == false))
                    select fs).ToList();
        }

        /// <summary>
        /// Get the forum object by sepcified forum id.
        /// </summary>
        /// <param name="forumID">Specified the forum id</param>
        /// <returns>The forum object instance.</returns>
        public Forum GetForum(int forumID)
        {
            return ForumDB.Forums.FirstOrDefault(f => f.ID == forumID);
        }

        /// <summary>
        /// Get the sub forum group collection of secified forum id.
        /// </summary>
        /// <param name="parentID">Specified the parent forum / forum group id .</param>
        /// <returns>The forum group object colleciton.</returns>
        public IEnumerable<ForumGroup> GetForumGroups(int parentID)
        {
            return (from fs in ForumDB.Forums
                    orderby fs.Pos descending
                    where ((fs.ParentID == parentID) && (fs.IsGroup == true))
                    select new ForumGroup()
                    {
                        ID = fs.ID,
                        Description = fs.Description,
                        ParentID = fs.ParentID,
                        Pos = fs.Pos,
                        Title = fs.Title
                    });
        }

        private void Reindex(int parentID)
        {
            var pages = (from p in ForumDB.Forums
                         where p.ParentID == parentID
                         orderby p.Pos
                         select p).ToList();
            for (int i = 0; i < pages.Count; i++)
                pages[i].Pos = i;
            ForumDB.SaveChanges();
        }

        ///<summary>
        /// Move the forum / forum group to a new position.
        /// </summary>
        /// <param name="id">Specified the forum id to move.</param>
        /// <param name="parentID">Specified the parent id which the forum belongs to .</param>
        /// <param name="pos">Specified the position where the forum move to.</param>
        public void Move(int parentID, int id, int pos)
        {
            var forum = ForumDB.Forums.FirstOrDefault(f => f.ID == id);
            if (forum == null)
                throw new ArgumentNullException("Forum not found");
            if ((parentID < 1) || (forum.ParentID == parentID))
            {
                int _from = forum.Pos;
                int _to = pos;

                if ((_to != 0) && (_from != 0))  //move up
                {
                    forum.Pos = _to;
                    var target = (from t in ForumDB.Forums
                                  where (t.ParentID == forum.ParentID) && (t.Pos == pos)
                                  select t).First();
                    target.Pos = _from;
                    ForumDB.SaveChanges();

                    Reindex(forum.ParentID);
                    return;
                }

                if (_to == 0)
                {
                    forum.Pos = 0;
                    var targets = (from t in ForumDB.Forums
                                   where (t.ParentID == forum.ParentID) && (t.ID != id)
                                   select t);
                    foreach (var w in targets)
                        w.Pos++;
                    ForumDB.SaveChanges();
                    Reindex(forum.ParentID);
                    return;
                }

                if (_from == 0)
                {
                    forum.Pos = _to;
                    var targets = (from t in ForumDB.Forums
                                   where (t.ParentID == forum.ParentID) && (t.ID != id)
                                   select t);
                    foreach (var w in targets)
                        w.Pos--;
                    ForumDB.SaveChanges();
                    Reindex(forum.ParentID);
                    return;
                }
            }

            if (forum.ParentID != parentID)
            {
                int orgParent = forum.ParentID;
                forum.Pos = pos;
                forum.ParentID = parentID;
                ForumDB.SaveChanges();

                //1.Repostion the orgin zone widgets
                Reindex(orgParent);

                var ws = (from w in ForumDB.Forums
                          where ((w.ParentID == parentID) && (w.ID != id) && (w.Pos >= pos))
                          orderby w.Pos
                          select w).ToList();

                if (ws.Count > 0)
                {
                    foreach (var _nw in ws)
                        _nw.Pos++;
                    ForumDB.SaveChanges();
                }

                Reindex(parentID);
            }
        }

        public bool HasChildren(int parentID)
        {
            return (from f in ForumDB.Forums
                    where ((f.IsGroup == false) && (f.ParentID == parentID))
                    select f.ID).Count() > 0;
        }

        #endregion

        public PopulateNodeFromForumDelegate PopulateDelegate { get; set; }

        protected virtual HierarchicalNode PopulateNode(Forum forum)
        {
            if (forum == null) throw new ArgumentNullException("forum");

            if (PopulateDelegate != null)
                return PopulateDelegate(forum);
            var Url = UrlUtility.CreateUrlHelper();
            string navigateUrl = Url.Action("Threads", "Forum", new { Area = "Community", id = forum.ID });
            if (forum.IsGroup)
                navigateUrl = Url.Action("Group", "Forum", new { Area = "Community", id = forum.ID });
            var node = new HierarchicalNode(this as IHierarchicalNodeProvider)
            {
                Title = forum.Title,
                Description = forum.Description,
                NavigateUrl = navigateUrl,
                Key = forum.ID.ToString(),
                Item = forum
            };
            //forum.Title, forum.Description, navigateUrl, forum.ID.ToString(), forum, this);
            node.Attributes.Add("key", forum.ID.ToString());
            if (forum.IsGroup)
                node.Attributes.Add("isGroup", true);
            return node;
        }

        #region HierarchicalNodeProviderBase Members

        public override IEnumerable<HierarchicalNode> GetChildNodes(HierarchicalNode node)
        {
            int id = int.Parse(node.Key);
            //var forum=GetForum(id);
            var forums = ForumDB.Forums.Where(f => f.ParentID == id);

            var result = new List<HierarchicalNode>();

            foreach (var forum in forums)
                result.Add(PopulateNode(forum));
            return result;
        }

        public override HierarchicalNode GetParentNode(HierarchicalNode node)
        {
            if (node.Item == null)
                return null;
            var forum = node.Item as Forum;
            var _parent = ForumDB.Forums.FirstOrDefault(f => f.ID == forum.ParentID);
            if (_parent == null)
                return null;
            return PopulateNode(_parent);
        }

        public override HierarchicalNode RootNode
        {
            get
            {
                if (root == null)
                {
                    root = new HierarchicalNode(this as IHierarchicalNodeProvider)
                    {
                        Title = "Community",
                        Description = "Community",
                        NavigateUrl = UrlUtility.CreateUrlHelper().Action("Index", "Forum", new { Area = "Community" }),
                        Key = "0"
                    }; //"Cummunity", "Cummunity", UrlUtlity.CreateUrlHelper().Action("Index", "Forum", new { Area = "Community" }), "0", null, this);
                    root.Attributes.Add("key", "0");
                }

                return root;
            }
            set
            {
                root = value;
            }
        }

        public override HierarchicalNode FindNodeFormKey(string key)
        {
            int id = int.Parse(key);
            return PopulateNode(GetForum(id));
        }

        #endregion
    }

    public delegate HierarchicalNode PopulateNodeFromForumDelegate(Forum forum);
}
