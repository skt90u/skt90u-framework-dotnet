﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DNA.Mvc.Areas.Community.Models;

namespace DNA.Mvc.Areas.Community.Services
{
    public class RankService:IRankService
    {
        iForumDBEntities forumDB;
        private iForumDBEntities ForumDB
        {
            get
            {
                if (forumDB == null)
                    forumDB = new iForumDBEntities();
                return forumDB;
            }
        }

        public Rank CreateRank(string name, bool isStart, int minimumPosts, string imageUrl)
        {
            Rank rank = new Rank()
            {
                Name = name,
                IsStart = isStart,
                ImageUrl = imageUrl,
                MinimumPosts = minimumPosts
            };

            if (isStart)
            {
                foreach (var r in ForumDB.Ranks)
                    r.IsStart = false;
            }

            ForumDB.AddToRanks(rank);
            ForumDB.SaveChanges();
            return rank;
        }

        public Rank EditRank(int id, string name, bool isStart, int minimumPosts, string imageUrl)
        {
            if (isStart)
            {
                foreach (var r in ForumDB.Ranks)
                    r.IsStart = false;
            }
            Rank rank = GetRank(id);
            rank.Name = name;
            rank.MinimumPosts = minimumPosts;
            rank.ImageUrl = imageUrl;
            rank.IsStart = isStart;
            ForumDB.SaveChanges();
            return rank;
        }

        public Rank GetRank(int id)
        {
            return ForumDB.Ranks.FirstOrDefault(r => r.ID == id);
        }

        public Rank GetRank(string name)
        {
            return ForumDB.Ranks.FirstOrDefault(r => r.Name == name);
        }

        public Rank GetRankByMinimumPosts(int posts)
        {
            var ranks = (from Rank r in ForumDB.Ranks
                         where posts >= r.MinimumPosts
                         select r).ToList();

            if (ranks.Count > 0)
            {
                var max = ranks.Max(r => r.MinimumPosts);
                return ranks.FirstOrDefault(r => r.MinimumPosts == max);
            }
            else
                return null;
        }
    }
}