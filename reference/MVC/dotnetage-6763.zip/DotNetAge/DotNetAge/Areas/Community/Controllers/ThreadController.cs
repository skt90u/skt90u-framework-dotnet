﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Mvc.Ajax;
using System.Web.Profile;
using System.Xml.Linq;
using DNA.Mvc.Areas.Community.Models;
using DNA.Mvc.Areas.Community.Services;
using DNA.Mvc.jQuery;

namespace DNA.Mvc.Areas.Community.Controllers
{
    [Log]
    [HandleError]
    public class ThreadController : Controller
    {
        private IPostService service;
        private IPostService Service
        {
            get
            {
                if (service == null)
                    service = new PostService();
                return service;
            }
        }

        [Pagable]
        public ActionResult Index(int id, QueryParams _params)
        {
            Post threadPost = Service.GetThread(id).Posts.CreateSourceQuery().FirstOrDefault(p => p.IsThread);
            if (!threadPost.ForumReference.IsLoaded) threadPost.ForumReference.Load();
            if ((!threadPost.Forum.AllowAnonymous) && (!HttpContext.Request.IsAuthenticated))
                return RedirectToAction("LogOn", "Account", new { Area = "", returnUrl = (new UrlHelper(ControllerContext.RequestContext).Action("Threads", "Forum", ControllerContext.RouteData.Values)) });

            if (threadPost == null)
                return View("NotFound");
            if (!threadPost.ThreadReference.IsLoaded) threadPost.ThreadReference.Load();
            if (!threadPost.ForumReference.IsLoaded) threadPost.ForumReference.Load();
            //int pageIndex = index == null ? 1 : index.Value;
            //int pageSize = size == null ? 10 : size.Value;
            int total = 0;

            var model = Service.GetThreadPosts(id, _params.Index, _params.Size, out total);
            ViewData["ThreadPost"] = threadPost;
            //ViewData["PageIndex"] = pageIndex;
            //ViewData["PageSize"] = pageSize;
            //ViewData["TotalRecords"] = total;

            if (_params.Index == 1)
            {
                if (HttpContext.Request.IsAuthenticated)
                {
                    if (!threadPost.UserName.Equals(User.Identity.Name))
                        Service.Read(id);
                }
                else
                    Service.Read(id);
            }
            return View(new ModelWrapper(model, total));
        }

        public ActionResult ModeratedThreads(int id,int? index, int? size)
        {
            int pageIndex = index == null ? 1 : index.Value;
            int pageSize = size == null ? 20 : size.Value;
            int total = 0;
            ViewData.Model = Service.GetModeratedThreads(id, pageIndex, pageSize, out total);
            ViewData["PageIndex"] = pageIndex;
            ViewData["PageSize"] = pageSize;
            ViewData["TotalRecords"] = total;
            return View();
        }
    }
}
