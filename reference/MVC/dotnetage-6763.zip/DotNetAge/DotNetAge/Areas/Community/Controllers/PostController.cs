﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Mvc.Ajax;
using System.Web.Profile;
using System.Xml.Linq;
using DNA.Mvc.Security;
using DNA.Mvc.Areas.Community.Models;
using DNA.Mvc.Areas.Community.Services;
using DNA.Mvc.jQuery;

namespace DNA.Mvc.Areas.Community.Controllers
{
    [Log]
    [HandleError]
    public partial class PostController : Controller
    {
        private IPostService service;
        private IPostService Service
        {
            get
            {
                if (service == null)
                    service = new PostService();
                return service;
            }
        }

        [SecurityAction("Community", "Create new thread", "Allows user can create a new thread")]
        public ActionResult New(int forumID)
        {
            var db = new iForumDBEntities();
            ViewData["Forum"] = db.Forums.FirstOrDefault(f => f.ID == forumID);
            return View();
        }

        [SecurityAction("Community", "Create new thread", "Allows user can create a new thread")]
        [HttpPost]
        [ValidateAntiForgeryToken]
        [ValidateInput(false)]
        public ActionResult New(int forumID, FormCollection form)
        {
            var post = new Post()
            {
                Title = form["PostTitle"],
                Body = form["PostBody"],
                UserName = User.Identity.Name
            };
            bool isPinned = form.AllKeys.Contains("PinPost") ? bool.Parse(form["PinPost"]) : false;
            bool isLocked = form.AllKeys.Contains("PinPost") ? bool.Parse(form["LockPost"]) : false;
            Thread thread = Service.NewThread(forumID, isPinned, isLocked, post);
            UpdateUserPosts();
            if (!thread.ForumReference.IsLoaded) thread.ForumReference.Load();
            if (HttpContext.Request.Files.Count > 0)
            {
                if (thread.Forum.AllowAttachment)
                    Service.AddAttachment(thread.ThreadPost, HttpContext);
            }
            return RedirectToAction("Index", "Thread", new { Area = "Community", id = thread.ID });
        }

        [SecurityAction("Community", "Delete threads or posts", "Allows user can delete threads and posts.")]
        public ActionResult Delete(int id)
        {
            Post post = Service.GetPost(id);
            post.ForumReference.Load();
            post.ThreadReference.Load();
            ViewData.Model = post;
            return View();
        }

        [HttpPost]
        [SecurityAction("Community", "Delete threads or posts", "Allows user can delete threads and posts.")]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, string deleteReason, bool keepPost)
        {
            Post post = Service.GetPost(id);
            bool isThread = post.IsThread;
            if (!post.ForumReference.IsLoaded) post.ForumReference.Load();
            if (!post.ThreadReference.IsLoaded) post.ThreadReference.Load();
            int forumID = post.Forum.ID;
            int threadID = post.Thread.ID;
            Service.Delete(id, deleteReason, keepPost);
            UpdateUserPosts();
            if (isThread)
                return RedirectToAction("Threads", "Forum", new { id = forumID });
            else
                return RedirectToAction("Index", "Thread", new { id = threadID });
        }

        private void UpdateUserPosts()
        {
            HttpContext.Profile.GetProfileGroup("Forum")["TotalPosts"] = Service.GetUserTotalPosts(User.Identity.Name);
            HttpContext.Profile.GetProfileGroup("Forum")["TotalThreads"] = Service.GetUserTotalThreads(User.Identity.Name);
        }

        [Authorize]
        [SecurityAction("Community", "Reply post", "Allows user can reply post.")]
        public ActionResult Reply(int id, int parentID)
        {
            ViewData.Model = Service.GetPost(parentID);
            return View();
        }

        [SecurityAction("Community", "Reply post", "Allows user can reply post.")]
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        [ValidateInput(false)]
        public ActionResult Reply(int id, int parentID, FormCollection forms)
        {
            Post reply = Service.Reply(id, parentID, forms["PostBody"], User.Identity.Name);
            HandlingAttachments(forms, reply);
            if (!reply.ThreadReference.IsLoaded) reply.ThreadReference.Load();
            UpdateUserPosts();
            return RedirectToAction("Index", "Thread", new { Area = "Community", id = reply.Thread.ID });
        }

        [SecurityAction("Community", "Move post", "Allows user can move post among fourms.")]
        public ActionResult Move(int id)
        {
            ViewData.Model = Service.GetThread(id);
            return View();
        }

        [SecurityAction("Community", "Move post", "Allows user can move post among fourms.")]
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        public ActionResult Move(int id, int forumID, FormCollection form)
        {
            Service.Move(id, forumID);
            return RedirectToAction("Index", "Thread", new { Area = "Community", id = id });
        }

        [Authorize]
        [Pagable]
        public ActionResult MyThreads(QueryParams query)
        {
            int total = 0;
            var model = Service.GetUserThreads(User.Identity.Name, query.Index, query.Size, out total);
            return View(new ModelWrapper<Thread>()
            {
                Model = model,
                Total = total
            });
        }

        public ActionResult ModeratedThreads()
        {
            return View();
        }

        [SecurityAction("Community", "Edit post", "Allows user can edit post content")]
        [HttpPost]
        [ValidateAntiForgeryToken]
        [ValidateInput(false)]
        public ActionResult Edit(int id, FormCollection forms)
        {
            string body = HttpContext.Server.HtmlDecode(forms["PostBody"]);
            Post post = Service.Edit(id, body, User.Identity.Name);
            HandlingAttachments(forms, post);
            if (!post.ThreadReference.IsLoaded) post.ThreadReference.Load();
            return RedirectToAction("Index", "Thread", new { Area = "Community", id = post.Thread.ID });
        }

        private void HandlingAttachments(FormCollection forms, Post post)
        {
            if (!post.ForumReference.IsLoaded) post.ForumReference.Load();
            if (post.Forum.AllowAttachment)
            {
                if (post.HasAttachment)
                {
                    var isDetach = forms.AllKeys.Contains("IsDetach") ? bool.Parse(forms["IsDetach"]) : false;

                    if ((HttpContext.Request.Files.Count > 0) || isDetach)
                        Service.RemoveAttachments(post);
                }
                Service.AddAttachment(post, HttpContext);
            }
        }

        [SecurityAction("Community", "Edit post", "Allows user can edit post content")]
        public ActionResult Edit(int id)
        {
            ViewData.Model = Service.GetPost(id);
            if (ViewData.Model == null)
                return View("NotFound");
            return View();
        }

        [SecurityAction("Community", "Quote post", "Allows user can quote other post content")]
        public ActionResult Quote(int id, int quoteID)
        {
            ViewData.Model = Service.GetPost(quoteID);
            if (ViewData.Model == null)
                return View("NotFound");
            return View();
        }

        [SecurityAction("Community", "Quote post", "Allows user can quote other post content")]
        [HttpPost]
        [ValidateAntiForgeryToken]
        [ValidateInput(false)]
        public ActionResult Quote(int id, int quoteID, FormCollection forms)
        {
            Post quote = Service.Quote(id, quoteID, HttpContext.Server.HtmlEncode(forms["PostBody"]), User.Identity.Name);
            HandlingAttachments(forms, quote);
            if (!quote.ThreadReference.IsLoaded) quote.ThreadReference.Load();
            return RedirectToAction("Index", "Thread", new { Area = "Community", id = quote.Thread.ID });
        }

        [SecurityAction("Community", "Audit post", "Allows user can audit the unappove posts")]
        public ActionResult Audit(int id)
        {
            var threadID = Service.Audit(id, User.Identity.Name);
            return RedirectToAction("Index", "Thread", new { Area = "Community", id = threadID });
        }

        [SecurityAction("Community", "Pin post", "Allows user can pin post")]
        public ActionResult Pin(int id)
        {
            Service.Pin(id, true);
            return RedirectToAction("Index", "Thread", new { Area = "Community", id = id });
        }

        [SecurityAction("Community", "Unpin post", "Allows user can unpin post")]
        public ActionResult Unpin(int id)
        {
            Service.Pin(id, false);
            return RedirectToAction("Index", "Thread", new { Area = "Community", id = id });
        }

        [SecurityAction("Community", "Unlock post", "Allows user can unlock the post")]
        public ActionResult Unlock(int id)
        {
            Service.Lock(id, false);
            return RedirectToAction("Index", "Thread", new { Area = "Community", id = id });
        }

        [SecurityAction("Community", "Lock post", "Allows user can lock the post")]
        public ActionResult Lock(int id)
        {
            Service.Lock(id, true);
            return RedirectToAction("Index", "Thread", new { Area = "Community", id = id });
        }

    }
}
