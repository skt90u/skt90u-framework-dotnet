﻿//  Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Mvc.Ajax;
using System.Web.Profile;
using System.Web.Security;
using System.Xml.Linq;
using DNA.Mvc.DynamicUI;
using DNA.Mvc.Security;
using DNA.Mvc.Areas.Community.Models;
using DNA.Mvc.Areas.Community.Services;

namespace DNA.Mvc.Areas.Community.Controllers
{
    [HandlePartialError]
    public partial class ForumController
    {
        [Widget("Stat.", "Display the statistics for community",
            ShowBorder = true,
            ShowHeader = true,
              Category = "Community",
             ImageUrl = "~/Content/Images/Widgets/stat.png",
             IconUrl = "~/Content/Images/Widgets/stat_16.png"
            )]
        public ActionResult Statistics()
        {
            ViewData.Model = Service.Stat();
            return View();
        }
    }
}