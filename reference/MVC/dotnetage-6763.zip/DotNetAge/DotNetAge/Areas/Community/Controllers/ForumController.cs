//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Mvc.Ajax;
using System.Web.Profile;
using System.Web.Security;
using System.Xml.Linq;
using DNA.Mvc.DynamicUI;
using DNA.Mvc.Security;
using DNA.Mvc.Areas.Community.Models;
using DNA.Mvc.Areas.Community.Services;
using DNA.Mvc.jQuery;

namespace DNA.Mvc.Areas.Community.Controllers
{
    [Log]
    [HandleError]
    public partial class ForumController : Controller
    {
        private IForumService service;
        private IForumService Service
        {
            get
            {
                if (service == null)
                    service = new ForumService();
                return service;
            }
        }

        [SiteMapAction(Title = "Community")]
        public ActionResult Index()
        {
            ViewData.Model = Service.GetForumGroups(0);
            return View();
        }

        public ActionResult Group(int id)
        {
            ViewData.Model = Service.GetForum(id);
            return View();
        }

        [ChildActionOnly]
        public ActionResult Detail(int id)
        {
            ViewData.Model = Service.GetForum(id);
            return PartialView();
        }

        [ChildActionOnly]
        public ActionResult SubForums(int parentID)
        {
            ViewData.Model = Service.GetForums(parentID);
            return PartialView();
        }

        [ChildActionOnly]
        public ActionResult ForumList(int parentID)
        {
            ViewData.Model = Service.GetForums(parentID);
            return PartialView();
        }

        [SecurityAction("Community", "Create forum", "Allows user can create new forum")]
        public ActionResult Create(int id, bool? isgroup)
        {
            ViewData["Parent"] = Service.GetForum(id);
            ViewData["IsGroup"] = isgroup.HasValue ? isgroup.Value : false;
            return PartialView();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [SecurityAction("Community", "Create forum", "Allows user can create new forum")]
        public ActionResult Create(int id, FormCollection form)
        {
            var subforum = new Forum();
            bool _group = bool.Parse(form["IsGroup"]);
            if (_group)
            {
                if (TryUpdateModel<Forum>(subforum, "Forum", new string[] { "Title", "Description" }))
                {
                    subforum.ParentID = id;
                    subforum.IsGroup = true;
                    Service.Update(subforum, null);
                    return RedirectToAction("Edit", new { id = subforum.ID });
                }
            }
            else
            {
                if (TryUpdateModel<Forum>(subforum, "Forum", new string[] { "Title", "Description", "IsLock", "IsModerated", "AllowAttachment", "AllowAnonymous" }))
                {
                    subforum.ParentID = id;
                    Service.Update(subforum, GetModeratorList(form));
                    return RedirectToAction("Edit", new { id = subforum.ID });
                }
            }
            return PartialView();
        }

        [HttpPost]
        [SecurityAction("Community", "Move forum", "Allows user can change the forums relationship")]
        public void Move(int id, int parentID, int pos)
        {
            Service.Move(parentID, id, pos);
        }

        [HttpPost]
        [SecurityAction("Community", "Delete forum", "Allows user can delete the forum and all data of the forum")]
        public void Delete(int id)
        {
            Service.Delete(id);
        }

        [SiteMapAction(Title = "View threads",
            ShowInMenu = false,
            IsShared = true,
            IgnoreRouteDataKeys = new string[] { "id", "index", "size" })]
        [Pagable]
        public ActionResult Threads(int id, QueryParams queryParams)
        {
            Forum forum = Service.GetForum(id);
            if ((!forum.AllowAnonymous) && (!HttpContext.Request.IsAuthenticated))
                return RedirectToAction("LogOn", "Account", new { Area = "", returnUrl = (new UrlHelper(ControllerContext.RequestContext).Action("Threads", "Forum", ControllerContext.RouteData.Values)) });

            ViewData["Forum"] = forum;
            //int pageIndex = index == null ? 1 : index.Value;
            //int pageSize = size == null ? 20 : size.Value;
            int total = 0;
            var threads = Service.GetThreads(id, queryParams.Index, queryParams.Size, out total);
            //ViewData["PageIndex"] = pageIndex;
            //ViewData["PageSize"] = pageSize;
            //ViewData["TotalRecords"] = total;
            return View(new ModelWrapper()
            {
                Model = threads,
                Total = total
            });
        }

        [SecurityAction("Community", "Edit forum", "Allows user can edit the forum settings")]
        public ActionResult Edit(int id)
        {
            var forum = Service.GetForum(id);
            ViewData.Model = forum;
            ViewData["IsGroup"] = forum.IsGroup;
            return View();
        }

        [HttpPost]
        [SecurityAction("Community", "Edit forum", "Allows user can edit the forum settings")]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, FormCollection form)
        {
            var forum = Service.GetForum(id);
            var _including = new string[] { "Title", "Description", "IsLock", "IsModerated", "AllowAttachment", "AllowAnonymous" };

            if (forum.IsGroup)
                _including = new string[] { "Title", "Description" };

            if (TryUpdateModel<Forum>(forum, "Forum", _including))
            {
                if (!forum.IsGroup)
                    Service.Update(forum, GetModeratorList(form));
                else
                    Service.Update(forum, null);
                ViewData.Model = forum;
            }

            return PartialView();
        }

        private static string[] GetModeratorList(FormCollection form)
        {
            var _modString = form["Forum.Moderators"];
            var _modList = new List<string>();

            if (!string.IsNullOrEmpty(_modString))
            {
                string[] moderators = _modString.Split(new char[] { ',' });

                foreach (var m in moderators)
                {
                    var member = Membership.GetUser(m);
                    if (member != null)
                        _modList.Add(m);
                }
                return _modList.ToArray();
            }
            return null;
        }

        [SecurityAction("Community", "Control panel", "Allows use can view the forum control panel.")]
        [SiteControlPanel(ResBaseName = "forums", ResKey = "forum", Order = 7)]
        public ActionResult Settings()
        {
            return View();
        }

        [MyControlPanel(ResBaseName = "forums", ResKey = "forum", Order = 7)]
        public ActionResult MyForum()
        {
            return View();
        }

        [Authorize]
        public ActionResult MyModeratedForums()
        {
            ViewData.Model = Service.GetModeratedForums(User.Identity.Name);
            return View();
        }

        //[MyControlPanel(ResBaseName = "forums", ResKey = "PrivateMessage")]
        public ActionResult PrivateMessages()
        {
            return PartialView();
        }

        [OutputCache(Duration = 3600, VaryByParam = "*")]
        public ActionResult Rss(int id)
        {
            Forum forum = Service.GetForum(id);
            //string fileName = "Forum" + forum.ID + "_" +(forum.LastPosted.HasValue ? forum.LastPosted.Value.ToString("yyyy-MM-dd") : "")+ ".xml";
            //string tmp = Server.MapPath("~/Shared/Temp/" + fileName);
            //if (System.IO.File.Exists(tmp))
            //    return File(tmp, "text/xml");

            var threads = (from t in forum.Threads.CreateSourceQuery()
                           where (t.IsAppoved)
                           select t).OrderByDescending(a => a.LastPosted).Take(50).ToList();

            XDocument doc = new XDocument(new XDeclaration("1.0", "utf-8", "yes"));
            XElement element = new XElement("rss");
            element.SetAttributeValue("version", "2.0");
            doc.Add(element);

            XElement channel = new XElement("channel");
            channel.Add(new XElement("title") { Value = forum.Title });
            if (!string.IsNullOrEmpty(forum.Description))
                channel.Add(new XElement("description") { Value = forum.Description });
            channel.Add(new XElement("link") { Value = Request.Url.Scheme + "://" + Request.Url.Authority + Url.Action("Threads", "Forum", new { Area = "Community", id = id }) });

            foreach (var thread in threads)
            {
                XElement item = new XElement("item");
                item.Add(new XElement("title") { Value = thread.Title });
                item.Add(new XElement("link") { Value = Request.Url.Scheme + "://" + Request.Url.Authority + Url.Action("Index", "Thread", new { Area = "Community", id = thread.ID }) });
                var _summary = thread.LastPost().Body;
                if (!string.IsNullOrEmpty(_summary))
                    item.Add(new XElement("description") { Value = this.Server.HtmlEncode(_summary) });
                item.Add(new XElement("author") { Value = thread.Author });
                item.Add(new XElement("pubDate") { Value = thread.LastPosted.ToString() });
                channel.Add(item);
            }
            element.Add(channel);
            //doc.Save(tmp);
            return Content(doc.ToString(), "text/xml"); //  File(tmp, "text/xml");
        }
    }
}
