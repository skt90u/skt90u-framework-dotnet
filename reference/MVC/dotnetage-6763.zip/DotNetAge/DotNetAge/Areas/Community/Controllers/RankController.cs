//  Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Mvc.Ajax;
using DNA.Mvc.Areas.Community.Models;
using DNA.Mvc.Areas.Community.Services;
using DNA.Mvc.Security;
using DNA.Mvc.jQuery;

namespace DNA.Mvc.Areas.Community.Controllers
{
    public class RankController : Controller
    {
        iForumDBEntities context;
        RankService service;

        private RankService Service
        {
            get
            {
                if (service == null)
                    service = new RankService();
                return service;
            }
        }

        private iForumDBEntities Context
        {
            get
            {
                if (context == null)
                    context = new iForumDBEntities();
                return context;
            }
        }

        public ActionResult List()
        {
            ViewData.Model = Context.Ranks.ToList();
            return PartialView();
        }

        //[Pagable]
        //public ActionResult Ranks()
        //{
        //    var ranks= Context.Ranks.ToList();
        //    foreach (var rank in ranks)
        //        rank.ImageUrl = Url.Content(rank.ImageUrl);
        //    return View(new ModelWrapper<Rank>()
        //    {
        //        Model =ranks,
        //        Total = ranks.Count()
        //    });
        //}

        [SecurityAction("Community", "Create rank", "Allows user can create new rank")]
        public ActionResult Create()
        {
            return this.PartialView("Edit");
        }

        [SecurityAction("Community", "Edit rank", "Allows user can edit the exists rank")]
        public ActionResult Edit(int id)
        {
            ViewData.Model = Service.GetRank(id);
            return PartialView();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [SecurityAction("Community", "Edit rank", "Allows user can edit the exists rank")]
        public ActionResult Edit(int id,FormCollection forms)
        {
            var _rank = Context.Ranks.FirstOrDefault(r => r.ID == id);
            //_rank.Name = forms["RankName"];
            //_rank.ImageUrl = forms["RankImage"];
            //_rank.MinimumPosts = int.Parse(forms["MinimumPostsForRank"]);
            //_rank.IsStart = bool.Parse(forms["IsStartRank"]);
            UpdateModel(_rank);

            if (_rank.IsStart)
            {
                foreach (var r in Context.Ranks)
                {
                    if (r.ID != id)
                        r.IsStart = false;
                }
            }
            Context.SaveChanges();
            return RedirectToAction("List");
        }

        [HttpPost]
        [SecurityAction("Community", "Delete rank", "Allows user can delete the exists rank")]
        public ActionResult Delete(int id)
        {
            var _rank = Context.Ranks.FirstOrDefault(r => r.ID == id);
            Context.Ranks.DeleteObject(_rank);
            Context.SaveChanges();
            return RedirectToAction("List");
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [SecurityAction("Community", "Create rank", "Allows user can create new rank")]
        public ActionResult Create(Rank rank)
        {

            //bool isStart = bool.Parse(form["IsStartRank"]);
            //string name = form["RankName"];
            //string imgUrl = form["RankImage"];
            //int minPosts = int.Parse(form["MinimumPostsForRank"]);

            if (rank.IsStart)
            {
                foreach (var r in Context.Ranks)
                    r.IsStart = false;
            }
            Context.AddToRanks(rank);
            //Context.AddToRanks(new Rank()
            //{
            //    Name = name,
            //    IsStart = isStart,
            //    ImageUrl = imgUrl,
            //    MinimumPosts = minPosts
            //});

            Context.SaveChanges();
            return RedirectToAction("List");
        }
    }
}
