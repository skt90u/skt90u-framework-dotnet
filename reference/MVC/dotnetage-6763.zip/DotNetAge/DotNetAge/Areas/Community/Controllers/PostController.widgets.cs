﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Mvc.Ajax;
using System.Web.Profile;
using System.Xml.Linq;
using DNA.Mvc.DynamicUI;
using DNA.Mvc.Security;
using DNA.Mvc.Areas.Community.Models;
using DNA.Mvc.Areas.Community.Services;

namespace DNA.Mvc.Areas.Community.Controllers
{
    [HandlePartialError]
    public partial class PostController
    {
        [Widget("TodayThreads", "Display a thread list of community for today.",
            Category = "Community",
           ShowBorder = true,
           ShowHeader = true,
            ImageUrl = "~/Content/Images/Widgets/todaypost.png",
            IconUrl = "~/Content/Images/Widgets/todaypost_16.png"
           )]
        public ActionResult TodayThreads()
        {
            ViewData.Model = Service.GetTodayThreads();
            return View();
        }

        [Widget("HotThreads", "Display a thread list of community for most popular.",
           ShowBorder = true,
           ShowHeader = true,
             Category = "Community",
            ImageUrl = "~/Content/Images/Widgets/hot.png",
            IconUrl = "~/Content/Images/Widgets/hot_16.png"
           )]
        [Property("MinimizeReads", ValueType = typeof(int), DefaultValue = 50)]
        public ActionResult HotThreads(int minimizeReads)
        {
            ViewData.Model = Service.GetHotThreads(minimizeReads);
            return View();
        }
    }
}