﻿DECLARE @owner nvarchar(50),
        @lang nvarchar(50),
        @pID int,@aID int

SELECT TOP 1 @owner=[Owner], @lang=[DefaultLanguage] FROM [dbo].[dna_WebSettings] WHERE [name]=N'home'
SELECT @pID=(SELECT top 1 [ID] FROM [dbo].[Publishing_Category] WHERE [Title]=N'{site}')

INSERT INTO [dbo].[publishing_Category]
           ([Title]
           ,[Description]
           ,[Url]
           ,[ParentID]
           ,[IsModerated]
           ,[EnableVersioning]
           ,[ArticleType]
           ,[TotalPosts]
           ,[LastPosted]
           ,[Path]
           ,[Pos]
           ,[AllowAnonymousPostComment])
VALUES ( N'{website-title}',N'{website-desc}',N'',@pID,0,0,0,1,GetDate(),N'{site}/{website-title}',0,1)

SELECT @pID=SCOPE_IDENTITY()

INSERT INTO [dbo].[publishing_Articles] ([Title],[Summary],[Body],[Tags],[Reads],[Rating],[LastModified],[Posted]
           ,[UserName],[ParentID],[Version],[CategoryID],[IsPublished],[IsAppoved],[ContentFormat]
           ,[TotalRatings],[TotalComments],[Language],[PingUrls],[Pos],[Path],[AllowPingback]
           ,[IsPrivate],[PermaLink],[AllowComments],[Categories],[SendTrackbackUrls],[Slug],[RelatedPosts],[Password])
     VALUES
           (
            N'Welcome' ,
            N'Welcome! This is your first post of document library.' ,
            N'Welcome!This is your first post of the document library.Edit or delete it and start library!',
            N'',0,0,getDate(),getDate(),@owner,
           0,0,@pID ,1,1,1,0,0,@lang,
           N'',0,N'',0,0,N'',0,N'',N'',N'welcome',N'',N'')

           SELECT @aID=SCOPE_IDENTITY()

           UPDATE [dbo].[publishing_Articles]
           SET [PermaLink]=N'/home/'+LTRIM(RTRIM(CONVERT(varchar(100), GETDATE(), 111)))+N'/'+RTRIM(LTRIM(STR(@aID)))+N'/hello-world.html'
           WHERE [ID]=@aID
  GO