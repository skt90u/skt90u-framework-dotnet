﻿/**** Init the category    ***/
DECLARE @owner nvarchar(50),
        @lang nvarchar(50),
        @pID int,@aID int

SELECT TOP 1 @owner=[Owner], @lang=[DefaultLanguage]FROM [dbo].[dna_WebSettings] WHERE [name]='home'
SELECT @pID=(SELECT top 1 [ID] FROM [dbo].[Publishing_Category] WHERE [Title]='{site}')

INSERT INTO [dbo].[publishing_Articles] ([Title],[Summary],[Body],[Tags],[Reads],[Rating],[LastModified],[Posted]
           ,[UserName],[ParentID],[Version],[CategoryID],[IsPublished],[IsAppoved],[ContentFormat]
           ,[TotalRatings],[TotalComments],[Language],[PingUrls],[Pos],[Path],[AllowPingback]
           ,[IsPrivate],[PermaLink],[AllowComments],[Categories],[SendTrackbackUrls],[Slug],[RelatedPosts],[Password])
     VALUES
           (
            /*Title*/'Hello world!' ,
		   /*Summary*/ 'Welcome!This is your first post.' ,
           /*Body*/ 'Welcome!This is your first post.Edit or delete it and start blogging!',
           /*Tags*/ '',
           /*Reads*/ 0,
           /*Rating*/ 0,
           /*LastModified*/ getDate(),
           /*Posted*/ getDate(),
           /*UserName*/ @owner,
           /*ParentID*/ 0,
           /*Version*/ 0,
           /*CategoryID*/ @pID ,
           /*IsPublished*/ 1,
           /*IsAppoved*/ 1,
           /*ContentFormat*/ 1,
           /*TotalRatings*/ 0,
           /*TotalComments*/ 0,
           /*Language*/ @lang,
           /*PingUrls*/ '',
           /*Pos*/ 0,
           /*Path*/ '',
           /*AllowPingback*/ 0,
           /*IsPrivate*/ 0,
           /*PermaLink*/ '',
           /*AllowComments*/ 0,
           /*Categories*/ '',
           /*SendTrackbackUrls*/'',
           /*Slug*/ 'hello-world',
           /*RelatedPosts*/ '',
           /*Password*/ '')

		   SELECT @aID=SCOPE_IDENTITY()

		   UPDATE [dbo].[publishing_Articles]
		   SET [PermaLink]='/home/'+LTRIM(RTRIM(CONVERT(varchar(100), GETDATE(), 111)))+'/'+RTRIM(LTRIM(STR(@aID)))+'/hello-world.html'
		   WHERE [ID]=@aID

           UPDATE [dbo].[Publishing_Category]
		   SET [TotalPosts]=1
		   WHERE [ID]=@pID
GO