﻿/******* Description: Insert the default forums   Generate date: 2010-8-30   ********/
SET IDENTITY_INSERT [dbo].[community_Forums] ON
INSERT [dbo].[community_Forums] ([ID], [Title], [Description], [IsGroup], [ParentID], [IsModerated], [TotalPosts], [TotalThreads], [LastPostID], [LastPostedUser], [LastPosted], [Theme], [IsLock], [Pos], [AllowAttachment], [AllowAnonymous]) VALUES (1, N'General discussion', NULL, 1, 0, 0, 0, 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0)
INSERT [dbo].[community_Forums] ([ID], [Title], [Description], [IsGroup], [ParentID], [IsModerated], [TotalPosts], [TotalThreads], [LastPostID], [LastPostedUser], [LastPosted], [Theme], [IsLock], [Pos], [AllowAttachment], [AllowAnonymous]) VALUES (2, N'Announcements', N'The announcements of forum site', 0, 1, 0, 0, 0, NULL, NULL, NULL, NULL, 1, 0, 1, 1)
INSERT [dbo].[community_Forums] ([ID], [Title], [Description], [IsGroup], [ParentID], [IsModerated], [TotalPosts], [TotalThreads], [LastPostID], [LastPostedUser], [LastPosted], [Theme], [IsLock], [Pos], [AllowAttachment], [AllowAnonymous]) VALUES (3, N'General', N'The general topics to discuss.', 0, 1, 0, 0, 0, NULL, NULL, NULL, NULL, 0, 0, 1, 1)
INSERT [dbo].[community_Forums] ([ID], [Title], [Description], [IsGroup], [ParentID], [IsModerated], [TotalPosts], [TotalThreads], [LastPostID], [LastPostedUser], [LastPosted], [Theme], [IsLock], [Pos], [AllowAttachment], [AllowAnonymous]) VALUES (4, N'FAQ', N'Questions and answers of the community site.', 0, 1, 1, 0, 0, NULL, NULL, NULL, NULL, 0, 0, 1, 1)
SET IDENTITY_INSERT [dbo].[community_Forums] OFF
GO

/******* Description: Insert the default ranks form forums        Generate date: 2010-8-30   *******/
SET IDENTITY_INSERT [dbo].[community_Ranks] ON
INSERT [dbo].[community_Ranks] ([ID], [Name], [IsStart], [MinimumPosts], [ImageUrl]) VALUES (1, N'Copper lv1', 1, 10, N'~/Content/Images/forums/medals/mc_0.gif')
INSERT [dbo].[community_Ranks] ([ID], [Name], [IsStart], [MinimumPosts], [ImageUrl]) VALUES (2, N'Copper lv2', 0, 20, N'~/Content/Images/forums/medals/mc_1.gif')
INSERT [dbo].[community_Ranks] ([ID], [Name], [IsStart], [MinimumPosts], [ImageUrl]) VALUES (3, N'Copper lv3', 0, 40, N'~/Content/Images/forums/medals/mc_2.gif')
INSERT [dbo].[community_Ranks] ([ID], [Name], [IsStart], [MinimumPosts], [ImageUrl]) VALUES (4, N'Silver lv1', 0, 80, N'~/Content/Images/forums/medals/ms_0.gif')
INSERT [dbo].[community_Ranks] ([ID], [Name], [IsStart], [MinimumPosts], [ImageUrl]) VALUES (5, N'Silver lv2', 0, 160, N'~/Content/Images/forums/medals/ms_1.gif')
INSERT [dbo].[community_Ranks] ([ID], [Name], [IsStart], [MinimumPosts], [ImageUrl]) VALUES (6, N'Silver lv3', 0, 320, N'~/Content/Images/forums/medals/ms_2.gif')
INSERT [dbo].[community_Ranks] ([ID], [Name], [IsStart], [MinimumPosts], [ImageUrl]) VALUES (7, N'Gold lv1', 0, 640, N'~/Content/Images/forums/medals/mg_0.gif')
INSERT [dbo].[community_Ranks] ([ID], [Name], [IsStart], [MinimumPosts], [ImageUrl]) VALUES (8, N'Gold lv2', 0, 1800, N'~/Content/Images/forums/medals/mg_1.gif')
INSERT [dbo].[community_Ranks] ([ID], [Name], [IsStart], [MinimumPosts], [ImageUrl]) VALUES (9, N'Gold lv3', 0, 3600, N'~/Content/Images/forums/medals/mg_2.gif')
INSERT [dbo].[community_Ranks] ([ID], [Name], [IsStart], [MinimumPosts], [ImageUrl]) VALUES (10, N'Top', 0, 5000, N'~/Content/Images/forums/medals/top.gif')
SET IDENTITY_INSERT [dbo].[community_Ranks] OFF
GO
