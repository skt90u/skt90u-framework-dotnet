﻿-- =============================================
-- Author:		<Ray liang>
-- Create date: <2010-8-30>
-- Lastupdate: <2010-10-21>
-- Description:	<This sql script file use to insert the data for blog template>
-- Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
-- Dual licensed under the MIT and GPL licenses:
-- http://www.opensource.org/licenses/mit-license.php
-- http://www.gnu.org/licenses/gpl.html
-- =============================================

/**** Init the category    ***/
DECLARE @name nvarchar(50),
               @pID int

SELECT @name='{website}'

IF (@name='home') BEGIN
IF NOT EXISTS(SELECT ID FROM [dbo].[Publishing_Category] WHERE [Title]='{site}') BEGIN
		   INSERT INTO [dbo].[Publishing_Category]
				   ([Title]
				   ,[Description]
				   ,[Url]
				   ,[ParentID]
				   ,[IsModerated]
				   ,[EnableVersioning]
				   ,[ArticleType]
				   ,[TotalPosts]
				   ,[LastPosted]
				   ,[Path]
				   ,[Pos]
				   ,[AllowAnonymousPostComment])
			 VALUES
				   ('{site}','','',0,0,0,
					0,0,GETDATE(),
				   '{site}',
				   0,1)

           SELECT @pID=SCOPE_IDENTITY() 
		   END
END ELSE
BEGIN
          IF NOT EXISTS(SELECT ID FROM [dbo].[Publishing_Category] WHERE [Title]='{blogs}') BEGIN
			   INSERT INTO [dbo].[Publishing_Category]
					([Title]
					,[Description]
					,[Url]
					,[ParentID]
					,[IsModerated]
					,[EnableVersioning]
					,[ArticleType]
					,[TotalPosts]
					,[LastPosted]
					,[Path]
					,[Pos]
					,[AllowAnonymousPostComment])
				VALUES
					('{blogs}','','',0,0,0,
					0,0,GETDATE(),
					'{blogs}',
					0,1)
				SELECT @pID=SCOPE_IDENTITY()
            END ELSE SELECT @pID=(SELECT top 1 [ID] FROM [dbo].[Publishing_Category] WHERE [Title]='{blogs}')

			INSERT INTO [dbo].[Publishing_Category]
					   ([Title]
					   ,[Description]
					   ,[Url]
					   ,[ParentID]
					   ,[IsModerated]
					   ,[EnableVersioning]
					   ,[ArticleType]
					   ,[TotalPosts]
					   ,[LastPosted]
					   ,[Path]
					   ,[Pos]
					   ,[AllowAnonymousPostComment])
				 VALUES
					   (
					   '{website}', 
					   '{website-title}',
					   '',@pID,
					   0,0,1,0,
					   GETDATE(),
					   '{blogs}/{website}',
					   0, 1
					   )
           SELECT @pID=SCOPE_IDENTITY()
END


DECLARE @aID int

INSERT INTO [dbo].[publishing_Articles] ([Title],[Summary],[Body],[Tags],[Reads],[Rating],[LastModified],[Posted]
           ,[UserName],[ParentID],[Version],[CategoryID],[IsPublished],[IsAppoved],[ContentFormat]
           ,[TotalRatings],[TotalComments],[Language],[PingUrls],[Pos],[Path],[AllowPingback]
           ,[IsPrivate],[PermaLink],[AllowComments],[Categories],[SendTrackbackUrls],[Slug],[RelatedPosts],[Password])
     VALUES
           (
            /*Title*/'Hello world!' ,
		   /*Summary*/ 'Welcome!This is your first post.' ,
           /*Body*/ 'Welcome!This is your first post.Edit or delete it and start blogging!',
           /*Tags*/ '',
           /*Reads*/ 0,
           /*Rating*/ 0,
           /*LastModified*/ getDate(),
           /*Posted*/ getDate(),
           /*UserName*/ @name,
           /*ParentID*/ 0,
           /*Version*/ 0,
           /*CategoryID*/ @pID ,
           /*IsPublished*/ 1,
           /*IsAppoved*/ 1,
           /*ContentFormat*/ 1,
           /*TotalRatings*/ 0,
           /*TotalComments*/ 0,
           /*Language*/ 'en-US',
           /*PingUrls*/ '',
           /*Pos*/ 0,
           /*Path*/ '',
           /*AllowPingback*/ 0,
           /*IsPrivate*/ 1,
           /*PermaLink*/ '',
           /*AllowComments*/ 0,
           /*Categories*/ '',
           /*SendTrackbackUrls*/'',
           /*Slug*/ 'hello-world',
           /*RelatedPosts*/ '',
           /*Password*/ '')

		   SELECT @aID=SCOPE_IDENTITY()

		   UPDATE [dbo].[publishing_Articles]
		   SET [PermaLink]='/'+@name+'/'+LTRIM(RTRIM(CONVERT(varchar(100), GETDATE(), 111)))+'/'+RTRIM(LTRIM(STR(@aID)))+'/hello-world.html'
		   WHERE [ID]=@aID

           UPDATE [dbo].[Publishing_Category]
		   SET [TotalPosts]=1
		   WHERE [ID]=@pID
GO