﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;
using DNA.Mvc.Security;
//using DNA.Mvc.Async;
using System.Diagnostics;

namespace DNA.Mvc
{
    // Note: For instructions on enabling IIS6 or IIS7 classic mode, 
    // visit http://go.microsoft.com/?LinkId=9394801

    public partial class WebApp : System.Web.HttpApplication
    {
        public static void RegisterRoutes(RouteCollection routes)
        {
            routes.IgnoreRoute("{resource}.axd/{*pathInfo}");

            routes.Add(new Route("{xmlrpc}", null, new RouteValueDictionary(new { httpMethod = new HttpMethodConstraint("POST"), xmlrpc = "xmlrpc.metaweblog" }), new DNA.Mvc.XmlRpc.MetaWeblogRouteHandler()));
            routes.Add(new Route("{xmlrpc}", null, new RouteValueDictionary(new { httpMethod = new HttpMethodConstraint("POST"), xmlrpc = "xmlrpc.ping" }), new DNA.Mvc.XmlRpc.PingbackRouteHandler()));
            routes.MapRoute("dna_intergation", "{service}", new { controller = "DynamicUI", action = "GoogleSiteMap" }, new { service = "google-sitemap" });
            routes.MapRoute("dna_rssFeeds", "{feeds}/{website}/{rss}", new { controller = "DynamicUI", action = "RssFeed", website = "home" }, new { feeds = "feeds", rss = "rss" });
            routes.MapRoute("dna_atomFeeds", "{feeds}/{website}/{atom}", new { controller = "DynamicUI", action = "AtomFeed", website = "home" }, new { feeds = "feeds", atom = "atom" });
            #region webfiles routes
            routes.MapRoute("dna_webfiles_copy", "{service}/{website}/{*path}",
                new { website = "home", controller = "WebFiles", action = "Copy" },
                new { service = "webshared", httpMethod = new HttpMethodConstraint("COPY") });

            routes.MapRoute("dna_webfiles_move", "{service}/{website}/{*path}",
                new { website = "home", controller = "WebFiles", action = "Move" },
                new { service = "webshared", httpMethod = new HttpMethodConstraint("MOVE") });

            routes.MapRoute("dna_webfiles_mkcol", "{service}/{website}/{*path}",
                new { website = "home", controller = "WebFiles", action = "CreatePath" },
                new { service = "webshared", httpMethod = new HttpMethodConstraint("MKCOL") });

            routes.MapRoute("dna_webfiles_get", "{service}/{website}/{*path}",
                new { website = "home", controller = "WebFiles", action = "GetFile" },
                new { service = "webshared", httpMethod = new HttpMethodConstraint("GET") });

            routes.MapRoute("dna_webfiles_put", "{service}/{website}/{*path}",
                new { website = "home", controller = "WebFiles", action = "Replace" },
                new { service = "webshared", httpMethod = new HttpMethodConstraint("PUT") });

            routes.MapRoute("dna_webfiles_post", "{service}/{website}/{*path}",
                new { website = "home", controller = "WebFiles", action = "Upload" },
                new { service = "webshared", httpMethod = new HttpMethodConstraint("POST") });

            routes.MapRoute("dna_webfiles_delete", "{service}/{website}/{*path}",
                new { website = "home", controller = "WebFiles", action = "Delete" },
                new { service = "webshared", httpMethod = new HttpMethodConstraint("DELETE") });

            routes.MapRoute("dna_webfiles_list", "{service}/{website}/{*path}",
    new { website = "home", controller = "WebFiles", action = "List" },
    new { service = "webshared", httpMethod = new HttpMethodConstraint("LIST") });

            routes.MapRoute("dna_webfiles_paths", "{service}/{website}/{*path}",
                new { website = "home", controller = "WebFiles", action = "PathList" },
                new { service = "webshared", httpMethod = new HttpMethodConstraint("PLIST") });

            routes.MapRoute("dna_webfiles_files", "{service}/{website}/{*path}",
    new { website = "home", controller = "WebFiles", action = "FileList" },
    new { service = "webshared", httpMethod = new HttpMethodConstraint("FLIST") });
            #endregion

            routes.MapRoute("dna_mypages", "{sites}/{website}/{layout}.{extension}", new { controller = "DynamicUI", action = "Index", website = "home" }, new { sites = "sites", extension = "html" });
            routes.MapRoute("dna_mysite", "{website}-{controller}/{action}/{id}", new { controller = "Home", action = "Index", id = "" });
            routes.MapRoute("Default", "{controller}/{action}/{id}", new { controller = "Home", action = "Index", id = "" });
        }

        protected void Application_Start()
        {
            AreaRegistration.RegisterAllAreas();
            RegisterRoutes(RouteTable.Routes);
            WebHost.Start();

        }
    }
}