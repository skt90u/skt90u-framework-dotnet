﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DNA.Mvc
{
    [AttributeUsage(AttributeTargets.Assembly, AllowMultiple = false, Inherited = false)]
    public class AssemblyAuthorInfoAttribute : Attribute
    {
        public string AuthorName { get; set; }
        public string AuthorEmail { get; set; }
        public string WebSite { get; set; }
        public AssemblyAuthorInfoAttribute(string author) { AuthorName = author; }
        public AssemblyAuthorInfoAttribute(string author, string email)
            : this(author)
        {
            AuthorEmail = email;
        }
     
        public AssemblyAuthorInfoAttribute(string author, string email, string website)
            : this(author, email)
        {
            WebSite = website;
        }
    }

    [AttributeUsage(AttributeTargets.Assembly, AllowMultiple = true)]
    public class AssemblyLicenseInfoAttribute : Attribute
    {
        public AssemblyLicenseInfoAttribute(string name, string title, string url)
        {
            Name = name;
            Title = title;
            Url = url;
        }
        public string Title { get; set; }
        public string Name { get; set; }
        public string Url { get; set; }
    }

    [AttributeUsage(AttributeTargets.Assembly, AllowMultiple = true, Inherited = false)]
    public class AssemblyHelpLinkAttribute : Attribute
    {
        public AssemblyHelpLinkAttribute(string title, string helpLink) { Title = title; Url = helpLink; }
        public string Title { get; set; }
        public string Url { get; set; }
    }
}
