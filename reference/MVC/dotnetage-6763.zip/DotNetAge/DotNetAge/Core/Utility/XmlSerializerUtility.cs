//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;
using System.Xml.Serialization;
using System.IO;

namespace DNA.Utility
{
    /// <summary>
    /// XmlSerializerUtility provides the helper methods of xml serialize and xml deserialize
    /// </summary>
	public static class XmlSerializerUtility
	{
        public static string defaultNameSpace = "http://schemas.portalserver.com/xsd/v3.0";

        /// <summary>
        /// Serialize the object to stream
        /// </summary>
        /// <param name="stream"></param>
        /// <param name="type"></param>
        /// <param name="instance"></param>
        public static void SerizlizeToStream(Stream stream, Type type, object instance)
        {
            stream.Position = 0;
            XmlSerializer ser = new XmlSerializer(type);
            ser.Serialize(stream, instance);
        }

        /// <summary>
        /// Serialize the object to xml file
        /// </summary>
        /// <param name="fileName"></param>
        /// <param name="type"></param>
        /// <param name="instance"></param>
		public static void SerializeToXmlFile(string fileName, Type type, object instance)
		{
			FileStream stream = new FileStream(fileName, FileMode.OpenOrCreate, FileAccess.Write, FileShare.Write);
            SerizlizeToStream(stream,type,instance);
	        stream.Close();
		}

        /// <summary>
        /// Serialize the object to xml text
        /// </summary>
        /// <param name="type"></param>
        /// <param name="instance"></param>
        /// <returns></returns>
		public static string SerializeToXml(Type type, object instance)
		{
            //XmlSerializerNamespaces namespaces = new XmlSerializerNamespaces();
            //string Namespace = "http://schemas.portalfoundationserver.com/v3.0/xsd/websitetemplate";
            ////namespaces.Add("components", Namespace);
            ////namespaces.Add("component", Namespace);
            //XmlRootAttribute root= new XmlRootAttribute("components");
            //root.Namespace=Namespace;
			XmlSerializer ser = new XmlSerializer(type);

            MemoryStream stream = new MemoryStream();
			XmlTextWriter writer = new XmlTextWriter(stream, System.Text.Encoding.UTF8);
           
			writer.Formatting = Formatting.None;
			ser.Serialize(writer, instance);
			writer.Flush();
			stream.Position = 0;
			StreamReader reader = new StreamReader(stream,System.Text.Encoding.UTF8);
			string xml = reader.ReadToEnd();
			reader.Close();
			stream.Close();
			writer.Close();
			return xml;
		}

        /// <summary>
        /// Deserialize the object from stream
        /// </summary>
        /// <param name="stream"></param>
        /// <param name="type"></param>
        /// <returns></returns>
        public static object DeserializeFormStream(Stream stream, Type type)
        {
            stream.Position = 0;
            XmlSerializer ser = new XmlSerializer(type);
            object obj = ser.Deserialize(stream);
            return obj;
        }

        /// <summary>
        /// Deserialize the object from file
        /// </summary>
        /// <param name="fileName"></param>
        /// <param name="type"></param>
        /// <returns></returns>
		public static object DeserializeFormXmlFile(string fileName,Type type)
		{
            try
            {
                XmlSerializer ser = new XmlSerializer(type);
                FileStream stream = new FileStream(fileName, FileMode.Open, FileAccess.Read, FileShare.Read);
                object obj = ser.Deserialize(stream);
                stream.Close();
                return obj;
            }
            catch 
            {
                throw new XmlDeserializeException(fileName, type.ToString());
                //return null;
            }
		}

        /// <summary>
        /// Deserialize the object from text
        /// </summary>
        /// <param name="xml"></param>
        /// <param name="type"></param>
        /// <returns></returns>
		public static object DeserializeFromXmlText(string xml, Type type)
		{
			MemoryStream stream = new MemoryStream();
			StreamWriter writer = new StreamWriter(stream,System.Text.Encoding.UTF8);
			writer.Write(xml);
			writer.Flush();
			stream.Position = 0;

            XmlSerializer serializer = new XmlSerializer(type);
			object obj=serializer.Deserialize(stream);
			writer.Close();
			stream.Close();
			return obj;
		}
	}
}
