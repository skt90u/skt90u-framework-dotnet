﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Mvc;
using System.Globalization;

namespace DNA.Mvc
{
    [AttributeUsage(AttributeTargets.Method | AttributeTargets.Class, Inherited = true, AllowMultiple = true)]
    public class HandlePartialErrorAttribute : FilterAttribute, IExceptionFilter
    {
        // Fields
        private const string _defaultView = "WidgetError";
        private Type _exceptionType;
        private string _view;
        public HandlePartialErrorAttribute()
        {
            this._exceptionType = typeof(Exception);
        }

        public virtual void OnException(ExceptionContext filterContext)
        {
            if (filterContext == null)
            {
                throw new ArgumentNullException("filterContext");
            }

            if (!filterContext.ExceptionHandled && filterContext.HttpContext.IsCustomErrorEnabled)
            {
                Exception innerException = filterContext.Exception;
                if ((new HttpException(null, innerException).GetHttpCode() == 500) && this.ExceptionType.IsInstanceOfType(innerException))
                {
                    string controllerName = (string)filterContext.RouteData.Values["controller"];
                    string actionName = (string)filterContext.RouteData.Values["action"];
                    HandleErrorInfo model = new HandleErrorInfo(filterContext.Exception, controllerName, actionName);

                    PartialViewResult result = new PartialViewResult();
                    result.ViewName = this.View;
                    result.ViewData = new ViewDataDictionary<HandleErrorInfo>(model);
                    result.TempData = filterContext.Controller.TempData;
                    filterContext.Result = result;
                    filterContext.ExceptionHandled = true;
                    filterContext.HttpContext.Response.Clear();
                    filterContext.HttpContext.Response.StatusCode = 500;
                    filterContext.HttpContext.Response.TrySkipIisCustomErrors = true;
                }
            }
        }

        // Properties
        public Type ExceptionType
        {
            get
            {
                return this._exceptionType;
            }
            set
            {
                if (value == null)
                {
                    throw new ArgumentNullException("value");
                }
                if (!typeof(Exception).IsAssignableFrom(value))

                {
                    throw new ArgumentException(string.Format(CultureInfo.CurrentUICulture, "The type '{0}' does not inherit from Exception.", new object[] { value.FullName }));
                }
                this._exceptionType = value;
            }
        }

        public string View
        {
            get
            {
                if (string.IsNullOrEmpty(this._view))
                {
                    return "~/Views/Shared/WidgetError.ascx";
                }
                return this._view;
            }
            set { _view = value; }
        }

    }
}
