﻿//  Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Globalization;
using System.IO;
using System.Web.Caching;
using DNA.Mvc.Configuration;
using DNA.Mvc.Exceptions;
using DNA.Mvc.Models;
using System.Web.Routing;

namespace DNA.Mvc
{
    public class WebContext
    {
        private HttpContext _httpContext;
        private Web _web = null;
        private RouteData routeData = null;
        private WebPage _page;

        /// <summary>
        /// Gets the current httpcontext object
        /// </summary>
        public HttpContext HttpContext
        {
            get { return _httpContext; }
        }

        public WebContext(Uri uri)
        {
            _httpContext = new HttpContext(new System.Web.Hosting.SimpleWorkerRequest(VirtualPathUtility.ToAppRelative(uri.LocalPath).Replace("~/", ""), "", null));
            //_httpContext = new HttpContext(new System.Web.Hosting.SimpleWorkerRequest(uri.LocalPath, "", null));
            var wrapper = new HttpContextWrapper(_httpContext);
            foreach (var route in RouteTable.Routes)
            {
                routeData = route.GetRouteData(wrapper);
                if (routeData != null)
                {
                    var vpath = route.GetVirtualPath(wrapper.Request.RequestContext, routeData.Values);
                    if (vpath != null)
                    {
                        RouteData.Route = route;
                        break;
                    }
                }
            }
        }

        public WebContext(HttpContext httpContext)
        {
            _httpContext = httpContext;
        }

        /// <summary>
        ///  Gets the current web context for DNA
        /// </summary>
        public static WebContext Current
        {
            get
            {
                string key = "dna_context";
                var context = System.Web.HttpContext.Current.Items[key] as WebContext;
                if (context == null)
                {
                    context = new WebContext(System.Web.HttpContext.Current);
                    System.Web.HttpContext.Current.Items.Add(key, context);
                }
                return context;
            }
        }

        /// <summary>
        /// Gets the current page object of request.
        /// </summary>
        public WebPage Page
        {
            get
            {
                if (_page == null)
                    _page = GetCurrentPage();
                return _page;
            }
        }

        public bool IsPageExists
        {
            get
            {
                return this.Page != null;
            }
        }

        /// <summary>
        /// Gets the current web object of request.
        /// </summary>
        public Web Web
        {
            get
            {
                if (_web == null)
                    _web = WebSite.Open(this.RouteData);
                return _web;
            }
        }

        public T GetService<T>(string name)
        {
            return WebSite.GetService<T>(name);
        }

        /// <summary>
        /// Gets the current user object.
        /// </summary>
        public System.Security.Principal.IPrincipal User
        {
            get
            {
                return this.HttpContext.User;
            }
        }

        public string ApplicationPath
        {
            get
            {
                return WebSite.Open().GetFullUrl();
            }
        }

        public List<CultureInfo> Cultures
        {
            get
            {
                return WebSite.InstalledCultures;
            }
        }

        public List<SelectableNode> Themes
        {
            get
            {
                return WebSite.Themes;
            }
        }

        public List<SelectableNode> Languages
        {
            get
            {
                return WebSite.InstalledLanguages;
            }
        }

        public List<SelectableNode> TimeZones
        {
            get
            {
                return WebSite.TimeZones;
            }
        }
        public RouteData RouteData
        {
            get
            {
                if (routeData == null)
                    return this._httpContext.Request.RequestContext.RouteData;
                else
                    return routeData;
            }
        }

        public RequestContext RequestContext
        {
            get
            {
                return this._httpContext.Request.RequestContext;
            }
        }

        /// <summary>
        /// Gets the default uri for current request by current route.
        /// </summary>
        public string GetRouteDefaultUrl(string[] ignoreRouteDataKeys)
        {
            string defaultUrl = "";
            var routeDataValues = new RouteValueDictionary(this.RouteData.Values);
            var route = (Route)this.RouteData.Route;

            if (route != null)
            {
                if (ignoreRouteDataKeys != null)
                {
                    //Using default value
                    foreach (string key in ignoreRouteDataKeys)
                    {
                        if (route.Defaults.ContainsKey(key) && (routeDataValues.ContainsKey(key)))
                            routeDataValues[key] = route.Defaults[key];
                    }
                }

                var virtualPathData = route.GetVirtualPath(this.HttpContext.Request.RequestContext, routeDataValues);
                if (virtualPathData != null)
                    defaultUrl = virtualPathData.VirtualPath;
            }

            if (!string.IsNullOrEmpty(defaultUrl))
                defaultUrl = defaultUrl.StartsWith("/") ? ("~" + defaultUrl) : ("~/" + defaultUrl);

            return defaultUrl;
        }

        public bool IsDefaultPageExists(string[] ignoreRouteDataKeys)
        {
            return Web.IsPageExists(GetRouteDefaultUrl(ignoreRouteDataKeys));
        }

        private WebPage GetCurrentPage()
        {
            //string virtualPath = "~" + HttpContext.Request.Url.LocalPath.ToLower();
            string virtualPath = VirtualPathUtility.ToAppRelative(HttpContext.Request.Url.LocalPath).ToLower();
            if ((virtualPath.Equals("~/", StringComparison.OrdinalIgnoreCase)) ||
                (virtualPath.Equals("~/default.aspx", StringComparison.OrdinalIgnoreCase)) ||
                (virtualPath.Equals("~/home", StringComparison.OrdinalIgnoreCase)))
                virtualPath = "~/home/index";

            if (Web == null)
                return null;

            var _tmp = Web.GetPage(virtualPath);
            if (_tmp == null)
            {
                var _staticPages = Web.GetStaticPages();

                if (_staticPages.Count() > 0)
                {
                    var sharingPages = _staticPages.Where(s => s.IsShared).ToList();
                    if (sharingPages.Count() > 0)
                    {
                        foreach (var sp in sharingPages)
                        {
                            if (sp.Path.Equals(GetRouteDefaultUrl(sp.GetIgnoreRouteKeys()), StringComparison.OrdinalIgnoreCase))
                            {
                                _tmp = sp;
                                break;
                            }
                        }

                    }
                }
            }
            return _tmp;
        }
    }

}