﻿//  Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;
using DNA.Mvc.Security;
using System.Diagnostics;
using System.Web.Configuration;
using DNA.Mvc.Configuration;
using System.Security.Cryptography;
using System.Text;

namespace DNA.Mvc
{
    public static class WebHost
    {
        //private static bool _isInstalled = false;
        private static DnaConfigurationSection config;

        public static bool IsInstalled
        {
            get { return Config.Deployment.IsInstalled; }
        }


        public static bool EnablePersonalWeb
        {
            get { return Config.Deployment.EnablePersonalWeb; }
        }

        internal static DnaConfigurationSection Config
        {
            get
            {
                if (config == null)
                    config = (DnaConfigurationSection)System.Web.Configuration.WebConfigurationManager.GetSection("dna");
                return config;
            }
        }

        //internal static void UpdateConfig()
        //{
        //    var webConfig=WebConfigurationManager.OpenWebConfiguration(null);
        //    var _config = (DnaConfigurationSection)System.Web.Configuration.WebConfigurationManager.GetSection("dna");
        //    _config.Deployment.IsInstalled = Config.Deployment.IsInstalled;
        //    _config.Deployment.PublicKeyToken = Config.Deployment.PublicKeyToken;
        //    _config.Deployment.DatabaseName = Config.Deployment.DatabaseName;
        //    webConfig.Save();
        //}

        internal static string GenerateTokenKey(int bytelength)
        {
            byte[] buff = new byte[bytelength];
            RNGCryptoServiceProvider rng = new RNGCryptoServiceProvider();
            rng.GetBytes(buff);
            StringBuilder sb = new StringBuilder(bytelength * 2);
            for (int i = 0; i < buff.Length; i++)
                sb.Append(string.Format("{0:X2}", buff[i]));
            return sb.ToString();
        }

        public static void Start()
        {
            //IsInstalled = bool.Parse(WebConfigurationManager.AppSettings["isInstalled"]);
            if (IsInstalled)
            {
                try
                {
                    WebSite.SecurityService.LoadSecurityActionsInAssemblies();
                    //DNA.Mvc.DynamicUI.WidgetLoader.Load();
                }
                catch { System.Web.HttpRuntime.UnloadAppDomain(); }
            }
        }

    }
}
