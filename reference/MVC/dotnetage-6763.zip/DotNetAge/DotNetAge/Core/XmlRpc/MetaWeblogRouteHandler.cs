﻿//  Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Web.Routing;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using DNA.Mvc.Text;
using DNA.Mvc.Areas.Publishing.Models;
using CookComputing.XmlRpc;
using DNA.Mvc.OpenAPI.Blogging;

namespace DNA.Mvc.XmlRpc
{
    public class MetaWeblogRouteHandler:IRouteHandler
    {
        public IHttpHandler GetHttpHandler(RequestContext requestContext)
        {
            return new MetaWebblog();
        }
    }
}