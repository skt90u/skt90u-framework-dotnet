﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Mvc;

namespace DNA.Mvc
{
    public static class ImageExtensions
    {
        public static MvcHtmlString Image(this HtmlHelper helper, string url)
        {
            return helper.Image(url, null, null, null);
        }

        public static MvcHtmlString Image(this HtmlHelper helper, string url, int width, int height)
        {
            return helper.Image(url, width, height, null);
        }

        public static MvcHtmlString Image(this HtmlHelper helper, string url, int? width, int? height, object htmlAttributes)
        {
            UrlHelper urlHelper = new UrlHelper(helper.ViewContext.RequestContext);
            TagBuilder builder = new TagBuilder("img");
            builder.Attributes.Add("src", urlHelper.Content(url));

            if (width.HasValue)
            {
                if (width.Value > 0)
                    builder.MergeAttribute("style", "width:" + width.Value.ToString() + "px");
            }

            if (height.HasValue)
            {
                if (height.Value > 0)
                    builder.MergeAttribute("style", "height:" + height.Value.ToString() + "px");
            }
            if (htmlAttributes != null)
                builder.MergeAttributes<string, object>(ObjectHelper.ConvertObjectToDictionary(htmlAttributes));

            return MvcHtmlString.Create(builder.ToString(TagRenderMode.SelfClosing));
        }

        public static MvcHtmlString ImageLink(this HtmlHelper helper, string text, string url, string imgUrl)
        {
            return helper.ImageLink(text, url, imgUrl, null);
        }

        public static MvcHtmlString ImageLink(this HtmlHelper helper, string text, string url, string imgUrl, object htmlAttributes)
        {
            var builder = new NodeUIBuilder();
            var node = new SelectableNode()
            {
                NavigateUrl = url,
                ImageUrl = imgUrl,
                Text = text
            };

            builder.WriteBeginLink(node, new { style = "display:inline-block;" });
            builder.WriteImage(node, new { style = "float:left;margin-top:2px;margin-right:3px;" });
            builder.WriteTitle(node, new { style = "float:left;" });
            builder.WriteEndTag("a");
            return MvcHtmlString.Create(builder.ToString());
        }

        /// <summary>
        /// Auto fit the images size.
        /// </summary>
        /// <param name="helper"></param>
        /// <param name="htmlContainer"></param>
        /// <param name="maxHeight"></param>
        /// <param name="maxWidth"></param>
        public static void ForceImageAutoSize(this HtmlHelper helper, string htmlContainer, int maxHeight, int maxWidth)
        {
            if (!string.IsNullOrEmpty(htmlContainer))
            {
                var scripts = new StringBuilder();
                scripts.Append("var imgs=$(\"#" + htmlContainer + "\").find('img');")
                          .Append("if (imgs.length) { imgs.load(function(){");
                
                if (maxWidth > 0)
                    scripts.Append("if ($(this).width()>" + maxWidth.ToString() + ") $(this).width(" + maxWidth.ToString() + ");");

                if (maxHeight > 0)
                    scripts.Append("if ($(this).height()>" + maxHeight.ToString() + ") $(this).height(" + maxHeight.ToString() + ");");

                scripts.Append("})}");
                helper.RegisterStartupScript(scripts.ToString());
            }
        }
    }
}
