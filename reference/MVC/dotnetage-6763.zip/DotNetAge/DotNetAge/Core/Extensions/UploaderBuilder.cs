﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using DNA.Mvc.jQuery;
using System.Web.Mvc;

namespace DNA.Mvc
{
    public class UploaderBuilder : jQueryComponentBuilder<UploaderOptions, Uploader, UploaderBuilder>
    {
        protected override string jQueryPluginName
        {
            get { return ""; }
        }

        public UploaderBuilder(Uploader component, AjaxHelper helper) : base(component, helper) { }
        
        public UploaderBuilder Upload(string url)
        {
            Options(opts => opts.Action = url);
            return this;
        }

        public override void Render()
        {
            if (options != null)
            {
                var optionBuilder = new OptionBuilder();
                optionBuilder.AddOptions(this.options);
                Helper.RegisterStartupScript("var _"+Component.Name+"= new AjaxUpload("+ jQuerySelector +"," + optionBuilder.ToString() + ");");
            }
        }
    }

    public class UploaderOptions
    {
        [jQueryOption("action")]
        public string Action { get; set; }

        [jQueryOption("name")]
        public string HttpFileName { get; set; }

        [jQueryOption("autoSubmit")]
        public bool? AutoSubmit { get; set; }

        [jQueryOption("onChange", ValueType = JavaScriptTypes.Function)]
        public string OnChanged { get; set; }

        [jQueryOption("onComplete", ValueType = JavaScriptTypes.Function, FunctionParams = new string[] { "file", "response" })]
        public string OnCompleted { get; set; }

        [jQueryOption("onSubmit", ValueType = JavaScriptTypes.Function, FunctionParams = new string[] { "file", "extension" })]
        public string OnSubmit { get; set; }

        [jQueryOption("responseType")]
        public string ResponseType { get; set; }
    }
}