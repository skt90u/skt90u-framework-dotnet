﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.IO;
using System.Reflection;
using System.Web.Mvc;

namespace DNA.Mvc
{
    /// <summary>
    /// Used to load MyControlPanel action and SiteControlPanel action
    /// </summary>
    public static class ControlPanelExtensions
    {
        private class SortedTab
        {
            public string Title { get; set; }
            public int Order { get; set; }
            public string Url { get; set; }
        }

        public static IDictionary<string, string> ControlPanelActions<T>(this UrlHelper url)
            where T : ControlPanelAttribute
        {
            string[] files = Directory.GetFiles(HttpContext.Current.Server.MapPath("~/bin"), "*.dll");
            IDictionary<string, string> tabs = new Dictionary<string, string>();
            List<SortedTab> sorted = new List<SortedTab>();
            foreach (string file in files)
            {
                try
                {
                    Assembly assembly = Assembly.LoadFrom(file);
                    AssemblyName asmname = assembly.GetName();
                    Type[] types = assembly.GetTypes();
                    var controllers = from c in types
                                      where c.BaseType == typeof(Controller)
                                      select c;

                    foreach (Type controller in controllers)
                    {
                        var methods = controller.GetMethods(BindingFlags.Public | BindingFlags.Instance);
                        var actions = from MethodInfo method in methods
                                      where (method.GetCustomAttributes(typeof(T), true).Length > 0)
                                      select method;

                        foreach (MethodInfo action in actions)
                        {
                            T attr = (T)Attribute.GetCustomAttribute(action, typeof(T));
                            string text = attr.Text;
                            //Get permission 
                            var securityAttr = Attribute.GetCustomAttribute(action, typeof(Security.SecurityActionAttribute));
                            if (securityAttr != null)
                            {
                                //Permission check

                                if ((!WebSite.SecurityService.IsAuthorize(controller, action.Name)) && (!HttpContext.Current.User.IsWebOwner()))
                                    continue;
                            }

                            /*--------------------Personal only-----------------------------*/
                            if (!WebHost.Config.Deployment.EnablePersonalWeb)
                            {
                                var attrType = attr as MyControlPanelAttribute;
                                if (attrType != null)
                                {
                                    if (attrType.ShowInPersonalSiteOnly)
                                        continue;
                                }
                            }

                            if (!string.IsNullOrEmpty(attr.ResKey))
                            {

                                if (!string.IsNullOrEmpty(attr.ResBaseName))
                                    text = GlobalizationExtensions.Global(null, attr.ResBaseName, attr.ResKey);
                                else
                                    text = GlobalizationExtensions.Global(null, attr.ResKey);
                            }
                            string _controller = controller.Name.Replace("Controller", "");
                            sorted.Add(new SortedTab()
                            {
                                Order = attr.Order,
                                Title = text,
                                Url = url.Action(action.Name, _controller, new { Area = GetArea(action.Name, _controller) })
                            });
                            //tabs.Add(text, url.Action(action.Name, _controller));
                        }
                    }
                }
                catch (Exception e)
                {
                    continue;
                }
            }

            if (sorted.Count > 0)
                return sorted.OrderBy(s => s.Order).ToDictionary(s => s.Title, s => s.Url);
            return tabs;
        }

        private static string GetArea(string action, string controller)
        {
            if (!Directory.Exists(HttpContext.Current.Server.MapPath("~/Areas")))
                return "";
            string path = "";
            string[] dirs = System.IO.Directory.GetDirectories(HttpContext.Current.Server.MapPath("~/Areas"));
            foreach (var dir in dirs)
            {
                path = dir + "\\Views\\" + controller;
                if (System.IO.Directory.Exists(path))
                    return ((new System.IO.DirectoryInfo(dir)).Name);
            }
            return "";
        }
    }
}
