﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using System.Web.Profile;
using System.Net.Mail;
using DNA.Mvc.Models;
namespace DNA.Mvc
{
    public static class MailExtensions
    {
        public static void MailTo(this Controller controller, string userName, string subject, string body)
        {
            controller.MailTo(userName, subject, body, false);
        }

        public static void MailTo(this Controller controller, string userName, string subject, string body, bool isHtml)
        {
            if (string.IsNullOrEmpty(userName))
                throw new ArgumentNullException("userName");

            MembershipUser user = Membership.GetUser(userName);
            if (user == null)
                throw new Exception("User not found.");

            controller.MailTo(new MailMessageModel()
            {
                IsHtml = isHtml,
                Receiver = user.Email,
                Subject = subject,
                MailBody = body
            });

        }

        public static void MailTo(this Controller controller, MailMessageModel mail)
        {
            var _mail = new MailMessage()
            {
                IsBodyHtml=mail.IsHtml,
                Subject=mail.Subject,
                Body=mail.MailBody
            };
            _mail.To.Add(new MailAddress(mail.Receiver));
            SendMailCore(_mail);
        }

        private static void SendMailCore(MailMessage mail)
        { 
            var web = WebSite.Open("");
            if (!string.IsNullOrEmpty(web.SiteMailAccount))
            {
                mail.From = new MailAddress(web.SiteMailAccount);
                var smtpClient = new SmtpClient();
                if (!string.IsNullOrEmpty(web.SMTPHost))
                    smtpClient.Host = web.SMTPHost;
                if (web.SMTPPort != 0)
                    smtpClient.Port = web.SMTPPort;

                if (web.SMTPUsedDefaultCredentials)
                    smtpClient.UseDefaultCredentials = web.SMTPUsedDefaultCredentials;
                else
                    smtpClient.Credentials = new System.Net.NetworkCredential(web.SMTPUserName, web.SMTPPassword);

                smtpClient.SendAsync(mail, null);
            }
        }
    }
}
