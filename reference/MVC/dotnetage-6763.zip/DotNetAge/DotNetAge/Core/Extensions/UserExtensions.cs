﻿//  Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Security.Principal;
using System.Web.Profile;

namespace DNA.Mvc
{
    public static class UserExtensions
    {
        /// <summary>
        /// Identity whether the current user is administrator
        /// </summary>
        /// <param name="user">The user object</param>
        /// <returns></returns>
        public static bool IsAdministrator(this IPrincipal user)
        {
            if (user.Identity != null)
            {
                if (user.IsInRole("administrators"))
                    return true;
            }

            return false;
        }

        /// <summary>
        /// Identity whether the current user is host.
        /// </summary>
        /// <param name="user">The user object</param>
        /// <returns></returns>
        public static bool IsHost(this IPrincipal user)
        {
            if (user.Identity != null)
                return user.Identity.Name.Equals("host", StringComparison.OrdinalIgnoreCase);
            return false;
        }

        /// <summary>
        /// Identity whether the current user is current web owner.
        /// </summary>
        /// <param name="user">The user object</param>
        /// <returns></returns>
        public static bool IsWebOwner(this IPrincipal user)
        {
            if (HttpContext.Current.Request.IsAuthenticated)
            {
                if (user.Identity != null)
                {
                    var currentWeb = WebContext.Current.Web;
                    return user.Identity.Name.Equals(currentWeb.Owner, StringComparison.OrdinalIgnoreCase);
                }
            }
            return false;
        }

        /// <summary>
        /// Get the permalink of this user.
        /// </summary>
        /// <param name="user"></param>
        /// <returns>A Uri will be return.</returns>
        public static Uri GetPermalinkUrl(this IPrincipal user)
        {
            return GetPermalinkUrlCore(user.Identity.Name);
        }

        public static Uri GetPermalinkUrl(this MembershipUser user)
        {
            return GetPermalinkUrlCore(user.UserName);
        }

        public static ProfileBase GetProfile(this MembershipUser user)
        {
            return GetProfile(user.UserName);
        }

        public static string GetDisplayName(this MembershipUser user)
        {
            return GetDisplayNameCore(user.UserName);
        }

        public static string GetAvatar(this MembershipUser user)
        {
            string avatar =GetProfile(user.UserName)["Avatar"] as string;
            if (string.IsNullOrEmpty(avatar))
                avatar = WebSite.ApplicationPath + "/Content/Images/no-avatar.gif";
            return avatar;
        }

        private static ProfileBase GetProfile(string name)
        {
            var profile = new ProfileBase();
            profile.Initialize(name, true);
            return profile;
        }

        private static string GetDisplayNameCore(string name)
        {
            string dName= GetProfile(name)["DisplayName"] as string;
            return string.IsNullOrEmpty(dName) ? name : dName;
        }

        private static Uri GetPermalinkUrlCore(string username)
        {
            Uri url = null;
            string userLink = WebSite.ApplicationPath + "/sites/" + username + "/index.html";
            if (!WebHost.Config.Deployment.EnablePersonalWeb)
                userLink=WebSite.ApplicationPath+"/account/info?username="+username;
            Uri.TryCreate(userLink, UriKind.Absolute, out url);
            return url;
        }
    }
}