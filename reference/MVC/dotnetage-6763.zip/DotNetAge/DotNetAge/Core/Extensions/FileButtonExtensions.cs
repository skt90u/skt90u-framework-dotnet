﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Mvc;

namespace DNA.Mvc.jQuery
{
    /// <summary>
    /// Provides the methods to render a button to show the file dialog to select or upload files.
    /// </summary>
    public static class FileButtonExtensions
    {
        /// <summary>
        /// Render the button html and has the open file dialog default behavior
        /// </summary>
        /// <param name="helper">The helper object</param>
        /// <param name="targetID">The target element which the selected file fills to .</param>
        /// <param name="path">The specified the init folder path</param>
        /// <param name="text">Specified the button text.</param>
        /// <returns>Button html </returns>
        public static MvcHtmlString FileButton(this AjaxHelper helper, string targetID, Uri path, string text)
        {
            return helper.FileButton(targetID, path, new ButtonOptions() { Text = text }, null);
        }

        /// <summary>
        /// Render the button html and has the open file dialog default behavior
        /// </summary>
        /// <param name="helper">The helper object</param>
        /// <param name="targetID">The target element which the selected file fills to .</param>
        /// <param name="path">The specified the init folder path</param>
        /// <param name="options">The ButtonOptions object</param>
        /// <returns>Button html</returns>
        public static MvcHtmlString FileButton(this AjaxHelper helper, string targetID, Uri path, ButtonOptions options)
        {
            return helper.FileButton(targetID, path, options, null);
        }

        /// <summary>
        /// Render the button html and has the open file dialog default behavior
        /// </summary>
        /// <param name="helper">The helper object</param>
        /// <param name="targetID">The target element which the selected file fills to .</param>
        /// <param name="path">The specified the init folder path</param>
        /// <param name="options">The ButtonOptions object</param>
        /// <param name="htmlAttributes">The html attributes of the buttons</param>
        /// <returns>Button html</returns>
        public static MvcHtmlString FileButton(this AjaxHelper helper, string targetID, Uri path, ButtonOptions options, object htmlAttributes)
        {
            if (options == null)
                throw new ArgumentNullException("options");

            if (string.IsNullOrEmpty(targetID))
                throw new ArgumentNullException("targetID");
            
            if (path == null)
                throw new ArgumentNullException("path");
            
            //UrlHelper Url = new UrlHelper(helper.ViewContext.RequestContext);
            //var _path = string.IsNullOrEmpty(path) ? "webfile://root" : path;

            var scripts = new StringBuilder();
            scripts.Append("portal.fileSharing.openFileDialog('")
               //       .Append(Url.Content("~/FileSharing"))
                  //    .Append("','")
                      .Append(path.ToString())
                      .Append("',function(_result) { $(\"#")
                      .Append(targetID)
                      .Append("\").val(_result);});");

            options.OnClick = string.IsNullOrEmpty(options.OnClick) ? scripts.ToString() : options.OnClick + scripts.ToString();

            //string clientScript="$('#" + name + "_browselink').click(function(event){" + 
            //    "event.preventDefault();portal.fileSharing.openFileDialog('" + Url.Content("~/FileSharing") + "','" +
            //    _path + "',function(_result) { $(\"#" + name + "\").val(_result);});" + "});";

            return helper.Button(options, htmlAttributes);
        }
    }
}
