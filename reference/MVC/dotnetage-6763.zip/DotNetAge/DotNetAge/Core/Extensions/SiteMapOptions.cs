﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DNA.Mvc
{

    /// <summary>
    /// Defines the options for SiteMap Extensions
    /// </summary>
    public class SiteMapOptions
    {
        private string _baseImagePath = "/content/images/treeview/";
        private string _key="0";
        /// <summary>
        /// Gets/Sets the SiteMap treeview image search path
        /// </summary>
        public string BaseImagePath
        {
            get { return _baseImagePath; }
            set { _baseImagePath = value; }
        }

        /// <summary>
        /// Gets/Sets the current selected key value
        /// </summary>
        public string SelectedKey { get { return _key; } set { _key = value; } }

        /// <summary>
        /// Gets/Sets the scripts when site map tree node selected.
        /// </summary>
        /// <remarks>
        ///  Using $(this) to get the current selected node jQuery object.
        /// </remarks>
        public string OnNodeSelected { get; set; }
    }
}
