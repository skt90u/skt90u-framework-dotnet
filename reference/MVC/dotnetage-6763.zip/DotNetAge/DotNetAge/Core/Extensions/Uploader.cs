﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DNA.Mvc
{
    public class Uploader : ViewComponent
    {
        public override void Render(System.Web.UI.HtmlTextWriter writer) { }
    }
}