﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Mvc;
using System.Web;
using System.Web.UI;
using System.IO;
using System.Globalization;
using System.Text.RegularExpressions;
using System.Web.Profile;

namespace DNA.Mvc
{
    public static class GlobalizationExtensions
    {
        /// <summary>
        /// Render the globalize resource text
        /// </summary>
        /// <param name="helper">The HTML helper</param>
        /// <param name="key">the reousece key</param>
        /// <returns></returns>
        public static string Global(this HtmlHelper helper, string key)
        {
            return Global(helper, null, key);
        }

        /// <summary>
        /// Render the globalize resource text
        /// </summary>
        /// <param name="helper">The HTML helper</param>
        /// <param name="classKey">the key specified the which resource shold load</param>
        /// <param name="key">the resource key</param>
        /// <returns></returns>
        public static string Global(this HtmlHelper helper, string classKey, string key)
        {
            string ck = "language";
            if (!string.IsNullOrEmpty(classKey))
                ck = classKey;
            try
            {
                return HttpContext.GetGlobalResourceObject(ck, key, CurrentCulture).ToString();
            }
            catch { return key ; }
        }

        private static CultureInfo CurrentCulture
        {
            get { return HtmlUIExtensions.GetCultureInfo(); }
        }

        /// <summary>
        /// Render the value to current culture number format.
        /// </summary>
        /// <param name="helper">The html helper.</param>
        /// <param name="value">The value to be formated.</param>
        /// <returns></returns>
        public static string Global(this HtmlHelper helper, int value)
        {
            return value.ToString("N", CurrentCulture.NumberFormat);
        }

        /// <summary>
        /// Render the value to current culture number format.
        /// </summary>
        /// <param name="helper">The html helper.</param>
        /// <param name="value">The value to be formated.</param>
        /// <returns></returns>
        public static string Global(this HtmlHelper helper, float value)
        {
            return value.ToString("N", CurrentCulture.NumberFormat);
        }

        /// <summary>
        /// Render the value to current culture number format.
        /// </summary>
        /// <param name="helper">The html helper.</param>
        /// <param name="value">The value to be formated.</param>
        /// <returns></returns>
        public static string Global(this HtmlHelper helper, decimal value)
        {
            return value.ToString("N", CurrentCulture.NumberFormat);
        }

        /// <summary>
        /// Render the value to current culture number format.
        /// </summary>
        /// <param name="helper">The html helper.</param>
        /// <param name="value">The value to be formated.</param>
        /// <returns></returns>
        public static string Global(this HtmlHelper helper, double value)
        {
            return value.ToString("N", CurrentCulture.NumberFormat);
        }

        /// <summary>
        /// Render the value to current culture currency format.
        /// </summary>
        /// <param name="helper">The html helper.</param>
        /// <param name="value">The value to be formated.</param>
        /// <returns></returns>
        public static string Currency(this HtmlHelper helper, float value)
        {
            return value.ToString("C", CurrentCulture.NumberFormat);
        }

        /// <summary>
        /// Render the value to current culture currency format.
        /// </summary>
        /// <param name="helper">The html helper.</param>
        /// <param name="value">The value to be formated.</param>
        /// <returns></returns>       
        public static string Currency(this HtmlHelper helper, decimal value)
        {
            return value.ToString("C", CurrentCulture.NumberFormat);
        }

        /// <summary>
        /// Render the value to current culture currency format.
        /// </summary>
        /// <param name="helper">The html helper.</param>
        /// <param name="value">The value to be formated.</param>
        /// <returns></returns>
        public static string Currency(this HtmlHelper helper, double value)
        {
            return value.ToString("C", CurrentCulture.NumberFormat);
        }

        /// <summary>
        /// Convert the date to current user's time zone and format the datetime to the user culture.
        /// </summary>
        /// <param name="helper">The html helper.</param>
        /// <param name="date">the date to be formated.</param>
        /// <returns></returns>
        public static string Global(this HtmlHelper helper, DateTime date, bool isTime)
        {
            DateTime _date = date;
            if (helper.ViewContext.HttpContext.Request.IsAuthenticated)
            {
                ProfileBase profile = helper.ViewContext.HttpContext.Profile;
                if (profile["TimeZone"] != null)
                {
                    if (!string.IsNullOrEmpty(profile["TimeZone"].ToString()))
                    {
                        try
                        {
                            var web = WebSite.Open(helper.ViewContext.RouteData);
                            TimeZoneInfo destTimeZone = TimeZoneInfo.FindSystemTimeZoneById(profile["TimeZone"].ToString());
                            if (destTimeZone != null)
                                _date = TimeZoneInfo.ConvertTime(date, web.TimeZoneInfo, destTimeZone);
                        }
                        catch (Exception e)
                        {
                            if (e is TimeZoneNotFoundException)
                            {
                                if (isTime)
                                    return _date.ToString(CurrentCulture.DateTimeFormat.LongTimePattern);
                                else
                                    return _date.ToString(CurrentCulture.DateTimeFormat);
                            }
                        }
                    }
                }

            }
            if (isTime)
                return _date.ToString(CurrentCulture.DateTimeFormat.LongTimePattern);
            else
                return _date.ToString(CurrentCulture.DateTimeFormat);
        }
        
        public static string Global(this HtmlHelper helper, DateTime date)
        {
            return helper.Global(date, false);
        }

        /// <summary>
        /// Format the input string to the globalize string text.if the input text start with # this method will the key 
        /// in the global resource file.
        /// </summary>
        /// <param name="helper">The Html helper</param>
        /// <param name="text">The input text to globalize</param>
        /// <returns></returns>
        public static string GlobalFormat(this HtmlHelper helper, string text)
        {
            if (text.StartsWith("#"))
            {
                string key = text.Substring(1);
                if (!string.IsNullOrEmpty(key))
                    return Global(helper, key);
            }
            return text;
        }

        ///// <summary>
        ///// Render the localize resource text
        ///// </summary>
        ///// <param name="helper">The HTML helper</param>
        ///// <param name="viewName">The view in LocalResources path</param>
        ///// <param name="key">the resource key</param>
        ///// <returns></returns>
        //public static string Local(this HtmlHelper helper, string viewName, string controller, string area, string key)
        //{
        //    string ctrlName = string.IsNullOrEmpty(controller) ? helper.ViewContext.RequestContext.RouteData.Values["controller"].ToString() : controller;
        //    var culture = System.Threading.Thread.CurrentThread.CurrentUICulture;
        //    string extension = culture.Name != "en-US" ? "." + culture.Name : "";
        //    string ascxPath = (string.IsNullOrEmpty(area) ? "~" : ("~/Areas/" + area)) + "/LocalResources/" + ctrlName + "/" + viewName + ".ascx";
        //    string aspxPath = (string.IsNullOrEmpty(area) ? "~" : ("~/Areas/" + area)) + "/LocalResources/" + ctrlName + "/" + viewName + ".aspx" ;
        //    if (File.Exists(helper.ViewContext.HttpContext.Server.MapPath(ascxPath+ extension + ".resx")))
        //        return HttpContext.GetLocalResourceObject(ascxPath, key, HtmlUIExtensions.GetCultureInfo()).ToString();
        //    if (File.Exists(helper.ViewContext.HttpContext.Server.MapPath(aspxPath + extension + ".resx")))
        //        return HttpContext.GetLocalResourceObject(aspxPath, key, HtmlUIExtensions.GetCultureInfo()).ToString();
        //    return key;
        //}

        //public static string Local(this HtmlHelper helper, string viewName, string controller, string key)
        //{
        //    return helper.Local(viewName, controller, "", key);
        //}

        //public static string Local(this HtmlHelper helper, string viewName, string key)
        //{
        //    return helper.Local(viewName, "", "", key);
        //}


        /// <summary>
        /// Register the client resource to the client resource object.
        /// </summary>
        /// <remarks>
        /// After register you can get the resource value in javascript by using portal.res.[the resource name you register]
        /// </remarks>
        /// <param name="helper">The html helper.</param>
        /// <param name="name">The resource name.</param>
        /// <param name="value">The resource value.</param>
        public static void ClientRes(this HtmlHelper helper, string name, string value)
        {
            if (helper.ViewContext.TempData["ClientRes"] == null)
                helper.ViewContext.TempData["ClientRes"] = new Dictionary<string, string>();
            Dictionary<string, string> resources = helper.ViewContext.TempData["ClientRes"] as Dictionary<string, string>;
            if (!resources.Keys.Contains(name))
                resources.Add(name, value);
        }
    }
}
