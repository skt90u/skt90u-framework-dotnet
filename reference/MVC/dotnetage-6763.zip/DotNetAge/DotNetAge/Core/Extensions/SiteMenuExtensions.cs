﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DNA.Mvc.DynamicUI;
using DNA.Mvc.jQuery;
using System.Web.Mvc;
using System.Web;
using System.Web.Caching;
using System.IO;
using System.Web.UI;
using DNA.Mvc.Models;

namespace DNA.Mvc
{
    public static class SiteMenuExtensions
    {
        //private static DynamicPageService Service { get { return WebSite.GetService<DynamicPageService>("pages"); } }

        public static MvcHtmlString SiteMenu(this AjaxHelper helper)
        {
            #region Old for cache
            //Cache cache = helper.ViewContext.HttpContext.Cache;
            //string key = "MainMenuNodes";

            //if (cache[key] == null)
            //{
            //    UrlHelper urlHelper = new UrlHelper(helper.ViewContext.RequestContext);
            //    var _nodes = Service.GetNavigatablePages();
            //    _nodes.ForEach(a => a.NavigateUrl = urlHelper.Content(a.NavigateUrl));
            //    cache.Add(key, _nodes, null, DateTime.Now.AddMinutes(1), TimeSpan.Zero, CacheItemPriority.Default, null);
            //}
            //List<SelectableNode> nodes = (List<SelectableNode>)cache[key];
            #endregion
            var web = WebSite.CurrentWeb();
            var provider = web.GetNodeProvider();
            TagBuilder builder = new TagBuilder("div");
            builder.Attributes.Add("style", "display:block;");
            builder.AddCssClass("dna-menu");

            var _builder = new HierarchicalNodeUIBuilder();
            var nodes = provider.RootNode.ChildNodes;
            _builder.WriteBeginTag("ul", null);
            var current = provider.CurrentNode;
            foreach (var node in nodes)
            {
                if ((bool)node.Attributes["ShowInMenu"])
                {
                    if (node.IsAccessibleToUser())
                    {
                        var attrs = new Dictionary<string, object>();
                        attrs.Union(node.Attributes);

                        if (current != null)
                        {
                            if (current.Equals(node) || current.IsDescendantOf(node))
                            {
                                attrs.Add("selected", true);
                                _builder.WriteBeginTag("li", attrs);

                            }
                            else
                                _builder.WriteBeginTag("li", attrs);
                        }
                        else
                            _builder.WriteBeginTag("li", attrs);
                        _builder.WriteNodeContent(node);

                        if (node.HasChildNodes)
                            _builder.WriteNodesRecursive(node.ChildNodes);
                        _builder.WriteEndTag("li");
                    }
                }
            }
            _builder.WriteEndTag("ul");
            string _html = _builder.ToString();
            var options = new MenuOptions()
            {
                TopMenuCssClass = "ui-menu-topmenu",
                TopItemCssClass = "ui-menu-topitem",
                TopItemHoverCssClass = "ui-menu-topitem-hover",
                TopItemSelectedCssClass = "ui-menu-topitem-selected",
                SubMenuCssClass = "ui-menu-submenu",
                SubMenuItemCssClass = "ui-menu-submenuitem",
                SubMenuItemHoverCssClass = "ui-menu-submenuitem-hover"
            };

            builder.InnerHtml += "<div id='DynamicMainMenu' class='ui-menu' style = \"display:inline-block;\">";
            builder.InnerHtml += _html;
            builder.InnerHtml += "</div>";

            //builder.InnerHtml += "<div style=\"display:block;height:3px;\" class=\"ui-widget-header\"></div>";
            helper.jQuery("#DynamicMainMenu>ul", "dnamenu", options);
            return MvcHtmlString.Create(builder.ToString());
        }

        public static MvcHtmlString SiteToolsMenu(this AjaxHelper helper)
        {
            //return helper.Menu("dna_site_toolsmenu")
            //                    .Options(options=>{
            //                        options.DropdownEvent = DomEvents.MouseOver;                                    
            //                    })
            //                    .Render();
            return MvcHtmlString.Empty;
        }

        //public static MvcHtmlString SubMenu(this AjaxHelper helper)
        //{
        //    return MvcHtmlString.Empty;
        //}




    }

}
