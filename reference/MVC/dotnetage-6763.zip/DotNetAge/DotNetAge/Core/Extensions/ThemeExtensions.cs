﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Mvc;
using System.Web;
using System.Web.UI;
using System.IO;
using System.Globalization;
using System.Text.RegularExpressions;
using DNA.Mvc.jQuery;
using DNA.Mvc.Models;

namespace DNA.Mvc.Theming
{
    public static class ThemeExtensions
    {
        public static MvcHtmlString ThemeSwitcher(this AjaxHelper helper)
        {
            return ThemeSwitcher(helper, "GlobalThemeSwitcher");
        }

        public static MvcHtmlString ThemeSwitcher(this AjaxHelper helper, string name)
        {
            var web = WebSite.Open(helper.ViewContext.RouteData);
            UrlHelper Url = new UrlHelper(helper.ViewContext.RequestContext);
            StringBuilder scripts = new StringBuilder();
            scripts.Append("$.post('" + Url.Action("ChangeTheme", "Sys",
                new { website = web.Name.Equals("home") ? "" : web.Name, Area = ""}) + "',")
                      .Append("{ theme:ui.value},")
                      .Append("function(txt) {")
                      .Append("$(\"head link[href*='Content/Themes']\").remove();")
                      .Append("$(\"head\").append(txt);")
                      .Append("});");
            //helper.ViewContext.Controller.
            return ThemeDropDown(helper, name, new DropDownOptions() { SelectedValue = web.Theme, OnClientSelectedChanged = scripts.ToString() });
        }

        public static MvcHtmlString ThemeDropDown(this AjaxHelper helper, string name)
        {
            return ThemeDropDown(helper, name, null);
        }

        public static MvcHtmlString ThemeDropDown(this AjaxHelper helper, string name, DropDownOptions options)
        {
            DropDownOptions opts = options == null ? new DropDownOptions() : options;
            opts.PrefixText = "Theme";
            opts.SelectWholeItem = false;
            opts.AutoSize = true;
            opts.TextFieldSelector = ">span";

            return DropDownExtensions.DropDown(helper, name, WebSite.Themes, opts);
        }
    }
}
