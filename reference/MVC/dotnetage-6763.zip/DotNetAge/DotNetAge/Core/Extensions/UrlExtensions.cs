﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace DNA.Mvc
{
    public static class UrlExtensions
    {
        public static string ThemeContent(this UrlHelper helper, string url)
        {
            return helper.Content("~/Content/Themes/" + WebSite.Open(HttpContext.Current).Theme + "/" + url);
        }
    }
}