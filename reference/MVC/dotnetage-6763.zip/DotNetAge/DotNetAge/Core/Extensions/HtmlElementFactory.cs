﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace DNA.Mvc
{
    public class HtmlElementFactory
    {
        private HtmlHelper html;
        private AjaxHelper ajax;

        public HtmlHelper Html
        {
            get { return html; }
        }

        public HtmlElementFactory(HtmlHelper helper)
        {
            html = helper;
            ajax = new AjaxHelper(html.ViewContext, html.ViewDataContainer);
        }

        public MvcHtmlString PageHeader()
        {
            var web = WebSite.CurrentWeb();
            var urlHelper = UrlUtility.CreateUrlHelper();
            string defaultUrl = string.IsNullOrEmpty(web.DefaultUrl) ? web.AppUrl.ToString() : urlHelper.Content(web.DefaultUrl);
            var header = new TagBuilder("div");
            var homeLink = new TagBuilder("a");
            var h1 = new TagBuilder("h1");

            header.GenerateId("dna-page-header");
            homeLink.MergeAttribute("href", defaultUrl);

            if (!string.IsNullOrEmpty(web.LogoImageUrl))
            {
                var logo = new TagBuilder("img");
                logo.MergeAttribute("alt", web.Title);
                logo.MergeAttribute("src", urlHelper.Content(web.LogoImageUrl));
                logo.MergeAttribute("border", "0");
                logo.MergeAttribute("style", "float:left;");
                homeLink.InnerHtml = logo.ToString(TagRenderMode.SelfClosing);
            }

            switch (web.LogoLayout)
            {
                case LogoLayouts.LogoOnly:
                    header.InnerHtml = homeLink.ToString();
                    break;
                case LogoLayouts.LogoAndTitle:
                    header.InnerHtml = "<table><tr><td>" + homeLink.ToString() + "</td><td><h1>" + web.Title + "</h1></td></tr></table>";
                    break;
                case LogoLayouts.LogoWithTitleRightBottom:
                    header.InnerHtml = "<table><tr><td>" + homeLink.ToString() + "</td><td valign=\"bottom\"><h1>" + web.Title + "</h1></td></tr></table>";
                    break;
                case LogoLayouts.LogoWithTitleRightTop:
                    header.InnerHtml = "<table><tr><td>" + homeLink.ToString() + "</td><td valign=\"top\"><h1>" + web.Title + "</h1></td></tr></table>";
                    break;
                case LogoLayouts.LogoWithTitleBlow:
                    header.InnerHtml = "<table><tr><td>" + homeLink.ToString() + "</td></tr><tr><td><h1>" + web.Title + "</h1></td></tr></table>";
                    break;
                default:
                    header.InnerHtml = "<h1>" + web.Title + "</h1>";
                    break;
            }

            return MvcHtmlString.Create(header.ToString());
        }
    }
}