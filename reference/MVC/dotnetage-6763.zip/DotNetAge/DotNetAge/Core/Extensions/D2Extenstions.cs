﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using DNA.Mvc.jQuery;
using System.IO;
using System.Web.UI;
using System.Web.Mvc;
using System.Xml.Linq;
using DNA.Mvc.Models;
using System.Web.Mvc;

namespace DNA.Mvc
{
    public static class D2Extenstions
    {
        public static ComboBoxBuilder MasterCombo(this DnaControlFactory factory, string name, string selectedValue)
        {
            string[] masters = Directory.GetFiles(factory.Helper.ViewContext.HttpContext.Server.MapPath("~/Views/Shared"), "*.master");
            List<SelectableNode> masterNodes = new List<SelectableNode>();
            foreach (string master in masters)
            {
                DirectoryInfo dir = new DirectoryInfo(master);
                string masterName = Path.GetFileNameWithoutExtension(dir.FullName);
                masterNodes.Add(new SelectableNode(masterName, masterName));
            }
            return factory.ComboBox(name)
                .DropDownStyle(DropdownStyles.DropdownList)
                .Bind(masterNodes)
                .Select(selectedValue);
        }

        public static ListBoxBuilder ImageFileListBox(this DnaControlFactory factory, string name, string url)
        {
            return ImageFileListBox(factory, name, url, "FLIST");
        }

        public static ListBoxBuilder ImageFileListBox(this DnaControlFactory factory, string name, string url, string httpMethod)
        {
            return factory.ListBox(name)
                     .ClientBind(url, httpMethod, () =>
                     {
                         using (var writer = new HtmlTextWriter(factory.Helper.ViewContext.Writer))
                         {
                             writer.Write("<li class=\"ui-corner-all\" style=\"width: 80px; height: 90px; float: left; margin: 2px; border: 1px solid #cccccc;overflow:hidden;\" title=\"${Name}\">");
                             writer.Write("<div style=\"padding-top: 5px;\"><center><img src=\"${Url}?thumb=true&w=64&h=64\" alt=\"${Name}\" /></center></div>");
                             writer.Write("<div style=\"text-align: center; width: 70px; white-space: pre-line;\" class=\"d-list-item-text\"><span style=\"font-weight:normal;\">${Name}</span></div><input type=\"hidden\" value=\"${Url}\" /></li>");
                         }
                     });
        }

        public static string Help(this UrlHelper helper, int id)
        {
            var docs = (HelpDocs)DNA.Utility.XmlSerializerUtility.DeserializeFormXmlFile(HttpContext.Current.Server.MapPath(helper.Content("~/content/help.xml")), typeof(HelpDocs));
            var help = docs.Docs.FirstOrDefault(doc => doc.HelpID == id);
            if (!string.IsNullOrEmpty(help.HelpUrl))
                return help.HelpUrl;
            return "";
        }

        public static ButtonBuilder LocText(this ButtonBuilder builder, string resClass, string resKey)
        {
            var helper = new HtmlHelper(builder.ViewContext, builder.ViewDataContainer);
            if (string.IsNullOrEmpty(resClass))
                return builder.Text(helper.Global(resKey));
            else
                return builder.Text(helper.Global(resClass, resKey));
        }

        public static ButtonBuilder LocText(this ButtonBuilder builder, string reskey)
        {
            return builder.LocText(null, reskey);
        }

        public static UploaderBuilder Uploader(this DnaControlFactory factory, string target)
        {
            return new UploaderBuilder(new Uploader() { Name = target }, factory.Helper);
        }
    }
}