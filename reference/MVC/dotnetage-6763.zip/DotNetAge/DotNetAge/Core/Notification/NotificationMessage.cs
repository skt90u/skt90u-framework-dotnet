﻿//  Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Xml.Serialization;

namespace DNA.Mvc.Notification
{
    [XmlRoot("message"),Serializable]
    public struct NotificationMessage
    {
        [XmlElement("subject")]
        public string Subject;

        [XmlElement("document")]
        public string Document;

        [XmlElement("content")]
        public NotificationMessageContent Content; 
    }

}