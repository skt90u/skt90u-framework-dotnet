﻿//  Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Xml.Serialization;
using System.Net.Mail;
using System.Text;
using System.Web.Security;

namespace DNA.Mvc.Notification
{
    public class EmailNotifier : INotifity
    {
        public bool Send(string userName, Messages type, params object[] args)
        {
            string code = ((int)type).ToString();
            return Send(userName, code, args);
        }

        public bool Send(string userName, string messageCode, params object[] args)
        {
            var user = Membership.GetUser(userName);
            var profile = user.GetProfile();
            var lang = profile["Language"] as string;
            if (string.IsNullOrEmpty(lang))
                lang = WebSite.Open().DefaultLanguage;
            string path = HttpContext.Current.Server.MapPath("~/Content/notifications/" + lang );
            if (!System.IO.Directory.Exists(path))
                path = HttpContext.Current.Server.MapPath("~/Content/notifications/en-US");

            string fileName = path + "/" + messageCode + ".xml";
            if (System.IO.File.Exists(fileName))
            {
                var msg = (NotificationMessage)DNA.Utility.XmlSerializerUtility.DeserializeFormXmlFile(fileName, typeof(NotificationMessage));
                msg.Subject= string.Format(msg.Subject, args);
                msg.Content.Text = string.Format(msg.Content.Text, args);
                return Send(userName, msg);
            }
            return false;
        }

        public bool Send(string userName, NotificationMessage message)
        {
            var user = Membership.GetUser(userName);
            if (user != null)
            {
                var mail = ConvertToMailMessage(message);
                mail.To.Add(new MailAddress(user.Email));
                SendMailCore(mail);
                return true;
            }
            return false;
        }

        private MailMessage ConvertToMailMessage(NotificationMessage message)
        {
            var msg = new MailMessage()
            {
                Subject = message.Subject,
                IsBodyHtml = message.Content.ContentType.Equals("html"),
                BodyEncoding = string.IsNullOrEmpty(message.Content.Encoding) ? Encoding.Default : Encoding.GetEncoding(message.Content.Encoding),
                Body = message.Content.Text
            };
            return msg;
        }

        public bool Broadcast(string[] mailList, NotificationMessage message)
        {
            return false;
        }

        private static void SendMailCore(MailMessage mail)
        {
            var web = WebSite.Open("");
            if (web != null)
            {
                if (!string.IsNullOrEmpty(web.SiteMailAccount))
                {
                    mail.From = new MailAddress(web.SiteMailAccount);
                    var smtpClient = new SmtpClient();
                    if (!string.IsNullOrEmpty(web.SMTPHost))
                        smtpClient.Host = web.SMTPHost;
                    if (web.SMTPPort != 0)
                        smtpClient.Port = web.SMTPPort;

                    if (web.SMTPUsedDefaultCredentials)
                        smtpClient.UseDefaultCredentials = web.SMTPUsedDefaultCredentials;
                    else
                        smtpClient.Credentials = new System.Net.NetworkCredential(web.SMTPUserName, web.SMTPPassword);

                    smtpClient.SendAsync(mail, null);
                }
            }
        }

    }
}