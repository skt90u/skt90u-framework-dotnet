﻿//  Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Routing;

namespace DNA.Mvc.Logging
{
    public interface ILogService
    {
        /// <summary>
        /// Save the request information to log.
        /// </summary>
        /// <param name="context"></param>
        void Log(HttpContextBase context,RouteData routeData);

        IEnumerable<UrlRefer> GetUrlRefers(string webName, int rows);

        WebStatistics GetStatistics(string webName,int interval);

        string[] GetOnlineUsers(string webName,bool isAuthorized,int interval);

        string[] GetMostActiveUsers(string webName);

        IEnumerable<HttpBrowser> GetBrowsers(string webName);
    }
}