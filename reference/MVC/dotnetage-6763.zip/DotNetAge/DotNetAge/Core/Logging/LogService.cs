﻿//  Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.Objects;
using DNA.Mvc.Models;

namespace DNA.Mvc.Logging
{
    public class LogService : ILogService
    {
        public void Log(HttpContextBase context, System.Web.Routing.RouteData routeData)
        {
            using (var db = DBMan.Instance())
            {
                WebEventLog log = new WebEventLog()
                {
                    Action = routeData.GetRequiredString("action"),
                    Browser = context.Request.Browser.Browser,
                    ClientAddress = context.Request.UserHostAddress,
                    Host = context.Request.UserHostName,
                    Controller = routeData.GetRequiredString("controller"),
                    HttpMethod = context.Request.HttpMethod,
                    QueryString = context.Request.QueryString.Count > 0 ? context.Request.Url.Query.ToString() : "",
                    //Cookies=context.Request.Cookies.ToString(),
                    Bytes = context.Request.TotalBytes,
                    WebName = routeData.Values.ContainsKey("website") ? routeData.Values["website"].ToString() : "home",
                    IsAnonymous = !context.Request.IsAuthenticated,
                    Logged = DateTime.Now,
                    RawUrl = context.Request.RawUrl,
                    Version = context.Request.Browser.Version,
                    UserAgent = context.Request.UserAgent,
                    UrlRefer = context.Request.UrlReferrer == null ? "" : context.Request.UrlReferrer.ToString(),
                    UserName = context.Request.IsAuthenticated ? context.User.Identity.Name : context.Request.UserHostAddress
                };

                db.AddToWebEventLogs(log);
                db.SaveChanges();
            }
        }

        public IEnumerable<UrlRefer> GetUrlRefers(string webName, int rows)
        {
            string filter = HttpContext.Current.Request.Url.Authority;
            string cmd = @"SELECT UrlRefer AS Url,COUNT(UrlRefer) AS Count
                                    FROM dna_EventLog
                                    WHERE CHARINDEX('" + filter + @"',UrlRefer,1)=0 AND 
                                                CHARINDEX('localhost',UrlRefer,1)=0 AND 
                                                UrlRefer<>N'' AND WebName='" + webName + "' " + @"
                                    GROUP BY UrlRefer
                                    ORDER BY Count DESC";

            using (var db = DBMan.Instance())
            {
                var refers = db.ExecuteStoreQuery<UrlRefer>(cmd).ToList();
                var _refers = new List<UrlRefer>();
                foreach (var refer in refers)
                {
                    var uri = new Uri(refer.Url);
                    string _url = uri.Scheme + "://" + uri.Authority + uri.AbsolutePath;
                    if (_refers.Exists(r => r.Url.Equals(_url, StringComparison.OrdinalIgnoreCase)))
                        _refers.First(r => r.Url.Equals(_url, StringComparison.OrdinalIgnoreCase)).Count++;
                    else
                        _refers.Add(new UrlRefer()
                        {
                            Count = refer.Count,
                            Url = _url
                        });
                }

                if (_refers.Count > rows)
                    return _refers.OrderByDescending(r => r.Count).Take(rows);
                else
                    return _refers.OrderByDescending(r => r.Count);
            }
        }

        public WebStatistics GetStatistics(string webName, int interval)
        {
            using (var db = DBMan.Instance())
            {
                return db.ExecuteStoreQuery<WebStatistics>("dna_statistics "+"'"+webName+"'"+"," + interval.ToString()).Single();
            }
        }

        public string[] GetOnlineUsers(string webName, bool isAuthorized, int interval)
        {
            using (var db = DBMan.Instance())
            {
                return db.ExecuteStoreQuery<string>("dna_getOnlineUsers " + "'" + webName + "'" + "," + (!isAuthorized).ToString() + "," + interval.ToString()).ToArray();
            }
        }

        public string[] GetMostActiveUsers(string webName)
        {
            using (var db = DBMan.Instance())
            {
                var users = from u in db.WebEventLogs
                            where u.WebName.Equals(webName, StringComparison.OrdinalIgnoreCase)
                            group u by u.UserName into g
                            select new { UserName = g.Key, Count = g.Count() };
                return users.OrderByDescending(u => u.Count).Select(u => u.UserName).Take(10).ToArray();

            }
        }

        public IEnumerable<HttpBrowser> GetBrowsers(string webName)
        {
            using (var db = DBMan.Instance())
            {
                var browser = from w in db.WebEventLogs
                              where w.WebName.Equals(webName, StringComparison.OrdinalIgnoreCase)
                              group w by new { w.Browser, w.Version } into g
                              orderby g.Key.Browser, g.Key.Version
                              select new HttpBrowser()
                              {
                                  Name = g.Key.Browser,
                                  Version = g.Key.Version,
                                  Count = g.Count()
                              };
                return browser.ToList();
            }
        }
    }
}