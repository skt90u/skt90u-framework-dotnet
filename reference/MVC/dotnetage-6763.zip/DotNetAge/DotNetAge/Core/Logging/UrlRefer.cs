﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DNA.Mvc.Logging
{
    public class UrlRefer
    {
        public string Url { get; set; }

        public int Count { get; set; }
    }
}