﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DNA.Mvc.Logging
{
    public class WebStatistics
    {
        /// <summary>
        /// Gets/Sets the online guest users count;
        /// </summary>
        public int OnlineGuests { get; set; }

        /// <summary>
        /// Gets/Sets the online register users count.
        /// </summary>
        public int OnlineRegisters { get; set; }

        /// <summary>
        /// Gets/Sets the registered user count
        /// </summary>
        public int RegistedUserCount { get; set; }
        
        /// <summary>
        /// Gets/Sets the most online user count
        /// </summary>
        public int MostOnlineCount { get; set; }
        
        /// <summary>
        /// Gets/Sets the most user online happend date
        /// </summary>
        public DateTime MostOnlined { get; set; }

        /// <summary>
        /// Gets/Sets the page view count.
        /// </summary>
        public int PageView { get; set; }

        /// <summary>
        /// Gets/Sets the total visits count.
        /// </summary>
        public int Visits { get; set; }
    }


}
