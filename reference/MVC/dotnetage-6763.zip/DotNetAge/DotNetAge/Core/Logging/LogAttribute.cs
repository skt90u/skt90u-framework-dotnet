﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Mvc;
using DNA.Mvc.Models;

namespace DNA.Mvc
{
    /// <summary>
    /// Identity the action to log every request info.
    /// </summary>
    public class LogAttribute : FilterAttribute, IActionFilter, IResultFilter
    {
        private string action;

        public void OnActionExecuted(ActionExecutedContext filterContext)
        {
        }

        public void OnActionExecuting(ActionExecutingContext filterContext)
        {
            // action = filterContext.ActionDescriptor.ActionName;
        }

        public void Log(ResultExecutedContext context)
        {
            //var db = MvcDB.Instance();
            HttpRequestBase request = context.HttpContext.Request;

            //if ((request.UserHostAddress=="127.0.0.1") || (request.UserHostAddress=="::1"))
            if (request.Url.IsLoopback)
                return;

            WebSite.LoggingService.Log(context.HttpContext, context.RouteData);

            //    using (var db = DBMan.Instance())
            //    {
            //        WebEventLog log = new WebEventLog()
            //        {
            //            Action = context.RouteData.GetRequiredString("action"), 
            //            Browser = request.Browser.Browser,
            //            ClientAddress = request.UserHostAddress,
            //            Host = request.UserHostName,
            //            Controller = context.RouteData.GetRequiredString("controller"),
            //            HttpMethod=context.HttpContext.Request.HttpMethod,
            //            WebName=context.RouteData.Values.ContainsKey("website") ? context.RouteData.Values["website"].ToString() : "home",
            //            IsAnonymous = !request.IsAuthenticated,
            //            Logged = DateTime.Now,
            //            RawUrl = request.RawUrl,
            //            Version = request.Browser.Version,
            //            UserAgent = request.UserAgent,
            //            UrlRefer = request.UrlReferrer == null ? "" : request.UrlReferrer.ToString()
            //        };

            //        if (context.HttpContext.Request.IsAuthenticated)
            //            log.UserName = context.HttpContext.User.Identity.Name;
            //        else
            //            log.UserName = context.HttpContext.Request.UserHostAddress;

            //        db.AddToWebEventLogs(log);
            //        db.SaveChanges();
            //    }
        }

        #region IResultFilter 成员

        public void OnResultExecuted(ResultExecutedContext filterContext)
        {
            if (filterContext.Result is ViewResult)
            {
                if (WebHost.IsInstalled)
                    Log(filterContext);
            }
        }

        public void OnResultExecuting(ResultExecutingContext filterContext)
        {

        }

        #endregion
    }
}
