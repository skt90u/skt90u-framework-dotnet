﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System.Collections.Generic;
using System.Data.SqlClient;
using System.Web.Configuration;
using System.Configuration;
using System.Xml;
using System.IO;
using System.Xml.Serialization;
using System;
using System.Web.Script.Serialization;
using System.Web.Mvc;
using DNA.IO.Compress;
using DNA.Mvc.DynamicUI;
using DNA.Mvc.Models;
using DNA.Utility;
namespace DNA.Mvc.Installation
{
    [Serializable]
    [XmlRoot("uiInstaller")]
    public class UIInstaller : InstallerBase
    {
        //private DynamicPageService _service;
        //private WidgetUIServcie widgetService;

        [XmlAttribute("src")]
        public string FileName { get; set; }

        /// <summary>
        /// The params of match the value placeholder and replace the value of the install sql file.
        /// </summary>
        [XmlElement("param", Type = typeof(ParamElement))]
        public List<ParamElement> Params { get; set; }

        private IDictionary<string, object> paramsDict;

        public override bool Install(DNA.IO.Compress.ZipExtract zip, object values)
        {
            //Check values
            if (Params.Count > 0)
            {
                if (values == null)
                    throw new ArgumentNullException("values");
                paramsDict = ObjectHelper.ConvertObjectToDictionary(values);
                foreach (var _param in Params)
                {
                    //if (_param.Scope.Equals("runtime",StringComparison.OrdinalIgnoreCase))
                    //    continue;

                    if (string.IsNullOrEmpty(_param.Tag))
                        throw new ArgumentNullException("The param of installer is not specified the tag name.");

                    if (!paramsDict.ContainsKey(_param.Tag))
                        throw new ArgumentOutOfRangeException(_param.Tag);
                }
                //foreach (var key in paramsDict.Keys)
                //{
                    
                //    if (!Params.Exists(p => p.Tag.Equals(key, StringComparison.OrdinalIgnoreCase)))
                //        throw new ArgumentOutOfRangeException(key);
                //}
            }

            string xml = zip.ReadFileAsText(FileName);
            if (string.IsNullOrEmpty(xml))
                throw new Exception("template source file read fail");

            var replacementParams = Params.FindAll(p => p.Scope.Equals("file", StringComparison.OrdinalIgnoreCase));

            foreach (var rp in replacementParams)
            {
                if (!string.IsNullOrEmpty(rp.Match))
                    xml = xml.Replace(rp.Match, paramsDict[rp.Tag].ToString());
            }

            var template = XmlSerializerUtility.DeserializeFromXmlText(xml, typeof(WebTemplate)) as WebTemplate;
            if (template == null)
                throw new Exception("Template file read fail.");
            //Create Root web

            //Create sub web
            CreateWeb(template, paramsDict["name"] as string, paramsDict["owner"] as string);
            return true;
        }

        private Web CreateWeb(WebTemplate template, string name,string owner)
        {
            //var root = WebSite.Open();
            var newWeb = new Web()
            {
                Name = name,
                Owner = string.IsNullOrEmpty(owner) ? name : owner,
                Created = DateTime.Now,
                //                AllowExtensions = root.AllowExtensions,
                DefaultLanguage = template.Language,
                Copyright = string.IsNullOrEmpty(template.Copyright) ? "" : template.Copyright,
                CssText = string.IsNullOrEmpty(template.CssText) ? "" : template.CssText,
                LogoImageUrl = string.IsNullOrEmpty(template.LogoImageUrl) ? "" : template.LogoImageUrl,
                DefaultUrl = string.IsNullOrEmpty(template.DefaultUrl) ? "" : template.DefaultUrl,
                MasterName = string.IsNullOrEmpty(template.MasterPage) ? "" : template.MasterPage,
                ShortcutIconUrl = string.IsNullOrEmpty(template.ShortcutIconUrl) ? "" : template.ShortcutIconUrl,
                SearchKeywords = string.IsNullOrEmpty(template.SearchKeywords) ? "" : template.SearchKeywords,
                MostOnlined = DateTime.Now,
                MostOnlineUserCount = 1,
                MaximumFileSize = 2,
                Type = (int)template.Type,
                IsEnabled = true,
                Title = template.Title,
                Description = template.Description,
                EnableUserRegistration=template.EnableUserRegistation,
                AllowExtensions = ".doc|.docx|.txt|.jpg|.gif|.png|.zip|.rar|.xls|.xlsx|.ppt|.pptx",
                //TimeZone = root.TimeZone,
                Theme = template.Theme
            };

            newWeb.SaveAndCreate();

            foreach (var p in template.WebPages)
                newWeb.CreatePage(0, p);

            return newWeb;
        }

        //private WidgetUIServcie WidgetService
        //{
        //    get
        //    {
        //        if (widgetService == null)
        //            widgetService = new WidgetUIServcie();
        //        return widgetService;
        //    }
        //}

        //private DynamicPageService Service
        //{
        //    get
        //    {
        //        if (_service == null)
        //            _service = new DynamicPageService();
        //        return _service;
        //    }
        //}

        //private UrlHelper _Url;

        //public UrlHelper Url
        //{
        //    get 
        //    {
        //        if (_Url == null)
        //            _Url = UrlUtility.CreateUrlHelper();
        //        return _Url; 
        //    }
        //}

        //private void CreateChildrenPages(int parentID, IEnumerable<WebPageDataContract> pages)
        //{
        //    foreach (var src in pages)
        //    {
        //        var _target = new WebPage();

        //        if (!Service.IsExists(src.Path))
        //        {
        //            Web web = null;
        //            if (ParamValues.ContainsKey("WebID"))
        //                web = WebSite.Open(ParamValues["WebID"] as string);
        //            else
        //                web = WebSite.Open("");

        //            _target.ParentID = parentID;
        //            src.UpdateModel(_target);
        //            web.WebPages.Add(_target);
        //            Service.Create(_target, new string[] { });
        //        }
        //        else
        //        {
        //            _target = Service.GetPage(src.Path);
        //            src.UpdateModel(_target);
        //            Service.Update(_target, new string[] { });
        //        }

        //        foreach (var widgetData in src.Widgets)
        //        {
        //            var descriptor = WidgetService.GetWidgetDescriptor(widgetData.PackageAssemblyName, widgetData.Controller, widgetData.Action);
        //            var widgetInstance = WidgetService.AddWidget(descriptor, src.Path, widgetData.ZoneID, widgetData.Position);
        //            widgetData.UpdateModel(widgetInstance);
        //            WidgetService.UpdateWidget(widgetInstance);
        //        }

        //        if (src.Children.Count > 0)
        //            CreateChildrenPages(_target.ID, src.Children);
        //    }
        //}
    }
}
