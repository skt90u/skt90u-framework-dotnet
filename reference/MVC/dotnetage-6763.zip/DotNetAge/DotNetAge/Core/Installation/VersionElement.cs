﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Serialization;

namespace DNA.Mvc.Installation
{
    [XmlRoot("version"), Serializable]
    public struct VersionElement
    {
        //private string build = "1.0.0.0";

        /// <summary>
        /// Gets/Sets the release notes
        /// </summary>
        [XmlElement("notes")]
        public string Notes;

        /// <summary>
        /// Gets/Sets the build verion number
        /// </summary>
        [XmlElement("build")]
        public string Build;

        public Version BuildVersion
        {
            get
            {
                if (!string.IsNullOrEmpty(Build))
                    return new Version(Build);
                return new Version("1.0.0.0");
            }
        }
    }
}
