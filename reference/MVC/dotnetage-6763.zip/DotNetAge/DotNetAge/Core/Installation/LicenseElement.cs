﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Serialization;

namespace DNA.Mvc.Installation
{
    /// <summary>
    /// Define the fields of the license element of the installation package config file.
    /// </summary>
    [XmlRoot("license"), Serializable]
    public struct LicenseElement
    {
        /// <summary>
        /// Gets/Sets the license name.
        /// </summary>
        [XmlAttribute("name")]
        public string Name;

        /// <summary>
        /// Gets/Sets the license file url
        /// </summary>
        [XmlAttribute("href")]
        public string Url;

        /// <summary>
        /// Gets/Sets the text content of this license
        /// </summary>
        [XmlText]
        public string Text;
    }
}
