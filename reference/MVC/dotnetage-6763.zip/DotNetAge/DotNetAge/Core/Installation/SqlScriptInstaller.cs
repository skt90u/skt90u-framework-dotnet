﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Web.Configuration;
using System.Configuration;
using System.Xml;
using System.IO;
using DNA.IO.Compress;
using System.Xml.Serialization;
using System;

namespace DNA.Mvc.Installation
{
    /// <summary>
    /// Run the sql script on the server at installaion progress. These are some config
    /// settings of this installer:
    /// </summary>
    /// <remarks>
    /// You can set the <b>type</b> attribute to "sql" of the installer element to
    /// using this installer.
    /// </remarks>
    /// <example>
    /// 	<code lang="XML" title="Configuation of SqlScriptInstaller">
    /// 		<![CDATA[
    /// <installer type="sql" src="install.sql"  connectionStringName="ServerConnection" >
    ///      <params>
    ///           <param match="" value="The value to replace the match value"  tag="the key in the appsettings"/>
    ///       </params>
    /// </installer>]]>
    /// 	</code>
    /// </example>
    [XmlRoot("sqlInstaller"), Serializable]
    public class SqlScriptInstaller : InstallerBase
    {
        //private List<ParamElement> _params = new List<ParamElement>();

        /// <summary>
        /// The params of match the value placeholder and replace the value of the install sql file.
        /// </summary>
        [XmlElement("param", Type = typeof(ParamElement))]
        public List<ParamElement> Params { get; set; }

        /// <summary>
        /// Gets/Sets the sql script file name.
        /// </summary>
        [XmlAttribute("src")]
        public string ScriptFileName { get; set; }

        private IDictionary<string, object> paramsDict;

        /// <summary>
        /// Gets/Sets the connection string name for the SqlScriptInstaller to using.
        /// </summary>
        [XmlAttribute("connectionStringName")]
        public string ConnectionStringName { get; set; }

        private string RemoveRiskChars(string raw)
        {
            string s = "";
            s = raw.Replace("'", "''");
            s = s.Replace(";", " ");
            s = s.Replace("1=1", " ");
            s = s.Replace("|", " ");
            s = s.Replace("<", " ");
            s = s.Replace(">", " ");

            return s;
        }

        /// <summary>
        /// Install the sql script file.
        /// </summary>
        /// <param name="values">Specified the initialize application values for installation.</param>
        /// <param name="zip"></param>
        /// <returns></returns>
        public override bool Install(DNA.IO.Compress.ZipExtract zip, object values)
        {
            if (string.IsNullOrEmpty(ConnectionStringName))
                throw new ArgumentNullException("connectionStringName");

            if (string.IsNullOrEmpty(ScriptFileName))
                throw new ArgumentNullException("src");

            if (Params.Count > 0)
            {
                if (values == null)
                    throw new ArgumentNullException("values");
                paramsDict = ObjectHelper.ConvertObjectToDictionary(values);
                foreach (var _param in Params)
                {
                    if (string.IsNullOrEmpty(_param.Tag))
                        throw new ArgumentNullException("The param of installer is not specified the tag name.");

                    if (!paramsDict.ContainsKey(_param.Tag))
                        throw new ArgumentOutOfRangeException(_param.Tag);
                }
                //foreach (var key in paramsDict.Keys)
                //{

                //    if (!Params.Exists(p => p.Tag.Equals(key, StringComparison.OrdinalIgnoreCase)))
                //        throw new ArgumentOutOfRangeException(key);
                //}
            }

            string sqlText = zip.ReadFileAsText(ScriptFileName);
            var cmds = DeploymentHelper.ReadSQLCommandBlocksFromText(sqlText);


            if (cmds.Length > 0)
            {
                #region replace the match value
                foreach (var p in Params)
                {
                    if ((!string.IsNullOrEmpty(p.Match)) && ((!string.IsNullOrEmpty(p.Value)) || (!string.IsNullOrEmpty(p.Tag))))
                    {
                        for (int i = 0; i < cmds.Length; i++)
                        {
                            if (!string.IsNullOrEmpty(p.Tag))
                            {
                                if (cmds[i].IndexOf(p.Match) > -1)
                                    cmds[i] = cmds[i].Replace(p.Match, RemoveRiskChars(paramsDict[p.Tag].ToString()));
                            }
                            else
                            {
                                //Using default value
                                if (cmds[i].IndexOf(p.Match) > -1)
                                    cmds[i] = cmds[i].Replace(p.Match, RemoveRiskChars(p.Value));
                            }
                        }
                    }
                }
                #endregion
                ConnectionStringSettings connectionString = WebConfigurationManager.ConnectionStrings[ConnectionStringName];
                using (var conn = new SqlConnection(connectionString.ConnectionString))
                {
                    conn.Open();
                    using (var trans = conn.BeginTransaction())
                    {
                        try
                        {
                            foreach (var cmd in cmds)
                            {

                                var command = conn.CreateCommand();
                                command.Transaction = trans;
                                command.CommandText = cmd;
                                command.ExecuteNonQuery();
                            }
                        }
                        catch (Exception e)
                        {
                            trans.Rollback();
                            return false;
                        }
                        trans.Commit();
                    }
                    conn.Close();
                };

                return true;
            }
            return false;
        }
    }
}
