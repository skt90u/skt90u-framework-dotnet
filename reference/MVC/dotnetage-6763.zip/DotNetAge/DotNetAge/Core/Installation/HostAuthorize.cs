﻿//  Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;
using System.Web.Security;

namespace DNA.Mvc.Installation
{
    [AttributeUsage(AttributeTargets.Method, AllowMultiple = false, Inherited = true)]
    public class HostAuthorize : ActionFilterAttribute
    {
        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            var context = filterContext.RequestContext.HttpContext;
            if ((!context.Request.IsAuthenticated) || (!context.User.Identity.Name.Equals("host",StringComparison.OrdinalIgnoreCase)))
                filterContext.Result = new RedirectToRouteResult(new RouteValueDictionary(new { controller = "Installation", action = "LogOn",website="",Area="" }));
            //base.OnActionExecuting(filterContext);
        }
    }
}
