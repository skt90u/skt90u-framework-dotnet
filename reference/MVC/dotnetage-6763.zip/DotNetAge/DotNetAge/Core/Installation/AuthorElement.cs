﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Serialization;

namespace DNA.Mvc.Installation
{
    /// <summary>Define the contact's fields.</summary>
    [XmlRoot("author"),Serializable]
    public struct AuthorElement
    {
        /// <summary>Gets/Sets the contact name.</summary>
        [XmlAttribute("name")]
        public string Name;

        /// <summary>Gets/Sets the contact people belongs to.</summary>
        [XmlAttribute("organzation")]
        public string Organization;

        /// <summary>Gets/Sets the where link to contact people</summary>
        [XmlAttribute("href")]
        public string Url;

        /// <summary>Gets/Sets the contact's Email</summary>
        [XmlAttribute("email")]
        public string Email;
    }
}
