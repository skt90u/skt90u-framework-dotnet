﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DNA.Mvc.Models;

namespace DNA.Mvc.Installation
{
    public interface IInstallationService
    {
        /// <summary>
        /// Load the package instances from specified path
        /// </summary>
        /// <param name="virtualPath"></param>
        /// <returns></returns>
        List<PackageDescriptor> LoadPackages(string virtualPath);

        /// <summary>
        /// Load the package instance from the specified file
        /// </summary>
        /// <param name="fileName"></param>
        /// <returns></returns>
        PackageDescriptor LoadPackage(string fileName);

        ///// <summary>
        ///// Get all installed package info in the portal
        ///// </summary>
        ///// <returns></returns>
        //List<PackageInfo> InstalledPackages();

        ///// <summary>
        ///// Get the specified package info from the installed list
        ///// </summary>
        ///// <param name="id"></param>
        ///// <returns></returns>
        //PackageInfo GetPackageInfo(int id);

        ///// <summary>
        ///// Get the package info by specified file
        ///// </summary>
        ///// <param name="fileName"></param>
        ///// <returns></returns>
        //PackageInfo GetPackageInfo(string fileName);
    }
}
