﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Web.Configuration;
using System.Configuration;
using System.Xml;
using System.IO;
using DNA.IO.Compress;
using System.Xml.Serialization;
using System;
using System.Linq;
using System.Web;

namespace DNA.Mvc.Installation
{
    /// <summary>
    /// The files installer use to extract the files to destination path.
    /// </summary>
    /// <example>
    /// 	<code lang="XML" title="Configuation of FilesInstaller">
    /// 		<![CDATA[
    /// <installer type="files" destination="/contents/themes/newtheme" />
    /// ]]>
    /// 	</code>
    /// </example>
    [XmlRoot("fileInstaller"), Serializable]
    public class FilesInstaller : InstallerBase
    {
        [XmlElement("folder", Type = typeof(FolderElement))]
        public List<FolderElement> Folders { get; set; }

        [XmlAttribute("destination")]
        public string Destination { get; set; }

        public override bool Install(DNA.IO.Compress.ZipExtract zip, object values)
        {
            if (!string.IsNullOrEmpty(Destination))
            {
                string path = Destination;

                if ((Folders != null) && (Folders.Count > 0))
                {
                    foreach (var _folder in Folders)
                    {
                        var _files = new List<string>();
                        if (!string.IsNullOrEmpty(_folder.Destination))
                        {
                            if ((!path.EndsWith("/")) && (!_folder.Destination.StartsWith("/")))
                                path += _folder.Destination;
                            else
                                path += "/" + _folder.Destination;
                        }

                        if (_folder.Files.Count > 0)
                        {
                            foreach (var _f in _folder.Files)
                            {
                                if (!string.IsNullOrEmpty(_folder.Source))
                                {
                                    if ((!_folder.Source.EndsWith("\\")) && (!_f.Name.StartsWith("\\")))
                                        _files.Add(_folder.Source + _f.Name);
                                    else
                                        _files.Add(_folder.Source + "\\" + _f.Name);
                                }
                                else
                                    _files.Add(_f.Name);
                            }
                            zip.ExtractTo(_files.ToArray(), MapServerPath(path,values));
                        }
                        else
                        {
                            zip.ExtractTo(_folder.Source, MapServerPath(path,values));
                        }
                    }
                    return true;
                }
                else
                {
                    if (!string.IsNullOrEmpty(path))
                    {
                        path = MapServerPath(path.StartsWith("/") ? ("~" + path) : Destination,values);
                        if (!Directory.Exists(path))
                            Directory.CreateDirectory(path);
                        if (!path.EndsWith("\\"))
                            path += "\\";
                        zip.ExtractTo(path);
                        return true;
                    }
                }
            }
            return false;
        }

        private string MapServerPath(string source,object values)
        {
            if (string.IsNullOrEmpty(source))
                throw new ArgumentNullException("source");
            string formatted = source;

            if (source.StartsWith("{public}",StringComparison.OrdinalIgnoreCase))
                formatted = source.Replace("{public}", "~/shared/public");

            if (source.StartsWith("{personal}",StringComparison.OrdinalIgnoreCase))
            {
                if (values != null)
                {
                    var dict = ObjectHelper.ConvertObjectToDictionary(values);
                    var username = "";
                    if (dict.ContainsKey("owner"))
                        username = dict["owner"] as string;
                    else
                    {
                        if (dict.ContainsKey("name"))
                            username = dict["name"] as string;
                    }

                    formatted = source.Replace("{personal}", "~/shared/personal/" + username);
                }
            }

            return HttpContext.Current.Server.MapPath(formatted);
        }
    }
}
