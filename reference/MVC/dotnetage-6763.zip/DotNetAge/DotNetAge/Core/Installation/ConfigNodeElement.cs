﻿//  Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Serialization;

namespace DNA.Mvc.Installation
{
    [XmlRoot("node"), Serializable]
    public struct ConfigNodeElement
    {
        [XmlAttribute("path")]
        public string Path;

        [XmlAttribute("action")]
        public string Action;

        [XmlAttribute("key")]
        public string Key;

        [XmlAttribute("value")]
        public string Value;

        [XmlAttribute("name")]
        public string Name;
    }

     public enum ConfiguationUpdateActions
     { 
         New,
         Update,
         Remove
     }
}
