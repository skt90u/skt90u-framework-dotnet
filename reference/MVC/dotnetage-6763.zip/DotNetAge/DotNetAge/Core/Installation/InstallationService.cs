﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using DNA.Mvc.Models;
using DNA.IO.Compress;
using DNA.Utility;

namespace DNA.Mvc.Installation
{
    public class InstallationService:IInstallationService
    {
        //private DNAEntities dbContext;
        //private DNAEntities DbContext
        //{
        //    get
        //    {
        //        if (dbContext == null)
        //            dbContext = DBMan.Instance();
        //        return dbContext;
        //    }
        //}

        public List<PackageDescriptor> LoadPackages(string virtualPath)
        {
            string path = System.Web.HttpContext.Current.Server.MapPath(virtualPath);
            string[] zipFiles = Directory.GetFiles(path,"*.zip");
            List<PackageDescriptor> pkgs = new List<PackageDescriptor>();

            foreach (string zipFile in zipFiles)
            {
                PackageDescriptor pkg = LoadPackage(zipFile);
                if (pkg != null)
                    pkgs.Add(pkg);
            }
            return pkgs;
         }

        public PackageDescriptor LoadPackage(string fileName)
        {
            ZipExtract extract=new ZipExtract(fileName);
            string xml = extract.ReadFileAsText("config.xml");
           return (PackageDescriptor)XmlSerializerUtility.DeserializeFromXmlText(xml, typeof(PackageDescriptor));
        }

        //public List<PackageInfo> InstalledPackages()
        //{
        //    return DbContext.PackageInfos.ToList();
        //}

        //public PackageInfo GetPackageInfo(int id)
        //{
        //    return DbContext.PackageInfos.First(p => p.ID == id);
        //}
        
        //public PackageInfo GetPackageInfo(string fileName)
        //{
        //    PackageDescriptor pkg = LoadPackage(fileName);
        //    if (pkg != null)
        //    {
        //        return new PackageInfo()
        //        {
        //            AuthorName=pkg.Author.Name,
        //            AuthorEmail=pkg.Author.Email,
        //            AuthorWebSite=pkg.Author.Url,
        //            Description=pkg.Description,
        //            Name=pkg.Name,
        //            Version=pkg.Version.Build
        //        };
        //    }
        //    return null;
        //}
    }
}
