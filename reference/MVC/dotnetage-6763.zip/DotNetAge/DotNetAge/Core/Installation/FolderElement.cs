﻿//  Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Serialization;

namespace DNA.Mvc.Installation
{
    [XmlRoot("folder"), Serializable]
    public struct FolderElement
    {
        /// <summary>
        /// Gets/Sets the destination path to decompress the files.
        /// </summary>
        [XmlAttribute("destination")]
        public string Destination;

        /// <summary>
        /// Gets/Sets the source path in the compress file.
        /// </summary>
        [XmlAttribute("src")]
        public string Source;

        //[XmlElement("folder", Type = typeof(FileElement))]
        //public List<FolderElement> Folders;

        [XmlElement("file", Type = typeof(FileElement))]
        public List<FileElement> Files;
    }
}