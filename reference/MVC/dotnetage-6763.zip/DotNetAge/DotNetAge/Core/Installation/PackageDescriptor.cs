﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using System.Xml.Serialization;
using System.IO;
using DNA.IO.Compress;
using System.Web.Script.Serialization;

namespace DNA.Mvc.Installation
{
    /// <summary>
    /// The PackageDescriptor class is use to descript the installation package file 's information.It can read the base information of the installation package and receive the installer which the package uses.
    /// </summary>
    [Serializable]
    [XmlRoot("package", Namespace = "http://www.dotnetage.com/XML/Schema/package")]
    public class PackageDescriptor
    {
         /// <summary>
        /// Gets/Sets the description of this package.
        /// </summary>
        [XmlElement("description")]
        public string Description;

        /// <summary>
        /// Gets/Sets the version info element of this package.
        /// </summary>
        [XmlElement("version")]
        public VersionElement Version;

        /// <summary>
        /// Gets/Sets the author's info element of the package.
        /// </summary>
        [XmlElement("author")]
        public AuthorElement Author;

        /// <summary>
        /// Gets/Sets the specify installers.
        /// </summary>
        [
        XmlArray("installers"),
        XmlArrayItem("uiInstaller", Type = typeof(UIInstaller)),
        XmlArrayItem("fileInstaller", Type = typeof(FilesInstaller)),
        XmlArrayItem("configInstaller", Type = typeof(ConfiguationNodeInstaller)),
        XmlArrayItem("sqlInstaller", Type = typeof(SqlScriptInstaller))
        ]
        [ScriptIgnore]
        public List<InstallerBase> Installers 
        {
            get
            {
                if (installers == null)
                    installers = new List<InstallerBase>();
                return installers;
            }
        }
        private List<InstallerBase> installers;
        /// <summary>
        /// Gets/Sets the licenses collection of this package.
        /// </summary>
        [XmlArray("licenses"), XmlArrayItem("license",Type = typeof(LicenseElement))]
        public List<LicenseElement> Licenses;

        /// <summary>
        /// Gets/Sets the link elements of the package.
        /// </summary>
        [XmlArray("links"),XmlArrayItem("link", Type = typeof(LinkElement))]
        public List<LinkElement> Links;

        /// <summary>
        /// Gets the default image url of the package.
        /// </summary>
        [XmlIgnore]
        public string ImageUrl
        {
            get
            {
                if (Images.Count > 0)
                {
                    var img = Images.FirstOrDefault(i => i.IsDefault);
                    //if (img == null)
                    //    img = Images[0];
                    return img.ImageUrl;
                }
                return "";
            }
        }

        /// <summary>
        /// Gets/Sets the images of the package.
        /// </summary>
        [XmlArray("images"),XmlArrayItem("img",Type = typeof(ImageElement))]
        public List<ImageElement> Images;

        /// <summary>
        /// Gets/Sets the publish date of the package.
        /// </summary>
        [XmlElement("published")]
        public DateTime Published;

        /// <summary>
        /// Gets/Sets the name of the package .
        /// </summary>
        [XmlElement("name", IsNullable = true)]
        public string Name;

    }
}
