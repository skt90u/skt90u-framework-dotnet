﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;
using System.Xml.Serialization;
using System.Collections;
using DNA.IO.Compress;

namespace DNA.Mvc.Installation
{
    /// <summary>
    /// The installer base class.
    /// </summary>
    //[XmlRoot("installer"), Serializable]
    public interface IInstaller
    {
        //protected IDictionary<string, object> ParamValues;

        //[XmlAttribute("type")]
        //public string InstallerType;

        //public virtual bool Install(ZipExtract zip,object values)
        //{
        //    if (values != null)
        //        ParamValues=ObjectHelper.ConvertObjectToDictionary(values);
        //    return Install(zip);
        //}

        bool Install(ZipExtract zip, object values);
    }
    
    [Serializable]
    public abstract class InstallerBase:IInstaller
    {
        public abstract bool Install(ZipExtract zip, object values);
        
        bool IInstaller.Install(ZipExtract zip, object values)
        {
            return this.Install(zip, values);
        }
    }
}
