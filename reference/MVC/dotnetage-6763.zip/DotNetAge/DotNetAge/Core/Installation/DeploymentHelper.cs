﻿//  Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Data;
using System.Data.SqlClient;
using System.Xml;
using System.Web;
using DNA.Utility;
using DNA.Mvc.Models;
using System.Configuration;
using System.Web.Configuration;
using System.Reflection;

namespace DNA.Mvc.Installation
{
    public static class DeploymentHelper
    {
        #region SQL helper methods

        /// <summary>
        /// Read the SQL command blocks into string array
        /// </summary>
        /// <param name="text">Specified the sql script text.</param>
        /// <returns>The sql command block string array.</returns>
        public static string[] ReadSQLCommandBlocksFromText(string text)
        {
            var reader = new StringReader(text);
            return ReadSQLCommandBlocksFromReader(reader);
        }

        /// <summary>
        /// Read the SQL command blocks into string array
        /// </summary>
        /// <param name="reader"></param>
        /// <returns>The sql command block string array</returns>
        public static string[] ReadSQLCommandBlocksFromReader(TextReader reader)
        {
            return ReadSQLCommandBlocksFromReader(reader, string.Empty, string.Empty);
        }

        /// <summary>
        /// Read the SQL command blocks into string array
        /// </summary>
        /// <param name="reader"></param>
        /// <param name="pattern"></param>
        /// <param name="replacement"></param>
        /// <returns>The sql command block string array</returns>
        public static string[] ReadSQLCommandBlocksFromReader(TextReader reader, string pattern, string replacement)
        {
            var sqls = new List<string>();
            string commandText = "";
            string varLine = "";

            while (reader.Peek() > -1)
            {
                varLine = reader.ReadLine();
                if (varLine == "")
                    continue;

                if (varLine.Trim().StartsWith("--"))
                    continue;

                if (!varLine.Trim().Equals("GO",StringComparison.OrdinalIgnoreCase))
                {
                    commandText += varLine;
                    commandText += " ";
                }
                else
                {
                    if ((!string.IsNullOrEmpty(pattern)) && (!string.IsNullOrEmpty(replacement)))
                    {
                        if (commandText.IndexOf(pattern) > -1)
                            commandText.Replace(pattern, replacement);
                    }
                    sqls.Add(commandText);
                    commandText = "";
                }
            }
            reader.Close();
            return sqls.ToArray();
        }

        /// <summary>
        /// Read the SQL command blocks from file into string array
        /// </summary>
        /// <param name="fileName">Specified the sql file name to read.</param>
        /// <returns>The sql command block string array</returns>
        public static string[] ReadSQLCommandBlocksFromFile(string fileName)
        {
            StreamReader reader = File.OpenText(fileName);
            return ReadSQLCommandBlocksFromReader(reader);
        }

        /// <summary>
        /// Run the specified sql command.
        /// </summary>
        /// <param name="connection">Specified the SqlConnection instance to run sql command.</param>
        /// <param name="cmdText">Specified the command text to run.</param>
        public static void RunSQLCommand(SqlConnection connection, string cmdText)
        {
            if (connection.State != ConnectionState.Open)
                connection.Open();

            using (var cmd = new SqlCommand(cmdText, connection))
            {
                cmd.ExecuteNonQuery();
            }
        }

        #endregion

        public static void CopyDirectory(string source, string distance)
        {
            String[] Files;
            if (distance[distance.Length - 1] != Path.DirectorySeparatorChar)
                distance += Path.DirectorySeparatorChar;
            if (!Directory.Exists(distance)) Directory.CreateDirectory(distance);
            Files = Directory.GetFileSystemEntries(source);
            foreach (string Element in Files)
            {
                // Sub directories
                if (Directory.Exists(Element))
                    CopyDirectory(Element, distance + Path.GetFileName(Element));
                // Files in directory
                else
                    File.Copy(Element, distance + Path.GetFileName(Element), true);
            }
        }

        public static void RestartWeb()
        {
            if (HttpContext.Current.User.IsAdministrator() || HttpContext.Current.User.IsHost())
                System.Web.HttpRuntime.UnloadAppDomain();
        }

        public static void UpdateWebConfig(string match, string key, string value, string configuationFile)
        {
            var config = new XmlDocument();
            string configPath = HttpContext.Current.Server.MapPath("~/" + configuationFile);
            config.Load(configPath);

            if (config == null)
                throw new Exception("The configuation file not found.");
            var sectionNode = config.SelectSingleNode(match);
            sectionNode.Attributes[key].Value = value;
            config.Save(configPath);
        }

        public static PackageDescriptor ReadPackage(string fileName)
        {
            var file = File.Open(fileName, FileMode.Open);
            var des = ReadPackage(file);
            file.Close();
            return des;
        }

        public static PackageDescriptor ReadPackage(Stream stream)
        {
            var zip = new DNA.IO.Compress.ZipExtract(stream);
            string xmlText = zip.ReadFileAsText("manifest.xml");
            zip.Dispose();
            return ReadPackageFormXML(xmlText);
        }

        public static PackageDescriptor ReadPackageFormXML(string xml)
        {
            PackageDescriptor desc = null;
            if (!string.IsNullOrEmpty(xml))
                desc = (PackageDescriptor)XmlSerializerUtility.DeserializeFromXmlText(xml, typeof(PackageDescriptor));
            return desc;
        }

        public static IEnumerable<PackageDescriptor> LoadPackages(string searchPath)
        {
            var files = Directory.GetFiles(searchPath, "*.zip");
            var pkgs = new List<PackageDescriptor>();
            foreach (var file in files)
                pkgs.Add(ReadPackage(file));
            return pkgs;
        }

        public static void DeployPackage(string packageName)
        {
            DeployPackage(packageName, null);
        }

        public static void DeployPackage(string packageName, object values)
        {
            string filename = HttpContext.Current.Server.MapPath("~/Shared/packages/" + packageName + ".zip");
            Deploy(filename, values);
        }

        /// <summary>
        /// Deploy the install package.
        /// </summary>
        /// <param name="values">Specified the initialize application values for installation.</param>
        /// <param name="fileName">Specified the target package file name</param>
        public static void Deploy(string fileName, object values)
        {
            using (var file = File.Open(fileName, FileMode.Open))
            {
                Deploy(file, values);
            };
        }

        public static void Deploy(string fileName)
        {
            Deploy(fileName, null);
        }

        public static void Deploy(Stream stream)
        {
            Deploy(stream, null);
        }

        /// <summary>
        /// Deploy the install package.
        /// </summary>
        /// <param name="values">Specified the initialize application values for installation.</param>
        /// <param name="stream">Specified the target package stream.</param>
        public static void Deploy(Stream stream, object values)
        {
            var zip = new DNA.IO.Compress.ZipExtract(stream);
            string xmlText = zip.ReadFileAsText("manifest.xml");
            var descriptor = ReadPackageFormXML(xmlText);
            for (int i = 0; i < descriptor.Installers.Count; i++)
                descriptor.Installers[i].Install(zip, values);
            zip.Dispose();
        }

        //public static Stream Pack(Web web)
        //{
        //    string xml=web.ToXml();

        //}
    }
}
