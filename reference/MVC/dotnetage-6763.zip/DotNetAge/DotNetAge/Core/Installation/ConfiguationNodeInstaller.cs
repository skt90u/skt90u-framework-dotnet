﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Text;
using System.Configuration;
using System.Web.Configuration;
using System.IO;
using DNA.IO.Compress;
using System.Xml;
using System.Web;
using System.Xml.Serialization;

namespace DNA.Mvc.Installation
{
    /// <summary>
    /// ConfiguationNodeInstaller can add/remove/update config nodes for the *.config file(s) at package install progress.
    /// </summary>
    /// <remarks>You can set the name attribute to "Config" of the installer element to using this installer.</remarks>
    /// <example>
    /// 	<code lang="XML" title="ConfiguationNodeInstaller config sample">
    /// 		<![CDATA[
    /// <installer type="config" file="web.config">
    ///     <install>
    ///       <node path="configuration/appSettings" action="Update" key="name" overwrite="true" value="Company Name" />
    ///      </install>
    ///      <uninstall>
    ///          <node path="configuration/appSettings" key="name" value="Company Name" action="Remove" />
    ///      </uninstall>
    /// </installer>]]>
    /// 	</code>
    /// </example>
    [XmlRoot("configInstaller"), Serializable]
    public class ConfiguationNodeInstaller : InstallerBase
    {
        //private string fileName = "web.config";
        //private List<ConfigNodeElement> _installNodes = new List<ConfigNodeElement>();
        //private List<ConfigNodeElement> _uninstallNodes = new List<ConfigNodeElement>();

        /// <summary>
        /// Gets/Sets the configuation file name.
        /// </summary>
        [XmlAttribute("file")]
        public string FileName { get; set; }

        [XmlArray("install"),
    XmlArrayItem(ElementName = "node", Type = typeof(ConfigNodeElement))]
        public List<ConfigNodeElement> InstallNodes { get; set; }

        [XmlArray("uninstall"),
   XmlArrayItem(ElementName = "node", Type = typeof(ConfigNodeElement))]
        public List<ConfigNodeElement> UninstallNodes { get; set; }

        public override bool Install(DNA.IO.Compress.ZipExtract zip, object param)
        {
            XmlDocument config = new XmlDocument();
            string configPath = HttpContext.Current.Server.MapPath("~/" + (String.IsNullOrEmpty(FileName) ? "web.config" : FileName));
            config.Load(configPath);

            if (config == null)
                throw new Exception("The configuation file not found.");
            var _changed = false;
            foreach (var node in InstallNodes)
            {
                var xpath = node.Path;

                ConfiguationUpdateActions action = (ConfiguationUpdateActions)Enum.Parse(typeof(ConfiguationUpdateActions), node.Action);

                if (action == ConfiguationUpdateActions.Update)
                {
                    //if (configNode != null)
                    //sectionNode.ReplaceChild(newNode, configNode);
                    DeploymentHelper.UpdateWebConfig(xpath, node.Key, node.Value, FileName);
                    continue;
                }

                if (action == ConfiguationUpdateActions.New)
                {
                    XmlNode sectionNode = config.SelectSingleNode(xpath);
                    XmlNode configNode = null;
                    if (!string.IsNullOrEmpty(node.Key))
                        configNode = config.SelectSingleNode(xpath + "/" + node.Name + "[@" + node.Key + "='" + node.Value + "']");

                    var newNode = config.CreateElement(node.Name);
                    var attr = config.CreateAttribute(node.Key);
                    attr.Value = node.Value;
                    newNode.Attributes.Append(attr);
                    sectionNode.AppendChild(newNode);
                    _changed = true;
                }
            }
            if (_changed)
                config.Save(configPath);
            return true;
        }

    }
}
