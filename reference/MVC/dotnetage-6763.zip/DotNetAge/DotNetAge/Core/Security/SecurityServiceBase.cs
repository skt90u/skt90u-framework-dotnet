﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DNA.Mvc.Models;
using System.Web.Mvc;
using System.Web;
using System.Web.Security;

namespace DNA.Mvc.Security
{

    public abstract class SecurityServiceBase:ISecurityActionService
    {
        /// <summary>
        /// Get all permissionsets of the system.
        /// </summary>
        public abstract List<PermissionSet> PermissionSets { get; }

        /// <summary>
        /// Get the permission instance by specified id.
        /// </summary>
        /// <param name="id">the specified id of the permission</param>
        /// <returns>The permission object instance</returns>
        public abstract Permission GetPermission(int id);

        /// <summary>
        /// Get the permission by specified controller type and action name.
        /// </summary>
        /// <param name="controllerType">The specified controllerType.</param>
        /// <param name="action">The action name of the specified controller.</param>
        /// <returns>The permission object instance</returns>
        public abstract Permission GetPermission(Type controllerType, string action);

        /// <summary>
        /// Get the permissions by specified ids.
        /// </summary>
        /// <param name="ids">the specified array of permission id.</param>
        /// <returns></returns>
        public abstract List<Permission> GetPermissions(int[] ids);

        public abstract IEnumerable<Permission> GetPermissions(int permSetID);

        /// <summary>
        /// Get the permissions for the specified role.
        /// </summary>
        /// <param name="roleName">The specified role name</param>
        /// <returns></returns>
        public abstract List<Permission> GetRolePermissions(string roleName);

        /// <summary>
        ///  Load all unregister security actions in assemblies in "Bin" folder then save the permission instance to the database.
        /// </summary>
        /// <remarks>
        ///  If the action already registered this method will do nothing.
        /// </remarks>
        public abstract void LoadSecurityActionsInAssemblies();

        /// <summary>
        /// Add the permissions to the specified role name.
        /// </summary>
        /// <param name="perms">The permissions to add.</param>
        /// <param name="roleName">The specified role name</param>
        public abstract void AddPermissionsToRole(List<Permission> perms, string roleName);

        /// <summary>
        /// Add the permissions to the specified role name.
        /// </summary>
        /// <param name="permissionIds">The permission id array</param>
        /// <param name="roleName">The specified role name</param>
        public void AddPermissionsToRole(int[] permissionIds, string roleName)
        {
            ((ISecurityActionService)this).AddPermissionsToRole(((ISecurityActionService)this).GetPermissions(permissionIds), roleName);
        }

        /// <summary>
        ///  Check the permission whether in the specified role name.
        /// </summary>
        /// <param name="perm">The permission to be check</param>
        /// <param name="roleName">The specified role name.</param>
        /// <returns>If success return true.</returns>
        public abstract bool IsAuthorize(Permission perm, string roleName);

        /// <summary>
        /// Check the permission whether in the specified controller type , action name and roleName.
        /// </summary>
        /// <param name="controllerType">The controller type</param>
        /// <param name="action">The action name in controller</param>
        /// <param name="roleName">The specified role name</param>
        /// <returns></returns>
        public bool IsAuthorize(Type controllerType, string action, string roleName)
        {
            return IsAuthorize(GetPermission(controllerType, action), roleName);
        }

        /// <summary>
        /// Receives the specified roles is authorize to access the target action.
        /// </summary>
        /// <param name="controllerType">The controller type.</param>
        /// <param name="action">The action name.</param>
        /// <param name="roles">The role names.</param>
        /// <returns></returns>
        public bool IsAuthorize(Type controllerType, string action, string[] roles)
        {
            return IsAuthorize(GetPermission(controllerType, action), roles);
        }
        
        /// <summary>
        /// Check current user whether has the permission to access the action.
        /// </summary>
        /// <param name="contorllerType">The controller type</param>
        /// <param name="action">The action name in controller</param>
        /// <returns></returns>
        public bool IsAuthorize(Type contorllerType, string action)
        {
            if ( HttpContext.Current.Request.IsAuthenticated)
                return IsAuthorize(contorllerType, action, Roles.GetRolesForUser());
            return false;
        }
        

        public abstract bool IsAuthorize(Permission perm,string[] roles);
        

        #region ISecurityActionService Members

        List<PermissionSet> ISecurityActionService.PermissionSets
        {
            get { return this.PermissionSets; }
        }

        Permission ISecurityActionService.GetPermission(int id)
        {
            return this.GetPermission(id);
        }

        Permission ISecurityActionService.GetPermission(Type controllerType, string action)
        {
            return this.GetPermission(controllerType, action);
        }

        List<Permission> ISecurityActionService.GetPermissions(int[] ids)
        {
            return this.GetPermissions(ids);
        }

        void ISecurityActionService.LoadSecurityActionsInAssemblies()
        {
            this.LoadSecurityActionsInAssemblies();
        }

        void ISecurityActionService.AddPermissionsToRole(List<Permission> perms, string roleName)
        {
            this.AddPermissionsToRole(perms, roleName);
        }

        bool ISecurityActionService.IsAuthorize(Permission perm, string roleName)
        {
            return this.IsAuthorize(perm, roleName);
        }

        #endregion
    }
}
