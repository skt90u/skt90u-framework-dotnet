﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DNA.Mvc.Models;
using System.Web;
using System.Web.Mvc;

namespace DNA.Mvc.Security
{
    /// <summary>
    /// Defines the methods used to control the action permssions
    /// </summary>
    public interface ISecurityActionService
    {
        /// <summary>
        /// Get all permissionsets of the system.
        /// </summary>
        List<PermissionSet> PermissionSets { get; }

        /// <summary>
        /// Get the permission instance by specified id.
        /// </summary>
        /// <param name="id">the specified id of the permission</param>
        /// <returns>The permission object instance</returns>
        Permission GetPermission(int id);

        /// <summary>
        /// Get the permission by specified controller type and action name.
        /// </summary>
        /// <param name="controllerType">The specified controller type.</param>
        /// <param name="action">The action name of the specified controller.</param>
        /// <returns>The permission object instance</returns>
        Permission GetPermission(Type controllerType, string action);

        /// <summary>
        /// Get the permissions by specified ids.
        /// </summary>
        /// <param name="ids">the specified array of permission id.</param>
        /// <returns></returns>
        List<Permission> GetPermissions(int[] ids);

        /// <summary>
        ///  Load all unregister security actions in assemblies in "Bin" folder then save the permission instance to the database.
        /// </summary>
        /// <remarks>
        ///  If the action already registered this method will do nothing.
        /// </remarks>
        void LoadSecurityActionsInAssemblies();

        /// <summary>
        /// Add the permissions to the specified role name.
        /// </summary>
        /// <param name="perms">The permissions to add.</param>
        /// <param name="roleName">The specified role name</param>
        void AddPermissionsToRole(List<Permission> perms, string roleName);

        /// <summary>
        ///  Check the permission whether in the specified role name.
        /// </summary>
        /// <param name="perm">The permission to be check</param>
        /// <param name="roleName">The specified role name.</param>
        /// <returns>If success return true.</returns>
        bool IsAuthorize(Permission perm, string roleName);

    }
}
