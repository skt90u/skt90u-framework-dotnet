﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;
using System.Web.Security;

namespace DNA.Mvc.Security
{
    ///UNDONE:This class need to implatement IAuthorizationFilter to finish the author.
    /// <summary>
    ///  This Action Filter is specify the Action's access roles managed by Portal
    /// </summary>
    [AttributeUsage(AttributeTargets.Method, AllowMultiple = false, Inherited = true)]
    public class SecurityActionAttribute : ActionFilterAttribute
    {
        private string permssionSet = "Default";
        private string title = "";
        private string description = "";
        private string redirectToController = "Security";
        private string redirectToAction = "";
        private bool throwOnDeny = false;

        public bool ThrowOnDeny
        {
            get { return throwOnDeny; }
            set { throwOnDeny = value; }
        }

        /// <summary>
        /// Gets/Sets the Action to redirect when authorize fail
        /// </summary>
        public string RedirectToAction
        {
            get
            {
                return redirectToAction;
            }
            set { redirectToAction = value; }
        }

        /// <summary>
        /// Init the SecurityActionAccribute class
        /// </summary>
        /// <param name="permissionSetName">Set the PermissionSetName which this Action belongs to.</param>
        /// <param name="permissionTitle">Set the PermissionTitle of this Action</param>
        public SecurityActionAttribute(string permissionSetName, string permissionTitle)
        {
            permssionSet = permissionSetName;
            title = permissionTitle;
        }

        /// <summary>
        /// Init the SecurityActionAccribute class
        /// </summary>
        /// <param name="permissionTitle">Set the PermissionTitle of this Action</param>
        public SecurityActionAttribute(string permissionTitle)
        {
            title = permissionTitle;
        }

        public SecurityActionAttribute(string permissionSetName, string permissionTitle, string permissionDescription)
        {
            permssionSet = permissionSetName;
            title = permissionTitle;
            description = permissionDescription;
        }

        /// <summary>
        /// Get/Sets the Description of the Permission for this Action
        /// </summary>
        public string Description
        {
            get { return description; }
            set { description = value; }
        }


        /// <summary>
        /// Gets/Sets the Title text of the Action
        /// </summary>
        public string Title
        {
            get { return title; }
            set { title = value; }
        }

        /// <summary>
        /// Gets/Sets the Permission Name which the security action belongs to
        /// </summary>
        ///<remark>
        ///  If the permission name is not exists Portal will add a new one
        ///</remark>
        public string PermssionSet
        {
            get { return permssionSet; }
            set { permssionSet = value; }
        }

        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            if (WebSite.SecurityService.IsAuthorize(filterContext.Controller.GetType(),
                filterContext.ActionDescriptor.ActionName,
                Roles.GetRolesForUser()) || HttpContext.Current.User.IsWebOwner())
                base.OnActionExecuting(filterContext);
            else
            {
                if (throwOnDeny) throw new AccessDenyException();
                else
                {
                    string defaultAction = "AccessDenied";
                    string defaultController = redirectToController;

                    if (!string.IsNullOrEmpty(redirectToAction))
                    {
                        defaultAction = redirectToAction;
                        defaultController = filterContext.ActionDescriptor.ControllerDescriptor.ControllerName;
                    }

                    filterContext.Result = new RedirectToRouteResult(new RouteValueDictionary(new { controller = defaultController, action = defaultAction }));
                    base.OnActionExecuting(filterContext);
                }
            }
        }

    }
}
