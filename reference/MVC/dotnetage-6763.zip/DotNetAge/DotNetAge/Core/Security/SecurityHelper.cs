﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using DNA.Mvc.Models;

namespace DNA.Mvc.Security
{
    /// <summary>
    /// Provides the helper methods for check the action can be access.
    /// </summary>
    public static class SecurityHelper
    {
        private static SecurityServiceBase Service
        {
            get
            {
                return WebSite.SecurityService;
            }
        }

        /// <summary>
        /// Check current user can access the specified action.
        /// </summary>
        /// <param name="helper">The html helper</param>
        /// <param name="action">The specified action name.</param>
        /// <param name="controller">The specified controller type.</param>
        /// <returns></returns>
        public static bool IsAuthorize(this HtmlHelper helper, string action, Type controller)
        {
            if (helper.ViewContext.HttpContext.Request.IsAuthenticated)
                return Service.IsAuthorize(controller, action, Roles.GetRolesForUser());
            return false;
        }

        public static bool IsAuthorize<TController>(this Controller controller, string action)
        {
            return Service.IsAuthorize(typeof(TController), action, Roles.GetRolesForUser());
        }
        public static bool IsAuthorize(this Controller controller, string action)
        {
            return Service.IsAuthorize(controller.GetType(), action, Roles.GetRolesForUser());
        }

        public static bool IsAuthorize<TController>(this HtmlHelper helper, string action)
            where TController:Controller
        {
            return helper.IsAuthorize(action,typeof(TController));
        }

        /// <summary>
        /// Check current user can access the specified action.
        /// </summary>
        /// <param name="helper">The html helper</param>
        /// <param name="action">The specified action name.</param>
        /// <returns></returns>
        public static bool IsAuthorize(this HtmlHelper helper, string action)
        {
            return IsAuthorize(helper, action, helper.ViewContext.Controller.GetType());
        }

        /// <summary>
        /// Check current user whether can access current action.
        /// </summary>
        /// <param name="helper">The html helper</param>
        /// <returns></returns>
        public static bool IsAuthorize(this HtmlHelper helper)
        {
            return IsAuthorize(helper, helper.ViewContext.RouteData.Values["action"].ToString());
        }

        /// <summary>
        /// Check the specified roles whether has permission.
        /// </summary>
        /// <param name="helper">The html helper</param>
        /// <param name="permission">The permission to be checked.</param>
        /// <param name="roles">The roles.</param>
        /// <returns></returns>
        public static bool IsAuthorize(this HtmlHelper helper, Permission permission, string[] roles)
        {
            if (helper.ViewContext.HttpContext.Request.IsAuthenticated)
                return Service.IsAuthorize(permission,roles);
            return false;
        }

        /// <summary>
        /// Check the specified role whether has permission
        /// </summary>
        /// <param name="helper">The html helper</param>
        /// <param name="permission">The permission to be checked.</param>
        /// <param name="role">The specified role name</param>
        /// <returns></returns>
        public static bool IsAuthorize(this HtmlHelper helper, Permission permission, string role)
        {
            return IsAuthorize(helper, permission, new string[] { role });
        }

        /// <summary>
        /// Check the current user whether has the specified permission
        /// </summary>
        /// <param name="helper">The html helper</param>
        /// <param name="permission">The specified permission inistance.</param>
        /// <returns></returns>
        public static bool IsAuthorize(this HtmlHelper helper, Permission permission)
        {
            return IsAuthorize(helper, permission, Roles.GetRolesForUser());
        }
    }
}
