﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DNA.Mvc.Models;
using System.Web;
using System.Web.Mvc;
using System.IO;
using System.Reflection;
using System.Web.Caching;
using System.Data.Objects;

namespace DNA.Mvc.Security
{
    /// <summary>
    /// Implement the ISecurityActionService used to control the action permssions
    /// </summary>
    public class SecurityActionService : SecurityServiceBase
    {
        private static readonly Func<DNAEntities, int, Permission> compiledGetPermission = CompiledQuery.Compile<DNAEntities, int, Permission>((db, pID) => (from p in db.Permissions where p.ID == pID select p).SingleOrDefault());
        private static readonly Func<DNAEntities, string, string, string, Permission> compiledGetPermission_2 = CompiledQuery.Compile<DNAEntities, string, string, string, Permission>((db, asm, act, ctrl) => (from p in db.Permissions where p.Action.Equals(act, StringComparison.OrdinalIgnoreCase) && p.Assembly.Equals(asm, StringComparison.OrdinalIgnoreCase) && p.Controller.Equals(ctrl, StringComparison.OrdinalIgnoreCase) select p).FirstOrDefault());
        private static readonly Func<DNAEntities, int, string, int> compiledGetPermissionRoleCount = CompiledQuery.Compile<DNAEntities, int, string, int>((db, perID, roleName) => (from pr in db.PermissionRoles where (pr.PermID == perID && pr.RoleName.Equals(roleName, StringComparison.OrdinalIgnoreCase)) select pr).Count());
        private static readonly Func<DNAEntities, string, PermissionSet> compiledGetPermissionSetByName = CompiledQuery.Compile<DNAEntities, string, PermissionSet>((db, name) => db.PermissionSets.FirstOrDefault(m => m.Name.Equals(name, StringComparison.OrdinalIgnoreCase)));
        private static readonly Func<DNAEntities, string, IEnumerable<PermissionRole>> compiledGetPermissionRoles = CompiledQuery.Compile<DNAEntities, string, IEnumerable<PermissionRole>>((db, name) => (from pr in db.PermissionRoles where pr.RoleName.Equals(name, StringComparison.OrdinalIgnoreCase) select pr));
        private static readonly Func<DNAEntities, int, IEnumerable<Permission>> compiledGetPermissions = CompiledQuery.Compile<DNAEntities, int, IEnumerable<Permission>>((db, pID) => (from p in db.Permissions where p.PermissionSetID == pID select p));
        private List<PermissionSet> permissionSets;

        /// <summary>
        /// Get all permissionsets of the system.
        /// </summary>
        public override List<PermissionSet> PermissionSets
        {
            get
            {
                if (permissionSets == null)
                {
                    using (var db = DBMan.Instance())
                    {
                        permissionSets = db.PermissionSets.ToList();
                    }
                }
                return permissionSets;
                //return DataBase.PermissionSets.ToList(); 
            }
        }


        /// <summary>
        /// Get the permission instance by specified id.
        /// </summary>
        /// <param name="id">the specified id of the permission</param>
        /// <returns>The permission object instance</returns>
        public override Permission GetPermission(int id)
        {
            string key = "cache_perm_" + id;
            var contextItem = HttpContext.Current.Items;
            Permission perm = null;
            if (contextItem.Contains(key))
                perm = contextItem[key] as Permission;

            if (perm == null)
            {
                using (var db = DBMan.Instance())
                {
                    perm = compiledGetPermission.Invoke(db, id);
                }
                if (perm == null) return null;
                contextItem.Add(key, perm);
            }
            return perm;
        }

        /// <summary>
        /// Get the permission by specified controller instance and action name.
        /// </summary>
        /// <param name="controllerType">The specified controller type.</param>
        /// <param name="action">The action name of the specified controller.</param>
        /// <returns>The permission object instance</returns>
        public override Permission GetPermission(Type controllerType, string action)
        {
            string assemblyName = controllerType.Assembly.GetName().Name;
            string key = "cache_perm_" + assemblyName + "_" + controllerType.Name + "_" + action;
            var contextItem = HttpContext.Current.Items;
            Permission perm = null;
            if (contextItem.Contains(key))
                perm = contextItem[key] as Permission;
            if (perm == null)
            {
                using (var db = DBMan.Instance())
                {
                    perm = compiledGetPermission_2(db, assemblyName, action, controllerType.Name);
                }
                if (perm == null) return null;
                contextItem.Add(key, perm);
            }
            return perm;
        }

        /// <summary>
        /// Get the permissions by specified ids.
        /// </summary>
        /// <param name="ids">the specified array of permission id.</param>
        /// <returns></returns>
        public override List<Permission> GetPermissions(int[] ids)
        {
            using (var db = DBMan.Instance())
            {
                var ps = (from Permission p in db.Permissions
                          where ids.Contains(p.ID)
                          select p);
                return ps.ToList();
            }
        }


        public override IEnumerable<Permission> GetPermissions(int permSetID)
        {
            using (var db = DBMan.Instance())
            {
                return compiledGetPermissions.Invoke(db, permSetID).ToList();
            }
        }

        /// <summary>
        /// Get the permissions for the specified role.
        /// </summary>
        /// <param name="roleName">The specified role name</param>
        /// <returns></returns>
        public override List<Permission> GetRolePermissions(string roleName)
        {
            using (var db = DBMan.Instance())
            {
                var permsInRole = compiledGetPermissionRoles.Invoke(db, roleName).ToList();

                List<Permission> perms = new List<Permission>();
                foreach (var p in permsInRole)
                {
                    if (!p.PermissionReference.IsLoaded)
                        p.PermissionReference.Load();
                    perms.Add(p.Permission);
                }
                return perms;
            }
        }

        /// <summary>
        ///  Load all unregister security actions in assemblies in "Bin" folder then save the permission instance to the database.
        /// </summary>
        /// <remarks>
        ///  If the action already registered this method will do nothing.
        /// </remarks>
        public override void LoadSecurityActionsInAssemblies()
        {
            string[] files = Directory.GetFiles(HttpContext.Current.Server.MapPath("~/bin"), "*.dll");
            using (var db = DBMan.Instance())
            {
                foreach (string file in files)
                {
                    try
                    {
                        //When using LoadFile will cause could not get CustomAttributes!
                        Assembly assembly = Assembly.LoadFrom(file);
                        AssemblyName asmname = assembly.GetName();
                        Type[] types = assembly.GetTypes();
                        var controllers = from c in types
                                          where c.BaseType == typeof(Controller)
                                          select c;

                        Dictionary<string, string> added = new Dictionary<string, string>();

                        foreach (Type controller in controllers)
                        {
                            var methods = controller.GetMethods(BindingFlags.Public | BindingFlags.Instance);
                            var actions = from MethodInfo method in methods
                                          where (method.GetCustomAttributes(typeof(SecurityActionAttribute), true).Length > 0)
                                          select method;

                            foreach (MethodInfo action in actions)
                            {
                                SecurityActionAttribute attr = (SecurityActionAttribute)Attribute.GetCustomAttribute(action, typeof(SecurityActionAttribute));

                                var instance = from p in db.Permissions
                                               where ((p.Action.Equals(action.Name, StringComparison.OrdinalIgnoreCase)) &&
                                               (p.Assembly.Equals(asmname.Name, StringComparison.OrdinalIgnoreCase)) &&
                                               (p.Controller.Equals(controller.Name, StringComparison.OrdinalIgnoreCase)) &&
                                               (p.Title.Equals(attr.Title, StringComparison.OrdinalIgnoreCase)))
                                               select p;

                                if (instance.Count() > 0)
                                    continue;

                                string _key = asmname.Name + "_" + controller.Name + "_" + action.Name;
                                if (added.ContainsKey(_key))
                                {
                                    if (added[_key] == attr.Title)
                                        continue;
                                }
                                else
                                    added.Add(_key, attr.Title);

                                Permission permission = new Permission()
                                {
                                    Action = action.Name,
                                    Assembly = asmname.Name,
                                    Controller = controller.Name,
                                    Title = attr.Title,
                                    Description = attr.Description
                                };

                                PermissionSet pset = null;
                                if (!string.IsNullOrEmpty(attr.PermssionSet))
                                    pset = compiledGetPermissionSetByName.Invoke(db, attr.PermssionSet);

                                if (pset == null)
                                {
                                    pset = new PermissionSet();
                                    pset.Name = attr.PermssionSet;
                                    db.AddToPermissionSets(pset);
                                    db.SaveChanges();
                                }

                                pset.Permissions.Add(permission);
                                db.AddToPermissions(permission);
                            }
                        }
                    }
                    catch (Exception e) { continue; }
                }
                db.SaveChanges();
            }
        }

        public override void AddPermissionsToRole(List<Permission> perms, string roleName)
        {
            if (perms == null)
                throw new ArgumentNullException("perms");

            if (perms.Count == 0)
                throw new ArgumentOutOfRangeException("perms");

            if (string.IsNullOrEmpty(roleName))
                throw new ArgumentNullException("roleName");

            using (var db = DBMan.Instance())
            {
                var prs = compiledGetPermissionRoles.Invoke(db, roleName).ToList();

                foreach (PermissionRole _pr in prs)
                    db.DeleteObject(_pr);
                db.SaveChanges();

                foreach (Permission p in perms)
                    db.PermissionRoles.AddObject(PermissionRole.CreatePermissionRole(p.ID, roleName));
                db.SaveChanges();
            }
        }

        /// <summary>
        ///  Check the permission whether in the specified role name.
        /// </summary>
        /// <param name="perm">The permission to be check</param>
        /// <param name="roleName">The specified role name.</param>
        /// <returns>If success return true.</returns>
        public override bool IsAuthorize(Permission perm, string roleName)
        {
            //Administrators role is the system default role
            if (roleName.ToLower() == "administrators")
                return true;
            using (var db = DBMan.Instance())
            {
                return compiledGetPermissionRoleCount.Invoke(db, perm.ID, roleName) > 0;
            }
        }

        public override bool IsAuthorize(Permission perm, string[] roles)
        {
            if (perm == null)
                return false;

            //var user = HttpContext.Current.User;
            //if (user.IsHost() || user.IsWebOwner()) return true;
            if (roles.Contains("administrators")) return true;

            using (var db = DBMan.Instance())
            {
                var roleNames = compiledGetRoleNames.Invoke(db, perm.ID).ToArray();
                //db.PermissionRoles.Where(r => r.PermID == perm.ID).Select(r => r.RoleName).ToArray();

                foreach (var r in roleNames)
                {
                    if (roles.Contains(r))
                        return true;
                }
                return false;
            }
        }
        private static readonly Func<DNAEntities, int, IEnumerable<string>> compiledGetRoleNames = CompiledQuery.Compile<DNAEntities, int, IEnumerable<string>>((db, pID) => (db.PermissionRoles.Where(r => r.PermID == pID).Select(r => r.RoleName)));
    }
}
