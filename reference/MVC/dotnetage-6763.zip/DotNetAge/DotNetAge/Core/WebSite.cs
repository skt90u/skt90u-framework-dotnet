﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Globalization;
using System.IO;
using System.Web.Caching;
using DNA.Mvc.Configuration;
using DNA.Mvc.Exceptions;
using DNA.Mvc.Models;

namespace DNA.Mvc
{
    /// <summary>
    /// The Dna data modal entry class. 
    /// </summary>
    public static class WebSite
    {

        public static string ApplicationPath
        {
            get
            {
                return Open().GetFullUrl();
            }
        }

        /// <summary>
        /// Gets the root url of the DNA Host.
        /// </summary>
        public static Uri AppUrl
        {
            get
            {
                if (url == null)
                    url = new Uri(ApplicationPath);
                return url;
            }
        }
        private static Uri url = null;
        /// <summary>
        /// Open the root web
        /// </summary>
        /// <returns></returns>
        public static Web Open()
        {
            return Open(string.Empty);
        }

        /// <summary>
        /// Open and get the web site by route data
        /// </summary>
        /// <param name="routeData">The route data object</param>
        /// <returns>Returns a web instance.</returns>
        public static Web Open(System.Web.Routing.RouteData routeData)
        {
            if (routeData.Values["website"] != null)
                return Open(routeData.Values["website"].ToString());
            else
                return Open(string.Empty);
        }

        /// <summary>
        /// Open and gets the web site by current http context.
        /// </summary>
        /// <param name="context">The context object</param>
        /// <returns>Returns a web instance.</returns>
        public static Web Open(HttpContext context)
        {
            return Open(context.Request.RequestContext.RouteData);
        }

        /// <summary>
        /// Open and get the Web instance by web name.
        /// </summary>
        /// <param name="name">Specified the web name.</param>
        /// <returns>Returns a web instance for specified name.</returns>
        public static Web Open(string name)
        {
            string key = "DNA_WEB_" + name;
            string _name = name;
            if ((string.IsNullOrEmpty(_name) || (_name.Equals("home", StringComparison.OrdinalIgnoreCase))))
                _name = "home";

            //This method may invoke by another threads.
            if (HttpContext.Current == null)
            {
                return UIService.GetWebByName(_name);
                //using (var db = DBMan.Instance())
                //{
                //    return compiledGetWeb.Invoke(db, _name);
                //}
            }
            else
            {
                if (!HttpContext.Current.Items.Contains(key))
                {
                    HttpContext.Current.Items[key] = UIService.GetWebByName(_name);
                    //using (var db = DBMan.Instance())
                    //{
                    //    HttpContext.Current.Items[key] = compiledGetWeb.Invoke(db, _name);
                    //}
                    //db.Webs.FirstOrDefault(w => w.Name == _name);
                }

                return HttpContext.Current.Items[key] as Web;
            }
        }

        /// <summary>
        /// Gets the current web instance from current request context.
        /// </summary>
        /// <param name="controller">The controller object</param>
        /// <returns>A web instance for current context</returns>
        public static Web CurrentWeb(this Controller controller)
        {
            var w = Open(controller.RouteData);
            if ((w == null) && (!WebHost.EnablePersonalWeb))
                return Open();
            return w;
        }

        public static Web CurrentWeb()
        {
            return Open(HttpContext.Current);
        }

        /// <summary>
        /// Gets the current web instance from current request context.
        /// </summary>
        /// <param name="ctrl">The ViewUserControl object</param>
        /// <returns>A web instance for current context</returns>
        public static Web CurrentWeb(this ViewUserControl ctrl)
        {
            return Open(ctrl.ViewContext.RouteData);
        }

        /// <summary>
        /// Gets the current web instance from current request context.
        /// </summary>
        /// <param name="page">The ViewMasterPage object</param>
        /// <returns>A web instance for current context</returns>
        public static Web CurrentWeb(this ViewMasterPage page)
        {
            return Open(page.ViewContext.RouteData);
        }

        internal static void SaveAndCreate(this Web web)
        {
            using (var db = DBMan.Instance())
            {
                db.Webs.AddObject(web);
                db.SaveChanges();
            }
        }

        internal static IEnumerable<Web> PeronsalWebs()
        {
            return Webs(WebTypes.Personal);
        }

        internal static IEnumerable<Web> TeamWebs()
        {
            return Webs(WebTypes.Team);
        }

        internal static IEnumerable<Web> Webs(WebTypes type)
        {
            int _type = (int)type;
            using (var db = DBMan.Instance())
            {
                return db.Webs.Where(w => w.Type == _type).ToList();
            }
        }

        /// <summary>
        /// Gets the webs belongs to specified user
        /// </summary>
        /// <param name="username">Specified the user name to query</param>
        /// <returns>A web collection belongs to user.</returns>
        internal static IEnumerable<Web> Webs(string username)
        {
            using (var db = DBMan.Instance())
            {
                return db.Webs.Where(w => w.Owner == username).ToList();
            }
        }

        private static NameTypeElementCollection serviceTypes;

        /// <summary>
        /// Gets the service type info from web.config
        /// </summary>
        private static NameTypeElementCollection RegisterServiceTypes
        {
            get
            {
                if (serviceTypes == null)
                {
                    var section = (DnaConfigurationSection)System.Web.Configuration.WebConfigurationManager.GetSection("dna");
                    serviceTypes = section.Services;
                }
                return serviceTypes;
            }
        }

        /// <summary>
        /// Get the naming service instance 
        /// </summary>
        /// <typeparam name="T">The type of the service</typeparam>
        /// <param name="name">Specified the service name that register in web.config</param>
        /// <returns>A service instance</returns>
        public static T GetService<T>(string name)
        {
            //var cache = HttpContext.Current.Cache;
            string key = "cache_" + name;
            var contextItems = HttpContext.Current.Items;
            object svc = null;
            if (contextItems.Contains(key))
                svc = contextItems[key];
            else
            {
                var typeInfo = RegisterServiceTypes[name];
                if (typeInfo == null)
                    throw new ServiceNotRegisterException(name);
                var serviceType = Type.GetType(typeInfo.Type);
                svc = Activator.CreateInstance(serviceType);
                contextItems.Add(key, svc);
            }

            //var svc = cache.Get(key);
            //if (svc == null)
            //{
            //    var typeInfo = RegisterServiceTypes[name];

            //    if (typeInfo == null)
            //        throw new ServiceNotRegisterException(name);
            //    var serviceType = Type.GetType(typeInfo.Type);
            //    svc = Activator.CreateInstance(serviceType);
            //    cache.Add(key, svc, null, Cache.NoAbsoluteExpiration, TimeSpan.FromMinutes(1), CacheItemPriority.Default, null);
            //}
            return (T)svc;
        }

        #region internal helper methods

        internal static DNA.Mvc.DynamicUI.IDynamicPageServcie UIService
        {
            get
            {
                return GetService<DNA.Mvc.DynamicUI.IDynamicPageServcie>("pages");
            }
        }

        internal static DNA.Mvc.Logging.ILogService LoggingService
        {
            get
            {
                return GetService<DNA.Mvc.Logging.ILogService>("logging");
            }
        }

        internal static DNA.Mvc.DynamicUI.WidgetUIServiceBase WidgetService
        {
            get { return GetService<DNA.Mvc.DynamicUI.WidgetUIServiceBase>("widgets"); }
        }

        internal static IWebResourceService WebRes { get { return GetService<IWebResourceService>("files"); } }

        internal static DNA.Mvc.Security.IMembershipService MembershipService
        {
            get
            { return GetService<DNA.Mvc.Security.IMembershipService>("membership"); }
        }

        internal static DNA.Mvc.Security.SecurityServiceBase SecurityService
        {
            get
            { return GetService<DNA.Mvc.Security.SecurityServiceBase>("security"); }
        }

        internal static DNA.Mvc.Security.IFormsAuthentication FormAuth
        {
            get
            { return GetService<DNA.Mvc.Security.IFormsAuthentication>("authentication"); }
        }
        #endregion

        /// <summary>
        /// Get the installed cultureinfo of the portal
        /// </summary>
        internal static List<CultureInfo> InstalledCultures
        {
            get
            {
                string key = "Global_Cultures";
                if (HttpContext.Current.Cache[key] == null)
                {
                    string[] files = Directory.GetFiles(HttpContext.Current.Server.MapPath("~/App_GlobalResources/language"));
                    List<CultureInfo> cis = new List<CultureInfo>();
                    cis.Add(CultureInfo.CreateSpecificCulture("en-US"));
                    for (int i = 0; i < files.Length; i++)
                    {
                        if (Path.GetExtension(files[i]).ToLower() == ".resx")
                        {
                            string locale = Path.GetFileNameWithoutExtension(files[i]);
                            if (locale.ToLower() == "language")
                                continue;
                            locale = locale.Replace("language.", "");
                            cis.Add(CultureInfo.CreateSpecificCulture(locale));
                        }
                    }

                    HttpContext.Current.Cache.Add(key, cis, null, DateTime.Now.AddMinutes(10), TimeSpan.Zero, System.Web.Caching.CacheItemPriority.Default, null);
                }
                return (List<CultureInfo>)HttpContext.Current.Cache[key];
            }
        }

        /// <summary>
        /// Get all installed language nodes of the portal
        /// </summary>
        internal static List<SelectableNode> InstalledLanguages
        {
            get
            {
                string key = "Global_Languages";
                if (HttpContext.Current.Cache[key] == null)
                {
                    List<SelectableNode> nodes = new List<SelectableNode>();
                    foreach (CultureInfo info in InstalledCultures)
                    {
                        SelectableNode node = new SelectableNode(info.NativeName, info.Name);
                        node.ImageUrl = "~/Content/Images/flags/" + info.Name + ".gif";
                        nodes.Add(node);
                    }
                    HttpContext.Current.Cache.Add(key, nodes, null, DateTime.Now.AddMinutes(10), TimeSpan.Zero, System.Web.Caching.CacheItemPriority.Default, null);
                }
                return (List<SelectableNode>)HttpContext.Current.Cache[key];
            }
        }

        /// <summary>
        /// Get all installed theme nodes of the portal
        /// </summary>
        public static List<SelectableNode> Themes
        {
            get
            {
                string key = "Global_Themes";
                if (HttpContext.Current.Cache[key] == null)
                {
                    string[] dirs = Directory.GetDirectories(HttpContext.Current.Server.MapPath("~/Content/Themes/"));
                    List<SelectableNode> nodes = new List<SelectableNode>();

                    foreach (string dir in dirs)
                    {
                        DirectoryInfo di = new DirectoryInfo(dir);
                        SelectableNode node = new SelectableNode(di.Name, di.Name)
                        {
                            ToolTip = di.Name,
                            ImageUrl = "~/Content/Themes/" + di.Name + "/images/thumb.gif"
                        };
                        nodes.Add(node);
                    }
                    HttpContext.Current.Cache.Add(key, nodes, null, DateTime.Now.AddMinutes(10), TimeSpan.Zero, System.Web.Caching.CacheItemPriority.Default, null);
                }
                return (List<SelectableNode>)HttpContext.Current.Cache[key];
            }
        }

        /// <summary>
        /// Gets the TimeZones of the System
        /// </summary>
        internal static List<SelectableNode> TimeZones
        {
            get
            {
                string key = "Global_TimeZones";
                if (HttpContext.Current.Cache[key] == null)
                {
                    System.Collections.ObjectModel.ReadOnlyCollection<TimeZoneInfo> zones = TimeZoneInfo.GetSystemTimeZones();
                    List<SelectableNode> nodes = new List<SelectableNode>();
                    foreach (TimeZoneInfo timeZone in zones)
                    {
                        SelectableNode node = new SelectableNode(timeZone.DisplayName, timeZone.Id);
                        node.ToolTip = timeZone.StandardName;
                        nodes.Add(node);
                    }
                    HttpContext.Current.Cache.Add(key, nodes, null, DateTime.Now.AddMinutes(10), TimeSpan.Zero, System.Web.Caching.CacheItemPriority.Default, null);
                }
                return (List<SelectableNode>)HttpContext.Current.Cache[key];
            }
        }

        public static WebContext CurrentContext(this Controller controller)
        {
            return WebContext.Current;
        }
    }
}
