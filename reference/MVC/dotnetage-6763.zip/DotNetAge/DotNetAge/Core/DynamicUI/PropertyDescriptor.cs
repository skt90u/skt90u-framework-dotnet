﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DNA.Mvc.DynamicUI
{
    public class PropertyDescriptor
    {
        private string dispName;
        private Type valueType = typeof(string);
        private ControlTypes propertyControl = ControlTypes.TextBox;

        public ControlTypes PropertyControl
        {
            get { return propertyControl; }
            set { propertyControl = value; }
        }

        public Type ValueType
        {
            get { return valueType; }
            set { valueType = value; }
        }

        /// <summary>
        /// Gets/Sets the property display name.
        /// </summary>
        public string DisplayName 
        { 
            get
            {
                return string.IsNullOrEmpty(dispName) ? Name : dispName;
            }
            set 
            {
                dispName = value;
            } 
        }
        
        /// <summary>
        /// Gets/Sets the property name
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// Gets/Sets the property value.
        /// </summary>
        public object Value { get; set; }
    }
}
