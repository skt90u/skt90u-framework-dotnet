﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace DNA.Mvc.DynamicUI
{
    public class WidgetZoneBuilder:ViewComponentBuilder<WidgetZone,WidgetZoneBuilder>
    {
        public WidgetZoneBuilder(WidgetZone zone, AjaxHelper helper) : base(zone, helper) { }
        
        protected WidgetUIServiceBase Service
        {
            get { return WebSite.WidgetService; }
        }
        
        public WidgetZoneBuilder Content(Action template)
        {
            Component.Content = template;
            return this;
        }

        public override void Render()
        {
            var isDesign = false;
            
            if (!string.IsNullOrEmpty(HttpContext.Current.Request.QueryString["design"]))
            {
                bool.TryParse(HttpContext.Current.Request.QueryString["design"], out isDesign);
            }

            if (isDesign!=true)
            {
                var instances = Service.GetWidgets(Component.Id);
                foreach (var instance in instances)
                {
                    Component.Widgets.Add(new Widget()
                    {
                        Name = instance.ID.ToString(),
                        Model = instance,
                        Html = new HtmlHelper(this.Helper.ViewContext, this.Helper.ViewDataContainer)
                    });
                }
            }
            
            base.Render();
        }
    }
}