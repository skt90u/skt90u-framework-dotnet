﻿//  Copyright (c) 2011 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using DNA.Mvc.Models;

namespace DNA.Mvc.DynamicUI
{
    public class WidgetHelper
    {
        private Dictionary<string, object> userPreferences;
        private WidgetInstance instance;
        private Dictionary<string, PropertyDescriptor> propertyDescriptors = null;

        public Dictionary<string, PropertyDescriptor> PropertyDescriptors
        {
            get { return propertyDescriptors; }
            internal set { propertyDescriptors = value; }
        }

        public string IDPrefix
        {
            get
            {
                if (instance != null)
                {
                    return instance.ID.ToString().Substring(0, 5);
                }
                return "";
            }
        }

        public WidgetInstance Model { get { return instance; } internal set { instance = value; } }

        public int GetInt(string key)
        {
            return GetData<int>(key);
        }

        public string GetString(string key)
        {
            return GetData<string>(key);
        }

        public T GetData<T>(string key)
        {
            if (UserPreferences.ContainsKey(key))
            {
                return (T)UserPreferences[key];
            }

            return default(T);
        }

        public Dictionary<string, object> UserPreferences
        {
            get { return userPreferences; }
            internal set { userPreferences = value; }
        }

        public string GenerateFieldID(string fieldName)
        {
            return fieldName + IDPrefix;
        }
    }
}