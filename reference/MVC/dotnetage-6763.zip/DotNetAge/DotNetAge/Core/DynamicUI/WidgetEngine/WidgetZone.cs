﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using DNA.Mvc.jQuery;

namespace DNA.Mvc.DynamicUI
{
    public class WidgetZone:ContainerViewComponent<Widget>
    {
        public string Title { get; set; }

        public IList<Widget> Widgets
        {
            get { return InnerItems; }
            set { InnerItems = value; }
        }
        public Action Content { get; set; }

        public override void RenderBeginTag(System.Web.UI.HtmlTextWriter writer)
        {
            MergeAttribute("class", "d-widget-zone");
            base.RenderBeginTag(writer);
        }

        public override void RenderContent(System.Web.UI.HtmlTextWriter writer)
        {
            if (Content != null)
                Content.Invoke();

            foreach (var widget in Widgets)
            {
                try
                {
                    if (widget.Model.IsExpanded)
                    {
                        widget.Render(writer);
                    }
                }
                catch(Exception e)
                {
                    continue;
                }
            }

            //base.RenderContent(writer);
        }
    }
}