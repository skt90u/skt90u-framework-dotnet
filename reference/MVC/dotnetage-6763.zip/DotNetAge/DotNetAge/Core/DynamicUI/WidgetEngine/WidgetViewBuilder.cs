﻿//  Copyright (c) 2011 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using DNA.Mvc.Models;
using System.Web.Mvc;

namespace DNA.Mvc.DynamicUI
{
    public class WidgetViewBuilder:ViewComponentBuilder<WidgetView,WidgetViewBuilder>
    {
        public WidgetViewBuilder(WidgetView view, AjaxHelper helper) : base(view, helper) { }

        public WidgetViewBuilder UserPreferences(Action<WidgetHelper> content)
        {
            Component.UserPreferencesTemplate = content;
            return this;
        }

        public WidgetViewBuilder Content(Action<WidgetHelper> content)
        {
            Component.ContentTemplate = content;
            return this;
        }

        public WidgetViewBuilder Design(Action<WidgetHelper> content)
        {
            Component.DesignTemplate = content;
            return this;
        }

        public WidgetViewBuilder Preview(Action<WidgetHelper> content)
        {
            Component.PreviewTemplate = content;
            return this;
        }

        //public WidgetViewBuilder Empty(Action<WidgetHelper> content)
        //{
        //    //content.Invoke();
        //    Component.EmptyTemplate = content;
        //    return this;
        //}

        //public override void Render()
        //{
        //    base.Render();
        //}
    }
}