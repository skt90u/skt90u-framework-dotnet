﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using DNA.Mvc.Models;
using System.Web.UI;
using System.Web.Mvc;
using System.Web.Mvc.Html;

namespace DNA.Mvc.DynamicUI
{
    public class Widget : ViewComponent
    {
        private UrlHelper urlHelper;
        private HtmlHelper helper;

        internal HtmlHelper Html
        {
            get { return helper; }
            set { helper = value; }
        }

        private UrlHelper Url
        {
            get
            {
                if (urlHelper == null)
                    urlHelper = UrlUtility.CreateUrlHelper();
                return urlHelper;
            }
        }

        public WidgetInstance Model { get; set; }

        public bool IsDesignModel
        {
            get
            {
                return true;
            }
        }

        public override void RenderBeginTag(HtmlTextWriter writer)
        {
            this.MergeAttribute("class", "d-widget");

            if (!this.Model.ShowBorder)
                this.MergeAttribute("style", "border:none;");

            base.RenderBeginTag(writer);
        }

        public override void RenderContent(HtmlTextWriter writer)
        {
            if (Model.ShowHeader)
            {
                writer.WriteBeginTag("h2");
                writer.WriteAttribute("class", "d-widget-header");
                writer.Write(HtmlTextWriter.TagRightChar);

                writer.WriteBeginTag("a");
                writer.WriteAttribute("class", "d-widget-title-link");
                if (!string.IsNullOrEmpty(Model.TitleLinkUrl))
                    writer.WriteAttribute("href", Url.Content(Model.TitleLinkUrl));
                else
                    writer.WriteAttribute("href", "javascript:void(0);");
                writer.Write(HtmlTextWriter.TagRightChar);

                if (!string.IsNullOrEmpty(Model.IconUrl))
                {
                    writer.WriteBeginTag("img");
                    writer.WriteAttribute("class", "d-widget-icon");
                    writer.WriteAttribute("src", Url.Content(Model.IconUrl));
                    writer.WriteAttribute("alt", Model.Title);
                    writer.Write(HtmlTextWriter.TagRightChar);
                    writer.WriteEndTag("img");
                }

                writer.Write(Model.Title);
                writer.WriteEndTag("a");
                writer.WriteEndTag("h2");
            }

            writer.WriteBeginTag("div");
            writer.WriteAttribute("class", "d-widget-body");
            writer.Write(HtmlTextWriter.TagRightChar);

            try
            {
                if (string.IsNullOrEmpty(Model.Url))
                    Html.RenderAction(Model.Action, Model.Controller, new { Area="", wid = Model.ID.ToString(), preview = false, design = false });
                else
                    Html.RenderAction(Model.Action, Model.Controller, new { Area = Model.Url, wid = Model.ID.ToString(), preview = false, design = false });
            }
            catch (Exception e)
            {
                writer.WriteBeginTag("div");
                writer.WriteAttribute("class", "ui-state-error");
                writer.WriteAttribute("style", "white-space:normal;");
                writer.Write(Html32TextWriter.TagRightChar);
                writer.Write(e.Message);
                writer.WriteEndTag("div");
                writer.WriteEndTag("div");
                writer.WriteEndTag("div");
            }

            writer.WriteEndTag("div");

        }
    }
}