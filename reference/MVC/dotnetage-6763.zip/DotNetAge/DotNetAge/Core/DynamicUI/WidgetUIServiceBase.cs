﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DNA.Mvc.Models;
using System.Web;

namespace DNA.Mvc.DynamicUI
{
    /// <summary>
    /// The base class of all WidgetUIService
    /// </summary>
    public abstract class WidgetUIServiceBase : IWidgetUIServcie
    {

        ///// <summary>
        ///// Get all WidgetCategories
        ///// </summary>
        //public abstract List<WidgetCategory> AllCategories { get; }

        /// <summary>
        /// Add the new WidgetDescriptor to the database.
        /// </summary>
        /// <param name="descriptor">The new descriptor instance.</param>
        /// <returns></returns>
        public abstract WidgetDescriptor AddDescriptor(WidgetDescriptor descriptor);

        /// <summary>
        /// Delete the specified descriptor by id.
        /// </summary>
        /// <param name="id">The specified descriptor id.</param>
        public abstract void DeleteDescriptor(int id);

        /// <summary>
        /// Get the specified descriptor by id.
        /// </summary>
        /// <param name="id">The specified descriptor id.</param>
        /// <returns></returns>
        public abstract WidgetDescriptor GetWidgetDescriptor(int id);

        public abstract WidgetDescriptor GetWidgetDescriptor(string controllerName, string action);

        /// <summary>
        /// Delete the specified Widget Instance.
        /// </summary>
        /// <param name="id"></param>
        public abstract void DeleteWidget(Guid id);

        /// <summary>
        /// Create the Widget Instance from specified installation page.
        /// </summary>
        /// <param name="installationID"></param>
        /// <param name="zoneID"></param>
        /// <returns></returns>
        public abstract WidgetInstance AddWidget(Guid id, WidgetDescriptor descriptor, string path, string zoneID, int position);

        public WidgetInstance AddWidget(WidgetDescriptor descriptor, string path, string zoneID, int position)
        {
            return AddWidget(Guid.NewGuid(), descriptor, path, zoneID, position);
        }

        /// <summary>
        /// Toggle the specified Widget status to collapsed / expanded.
        /// </summary>
        /// <param name="id"></param>
        public void Toggle(Guid id)
        {
            var widget = GetWidget(id);
            //if (widget.IsExpanded == null)
            //    widget.IsExpanded = true;
            //else
            widget.IsExpanded = !widget.IsExpanded;
            UpdateWidget(widget);
        }

        /// <summary>
        /// Move the specified widget to a zone.
        /// </summary>
        /// <param name="id"></param>
        /// <param name="zoneID"></param>
        /// <param name="position"></param>
        public abstract void MoveTo(Guid id, string zoneID, int position);

        /// <summary>
        /// Load the settings data object for specified Widget
        /// </summary>
        /// <param name="id">The specified widget id</param>
        /// <returns></returns>
        public object SyncSettings(Guid id)
        {
            var widget = GetWidget(id);
            if (widget != null)
                return widget.ReadUserPreferences();
            return null;
        }

        /// <summary>
        /// Save the setting data for the specified widget.
        /// </summary>
        /// <param name="id">The specified widget id</param>
        /// <param name="settings">The settings object instance</param>
        public void ApplySettings(Guid id, object settings)
        {
            var widget = GetWidget(id);
            if (widget != null)
            {
                if (settings != null)
                {
                    IDictionary<string, object> data = ObjectHelper.ConvertObjectToDictionary(settings);
                    widget.SaveUserPreferences(data);
                    UpdateWidget(widget);
                }
            }
        }

        //[Obsolete]
        //public abstract IEnumerable<WidgetDescriptor> GetWidgetDescriptors(int categoryID);

        public abstract IEnumerable<WidgetDescriptor> GetWidgetDescriptors(string installedPath);

        public abstract int GetInusingWidgetsCount(string installedPath);

       // public abstract WidgetCategory GetWidgetCategory(int id);

        public abstract WidgetDescriptor GetWidgetDescriptor(string installedPath);

       // public abstract PackageInfo GetPackage(int id);

        /// <summary>
        /// Get all Widget instances for specified web page url.
        /// </summary>
        /// <param name="url">The web page url</param>
        /// <returns>A widget collection will return.</returns>
        public abstract List<WidgetInstance> GetWidgets(Uri url);

        public abstract IEnumerable<WidgetInstance> GetWidgets(int pageId);

        public abstract IEnumerable<WidgetInstance> GetWidgets(Uri url, string zoneName);

        public IEnumerable<WidgetInstance> GetWidgets(string zoneName)
        {
            return this.GetWidgets(HttpContext.Current.Request.Url, zoneName);
        }

        /// <summary>
        /// Get the widget instance by specified id.
        /// </summary>
        /// <param name="id">The specified widget id.</param>
        /// <returns></returns>
        public abstract WidgetInstance GetWidget(Guid id);

        public abstract void UpdateWidget(WidgetInstance widget);

        #region IWidgetUIServcie 成员

        // List<WidgetCategory> IWidgetUIServcie.AllCategories
        //{
        //    get { return this.AllCategories; }
        //}

        WidgetDescriptor IWidgetUIServcie.AddDescriptor(WidgetDescriptor descriptor)
        {
            return this.AddDescriptor(descriptor);
        }

        void IWidgetUIServcie.DeleteDescriptor(int id)
        {
            this.DeleteDescriptor(id);
        }

        WidgetDescriptor IWidgetUIServcie.GetWidgetDescriptor(string installedPath)
        {
            return this.GetWidgetDescriptor(installedPath);
        }

        WidgetDescriptor IWidgetUIServcie.GetWidgetDescriptor(int id)
        {
            return this.GetWidgetDescriptor(id);
        }

        WidgetDescriptor IWidgetUIServcie.GetWidgetDescriptor(string controllerName, string action)
        {
            return this.GetWidgetDescriptor(controllerName, action);
        }

        void IWidgetUIServcie.DeleteWidget(Guid id)
        {
            this.DeleteWidget(id);
        }

        WidgetInstance IWidgetUIServcie.AddWidget(WidgetDescriptor descriptor, string path, string zoneID, int position)
        {
            return this.AddWidget(descriptor, path, zoneID, position);
        }

        void IWidgetUIServcie.MoveTo(Guid id, string zoneID, int position)
        {
            this.MoveTo(id, zoneID, position);
        }

        List<WidgetInstance> IWidgetUIServcie.GetWidgets(Uri url)
        {
            return this.GetWidgets(url);
        }

        WidgetInstance IWidgetUIServcie.GetWidget(Guid id)
        {
            return this.GetWidget(id);
        }

        void IWidgetUIServcie.UpdateWidget(WidgetInstance widget)
        {
            this.UpdateWidget(widget);
        }

        //IEnumerable<WidgetDescriptor> IWidgetUIServcie.GetWidgetDescriptors(int categoryID)
        //{
        //    return this.GetWidgetDescriptors(categoryID);
        //}
        #endregion
    }
}
