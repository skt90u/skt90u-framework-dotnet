﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DNA.Mvc.Models;

namespace DNA.Mvc.DynamicUI
{
    /// <summary>
    /// Defines the contract that application to process the widget instance data.
    /// </summary>
    public interface IWidgetUIServcie
    {
        ///// <summary>
        ///// Get all WidgetCategories
        ///// </summary>
        //List<WidgetCategory> AllCategories { get; }

        /// <summary>
        /// Add the new WidgetDescriptor to the database.
        /// </summary>
        /// <param name="descriptor">The new descriptor instance.</param>
        /// <returns>The new WidgetDescriptor instance.</returns>
        WidgetDescriptor AddDescriptor(WidgetDescriptor descriptor);

        /// <summary>
        /// Delete the specified descriptor by id.
        /// </summary>
        /// <param name="id">The specified descriptor id.</param>
        void DeleteDescriptor(int id);

        /// <summary>
        /// Get the specified descriptor by id.
        /// </summary>
        /// <param name="id">The specified descriptor id.</param>
        /// <returns></returns>
        WidgetDescriptor GetWidgetDescriptor(int id);

        /// <summary>
        /// Gets the WidgetDescriptor by specified the widget assembly name,widget controller name and widget action name.
        /// </summary>
        /// <param name="controllerName">The controller that contains the widget definition.</param>
        /// <param name="action">The widget Action name.</param>
        /// <returns>The WidgetDescriptor instance.</returns>
        WidgetDescriptor GetWidgetDescriptor(string controllerName, string action);

        WidgetDescriptor GetWidgetDescriptor(string installedPath);

        /// <summary>
        /// Gets a WidgetDescriptor collection by specified the category id.
        /// </summary>
        /// <param name="categoryID">The category id.</param>
        /// <returns>A collection contains the WidgetDescriptor instances.</returns>
       // [Obsolete()]
        //IEnumerable<WidgetDescriptor> GetWidgetDescriptors(int categoryID);
        
        IEnumerable<WidgetDescriptor> GetWidgetDescriptors(string installedPath);
        /// <summary>
        /// Delete the specified Widget Instance.
        /// </summary>
        /// <param name="id">The widget instance id.</param>
        void DeleteWidget(Guid id);

        /// <summary>
        /// Create the Widget Instance by specified widget descriptor ,the web page visual path ,the zone element id and the position in widgets sequence.
        /// </summary>
        ///<param name="descriptor">The WidgetDescriptor instance.</param>
        /// <param name="path">The web page visual path where the widget adds to.</param>
        /// <param name="zoneID">The zone element id</param>
        /// <param name="position"> The position in widgets sequence</param>
        /// <returns>A new Widget instance.</returns>
        WidgetInstance AddWidget(WidgetDescriptor descriptor, string path, string zoneID, int position);

        /// <summary>
        /// Move the specified widget to a zone.
        /// </summary>
        /// <param name="id">The widget instance id.</param>
        /// <param name="zoneID">the zone element id</param>
        /// <param name="position">The position in widgets sequence</param>
        void MoveTo(Guid id, string zoneID,int position);

        /// <summary>
        /// Get all Widget instances for specified web page url.
        /// </summary>
        /// <param name="url">The web page url</param>
        /// <returns>A collection of widgets.</returns>
        List<WidgetInstance> GetWidgets(Uri url);

        /// <summary>
        /// Get the widget instance by specified id.
        /// </summary>
        /// <param name="id">The specified widget id.</param>
        /// <returns>A widget instance.</returns>
        WidgetInstance GetWidget(Guid id);

        /// <summary>
        /// Update the widget's changed to the database.
        /// </summary>
        /// <param name="widget">The widget instance.</param>
        void UpdateWidget(WidgetInstance widget);
    }
}
