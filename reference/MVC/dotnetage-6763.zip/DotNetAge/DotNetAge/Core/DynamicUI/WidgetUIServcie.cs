﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using DNA.Mvc.Models;
using System.Web.Security;
using System.Data.Objects;

namespace DNA.Mvc.DynamicUI
{
    public class WidgetUIServcie : WidgetUIServiceBase
    {
        private static readonly Func<DNAEntities, Guid, WidgetInstance> compiledGetWidget = CompiledQuery.Compile<DNAEntities, Guid, WidgetInstance>((db, id) => (from w in db.WidgetInstances where w.ID == id select w).FirstOrDefault());
        private static readonly Func<DNAEntities, int, WidgetDescriptor> compiledGetWidgetDescriptor = CompiledQuery.Compile<DNAEntities, int, WidgetDescriptor>((db, id) => (from w in db.WidgetDescriptors where w.ID == id select w).FirstOrDefault());
        private static readonly Func<DNAEntities, string, string, WidgetDescriptor> compiledGetWidgetDescriptorByControllerAndAction = CompiledQuery.Compile<DNAEntities, string, string, WidgetDescriptor>((db, controller,action) => (from w in db.WidgetDescriptors where ((w.Action.Equals(action)) && (w.Controller.Equals(controller))) select w).FirstOrDefault());
        private static readonly Func<DNAEntities, string, WidgetDescriptor> compiledGetWidgetDescriptorByPath = CompiledQuery.Compile<DNAEntities, string, WidgetDescriptor>((db,path) => (from w in db.WidgetDescriptors where w.InstalledPath.Equals(path,StringComparison.OrdinalIgnoreCase) select w).FirstOrDefault());

        private static readonly Func<DNAEntities, int, IEnumerable<WidgetInstance>> compiledGetWidgets = CompiledQuery.Compile<DNAEntities, int, IEnumerable<WidgetInstance>>((db, pageID) => db.WidgetInstances.Where(w => w.PageID == pageID));
        private static readonly Func<DNAEntities, int, string, IEnumerable<WidgetInstance>> compiledGetPageWidgets = CompiledQuery.Compile<DNAEntities, int, string, IEnumerable<WidgetInstance>>((db, pageID, zoneID) => (from w in db.WidgetInstances orderby w.Pos where (w.PageID == pageID) && (w.ZoneID.Equals(zoneID, StringComparison.OrdinalIgnoreCase)) select w));
        private static readonly Func<DNAEntities, int, IEnumerable<WidgetInstance>> compiledGetWidgetsByDescriptorID = CompiledQuery.Compile<DNAEntities, int,  IEnumerable<WidgetInstance>>((db, descriptorID) => (from w in db.WidgetInstances orderby w.Pos where w.DescriptorID==descriptorID select w));

        private static readonly Func<DNAEntities, string, WebPage> compiledGetPageByPath = CompiledQuery.Compile<DNAEntities, string, WebPage>((db, path) => (from p in db.WebPages where p.Path.Equals(path, StringComparison.OrdinalIgnoreCase) select p).FirstOrDefault());
       // private static readonly Func<DNAEntities, int, IEnumerable<WidgetDescriptor>> compiledGetWidgetDescriptors = CompiledQuery.Compile<DNAEntities, int, IEnumerable<WidgetDescriptor>>((db, catID) => (from d in db.WidgetDescriptors where d.CatID == catID select d));

        private static readonly Func<DNAEntities, string, IEnumerable<WidgetDescriptor>> compiledGetWidgetDescriptorsByPath = CompiledQuery.Compile<DNAEntities, string, IEnumerable<WidgetDescriptor>>((db, path) => (from d in db.WidgetDescriptors where d.InstalledPath.Contains(path) select d));

        //private static readonly Func<DNAEntities, int, WidgetCategory> compiledGetWidgetCategory = CompiledQuery.Compile<DNAEntities, int, WidgetCategory>((db, id) => (from c in db.WidgetCategories where c.Id == id select c).FirstOrDefault());
        //private static readonly Func<DNAEntities, int, PackageInfo> compiledGetPackage = CompiledQuery.Compile<DNAEntities, int, PackageInfo>((db, id) => (from p in db.PackageInfos where p.ID == id select p).FirstOrDefault());

        //private static readonly Func<DNAEntities,int
        public override void DeleteWidget(Guid id)
        {
            if ((id == Guid.Empty) || (id == null))
                throw new ArgumentNullException("id");

            using (var db = DBMan.Instance())
            {
                var widget = compiledGetWidget.Invoke(db, id);
                if (widget == null)
                    throw new ArgumentOutOfRangeException("Widget not found.");

                if (!widget.WebPageReference.IsLoaded)
                    widget.WebPageReference.Load();
                var zoneID = widget.ZoneID;
                var page = widget.WebPage;
                db.DeleteObject(widget);
                db.SaveChanges();
                Reposition(page, zoneID);
            }
        }

        public override WidgetInstance AddWidget(Guid id, WidgetDescriptor descriptor, string path, string zoneID, int position)
        {
            int pos = 0;
            if (position > -1)
                pos = position;

            if (descriptor == null)
                throw new ArgumentNullException("descriptor");

            if (string.IsNullOrEmpty(path))
                throw new ArgumentNullException(path);

            if (string.IsNullOrEmpty(zoneID))
                throw new ArgumentNullException(zoneID);

            using (var db = DBMan.Instance())
            {
                WebPage page = compiledGetPageByPath(db, path);

                if (page == null)
                    throw new Exception("The path of page is not found! The widget must be added to the existing page.");

                //if (!page.IsAuthorize())
                //   throw new Exception("Access defined.");

                //Update the position below pos
                var widgetsForUpdate = from WidgetInstance w in page.Widgets
                                       where ((w.ZoneID == zoneID) && (w.Pos >= pos))
                                       select w;

                if (widgetsForUpdate != null)
                {
                    foreach (WidgetInstance _w in widgetsForUpdate)
                        _w.Pos++;
                    db.SaveChanges();
                }

                WidgetInstance widget = new WidgetInstance()
                {
                    ID = id,
                    Action = descriptor.Action,
                    Controller = descriptor.ControllerShortName,
                    Url = descriptor.Url,
                    IconUrl = descriptor.IconUrl,
                    Title = descriptor.Title,
                    IsClosable = descriptor.IsClosable.HasValue ? descriptor.IsClosable.Value : true,
                    IsDeletable = descriptor.IsDeletable.HasValue ? descriptor.IsDeletable.Value : true,
                    IsExpanded = true,
                    Scope = descriptor.Scopes,
                    Pos = pos,
                    ShowHeader = descriptor.ShowHeader.HasValue ? descriptor.ShowHeader.Value : true,
                    ShowBorder = descriptor.ShowBorder,
                    ZoneID = zoneID
                };
                

                widget.DescriptorID = descriptor.ID;
                widget.PageID = page.ID;
                //descriptor.Widgets.Add(widget);
                //page.Widgets.Add(widget);
                db.AddToWidgetInstances(widget);
                db.SaveChanges();
                return widget;
            }
        }


        private void Reposition(WebPage page, string zoneID)
        {
            using (var db = DBMan.Instance())
            {
                var widgets = compiledGetPageWidgets.Invoke(db, page.ID, zoneID).ToList();
                for (int i = 0; i < widgets.Count; i++)
                    widgets[i].Pos = i;
                db.SaveChanges();
            }
        }

        public override void MoveTo(Guid id, string zoneID, int position)
        {
            using (var db = DBMan.Instance())
            {
                var widget = compiledGetWidget.Invoke(db, id);

                if (widget == null)
                    throw new Exception("Widget not found.");

                if (!widget.WebPageReference.IsLoaded)
                    widget.WebPageReference.Load();

                //#region Move the widget at new position in the same zone
                if ((widget.ZoneID == zoneID) && (widget.Pos != position))
                {
                    int _from = widget.Pos;
                    int _to = position;

                    if ((_to != 0) && (_from != 0))  //move up
                    {
                        widget.Pos = _to;
                        var target = (from t in widget.WebPage.Widgets.CreateSourceQuery()
                                      where (t.ZoneID == zoneID) && (t.Pos == position)
                                      select t).FirstOrDefault();
                        if (target != null)
                            target.Pos = _from;
                        db.SaveChanges();
                        Reposition(widget.WebPage, zoneID);
                        return;
                    }

                    if (_to == 0)
                    {
                        widget.Pos = 0;
                        var targets = (from t in widget.WebPage.Widgets.CreateSourceQuery()
                                       where (t.ZoneID == zoneID) && (t.ID != id)
                                       select t);
                        foreach (var w in targets)
                            w.Pos++;
                        db.SaveChanges();
                        Reposition(widget.WebPage, zoneID);
                        return;
                    }

                    if (_from == 0)
                    {
                        widget.Pos = _to;
                        var targets = (from t in widget.WebPage.Widgets.CreateSourceQuery()
                                       where (t.ZoneID == zoneID) && (t.ID != id)
                                       select t);
                        foreach (var w in targets)
                            w.Pos--;
                        db.SaveChanges();
                        Reposition(widget.WebPage, zoneID);
                        return;
                    }
                }

                //Move in org zone
                if (widget.ZoneID != zoneID)
                {
                    string orgZone = widget.ZoneID;
                    widget.Pos = position;
                    widget.ZoneID = zoneID;
                    db.SaveChanges();

                    //1.Repostion the orgin zone widgets
                    Reposition(widget.WebPage, orgZone);

                    var ws = (from w in widget.WebPage.Widgets.CreateSourceQuery()
                              where ((w.ZoneID == zoneID) && (w.ID != id) && (w.Pos >= position))
                              orderby w.Pos
                              select w).ToList();

                    if (ws.Count > 0)
                    {
                        foreach (var _nw in ws)
                            _nw.Pos++;
                        db.SaveChanges();
                    }
                    //1.Repostion the orgin zone widgets
                    Reposition(widget.WebPage, zoneID);
                }
            }
        }

        public override IEnumerable<WidgetInstance> GetWidgets(int pageId)
        {
            using (var db = DBMan.Instance())
            {
                return compiledGetWidgets.Invoke(db, pageId).ToList();
            }
        }

        public override IEnumerable<WidgetInstance> GetWidgets(Uri url, string zoneName)
        {
            if (url == null)
                throw new ArgumentNullException("url");
            
            if (string.IsNullOrEmpty(zoneName))
                throw new ArgumentNullException("zoneName");

            var webContext = new WebContext(url);
            if (webContext.IsPageExists)
            {
                using (var db = DBMan.Instance())
                {
                    return compiledGetPageWidgets.Invoke(db, webContext.Page.ID,zoneName).ToList();
                }
            }
            return new List<WidgetInstance>();
        }

        public override List<WidgetInstance> GetWidgets(Uri url)
        {
            if (url == null)
                throw new ArgumentNullException("url");

            var webContext = new WebContext(url);
            if (webContext.IsPageExists)
            {
                using (var db = DBMan.Instance())
                {
                    return compiledGetWidgets.Invoke(db, webContext.Page.ID).ToList();
                }
            }
            return new List<WidgetInstance>();
        }

        public override WidgetInstance GetWidget(Guid id)
        {
            using (var db = DBMan.Instance())
            {
                return compiledGetWidget.Invoke(db, id);
            }
        }

        public override void UpdateWidget(WidgetInstance widget)
        {
            using (var db = DBMan.Instance())
            {
                var origialWidget = compiledGetWidget.Invoke(db, widget.ID);
                db.WidgetInstances.ApplyCurrentValues(widget);
                db.SaveChanges();
            }
        }

        public override WidgetDescriptor AddDescriptor(WidgetDescriptor descriptor)
        {
            using (var db = DBMan.Instance())
            {
                db.AddToWidgetDescriptors(descriptor);
                db.SaveChanges();
                return descriptor;
            }
        }

        //private List<WidgetCategory> _allCategories;

        //public override List<WidgetCategory> AllCategories
        //{
        //    get
        //    {
        //        if (_allCategories == null)
        //        {
        //            using (var db = DBMan.Instance())
        //            {
        //                _allCategories = db.WidgetCategories.ToList();
        //            }
        //        }
        //        return _allCategories;
        //        //return DbContext.WidgetCategories.ToList(); 
        //    }
        //}

        public override void DeleteDescriptor(int id)
        {
            using (var db = DBMan.Instance())
            {
                var descriptor = compiledGetWidgetDescriptor(db, id);
                if (descriptor != null)
                {
                    db.DeleteObject(descriptor);
                    db.SaveChanges();
                }
            }
        }

        //[Obsolete]
        //public override IEnumerable<WidgetDescriptor> GetWidgetDescriptors(int categoryID)
        //{
        //    using (var db = DBMan.Instance())
        //    {
        //        return compiledGetWidgetDescriptors.Invoke(db, categoryID).ToList();
        //    }
        //}

        public override IEnumerable<WidgetDescriptor> GetWidgetDescriptors(string installedPath)
        {
            using (var db = DBMan.Instance())
            {
                return compiledGetWidgetDescriptorsByPath.Invoke(db, installedPath).ToList();
            }
        }

        //public override WidgetCategory GetWidgetCategory(int id)
        //{
        //    using (var db = DBMan.Instance())
        //    {
        //        return compiledGetWidgetCategory.Invoke(db, id);
        //    }
        //}

        public override WidgetDescriptor GetWidgetDescriptor(int id)
        {
            using (var db = DBMan.Instance())
            {
                return compiledGetWidgetDescriptor.Invoke(db, id);
            }
        }

        public override WidgetDescriptor GetWidgetDescriptor(string installedPath)
        {
            using (var db = DBMan.Instance())
            {
                return compiledGetWidgetDescriptorByPath.Invoke(db, installedPath);
            }
        }

        public override WidgetDescriptor GetWidgetDescriptor(string controllerName, string action)
        {
            using (var db = DBMan.Instance())
            {
                ///TODO:Use controller type to get the widget descriptor or installed path to insist this method.

                //var pkg = db.PackageInfos.FirstOrDefault(p => p.AssemblyName == assemblyName);
                //if (pkg == null)
                //    return null;

                //var ws = from w in db.WidgetDescriptors
                //         where ((w.Action == action) && (w.Controller == controllerName))
                //         select w;

                //foreach (var descriptor in ws)
                //{
                //    if (!descriptor.PackageInfoReference.IsLoaded)
                //        descriptor.PackageInfoReference.Load();
                //    if (descriptor.PackageInfo.AssemblyName == pkg.AssemblyName)
                //        return descriptor;
                //}
                //return null;
                return compiledGetWidgetDescriptorByControllerAndAction.Invoke(db, controllerName, action);
            }
        }

        //public override PackageInfo GetPackage(int id)
        //{
        //    using (var db = DBMan.Instance())
        //    {
        //        return compiledGetPackage.Invoke(db, id);
        //    }
        //}

        public override int GetInusingWidgetsCount(string installedPath)
        {
            var tmpl = this.GetWidgetDescriptor(installedPath);
            if (tmpl != null)
            {
                using (var db = DBMan.Instance())
                {
                    return compiledGetWidgetsByDescriptorID.Invoke(db, tmpl.ID).Count();
                }
            }
            return 0;
        }
    }
}
