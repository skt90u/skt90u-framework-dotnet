﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Routing;
using DNA.Mvc.Models;
using System.Data.Objects;

namespace DNA.Mvc.DynamicUI
{
    /// <summary>
    /// Provides the methods to manipulate WebPage data and Widget data.
    /// </summary>
    public class DynamicPageService : IDynamicPageServcie, IHierarchicalNodeProvider
    {
        #region CompiledQueries
        private static readonly Func<DNAEntities, int, Web> compiledGetWeb = CompiledQuery.Compile<DNAEntities, int, Web>((db, webID) => (from w in db.Webs where w.Id == webID select w).FirstOrDefault());
        private static readonly Func<DNAEntities, int, WebPage> compiledGetPageByID = CompiledQuery.Compile<DNAEntities, int, WebPage>((db, pageID) => (from p in db.WebPages where p.ID == pageID select p).SingleOrDefault());
        private static readonly Func<DNAEntities, string, WebPage> compiledGetPageByPath = CompiledQuery.Compile<DNAEntities, string, WebPage>((db, path) => (from p in db.WebPages where p.Path.Equals(path, StringComparison.OrdinalIgnoreCase) select p).FirstOrDefault());
        private static readonly Func<DNAEntities, int, int, IEnumerable<WebPage>> compiledGetChildrenPages = CompiledQuery.Compile<DNAEntities, int, int, IEnumerable<WebPage>>((db, webID, parentID) => (from p in db.WebPages orderby p.Pos where (((p.WebID == webID) && (p.ParentID == parentID))) select p));
        private static readonly Func<DNAEntities, int, IEnumerable<WebPage>> compiledGetWebPages = CompiledQuery.Compile<DNAEntities, int, IEnumerable<WebPage>>((db, webID) => (from p in db.WebPages orderby p.Pos where p.WebID == webID select p));
        private static readonly Func<DNAEntities, int, IEnumerable<WebPage>> compiledGetStaticWebPages = CompiledQuery.Compile<DNAEntities, int, IEnumerable<WebPage>>((db, webID) => (from p in db.WebPages orderby p.Pos where (p.WebID == webID) && (p.IsStatic) select p));
        private static readonly Func<DNAEntities, int, IEnumerable<WebPageRole>> compiledGetPageRoles = CompiledQuery.Compile<DNAEntities, int, IEnumerable<WebPageRole>>((db, pageID) => (from rp in db.WebPageRoles where rp.PageID == pageID select rp));
        private static readonly Func<DNAEntities, int, string, WebPageRole> compiledGetPageRole = CompiledQuery.Compile<DNAEntities, int, string, WebPageRole>((db, pageID, roleName) => (from role in db.WebPageRoles where ((role.PageID == pageID) && (role.RoleName.Equals(roleName, StringComparison.OrdinalIgnoreCase))) select role).SingleOrDefault());
        private static readonly Func<DNAEntities, string, Web> compiledGetWebByName = System.Data.Objects.CompiledQuery.Compile<DNAEntities, string, Web>((db, name) => db.Webs.FirstOrDefault(w => w.Name.Equals(name, StringComparison.OrdinalIgnoreCase)));
        #endregion

        /// <summary>
        /// Gets the page is exists by specified path
        /// </summary>
        /// <param name="path">Specified the page path</param>
        /// <returns>Return bool value</returns>
        public bool IsExists(string path)
        {
            if (WebPageCache.IsExists(path))
                return true;
            else
                return (GetPage(path) != null);
        }

        /// <summary>
        /// Gets the web instance by specified web id.
        /// </summary>
        /// <param name="id">The specified web id.</param>
        /// <returns>A Web object.</returns>
        public Web GetWebByID(int id)
        {
            using (var db = DBMan.Instance())
            {
                return compiledGetWeb.Invoke(db, id);
            }
        }

        /// <summary>
        /// Gets the web instance by specified web name.
        /// </summary>
        /// <param name="name">Specfied the web name.</param>
        /// <returns>A Web object.</returns>
        public Web GetWebByName(string name)
        {
            using (var db = DBMan.Instance())
            {
                return compiledGetWebByName.Invoke(db, name);
            }

        }

        /// <summary>
        /// Get the WebPageRole instance by specified the page id and role name.
        /// </summary>
        /// <param name="pageID">Specified the id of the page.</param>
        /// <param name="roleName">Specfied the role name to get.</param>
        /// <returns>The WebPageRole instance.</returns>
        public WebPageRole GetPageRole(int pageID, string roleName)
        {
            using (var db = DBMan.Instance())
            {
                return compiledGetPageRole.Invoke(db, pageID, roleName);
            }
        }

        /// <summary>
        ///  Get the WebPageRole collection by specified the page id.
        /// </summary>
        /// <param name="id">The page id.</param>
        /// <returns>A collection of the WebPageRole instances.</returns>
        public IEnumerable<WebPageRole> GetPageRoles(int id)
        {
            using (var db = DBMan.Instance())
            {
                return compiledGetPageRoles.Invoke(db, id).ToList();
            }
        }

        /// <summary>
        /// Get the WebPage instance for sepecifed path.
        /// </summary>
        /// <param name="path">The path of the page.</param>
        /// <returns>The WebPage instance.</returns>
        public WebPage GetPage(string path)
        {
            if (string.IsNullOrEmpty(path))
                throw new ArgumentNullException("path");

            using (var db = DBMan.Instance())
            {
                return compiledGetPageByPath.Invoke(db, path);
                //var page = Context.WebPages.FirstOrDefault(p => p.Path.ToLower() == path);
                //return page;
            }
        }

        /// <summary>
        /// Get the child pages for specified page id.
        /// </summary>
        /// <param name="webID">The parent web id.</param>
        /// <param name="parentID">Specified th page id.</param>
        /// <returns>The WebPages of the specified id.</returns>
        public IEnumerable<WebPage> GetChildPages(int webID, int parentID)
        {
            using (var db = DBMan.Instance())
            {
                return compiledGetChildrenPages.Invoke(db, webID, parentID).ToList();
            }
        }

        /// <summary>
        /// Get all static page for specified webid
        /// </summary>
        /// <param name="webID">Specified the webid</param>
        /// <returns>A collection contains the static type pages.</returns>
        public IEnumerable<WebPage> GetStaticPages(int webID)
        {
            using (var db = DBMan.Instance())
            {
                return compiledGetStaticWebPages.Invoke(db, webID).ToList();
            }
        }

        /// <summary>
        /// Get the descendant pages by specfied web id and parent page id.
        /// </summary>
        /// <param name="webID">The web id.</param>
        /// <param name="parentID">The parent page id.</param>
        /// <returns>A collection contains the descendant page instances.</returns>
        public IEnumerable<WebPage> GetDescendantPages(int webID, int parentID)
        {
            using (var db = DBMan.Instance())
            {
                if (parentID == 0)
                {
                    return compiledGetWebPages.Invoke(db, webID).ToList();
                }
                else
                {
                    var allPages = compiledGetWebPages.Invoke(db, webID).ToList();
                    var result = new List<WebPage>();
                    GetWebPageRecursive(allPages, result, parentID);
                    return result;
                }
            }
        }

        private void GetWebPageRecursive(List<WebPage> source, List<WebPage> container, int id)
        {
            var children = source.Where(c => c.ParentID == id);
            foreach (var c in children)
            {
                GetWebPageRecursive(source, container, c.ID);
                container.Add(c);
            }
        }

        private string GeneratePagePermalink(string webName,WebPage page)
        {

            string path = TextUtility.Slug(page.Title); // +"-" + DateTime.Now.ToString("yyyyMMddHHmm") + ".html";
            
            if ((string.IsNullOrEmpty(webName)) || webName.Equals("home", StringComparison.OrdinalIgnoreCase))
                path = "~/sites/home/" + path; 
            else
                path = "~/sites/" + webName.ToLower() + "/" + path;
            
            if (GetPage(path + ".html") == null)
                path += ".html";
            else
                path +="-" + DateTime.Now.ToString("yyMMddHHmm") + ".html";

            return path;
        }

        /// <summary>
        /// Createt the page instance and save the page data to the database.
        /// </summary>
        /// <param name="page">The page instance wait for create.</param>
        public WebPage Create(WebPage page, string[] roles)
        {
            if (page == null)
                throw new ArgumentNullException("page");

            using (var db = DBMan.Instance())
            {
                var web = page.WebID > 0 ? compiledGetWeb.Invoke(db, page.WebID) : WebSite.Open();

                /*------------- Bad Code----------------------------------------------------------------------------------------*/
                string owner = string.IsNullOrEmpty(page.Owner) ? HttpContext.Current.User.Identity.Name : page.Owner;
                if (owner.Equals("host", StringComparison.OrdinalIgnoreCase)) owner = "administrator";
                /*----------------------------------------------------------------------------------------------------------------*/

                var newPage = new WebPage()
                {
                    WebID=web.Id,
                    AllowAnonymous = page.AllowAnonymous,
                    Created = DateTime.Now,
                    Description = page.Description,
                    IsStatic = page.IsStatic,
                    IsShared = page.IsShared,
                    LastModified = DateTime.Now,
                    LinkUrl = page.LinkUrl,
                    Owner =owner,
                    ParentID = page.ParentID,
                    Path = string.IsNullOrEmpty(page.Path) ? GeneratePagePermalink(web.Name,page) : page.Path,
                    ShowInMenu = page.ShowInMenu,
                    Target = string.IsNullOrEmpty(page.Target) ? "_self":page.Target,
                    Title = page.Title,
                    Pos = web.ChildrenCount(),
                    ViewData = page.ViewData,
                    ViewName = page.ViewName
                };

                if (roles != null)
                {
                    foreach (var role in roles)
                        newPage.Roles.Add(new WebPageRole() { RoleName = role });
                }

                  

                db.WebPages.AddObject(newPage);
                db.SaveChanges();

                return newPage;
            }
        }

        /// <summary>
        /// Save WebPage's changes to database.
        /// </summary>
        /// <param name="roles">Specified the accessable roles for the exists page</param>
        /// <param name="page">The page instance</param>
        public void Update(WebPage page, string[] roles)
        {
            if (page == null)
                throw new ArgumentNullException("page");

            using (var db = DBMan.Instance())
            {
                var originalPage = compiledGetPageByID.Invoke(db, page.ID);
                page.LastModified = DateTime.Now;
                db.WebPages.ApplyCurrentValues(page);
                db.SaveChanges();

                var pageRoles = page.GetRoles();

                if (pageRoles.Count() > 0)
                {
                    foreach (var r in pageRoles)
                    {
                        var orgRole = (from role in db.WebPageRoles
                                       where role.PageID == r.PageID && role.RoleName == r.RoleName
                                       select role).SingleOrDefault();

                        if (orgRole != null)
                            db.DeleteObject(orgRole);
                    }
                    db.SaveChanges();
                }

                if ((roles != null) && (roles.Length > 0))
                {
                    foreach (string _role in roles)
                    {
                        var r = WebPageRole.CreateWebPageRole(_role, page.ID);
                        db.AddToWebPageRoles(r);
                    }
                    db.SaveChanges();
                }
                WebPageCache.Remove(page.Path);
            }
        }

        /// <summary>
        /// Delete the specified page
        /// </summary>
        /// <param name="id">Specified the page id</param>
        public void Delete(int id)
        {
            if (id <= 0)
                throw new ArgumentOutOfRangeException("id");

            using (var db = DBMan.Instance())
            {
                var page = compiledGetPageByID.Invoke(db, id);
                if (page != null)
                {
                    WebPageCache.Remove(page.Path);
                    int pId = page.ParentID;

                    var children = compiledGetChildrenPages.Invoke(db, page.WebID, page.ID);

                    foreach (var child in children)
                    {
                        child.ParentID = 0;
                        child.ShowInMenu = false;
                    }

                    db.DeleteObject(page);
                    db.SaveChanges();
                    Reindex(page.WebID, pId);
                }
                else
                    throw new PageNotFoundException();
            }
        }

        /// <summary>
        /// Gets the page instance form request context.
        /// </summary>
        /// <param name="context">The requestcontext instance.</param>
        /// <returns>The page instance object</returns>
        public WebPage GetPage(RequestContext context)
        {
            return GetPage(UrlUtility.ParseVirtualPath(context));
        }

        /// <summary>
        /// Get the page instance from specified Url.
        /// </summary>
        /// <param name="url">Specified the Url</param>
        /// <returns>The page instance object</returns>
        public WebPage GetPage(Uri url)
        {
            return GetPage(UrlUtility.ParseVirtualPath(url));
        }

        /// <summary>
        /// Reindex the same parent pages's position
        /// </summary>
        /// <param name="webID">The parent web id.</param>
        /// <param name="parentID">Specified the parent id</param>
        private void Reindex(int webID, int parentID)
        {
            using (var db = DBMan.Instance())
            {
                var pages = compiledGetChildrenPages.Invoke(db, webID, parentID).ToList();
                for (int i = 0; i < pages.Count; i++)
                    pages[i].Pos = i;
                db.SaveChanges();
            }
        }

        /// <summary>
        /// Move the page to specified position
        /// </summary>
        /// <param name="parentID">Specified the parent id</param>
        /// <param name="id">Specified the page id which to move</param>
        /// <param name="pos">Specified the distansion</param>
        public void Move(int parentID, int id, int pos)
        {
            using (var db = DBMan.Instance())
            {
                var page = compiledGetPageByID.Invoke(db, id);

                if (page == null)
                    throw new ArgumentNullException("Page not found");


                var webPages = compiledGetWebPages.Invoke(db, page.WebID).ToList();

                // (parentID < 1) || ?? why?
                if (page.ParentID == parentID)
                {
                    int _from = page.Pos;
                    int _to = pos;

                    if ((_to != 0) && (_from != 0))  //move up
                    {
                        var target = webPages.FirstOrDefault(w => (w.ParentID == parentID && w.Pos == pos));

                        if (target == null)
                        {
                            Reindex(page.WebID, parentID);
                            webPages = compiledGetWebPages.Invoke(db, page.WebID).ToList();
                            target = webPages.FirstOrDefault(w => (w.ParentID == parentID && w.Pos == pos));
                        }

                        page.Pos = _to;

                        //If the target is null we need to re index the position and 
                        //run this code again.
                        if (target != null)
                        {
                            target.Pos = _from;
                            db.SaveChanges();
                            Reindex(page.WebID, page.ParentID);
                        }
                        return;
                    }

                    if (_to == 0)
                    {
                        page.Pos = 0;
                        //Context.WebPages
                        var targets = (from t in webPages
                                       where (t.ParentID == page.ParentID) && (t.ID != id)
                                       select t);

                        foreach (var w in targets)
                            w.Pos++;

                        if (targets.Count() > 0)
                        {
                            db.SaveChanges();
                            Reindex(page.WebID, page.ParentID);
                        }

                        return;
                    }

                    if (_from == 0)
                    {
                        page.Pos = _to;
                        var targets = (from t in webPages
                                       where (t.ParentID == page.ParentID) && (t.ID != id)
                                       select t);

                        foreach (var w in targets)
                            w.Pos--;

                        if (targets.Count() > 0)
                        {
                            db.SaveChanges();
                            Reindex(page.WebID, page.ParentID);
                        }
                        return;
                    }
                }

                if (page.ParentID != parentID)
                {
                    int orgParent = page.ParentID;
                    page.Pos = pos;
                    page.ParentID = parentID;
                    db.SaveChanges();
                    Reindex(page.WebID, orgParent);

                    var ws = (from w in webPages
                              where ((w.ParentID == parentID) && (w.ID != id) && (w.Pos >= pos))
                              orderby w.Pos
                              select w);

                    if (ws.Count() > 0)
                    {
                        foreach (var _nw in ws)
                            _nw.Pos++;
                        db.SaveChanges();
                    }

                    Reindex(page.WebID, parentID);
                }
            }
        }

        /// <summary>
        /// Get the WebPage instance for specified page id.
        /// </summary>
        /// <param name="id">Specified th page instance id.</param>
        /// <returns>The WebPage instance.</returns>
        public WebPage GetPage(int id)
        {
            using (var db = DBMan.Instance())
            {
                return compiledGetPageByID.Invoke(db, id);
                //   return Context.WebPages.FirstOrDefault(p => p.ID == id);
            }
        }

        #region INavigatableNodeProvider<NavigatableNode> 成员

        public string[] GetNodeRoles(HierarchicalNode node)
        {
            if (node == null)
                throw new ArgumentNullException("node");

            var page = node.Item as WebPage;

            if (page == null)
                throw new ArgumentNullException("Node.Item");

            if (!page.Roles.IsLoaded)
                page.Roles.Load();

            return page.Roles.Select(r => r.RoleName).ToArray();
        }

        private IEnumerable<HierarchicalNode> PopuplateNavigatableNodes(IEnumerable<WebPage> pages)
        {
            List<HierarchicalNode> nodes = new List<HierarchicalNode>();
            foreach (var page in pages)
                nodes.Add(PopuplateNavigatableNode(page));
            return nodes;
        }

        private HierarchicalNode PopuplateNavigatableNode(WebPage page)
        {
            if (page == null)
                throw new ArgumentNullException("Page");
            //if (nodeCache.ContainsKey(page.ID.ToString()))
            //    return nodeCache[page.ID.ToString()];

            var node = new HierarchicalNode(this)
            {
                Title = page.Title,
                Description = page.Description,
                NavigateUrl = page.ClientUrl,
                Key = page.ID.ToString()
            };
            //page.Title, page.Description, page.ClientUrl, page.ID.ToString(), null, this);
            //node.Attributes.Add("Target", page.Target);
            node.Target = page.Target;
            node.Attributes.Add("key", page.ID.ToString());
            node.Attributes.Add("ShowInMenu", page.ShowInMenu);
            node.Item = page;
            //nodeCache.Add(page.ID.ToString(), node);
            return node;
        }

        //private Dictionary<string, NavigatableNode> nodeCache = new Dictionary<string, NavigatableNode>();

        private WebPage GetPageFromKey(string key)
        {
            return GetPage(GetIDFromKey(key));
        }

        private int GetIDFromKey(string key)
        {
            if (string.IsNullOrEmpty(key))
                throw new ArgumentNullException("Key is empty");
            int id = 0;
            bool valid = int.TryParse(key, out id);
            return id;
        }

        public IEnumerable<HierarchicalNode> GetChildNodes(HierarchicalNode node)
        {
            if (node == null)
                throw new ArgumentNullException("node");
            var web = RootNode.Item as Web;

            return PopuplateNavigatableNodes(this.GetChildPages(web.Id, GetIDFromKey(node.Key)));
        }

        public HierarchicalNode GetParentNode(HierarchicalNode node)
        {
            if (node == null)
                throw new ArgumentNullException("node");
            int id = GetIDFromKey(node.Key);
            if (id == 0)
                return null;
            else
            {
                var page = GetPageFromKey(node.Key);
                if (page.ParentID == 0)
                    return RootNode;
                else
                {
                    //if (nodeCache.ContainsKey(node.Key))
                    //    return nodeCache[node.Key];
                    return PopuplateNavigatableNode(GetPage(page.ParentID));
                }
            }
        }

        public bool IsAccessibleToUser(HttpContext context, HierarchicalNode node)
        {
            if (node.Equals(RootNode)) return true;
            var page = GetPageFromKey(node.Key);
            return page.IsAuthorize();
        }

        public string ResourceKey
        {
            get
            {
                throw new NotImplementedException();
            }
            set
            {
                throw new NotImplementedException();
            }
        }

        private HierarchicalNode rootNode;
        public HierarchicalNode RootNode
        {
            get
            {
                var web = WebSite.CurrentWeb();
                if (web == null)
                    web = WebSite.Open();

                if ((rootNode == null) || (rootNode.Title != web.Title))
                {
                    rootNode = new HierarchicalNode(this)
                    {
                        Title = web.Title,
                        Description = web.Description,
                        NavigateUrl = VirtualPathUtility.ToAbsolute("~/"),
                        Key = "0",
                        Item = web
                    };
                    rootNode.Attributes.Add("key", 0);
                }
                rootNode.ParentNode = null;
                return rootNode;
            }
        }

        public HierarchicalNode CurrentNode
        {
            get
            {
                var _node = GetPage(HttpContext.Current.Request.Url);
                if (_node != null)
                    return PopuplateNavigatableNode(_node);
                return null;
            }
        }

        public bool EnableLocalization
        {
            get
            {
                return false;
            }
            set
            {
            }
        }

        public HierarchicalNode FindNodeFormKey(string key)
        {
            //if (nodeCache.ContainsKey(key))
            //    return nodeCache[key];
            return PopuplateNavigatableNode(GetPageFromKey(key));
        }

        public void AddChildren(HierarchicalNode parentNode, HierarchicalNode node) { }

        public void RemoveNode(HierarchicalNode node) { }

        #endregion
    }
}
