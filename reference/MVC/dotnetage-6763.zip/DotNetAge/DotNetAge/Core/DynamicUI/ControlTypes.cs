﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DNA.Mvc.DynamicUI
{
    /// <summary>
    /// Specifies the function of a Property in a Widget.
    /// </summary>
    /// <remarks>
    ///  You can use the ControlTypes to specifies the function of a Property in a Widget definition use by auto render setting form.
    /// </remarks>
    /// <example>
    /// <para>The ControlTypes use by the Ajax.RenderAutoSettingForm to render the user preferences setting form.</para>
    /// <code language="cs"> 
    ///   public class SampleWidgetController:Controller
    ///   {
    ///       [Widget("SayHello","The widget just say hello.")]
    ///       [Property("Word", PropertyControl=ConrolTypes.TextArea)]
    ///       public ActionResult Hello()
    ///       {
    ///            return View();
    ///       }
    ///   }
    ///   
    ///   &lt;%:@ Control Language="C#" Inherits="DNA.Mvc.DynamicUI.WidgetViewUserControl"  %&gt;
    ///   &lt;%:Ajax.RenderAutoSettingForm(PropertyDescriptors, IDPrefix, IsDesignMode)%&gt;
    ///   &lt;%:UserData["Word"] %&gt;
    ///   &lt;%:Html.StartupScripts() %&gt;
    /// </code>
    /// </example>
    public enum ControlTypes
    {
        /// <summary>
        /// A textbox control of the Widget property.
        /// </summary>
        TextBox,
        /// <summary>
        /// A TextArea control of the Widget property
        /// </summary>
        TextArea,
        /// <summary>
        /// A Number control of the Widget property
        /// </summary>
        Number,
        /// <summary>
        /// A Richtext control of the Widget property
        /// </summary>
        Richtext,
        /// <summary>
        /// A Checkbox control of the Widget property
        /// </summary>
        Checkbox,
        /// <summary>
        /// A Radiobox control of the Widget property
        /// </summary>
        Radiobox,
        /// <summary>
        /// A FileSelector control of the Widget property
        /// </summary>
        FileSelector,
        /// <summary>
        /// A Slider control of the Widget property
        /// </summary>
        Slider,
        /// <summary>
        /// A DateTimePicker control of the Widget property
        /// </summary>
        DateTimePicker,
        /// <summary>
        /// A Dropdown control of the Widget property
        /// </summary>
        Dropdown
    }
}
