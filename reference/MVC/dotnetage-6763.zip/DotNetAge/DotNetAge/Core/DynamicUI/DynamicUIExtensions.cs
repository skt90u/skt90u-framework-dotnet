﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;
using System.Web.Caching;
using System.Text;
using DNA.Mvc.jQuery;
using DNA.Mvc.Models;
using System.IO;
using System.Reflection;

namespace DNA.Mvc.DynamicUI
{
    /// <summary>
    /// Defines the DynamicUI methods to extend the AjaxHelper.
    /// </summary>
    public static class DynamicUIExtensions
    {
        private static DynamicPageService Service
        {
            get
            {
                return (DynamicPageService)WebSite.UIService;
            }
        }
        #region Control extensions

        /// <summary>
        /// Render a DropDown control that auto fills with the availdible master layout files.
        /// </summary>
        /// <param name="helper">The Ajax helper object to extends</param>
        /// <param name="name">The name of the form field </param>
        /// <param name="options">The DropDownOptions instance.</param>
        /// <returns>The Html elements of the dropdown control.</returns>
       [Obsolete]
        public static MvcHtmlString MasterLayoutDropDown(this AjaxHelper helper, string name, DropDownOptions options)
        {
            string[] masters = Directory.GetFiles(helper.ViewContext.HttpContext.Server.MapPath("~/Views/Shared"), "*.master");
            List<SelectableNode> masterNodes = new List<SelectableNode>();
            foreach (string master in masters)
            {
                DirectoryInfo dir = new DirectoryInfo(master);
                string masterName = Path.GetFileNameWithoutExtension(dir.FullName);
                masterNodes.Add(new SelectableNode(masterName, masterName));
            }
            return helper.DropDown(name, masterNodes, options);
        }

        ///// <summary>
        /////  Render the static widget by specified widget id,widget action name and widget controller name.
        ///// </summary>
        ///// <remarks>
        ///// The RenderWidget will tells the DotNetAge create the specified widget on runtime.If the specified id is already using by another widget this method will do nothing.
        ///// </remarks>
        ///// <param name="helper">The Ajax helper object to extends</param>
        ///// <param name="id">Specified the widget id of the widget.</param>
        ///// <param name="action">Specified the action name of the widget. </param>
        ///// <param name="controller">Specified the controller of the widget.</param>
        //public static void RenderWidget(this AjaxHelper helper, Guid id, string action, string controller)
        //{
        //    helper.RenderWidget(id, action, controller, "zone0", 0, null);
        //}

        ///// <summary>
        ///// Render the static widget by specified widget id,widget action name , widget controller name and the zone id that contains the widget.
        ///// </summary>
        ///// <remarks>
        ///// The RenderWidget will tells the DotNetAge create the specified widget on runtime.If the specified id is already using by another widget this method will do nothing.
        ///// </remarks>
        ///// <param name="helper">The Ajax helper object to extends</param>
        ///// <param name="id">Specified the widget id of the widget.</param>
        ///// <param name="action">Specified the action name of the widget. </param>
        ///// <param name="controller">Specified the controller of the widget.</param>
        ///// <param name="zoneID">Specified the zone id that contains the widget.</param>
        //public static void RenderWidget(this AjaxHelper helper, Guid id, string action, string controller, string zoneID)
        //{
        //    helper.RenderWidget(id, action, controller, "DNA.Mvc", zoneID, 0, null);
        //}

        ///// <summary>
        ///// Render the static widget by specified widget id,widget action name , widget controller name , the zone id that contains the widget and the widget position of the widget sequence in zone.
        ///// </summary>
        ///// <remarks>
        ///// The RenderWidget will tells the DotNetAge create the specified widget on runtime.If the specified id is already using by another widget this method will do nothing.
        ///// </remarks>
        ///// <param name="helper">The Ajax helper object to extends</param>
        ///// <param name="id">Specified the widget id of the widget.</param>
        ///// <param name="action">Specified the action name of the widget. </param>
        ///// <param name="controller">Specified the controller of the widget.</param>
        ///// <param name="zoneID">Specified the zone id that contains the widget.</param>
        ///// <param name="position">Specified the widget position of the widget sequence in zone</param>
        //public static void RenderWidget(this AjaxHelper helper, Guid id, string action, string controller, string zoneID, int position)
        //{
        //    helper.RenderWidget(id, action, controller, "DNA.Mvc", zoneID, position, null);
        //}

        ///// <summary>
        ///// Render the static widget by specified widget id,widget action name , widget controller name , the zone id that contains the widget and the initialize values of the UserPreferences.
        ///// </summary>
        ///// <remarks>
        ///// The RenderWidget will tells the DotNetAge create the specified widget on runtime.If the specified id is already using by another widget this method will do nothing.
        ///// </remarks>
        ///// <param name="helper">The Ajax helper object to extends</param>
        ///// <param name="id">Specified the widget id of the widget.</param>
        ///// <param name="action">Specified the action name of the widget. </param>
        ///// <param name="controller">Specified the controller of the widget.</param>
        ///// <param name="zoneID">Specified the zone id that contains the widget.</param>
        ///// <param name="userPreferences">Specified the object initialize the UserPreferences values.</param>
        //[Obsolete]
        //public static void RenderWidget(this AjaxHelper helper, Guid id, string action, string controller, string zoneID, object userPreferences)
        //{
        //    helper.RenderWidget(id, action, controller, "DNA.Mvc", zoneID, 0, userPreferences);
        //}

        /// <summary>
        /// Render the static widget by specified widget id,widget action name , widget controller name , the assembly name that the widget belongs to,
        /// the zone id that contains the widget and the widget,position of the widget sequence in zone and  the initialize values of the UserPreferences.
        /// </summary>
        /// <remarks>
        /// The RenderWidget will tells the DotNetAge create the specified widget on runtime.If the specified id is already using by another widget this method will do nothing.
        /// </remarks>
        /// <param name="helper">The Ajax helper object to extends</param>
        /// <param name="id">Specified the widget id of the widget.</param>
        /// <param name="action">Specified the action name of the widget. </param>
        /// <param name="controller">Specified the controller of the widget.</param>
        /// <param name="assembly">Specified the assembly name that the widget belongs to.</param>
        /// <param name="zoneID">Specified the zone id that contains the widget.</param>
        /// <param name="position">Specified the widget position of the widget sequence in zone</param>
        /// <param name="userPreferences">Specified the object initialize the UserPreferences values.</param>
        //[Obsolete]
        //public static void RenderWidget(this AjaxHelper helper, Guid id, string action, string controller, string assembly, string zoneID, int position, object userPreferences)
        //{
        //    var page = WebContext.Current.Page;
        //    // helper.ViewContext.HttpContext.Request.GetCurrentPage();
        //    var widget = page.GetWidget(id);

        //    if (widget == null)
        //    {
        //        widget = page.AddWidget(id, action, controller, assembly, zoneID, position);
        //        widget.IsStatic = true;
        //        if (userPreferences != null)
        //        {
        //            var descriptor = WebContext.Current.Web.GetWidgetDescriptor(assembly, controller, action);
        //            var _preferences = new Dictionary<string, object>();
        //            var _properties = new Dictionary<string, object>();

        //            IDictionary<string, object> preferenceDict = ObjectHelper.ConvertObjectToDictionary(userPreferences);
        //            var desProps = descriptor.GetType().GetProperties();

        //            foreach (var key in preferenceDict.Keys)
        //            {
        //                if (desProps.FirstOrDefault(p => p.Name.Equals(key, StringComparison.OrdinalIgnoreCase)) != null)
        //                    _properties.Add(key, preferenceDict[key]);
        //                else
        //                    _preferences.Add(key, preferenceDict[key]);
        //            }

        //            if (_properties.Count > 0)
        //            {
        //                var isSet = false;
        //                var _type = typeof(WidgetInstance);
        //                foreach (var key in _properties.Keys)
        //                {
        //                    var _pro = _type.GetProperty(key);
        //                    if (_pro.CanWrite)
        //                    {
        //                        _pro.SetValue(widget, _properties[key], null);
        //                        isSet = true;
        //                    }
        //                }
        //                if (isSet) widget.Update();
        //            }

        //            if (_preferences.Count > 0)
        //                widget.Apply(_preferences);
        //        }
        //        //widget.Update();
        //    }
        //}

        /// <summary>
        /// Enable the page can support the widgets
        /// </summary>
        /// <param name="helper"></param>
        [Obsolete]
        public static void EnabledCustomization(this AjaxHelper helper)
        {
            //Register the widgets
            helper.EnabledCustomization("#dna-page");
        }

        /// <summary>
        /// Enable the page can support the widgets
        /// </summary>
        /// <param name="helper"></param>
        [Obsolete]
        public static void EnabledCustomization(this AjaxHelper helper, string widgetZonejQuerySelector)
        {
            bool isDesignMode = false;
            string key = "design";
            if (!string.IsNullOrEmpty(HttpContext.Current.Request.QueryString[key]))
                bool.TryParse(HttpContext.Current.Request.QueryString[key], out isDesignMode);
            var Url =new UrlHelper(helper.ViewContext.RequestContext);

            if (isDesignMode)
                helper.jQuery(widgetZonejQuerySelector, "portable", new { mode = key, 
                    url = Url.Action("LoadData", "Widget", new { Area = "" }) ,
                    baseUrl=Url.Content("~/Widget/")
                });
           // else
              //  helper.jQuery(widgetZonejQuerySelector, "portable", new { url = Url.Action("LoadData", "Widget", new { Area = "" }), baseUrl = Url.Content("~/Widget/") });
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="helper">The Ajax helper object to extends</param>
        /// <param name="descriptors"></param>
        /// <param name="idPrefix"></param>
        /// <param name="isDesignMode"></param>
        /// <returns></returns>
        [Obsolete("This method is obsolete in DNA2 please use Ajax.Dna().Widget()")]
        public static MvcHtmlString RenderAutoSettingForm(this AjaxHelper helper, Dictionary<string, PropertyDescriptor> descriptors, string idPrefix, bool isDesignMode)
        {
            if (!isDesignMode)
                return MvcHtmlString.Empty;
            TagBuilder _form = new TagBuilder("form");
            _form.MergeAttribute("class", "d-widget-userpreferences");
            _form.MergeAttribute("action", "#");


            //UrlHelper urlHelper = new UrlHelper(helper.ViewContext.RequestContext);
            foreach (var key in descriptors.Keys)
            {
                TagBuilder _dispName = new TagBuilder("div");
                _dispName.Attributes.Add("style", "clear:both");
                _dispName.InnerHtml = descriptors[key].DisplayName;
                _form.InnerHtml += _dispName.ToString();
                TagBuilder _ctrl = new TagBuilder("div");

                _ctrl.InnerHtml = helper.RenderPropertyControl(descriptors[key], idPrefix).ToHtmlString();
                _form.InnerHtml += _ctrl.ToString();
            }
            return MvcHtmlString.Create(_form.ToString());
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="helper">The Ajax helper object to extends</param>
        /// <param name="descriptor"></param>
        /// <param name="idPrefix"></param>
        /// <returns></returns>
        [Obsolete("This method is obsolete DNA2 please use Ajax.Dna().Widget()")]
        public static MvcHtmlString RenderPropertyControl(this AjaxHelper helper, PropertyDescriptor descriptor, string idPrefix)
        {
            switch (descriptor.PropertyControl)
            {
                case ControlTypes.TextArea:
                    return helper.TextArea(descriptor.Name + idPrefix, descriptor.Value == null ? "" : descriptor.Value.ToString());
                    break;
                case ControlTypes.Checkbox:
                    return helper.CheckBox(descriptor.Name + idPrefix, descriptor.DisplayName, (bool)descriptor.Value);
                    break;
                case ControlTypes.DateTimePicker:
                    //UNDONE: THe datetime picker options is not completed
                    return helper.DatePicker(descriptor.Name + idPrefix);
                    break;
                //case ControlTypes.FileSelector:
                //    UrlHelper urlHelper = new UrlHelper(helper.ViewContext.RequestContext);
                //    return helper.FileTextBox(idPrefix + descriptor.Name, descriptor.Value == null ? "" : urlHelper.FileUrl(descriptor.Value.ToString()), "$$", "Browse", "ui-icon ui-icon-folder-open");
                //    break;
                case ControlTypes.Number:
                    return helper.Number(descriptor.Name + idPrefix, descriptor.Value, 75);
                    break;
                case ControlTypes.Slider:
                    return helper.Slider(descriptor.Name + idPrefix, (int)descriptor.Value);
                    break;
                case ControlTypes.Radiobox:
                    return helper.RadioBox(descriptor.Name + idPrefix, descriptor.DisplayName, (bool)descriptor.Value);

                    break;
                case ControlTypes.Richtext:
                    return helper.RichTextBox(descriptor.Name + idPrefix, descriptor.Value == null ? "" : helper.ViewContext.HttpContext.Server.HtmlDecode(descriptor.Value.ToString()));
                    break;
                default:
                    return helper.TextBox(descriptor.Name + idPrefix, descriptor.Value == null ? "" : descriptor.Value.ToString());
                    break;
            }
        }

        public static WidgetViewBuilder Widget(this DnaControlFactory dna)
        {
            return new WidgetViewBuilder(new WidgetView() { }, dna.Helper);
        }

        public static WidgetZoneBuilder WidgetZone(this DnaControlFactory dna)
        {
            return WidgetZone(dna, "", "");
        }

        public static WidgetZoneBuilder WidgetZone(this DnaControlFactory dna, string title)
        {
            return WidgetZone(dna,title,"");
        }

        public static WidgetZoneBuilder WidgetZone(this DnaControlFactory dna,string title,string name)
        {
            return new WidgetZoneBuilder(new WidgetZone() {Name=name,Title=title }, dna.Helper).GenerateId();
        }

        #endregion

    }
}
