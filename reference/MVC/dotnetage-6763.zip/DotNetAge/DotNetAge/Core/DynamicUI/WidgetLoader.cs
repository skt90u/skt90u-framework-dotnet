﻿//  Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using DNA.Mvc.DynamicUI;
using DNA.Mvc.Models;
using System.IO;
using System.Reflection;
using System.Web.Mvc;
using System.Web.Security;

namespace DNA.Mvc.DynamicUI
{
    public static class WidgetLoader
    {
        /// <summary>
        /// Load all runtime assembly and discovery Mvc Widgets and generate the widget packages and save theme to widget libarary.
        /// Notes:Added in DNA2
        /// </summary>
        public static void SyncWidgetLibrary()
        {
            //Auto detect package info
            string[] files = Directory.GetFiles(HttpContext.Current.Server.MapPath("~/bin"), "*.dll");

            //using (var db = DBMan.Instance())
            //{
            // var pkgs = db.PackageInfos.ToList();
            var web = WebSite.Open();
            var webOwner=Membership.GetUser(web.Owner);

            foreach (string file in files)
            {
                //When using LoadFile will cause could not get CustomAttributes!
                Assembly assembly = Assembly.LoadFrom(file);
                var attrs = assembly.GetCustomAttributes(true);
                var fileInfo = new FileInfo(file);
                var asmname = assembly.GetName();

                string libPath = HttpContext.Current.Server.MapPath("~/content/widgets/");

                Type[] types = assembly.GetTypes();
                var controllers = from c in types
                                  where (c.BaseType == typeof(Controller) || c.BaseType == typeof(AsyncController))
                                  select c;

                foreach (Type controller in controllers)
                {
                    var methods = controller.GetMethods(BindingFlags.Public | BindingFlags.Instance);
                    var actions = from MethodInfo method in methods
                                  where (method.GetCustomAttributes(typeof(WidgetAttribute), true).Length > 0)
                                  select method;
                    string controllerShortName = controller.Name.Replace("Controller", "");
                    List<string> actionNames = new List<string>();

                    foreach (MethodInfo action in actions)
                    {
                        WidgetAttribute widgetAttr = (WidgetAttribute)action.GetCustomAttributes(typeof(WidgetAttribute), true)[0];
                        string widgetCat = !string.IsNullOrEmpty(widgetAttr.Category) ? widgetAttr.Category : "Shared";
                        string installedPath = libPath + widgetCat;

                        if (!Directory.Exists(installedPath))
                            Directory.CreateDirectory(installedPath);

                        var actionName = action.Name;

                        //Supports the AsyncController
                        if (action.Name.EndsWith("async", StringComparison.OrdinalIgnoreCase))
                            actionName = action.Name.Replace("Async", "");

                        installedPath += "\\" + actionName;

                        //When the Widget have already register in database ignore the creation blow.
                        var registeredDescriptor=web.GetWidgetDescriptor(widgetCat+"\\"+actionName);
                        if (registeredDescriptor != null)
                            continue;

                        if (!Directory.Exists(installedPath))
                            Directory.CreateDirectory(installedPath);

                        actionNames.Add("\"" + actionName + "\"");

                        //var descriptor = pkg.WidgetDescriptors.FirstOrDefault(d => (d.Action == actionName && d.Controller == controllerShortName));
                        var properties = action.GetCustomAttributes(typeof(PropertyAttribute), true);
                        var defaults = new Dictionary<string, object>();
                        foreach (var pro in properties)
                        {
                            var _pro = ((PropertyAttribute)pro);
                            defaults.Add(_pro.Name, _pro.DefaultValue);
                        }

                        var tmpl = new WidgetTemplate()
                        {
                            Name = actionName,
                            Description = widgetAttr.Description,
                            Version = assembly.GetName().Version.ToString(),
                            Author = new WidgetAuthor()
                            {
                                Name = web.Owner,
                                Uri = web.AppUrl.ToString(),
                                Email = webOwner.Email
                            },
                            Defaults = new WidgetDefaults()
                            {
                                Action = actionName,
                                Controller = controller.AssemblyQualifiedName, // controllerShortName,
                                IconUrl = widgetAttr.IconUrl,
                                ShowBorder = widgetAttr.ShowBorder,
                                ShowHeader = widgetAttr.ShowHeader,
                                Title = widgetAttr.Title,
                                TitleLinkUrl = widgetAttr.TitleLink
                            },
                            UserPreferences = new List<WidgetUserPreference>()
                        };

                        if (defaults.Count > 0)
                        {
                            foreach (var key in defaults.Keys)
                            {
                                tmpl.UserPreferences.Add(new WidgetUserPreference()
                                {
                                    IsReadonly = false,
                                    Name = key,
                                    Type = defaults[key] != null ? defaults[key].GetType().ToString() : (typeof(string)).ToString(),
                                    Value = defaults[key] != null ? defaults[key].ToString() : ""
                                });
                            }
                        }
                        DNA.Utility.XmlSerializerUtility.SerializeToXmlFile(installedPath + "\\config.xml", typeof(WidgetTemplate), tmpl);
                    }
                }
            }
        }

        public static void ExtractWidgetPackage()
        { 
        }



        //[Obsolete]
        //public static void Load()
        //{
        //    //Auto detect package info
        //    string[] files = Directory.GetFiles(HttpContext.Current.Server.MapPath("~/bin"), "*.dll");
        //    using (var db = DBMan.Instance())
        //    {

        //        var pkgs = db.PackageInfos.ToList();
        //        foreach (string file in files)
        //        {
        //            //When using LoadFile will cause could not get CustomAttributes!
        //            Assembly assembly = Assembly.LoadFrom(file);
        //            var attrs = assembly.GetCustomAttributes(true);
        //            var fileInfo = new FileInfo(file);
        //            var asmname = assembly.GetName();

        //            #region Get assembly attribute info
        //            AssemblyCompanyAttribute companyAttr = null;
        //            AssemblyAuthorInfoAttribute authorInfoAttr = null;
        //            AssemblyTitleAttribute titleAttr = null;
        //            AssemblyDescriptionAttribute descAttr = null;
        //            foreach (var attr in attrs)
        //            {
        //                Type _type = attr.GetType();
        //                if (_type == typeof(AssemblyCompanyAttribute))
        //                {
        //                    companyAttr = (AssemblyCompanyAttribute)attr;
        //                    continue;
        //                }

        //                if (_type == typeof(AssemblyAuthorInfoAttribute))
        //                {
        //                    authorInfoAttr = (AssemblyAuthorInfoAttribute)attr;
        //                    continue;
        //                }

        //                if (_type == typeof(AssemblyTitleAttribute))
        //                {
        //                    titleAttr = (AssemblyTitleAttribute)attr;
        //                    continue;
        //                }

        //                if (_type == typeof(AssemblyCompanyAttribute))
        //                {
        //                    companyAttr = (AssemblyCompanyAttribute)attr;
        //                    continue;
        //                }

        //                if (_type == typeof(AssemblyDescriptionAttribute))
        //                {
        //                    descAttr = (AssemblyDescriptionAttribute)attr;
        //                    continue;
        //                }
        //            }
        //            #endregion

        //            #region Loading packages
        //            //The packageinfo not found
        //            var pkg = pkgs.FirstOrDefault(p => p.AssemblyName == asmname.Name);
        //            if (pkg == null)
        //            {
        //                pkg = new PackageInfo()
        //                {
        //                    AssemblyName = asmname.Name,
        //                    Installed = DateTime.Now,
        //                };
        //                BindPackage(fileInfo, companyAttr, authorInfoAttr, titleAttr, descAttr, asmname, pkg);
        //                db.AddToPackageInfos(pkg);
        //                db.SaveChanges();
        //            }
        //            else
        //            {
        //                if (pkg.AssemblyFullName != asmname.FullName)
        //                {
        //                    BindPackage(fileInfo, companyAttr, authorInfoAttr, titleAttr, descAttr, asmname, pkg);
        //                    db.SaveChanges();
        //                }
        //                else
        //                    continue;
        //            }

        //            #endregion

        //            #region Loading Widget Description add / update the widget descriptor
        //            if (!pkg.WidgetDescriptors.IsLoaded)
        //                pkg.WidgetDescriptors.Load();

        //            Type[] types = assembly.GetTypes();
        //            var controllers = from c in types
        //                              where (c.BaseType == typeof(Controller) || c.BaseType == typeof(AsyncController))
        //                              select c;

        //            foreach (Type controller in controllers)
        //            {
        //                var methods = controller.GetMethods(BindingFlags.Public | BindingFlags.Instance);
        //                var actions = from MethodInfo method in methods
        //                              where (method.GetCustomAttributes(typeof(WidgetAttribute), true).Length > 0)
        //                              select method;
        //                string controllerShortName = controller.Name.Replace("Controller", "");
        //                List<string> actionNames = new List<string>();
        //                foreach (MethodInfo action in actions)
        //                {
        //                    WidgetAttribute widgetAttr = (WidgetAttribute)action.GetCustomAttributes(typeof(WidgetAttribute), true)[0];
        //                    WidgetCategory category = string.IsNullOrEmpty(widgetAttr.Category) ? null : db.WidgetCategories.FirstOrDefault(c => c.Title.Equals(widgetAttr.Category, StringComparison.OrdinalIgnoreCase));

        //                    if (category == null)
        //                    {
        //                        //category = db.WidgetCategories.FirstOrDefault();
        //                        category = new WidgetCategory() { Title = widgetAttr.Category };
        //                        db.WidgetCategories.AddObject(category);
        //                        db.SaveChanges();
        //                    }

        //                    //if (!category.WidgetDescriptors.IsLoaded) category.WidgetDescriptors.Load();

        //                    var actionName = action.Name;

        //                    //Supports the AsyncController
        //                    if (action.Name.EndsWith("async", StringComparison.OrdinalIgnoreCase))
        //                        actionName = action.Name.Replace("Async", "");

        //                    actionNames.Add("\"" + actionName + "\"");
        //                    var descriptor = pkg.WidgetDescriptors.FirstOrDefault(d => (d.Action == actionName && d.Controller == controllerShortName));
        //                    var properties = action.GetCustomAttributes(typeof(PropertyAttribute), true);
        //                    var defaults = new Dictionary<string, object>();
        //                    foreach (var pro in properties)
        //                    {
        //                        var _pro = ((PropertyAttribute)pro);
        //                        defaults.Add(_pro.Name, _pro.DefaultValue);
        //                    }

        //                    if (descriptor == null)
        //                    {
        //                        descriptor = new WidgetDescriptor();
        //                        BindDescriptor(descriptor, widgetAttr, actionName, controllerShortName, defaults);
        //                        db.AddToWidgetDescriptors(descriptor);
        //                        descriptor.WidgetCategory = category;
        //                        //category.WidgetDescriptors.Add(descriptor);
        //                        pkg.WidgetDescriptors.Add(descriptor);
        //                    }
        //                    else
        //                    {
        //                        BindDescriptor(descriptor, widgetAttr, actionName, controllerShortName, defaults);
        //                        if (!descriptor.WidgetCategoryReference.IsLoaded) descriptor.WidgetCategoryReference.Load();
        //                        if (descriptor.WidgetCategory.Id != category.Id)
        //                            descriptor.WidgetCategory = category;
        //                    }
        //                    db.SaveChanges();
        //                }

        //                #region Remove the unusing widget  descriptor
        //                string[] _as = actionNames.ToArray();
        //                if (_as.Length > 0)
        //                {
        //                    string esql = "SELECT VALUE s FROM [WidgetDescriptors] AS s WHERE (s.Action NOT IN {" + string.Join(",", _as) + "}) AND s.Controller=\"" + controllerShortName + "\"";
        //                    var _lost = db.CreateQuery<WidgetDescriptor>(esql).ToList();

        //                    foreach (var lostDescriptor in _lost)
        //                        db.DeleteObject(lostDescriptor);
        //                    if (_lost.Count > 0)
        //                        db.SaveChanges();
        //                }
        //                else
        //                {
        //                    var _lost = (from l in db.WidgetDescriptors
        //                                 where l.Controller == controllerShortName
        //                                 select l).ToList();
        //                    foreach (var _l in _lost)
        //                        db.DeleteObject(_l);
        //                    if (_lost.Count > 0)
        //                        db.SaveChanges();
        //                }
        //                #endregion

        //            }
        //            #endregion

        //        }
        //    }
        //}

        //[Obsolete]
        //private static void BindPackage(FileInfo fileInfo, AssemblyCompanyAttribute companyAttr, AssemblyAuthorInfoAttribute authorInfoAttr, AssemblyTitleAttribute titleAttr, AssemblyDescriptionAttribute descAttr, AssemblyName asmname, PackageInfo pkg)
        //{
        //    pkg.AssemblyFullName = asmname.FullName;
        //    pkg.AuthorEmail = authorInfoAttr == null ? "" : authorInfoAttr.AuthorEmail;
        //    pkg.AuthorName = authorInfoAttr == null ? "" : authorInfoAttr.AuthorName;
        //    pkg.AuthorWebSite = authorInfoAttr == null ? "" : authorInfoAttr.WebSite;
        //    pkg.Description = descAttr == null ? "" : descAttr.Description;
        //    pkg.Organization = companyAttr == null ? "" : companyAttr.Company;
        //    pkg.Published = fileInfo.CreationTime;
        //    pkg.Version = asmname.Version.ToString();
        //    pkg.Name = titleAttr == null ? "" : titleAttr.Title;
        //}

        //[Obsolete]
        //private static void BindDescriptor(WidgetDescriptor descriptor, WidgetAttribute widgetAttr, string actionName, string controllerShortName, Dictionary<string, object> defaults)
        //{
        //    descriptor.Title = widgetAttr.Title;
        //    descriptor.Description = widgetAttr.Description;
        //    descriptor.Action = actionName;
        //    descriptor.Controller = controllerShortName;
        //    descriptor.IsClosable = widgetAttr.IsClosable;
        //    descriptor.IsDeletable = widgetAttr.IsDeletable;
        //    descriptor.IconUrl = widgetAttr.IconUrl;
        //    descriptor.ShowHeader = widgetAttr.ShowHeader;
        //    descriptor.ImageUrl = widgetAttr.ImageUrl;
        //    descriptor.Properties = defaults;
        //    descriptor.ShowBorder = widgetAttr.ShowBorder;
        //    descriptor.Scopes = (int)widgetAttr.Scope;
        //    descriptor.Url = string.IsNullOrEmpty(widgetAttr.Area) ? GetArea(actionName, controllerShortName) : widgetAttr.Area;
        //}

      
    }
}