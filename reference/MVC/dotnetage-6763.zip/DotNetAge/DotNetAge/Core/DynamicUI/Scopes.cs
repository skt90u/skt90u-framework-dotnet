﻿//  Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Mvc;

namespace DNA.Mvc.DynamicUI
{
    /// <summary>
    /// Defines the scropes of the widgets
    /// </summary>
    public enum Scopes
    {
        /// <summary>
        /// Idenitity the widget can be show anywhere
        /// </summary>
        Shared=0,

        /// <summary>
        /// Idenitity the widget just only shows for site owner.
        /// </summary>
        Personal=1
    }
}