﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Mvc;
using DNA.Mvc.Models;

namespace DNA.Mvc.DynamicUI
{
    /// <summary>
    /// Extend the ViewUserControl to provide some necessary properties for Widget View.
    /// </summary>
    /// <remarks>
    /// Every widget views must by inherit this class.
    /// </remarks>
    public class WidgetViewUserControl : ViewUserControl
    {
        /// <summary>
        /// Override the OnInit method
        /// </summary>
        /// <param name="e"></param>
        protected override void OnInit(EventArgs e)
        {
            if (TempData.Count > 0)
            {
                if (TempData.ContainsKey("PropertyDescriptors"))
                {
                    propertyDescriptors = (Dictionary<string, PropertyDescriptor>)TempData["PropertyDescriptors"];
                    foreach (var key in propertyDescriptors.Keys)
                        userdata.Add(key, propertyDescriptors[key].Value);
                }

                if (TempData.ContainsKey("IsPreview"))
                    Boolean.TryParse(TempData["IsPreview"].ToString(), out isPreviewMode);
                if (TempData.ContainsKey("WidgetInstance"))
                    widgetInstance = TempData["WidgetInstance"] != null ? (WidgetInstance)TempData["WidgetInstance"] : null;
            }

            base.OnInit(e);
        }

        private bool isPreviewMode = false;
        private WidgetInstance widgetInstance = null;
        private Dictionary<string, PropertyDescriptor> propertyDescriptors = null;
        private Dictionary<string, object> userdata = new Dictionary<string, object>();
        public Dictionary<string, PropertyDescriptor> PropertyDescriptors
        {
            get { return propertyDescriptors; }
        }

        /// <summary>
        /// Gets the id prefix of current widget
        /// </summary>
        public string IDPrefix
        {
            get
            {
                if (widgetInstance != null)
                {
                    return widgetInstance.ID.ToString().Substring(0, 5);
                }
                return "";
            }
        }

        public string GenerateFieldID(string fieldName)
        {
            return fieldName + IDPrefix;
        }

        /// <summary>
        /// Gets a value identity wheather the widget is in design mode.
        /// </summary>
        public bool IsDesignMode
        {
            get
            {
                bool isDesignMode = false;
                string key = "design";
                if (!string.IsNullOrEmpty(Request.QueryString[key]))
                    bool.TryParse(Request.QueryString[key], out isDesignMode);
                return isDesignMode;
            }
        }

        //private Dictionary<string, PropertyDescriptor> data = null;
        /// <summary>
        /// Gets the usersetting object instance
        /// </summary>
        /// <remarks>
        /// The UserSettings Property my store two kind of settings object
        /// 1.When the "SettingModelType" proerty of the WidgetAttribute is specified ,the 
        /// UserSettings will store the strongly type UserSettings object.
        /// 2.In common the settings object will store the NameValue pairs 
        /// </remarks>
        public Dictionary<string, object> UserData
        {
            get { return userdata; }
        }

        /// <summary>
        /// Gets the widget data instance.
        /// </summary>
        public WidgetInstance WidgetInstance
        {
            get { return widgetInstance; }
        }

        /// <summary>
        /// Identitied wheather the Widget is view in privew dialog.
        /// </summary>
        public bool IsPreviewMode
        {
            get { return isPreviewMode; }
        }


        public MvcHtmlString GenVerbLink(string text, WidgetVerbs verb)
        {
            return GenVerbLink(text, verb,null);
        }

        public MvcHtmlString GenVerbLink(string text, WidgetVerbs verb, object htmlAttributes)
        {
            var tag = new TagBuilder("a");
            tag.MergeAttribute("href", "javascript:void(0);");
            if (htmlAttributes != null)
                tag.MergeAttributes<string, object>(ObjectHelper.ConvertObjectToDictionary(htmlAttributes));
            string verbName = "refreshVerb";
            switch (verb)
            {
                case WidgetVerbs.Settings:
                    verbName = "settingVerb";
                    break;
                case WidgetVerbs.Refresh:
                    verbName = "refreshVerb";
                    break;
                case WidgetVerbs.Toggle:
                    verbName = "toggleVerb";
                    break;
                case WidgetVerbs.Delete:
                    verbName = "deleteVerb";
                    break;
                case WidgetVerbs.Export:
                    verbName = "exportVerb";
                    break;
            }
            if (this.WidgetInstance == null)
                return MvcHtmlString.Create(text);
            else
            {
                tag.MergeAttribute("onclick", "$('#" + this.WidgetInstance.ID.ToString() + "').portlet('doVerb','" + verbName + "');");
                tag.InnerHtml = text;
                return MvcHtmlString.Create(tag.ToString());
            }
        }
    }

    public class WidgetViewUserControl<T> : ViewUserControl<T>
    {
        /// <summary>
        /// Override the OnInit method
        /// </summary>
        /// <param name="e"></param>
        protected override void OnInit(EventArgs e)
        {
            if (TempData.Count > 0)
            {
                if (TempData.ContainsKey("PropertyDescriptors"))
                {
                    propertyDescriptors = (Dictionary<string, PropertyDescriptor>)TempData["PropertyDescriptors"];
                    foreach (var key in propertyDescriptors.Keys)
                        userdata.Add(key, propertyDescriptors[key].Value);
                }

                if (TempData.ContainsKey("IsPreview"))
                    Boolean.TryParse(TempData["IsPreview"].ToString(), out isPreviewMode);
                if (TempData.ContainsKey("WidgetInstance"))
                    widgetInstance = TempData["WidgetInstance"] != null ? (WidgetInstance)TempData["WidgetInstance"] : null;
            }

            base.OnInit(e);
        }

        private bool isPreviewMode = false;
        private WidgetInstance widgetInstance = null;
        private Dictionary<string, PropertyDescriptor> propertyDescriptors = null;
        private Dictionary<string, object> userdata = new Dictionary<string, object>();
        public Dictionary<string, PropertyDescriptor> PropertyDescriptors
        {
            get { return propertyDescriptors; }
        }

        /// <summary>
        /// Gets the id prefix of current widget
        /// </summary>
        public string IDPrefix
        {
            get
            {
                if (widgetInstance != null)
                {
                    return widgetInstance.ID.ToString().Substring(0, 5);
                }
                return "";
            }
        }

        public string GenerateFieldID(string fieldName)
        {
            return fieldName + IDPrefix;
        }

        /// <summary>
        /// Gets a value identity wheather the widget is in design mode.
        /// </summary>
        public bool IsDesignMode
        {
            get
            {
                bool isDesignMode = false;
                string key = "design";
                if (!string.IsNullOrEmpty(Request.QueryString[key]))
                    bool.TryParse(Request.QueryString[key], out isDesignMode);
                return isDesignMode;
            }
        }

        //private Dictionary<string, PropertyDescriptor> data = null;
        /// <summary>
        /// Gets the usersetting object instance
        /// </summary>
        /// <remarks>
        /// The UserSettings Property my store two kind of settings object
        /// 1.When the "SettingModelType" proerty of the WidgetAttribute is specified ,the 
        /// UserSettings will store the strongly type UserSettings object.
        /// 2.In common the settings object will store the NameValue pairs 
        /// </remarks>
        public Dictionary<string, object> UserData
        {
            get { return userdata; }
        }

        /// <summary>
        /// Gets the widget data instance.
        /// </summary>
        public WidgetInstance WidgetInstance
        {
            get { return widgetInstance; }
        }

        /// <summary>
        /// Identitied wheather the Widget is view in privew dialog.
        /// </summary>
        public bool IsPreviewMode
        {
            get { return isPreviewMode; }
        }

        public MvcHtmlString GenVerbLink(string text, WidgetVerbs verb)
        {
            return GenVerbLink(text, verb,null);
        }

        public MvcHtmlString GenVerbLink(string text,WidgetVerbs verb,object htmlAttributes)
        {
            var tag = new TagBuilder("a");
            tag.MergeAttribute("href", "javascript:void(0);");
            if (htmlAttributes != null)
                tag.MergeAttributes<string,object>(ObjectHelper.ConvertObjectToDictionary(htmlAttributes));
            string verbName = "refreshVerb";
            switch (verb)
            { 
                case WidgetVerbs.Settings:
                    verbName = "settingVerb";
                    break;
                case WidgetVerbs.Refresh:
                    verbName = "refreshVerb";
                    break;
                case WidgetVerbs.Toggle:
                    verbName = "toggleVerb";
                    break;
                case WidgetVerbs.Delete:
                    verbName = "deleteVerb";
                    break;
                case WidgetVerbs.Export:
                    verbName = "exportVerb";
                    break;
            }
            if (this.WidgetInstance == null)
                return MvcHtmlString.Create(text);
            else
            {
                tag.MergeAttribute("onclick", "$('#" + this.WidgetInstance.ID.ToString() + "').portlet('doVerb','" + verbName + "');");
                tag.InnerHtml = text;
                return MvcHtmlString.Create(tag.ToString());
            }
        }
    }
}
