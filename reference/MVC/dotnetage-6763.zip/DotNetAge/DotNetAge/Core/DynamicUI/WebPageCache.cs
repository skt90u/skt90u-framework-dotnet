﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Mvc;
using DNA.Mvc.Models;
using System.Web.Caching;

namespace DNA.Mvc.DynamicUI
{
    internal static class WebPageCache
    {
        private static Cache cache 
        { 
            get 
            {
                return HttpContext.Current.Cache;
            } 
        }

        internal static bool IsExists(string key)
        {
            return Get(key) != null;
        }

        internal static WebPage Get(string key)
        {
            var _page=cache.Get(key);
            if (_page != null)
                return (WebPage)_page;
            return null;
        }

        internal static void Add(string key, WebPage page)
        {
            if (!IsExists(key))
                cache.Add(key, page, null, DateTime.Now.AddMinutes(5), TimeSpan.Zero, CacheItemPriority.Default, null);
        }

        internal static void Remove(string key)
        {
            if (IsExists(key))
                cache.Remove(key);
        }
    }
}
