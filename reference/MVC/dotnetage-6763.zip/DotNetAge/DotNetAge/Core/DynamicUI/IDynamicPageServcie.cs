﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DNA.Mvc.Models;

namespace DNA.Mvc.DynamicUI
{
    /// <summary>
    ///  Defines the methods used to control the WebPage data
    /// </summary>
    public interface IDynamicPageServcie
    {
        /// <summary>
        /// Createt the page instance and save the page data to the database.
        /// </summary>
        /// <param name="roles">Specified the accessable roles for the new page</param>
        /// <param name="page">The page instance wait for create.</param>
        WebPage Create(WebPage page,string[] roles);

        /// <summary>
        /// Save WebPage's changes to database.
        /// </summary>
        /// <param name="roles">Specified the accessable roles for the exists page</param>
        /// <param name="page">The page instance</param>
        void Update(WebPage page,string[] roles);

        /// <summary>
        /// Delete the page by specified id.
        /// </summary>
        /// <param name="id">Specified the page id for delete</param>
        void Delete(int id);

        /// <summary>
        /// Get the WebPage instance for sepecifed path.
        /// </summary>
        /// <param name="path">The path of the page.</param>
        /// <returns>The WebPage instance.</returns>
        WebPage GetPage(string path);

        /// <summary>
        ///  Get the WebPageRole collection by specified the page id.
        /// </summary>
        /// <param name="id">The page id.</param>
        /// <returns>A collection of the WebPageRole instances.</returns>
        IEnumerable<WebPageRole> GetPageRoles(int id);

        /// <summary>
        /// Get the WebPageRole instance by specified the page id and role name.
        /// </summary>
        /// <param name="pageID">Specified the id of the page.</param>
        /// <param name="roleName">Specfied the role name to get.</param>
        /// <returns>The WebPageRole instance.</returns>
        WebPageRole GetPageRole(int pageID, string roleName);

        /// <summary>
        /// Get the child pages for specified page id.
        /// </summary>
        /// <param name="webID">The parent web id.</param>
        /// <param name="parentID">Specified th page id.</param>
        /// <returns>The WebPages of the specified id.</returns>
        IEnumerable<WebPage> GetChildPages(int webID,int parentID);

        /// <summary>
        /// Get all static page for specified webid
        /// </summary>
        /// <param name="webID">Specified the webid</param>
        /// <returns>A collection contains the static type pages.</returns>
        IEnumerable<WebPage> GetStaticPages(int webID);

        /// <summary>
        /// Get the descendant pages by specfied web id and parent page id.
        /// </summary>
        /// <param name="webID">The web id.</param>
        /// <param name="parentID">The parent page id.</param>
        /// <returns>A collection contains the descendant page instances.</returns>
        IEnumerable<WebPage> GetDescendantPages(int webID,int parentID);

        /// <summary>
        /// Get the WebPage instance for specified page id.
        /// </summary>
        /// <param name="id">Specified th page instance id.</param>
        /// <returns>The WebPage instance.</returns>
        WebPage GetPage(int id);

        /// <summary>
        /// Gets the page is exists by specified path
        /// </summary>
        /// <param name="path">Specified the page path</param>
        /// <returns>Return bool value</returns>
        bool IsExists(string path);

        /// <summary>
        /// Move the specified page to the new position
        /// </summary>
        /// <param name="parentID">Specified the page parent id which page belongs to.</param>
        /// <param name="id">Specified the exisits page id.</param>
        /// <param name="pos">Specified the new position</param>
        void Move(int parentID, int id, int pos);

        /// <summary>
        /// Gets the web instance by specified web id.
        /// </summary>
        /// <param name="id">The specified web id.</param>
        /// <returns>A Web object.</returns>
        Web GetWebByID(int id);

        /// <summary>
        /// Gets the web instance by specified web name.
        /// </summary>
        /// <param name="name">Specfied the web name.</param>
        /// <returns>A Web object.</returns>
        Web GetWebByName(string name);
    }
}
