﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Mvc;
using DNA.Mvc.Models;
using System.Web.Routing;
using System.IO;
using System.Web.Script.Serialization;

namespace DNA.Mvc.DynamicUI
{
    /// <summary>
    ///  Extends Action that allows the View contains Widget, role base accessibility control,SEO meta editing feature.
    /// </summary>
    /// <remarks>
    /// When the administrator request that Url to Action that defines SiteMapActionAttribute and the Page is not exists in database,
    /// DotNetAge will auto create the web page instance for the request url.
    /// </remarks>
    public class SiteMapActionAttribute : ActionFilterAttribute
    {
        private bool showInMenu = true;
        private bool isShared = true;
        private string[] ignoreRouteValues;

        /// <summary>
        /// 
        /// </summary>
        public string[] IgnoreRouteDataKeys
        {
            get { return ignoreRouteValues; }
            set { ignoreRouteValues = value; }
        }

        /// <summary>
        /// Gets/Sets only create page for this action once time.
        /// </summary>
        /// <remarks>
        /// If this property sets the ExcludeValues will be enable
        /// </remarks>
        public bool IsShared
        {
            get { return isShared; }
            set { isShared = value; }
        }

        /// <summary>
        /// Gets/Sets the whether the SiteMapAction can shows in the main menu.
        /// </summary>
        public bool ShowInMenu
        {
            get { return showInMenu; }
            set { showInMenu = value; }
        }

        /// <summary>
        /// Gets/Sets the ParentAction name of the SiteMapAction
        /// </summary>
        public string ParentAction { get; set; }

        /// <summary>
        /// Gets/Sets the title of the SiteMapAction
        /// </summary>
        /// <remarks>
        /// This title will shows in menu and html header's title tag.
        /// </remarks>
        public string Title { get; set; }

        /// <summary>
        /// Gets/Sets the description of the SiteMapAction
        /// </summary>
        public string Description { get; set; }

        /// <summary>
        /// Gets/Sets the personal title when the page is a personal page.
        /// </summary>
        public string PersonalTitle { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string PersonalDescription { get; set; }

        /// <summary>
        /// Gets/Sets the template file visual path that using when the action page is create.
        /// </summary>
        public string Template { get; set; }

        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            if (WebHost.IsInstalled)
            {
                if (filterContext.HttpContext.Request.IsAuthenticated)
                {
                    var context = WebContext.Current;
                    if (context.Web != null)
                    {
                        if (!context.IsPageExists)
                        {
                            if ((IsShared) && (IgnoreRouteDataKeys != null) && (IgnoreRouteDataKeys.Length > 0))
                            {
                                if (context.IsDefaultPageExists(IgnoreRouteDataKeys))
                                    return;
                            }
                            bool isPersonalPage = false;

                            if (filterContext.RouteData.Values.ContainsKey("website"))
                                isPersonalPage = (!string.IsNullOrEmpty((filterContext.RouteData.Values["website"] as string)) &&
                                    (!(filterContext.RouteData.Values["website"] as string).Equals("home", StringComparison.OrdinalIgnoreCase)));


                            var page = context.Web.CreatePage(
                             new WebPage()
                             {
                                 Path = context.GetRouteDefaultUrl(IgnoreRouteDataKeys),
                                 IsStatic = true,
                                 IsShared = IsShared,
                                 ViewData = ((IgnoreRouteDataKeys != null) && (IgnoreRouteDataKeys.Length > 0)) ? String.Join(",", IgnoreRouteDataKeys) : "",
                                 Title = isPersonalPage ? (string.IsNullOrEmpty(PersonalTitle) ? ((string.IsNullOrEmpty(Title) ? filterContext.ActionDescriptor.ActionName : Title)) : PersonalTitle) :
                                 (string.IsNullOrEmpty(Title) ? filterContext.ActionDescriptor.ActionName : Title),
                                 Description = isPersonalPage ? PersonalDescription : Description,
                                 ShowInMenu = ShowInMenu,
                                 AllowAnonymous = filterContext.ActionDescriptor.GetFilters().AuthorizationFilters.Count == 0
                             }, null);

                            if (!string.IsNullOrEmpty(this.Template))
                            {
                                var templateFile = HttpContext.Current.Server.MapPath(this.Template);
                                if (File.Exists(templateFile))
                                {
                                    try
                                    {
                                        string src = File.ReadAllText(templateFile);
                                        //var data = (new JavaScriptSerializer()).Deserialize<WebPageDataContract>(src);
                                        //page.Import(data);
                                        page.Import(src);
                                    }
                                    catch { }
                                }
                            }

                        }
                    }
                }
            }
            base.OnActionExecuting(filterContext);
        }

    }
}
