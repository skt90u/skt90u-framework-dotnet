﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DNA.Mvc
{
    public enum LogoLayouts
    {
        LogoOnly = 1,
        LogoAndTitle = 2,
        LogoWithTitleRightBottom = 3,
        LogoWithTitleRightTop = 4,
        LogoWithTitleBlow = 5,
        TitleOnly = 6
    }
}