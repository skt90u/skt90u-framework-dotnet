﻿//  Copyright (c) 2011 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using DNA.Mvc.Models;
namespace DNA.Mvc
{
    public static class SEOHelper
    {
        private static HttpContext Context
        {
            get
            { 
                return HttpContext.Current;
            }
        }
        private const string SEO_TITLE = "SEO_PAGE_TITLE";
        private const string SEO_DESC = "SEO_PAGE_DESC";
        private const string SEO_KEYWORDS = "SEO_PAGE_KEYWORDS";
        
        public static string GetTitle()
        {
            if (Context.Items.Contains(SEO_TITLE) && Context.Items[SEO_TITLE]!=null)
                return Context.Items[SEO_TITLE].ToString();
            var page = WebContext.Current.Page;
            string pageTitle="";
            if ((page != null) && (!string.IsNullOrEmpty(page.Title)))
                pageTitle=page.Title;
            string websiteTitle = WebSite.CurrentWeb().Title;
            return pageTitle + " - " + websiteTitle;
        }
        
        public static string GetDescription()
        {
            if (Context.Items.Contains(SEO_DESC) && Context.Items[SEO_DESC] != null)
                return Context.Items[SEO_DESC].ToString();
            var page = WebContext.Current.Page;

            if ((page != null) && (!string.IsNullOrEmpty(page.Description)))
                return page.Description;

            return WebSite.CurrentWeb().Description;
        }

        public static string GetKeywords()
        {
            if (Context.Items.Contains(SEO_KEYWORDS) && Context.Items[SEO_KEYWORDS] != null)
                return Context.Items[SEO_KEYWORDS].ToString();
            //var page = WebContext.Current.Page;

            //if ((page != null) && (!string.IsNullOrEmpty(page.key)))
               // return page.Description;

            return WebSite.CurrentWeb().SearchKeywords;
        }

        public static void SetTitle(string title)
        {
            Context.Items[SEO_TITLE] = title;
        }

        public static void SetKeywords(string keywords)
        {
            Context.Items[SEO_KEYWORDS] = keywords;
        }

        public static void SetDescription(string description)
        {
            Context.Items[SEO_DESC] = description;
        }
    }
}