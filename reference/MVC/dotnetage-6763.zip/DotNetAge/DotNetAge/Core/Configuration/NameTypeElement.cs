﻿//  Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;

namespace DNA.Mvc.Configuration
{
    /// <summary>
    /// Defines the name ,type configuration element.
    /// </summary>
    public class NameTypeElement : ConfigurationElement
    {
        /// <summary>
        /// Gets/Sets the name property value.
        /// </summary>
        [ConfigurationProperty("name", IsRequired = false)]
        public string Name
        {
            get
            {
                return this["name"].ToString();
            }
            set
            {
                this["name"] = value;
            }
        }

        /// <summary>
        /// Gets/Sets the type property value.
        /// </summary>
        [ConfigurationProperty("type", IsRequired = false)]
        public string Type
        {
            get
            {
                return this["type"].ToString();
            }
            set
            {
                this["type"] = value;
            }
        }
    }
}
