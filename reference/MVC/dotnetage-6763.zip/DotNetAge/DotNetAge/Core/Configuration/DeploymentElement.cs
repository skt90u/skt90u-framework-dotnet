﻿//  Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;

namespace DNA.Mvc.Configuration
{
    /// <summary>
    /// Defines configuration settings that are used to support the dna web delpoyment infrastructure.
    /// </summary>
    public class DeploymentElement : ConfigurationElement
    {
        /// <summary>
        /// Gets/Sets DotNetAge is already installed.
        /// </summary>
        [ConfigurationProperty("installed")]
        public bool IsInstalled 
        {
            get { return (bool)this["installed"]; }
            set { this["installed"] = value; }
        }
        
        [Obsolete]
        [ConfigurationProperty("database", IsRequired = false)]
        public string DatabaseName 
        {
            get { return this["database"] as string; }
            set { this["database"] = value; }
        }

        /// <summary>
        /// Gets/Sets the host password to login and use host panel.
        /// </summary>
        [ConfigurationProperty("password", IsRequired = true)]
        public string HostPassword 
        {
            get { return this["password"] as string; }
            set { this["password"] = value; }
        }

        /// <summary>
        /// Gets/Sets wheather the DotNetAge support the personal webs.
        /// </summary>
        [ConfigurationProperty("enablePersonalWeb", IsRequired = true)]
        public bool EnablePersonalWeb
        {
            get { return (bool)this["enablePersonalWeb"]; }
            set { this["enablePersonalWeb"] = value; }
        }


    }
}
