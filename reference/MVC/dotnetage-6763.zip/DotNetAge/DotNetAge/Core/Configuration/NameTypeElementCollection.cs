﻿//  Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;

namespace DNA.Mvc.Configuration
{
    public class NameTypeElementCollection : ConfigurationElementCollection
    {
        public void Add(NameTypeElement nameType)
        {
            BaseAdd(nameType);
        }

        public NameTypeElement this[int index]
        {
            get
            {
                return (NameTypeElement)BaseGet(index);
            }
        }

        public new NameTypeElement this[string key]
        {
            get
            {
                return (NameTypeElement)BaseGet(key);
            }
        }

        public void Remove(string key)
        {
            BaseRemove(key);
        }

        public void Remove(int index)
        {
            BaseRemoveAt(index);
        }

        public void Clear()
        {
            BaseClear();
        }

        protected override ConfigurationElement CreateNewElement()
        {
            return new NameTypeElement();
        }

        protected override object GetElementKey(ConfigurationElement element)
        {
            return ((NameTypeElement)element).Name;
        }
    }
}
