﻿//  Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;

namespace DNA.Mvc.Configuration
{
    /// <summary>
    /// Configures the dna section
    /// </summary>
    public class DnaConfigurationSection : ConfigurationSection
    {
        /// <summary>
        ///  Get the collection of service objects.
        /// </summary>
        [ConfigurationProperty("services")]
        [ConfigurationCollection(typeof(NameTypeElement),
            CollectionType = ConfigurationElementCollectionType.AddRemoveClearMap,
            AddItemName = "add",
            ClearItemsName = "clear",
            RemoveItemName = "remove")
        ]
        public NameTypeElementCollection Services
        {
            get
            {
                return (NameTypeElementCollection)this["services"];
            }
        }

        /// <summary>
        /// Get the deploy config group.
        /// </summary>
        [ConfigurationProperty("deploy")]
        public DeploymentElement Deployment
        {
            get { return (DeploymentElement)this["deploy"]; }
        }
    }
}