///  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
///  Dual licensed under the MIT and GPL licenses:
///  http://www.opensource.org/licenses/mit-license.php
///  http://www.gnu.org/licenses/gpl.html
using System;
using System.IO;
using ICSharpCode.SharpZipLib.Zip;
using ICSharpCode.SharpZipLib.Checksums;
using System.Collections.Specialized;

namespace DNA.IO.Compress
{
    /// <summary>
    /// Ϊzip�ļ��ṩѹ������ѹ���ķ���
    /// </summary>
    public class ZipCompress:IDisposable
    {
        private ZipOutputStream internalStream;
        private MemoryStream memoryStream = new MemoryStream();
        private Crc32 crc = new Crc32();
        private string _rootPath = "";

        public string Root
        {
            get { return _rootPath; }
            set { _rootPath = value; }
        }

        public ZipCompress() 
        {
            internalStream = new ZipOutputStream(memoryStream);
            internalStream.SetLevel(6);
        }
        
        public ZipCompress(string password):this()
        {
            if (!string.IsNullOrEmpty(password))
                internalStream.Password = password;
        }

        public ZipCompress(string removePath, string password):this(password)
        {
            _rootPath = removePath; 
        }

        /// <summary>
        /// ����������Zip�ļ�
        /// </summary>
        /// <param name="stream">Դ������</param>
        /// <param name="targetFile">������ѹ�����ڵ�Ŀ¼�ļ�·��</param>
        public void AddFile(Stream stream, string targetFile)
        {
            stream.Position = 0;
            byte[] buffer = new byte[stream.Length];
            stream.Read(buffer, 0, buffer.Length);
            string entryName = targetFile;

            //���ø�·��
            if (!string.IsNullOrEmpty(_rootPath))
            {
                int startIndex = entryName.IndexOf(_rootPath);

                if (startIndex != -1)
                    entryName = entryName.Remove(startIndex, _rootPath.Length);
            }

            ZipEntry entry = new ZipEntry(entryName);
            entry.DateTime = DateTime.Now;
            entry.Size = stream.Length;
            crc.Reset();
            crc.Update(buffer);
            entry.Crc = crc.Value;
            internalStream.PutNextEntry(entry);
            internalStream.Write(buffer, 0, buffer.Length);
        }

        /// <summary>
        /// ��ѹ���������ļ��������������ļ��ڰ��ڵ��ļ�·��
        /// </summary>
        /// <param name="sourceFile">Դ�ļ�������·��</param>
        /// <param name="targetFile">������������·��</param>
        public void AddFile(string sourceFile, string targetFile)
        {
            System.IO.FileStream fs = System.IO.File.OpenRead(sourceFile);
            if (!string.IsNullOrEmpty(targetFile))
                AddFile(fs, targetFile);
            else
                AddFile(fs, sourceFile);
            fs.Close();
        }

        public void AddFile(string sourceFile)
        {
            AddFile(sourceFile, string.Empty);
        }

        public Stream Compress()
        {
            if (!internalStream.IsFinished)
                internalStream.Finish();
            long size = internalStream.Length;
            memoryStream.Position = 0;
            return memoryStream;
        }

        /// <summary>
        /// �ر�ZipFile�ļ������ͷ����е���Դ
        /// </summary>
        public void Dispose()
        {
            internalStream.Close();
            memoryStream.Close();
        }
    }
}
