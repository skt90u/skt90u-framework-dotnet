﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DNA.Mvc
{
    /// <summary>
    /// ControlPanelAttribute base class,defines the properties of the control panel
    /// </summary>
    [AttributeUsage(AttributeTargets.Method, AllowMultiple = false, Inherited = true)]
    public abstract class ControlPanelAttribute : Attribute
    {
        private string _text;
        private string _resKey;
        private string _resBaseName;
        private int order = 0;

        /// <summary>
        /// Gets/sets the control panel order
        /// </summary>
        public int Order
        {
            get { return order; }
            set { order = value; }
        }

        /// <summary>
        /// Gets/Sets the control panel title resource key
        /// </summary>
        public string ResKey
        {
            get { return _resKey; }
            set { _resKey = value; }
        }

        /// <summary>
        /// Gets/Sets the control panel resource file base name.
        /// </summary>
        public string ResBaseName
        {
            get { return _resBaseName; }
            set { _resBaseName = value; }
        }

        /// <summary>
        /// Gets/Sets the control panel display title text.
        /// </summary>
        public string Text
        {
            get { return _text; }
            set { _text = value; }
        }
    }

    /// <summary>
    /// Specified the action as personal control panel action.
    /// </summary>
    [AttributeUsage(AttributeTargets.Method, AllowMultiple = false, Inherited = true)]
    public class MyControlPanelAttribute : ControlPanelAttribute
    {
        private bool showInPersonalSiteOnly = false;

        public bool ShowInPersonalSiteOnly
        {
            get { return showInPersonalSiteOnly; }
            set { showInPersonalSiteOnly = value; }
        }

        public MyControlPanelAttribute() { }
        
        public MyControlPanelAttribute(string text)
        {
            Text = text;
        }

    }

    /// <summary>
    /// Specified the action as a control panel action.
    /// </summary>
    [AttributeUsage(AttributeTargets.Method, AllowMultiple = false, Inherited = true)]
    public class SiteControlPanelAttribute : ControlPanelAttribute
    {
        public SiteControlPanelAttribute() { }

        public SiteControlPanelAttribute(string text)
        {
            Text = text;
        }
    }
}
