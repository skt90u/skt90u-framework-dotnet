﻿//  Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Xml;
using System.Xml.Serialization;

namespace DNA.Mvc.OpenAPI.BlogML
{
    [Serializable]
    public struct BlogMLAuthor
    {
        [XmlAttribute("id")]
        public string ID;

        [XmlElement("title")]
        public string Title;

        [XmlAttribute("date-created", DataType = "dateTime")]
        public DateTime DateCreated;

        [XmlAttribute("date-modified", DataType = "dateTime")]
        public DateTime DateModified;

        [XmlAttribute("approved")]
        public bool Approved;

        [XmlAttribute("email")]
        public string Email;
    }

    [Serializable]
    public struct BlogMLAuthorRef
    {
        [XmlAttribute("ref")]
        public string Ref;
    }
}