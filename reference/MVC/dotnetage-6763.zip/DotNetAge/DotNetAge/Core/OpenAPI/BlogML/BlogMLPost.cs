﻿//  Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Xml;
using System.Xml.Serialization;

namespace DNA.Mvc.OpenAPI.BlogML
{
    [Serializable]
    public struct BlogMLPost
    {
        [XmlAttribute("id")]
        public string ID;

        [XmlElement("title")]
        public string Title;

        [XmlAttribute("date-created", DataType = "dateTime")]
        public DateTime DateCreated;

        [XmlAttribute("date-modified", DataType = "dateTime")]
        public DateTime DateModified;

        [XmlAttribute("approved")]
        public bool Approved;

        [XmlAttribute("post-url")]
        public string PostUrl;

        [XmlAttribute("hasexcerpt")]
        public bool HasExcerpt;

        [XmlAttribute("type")]
        public BlogPostTypes PostType;

        [XmlAttribute("views")]
        public UInt32 Views;

        [XmlElement("post-name")]
        public string PostName;

        [XmlElement("content")]
        public BlogMLContent Content;

        [XmlElement("excerpt")]
        public BlogMLContent Excerpt;

        [XmlArray("authors")]
        [XmlArrayItem("author", typeof(BlogMLAuthorRef))]
        public List<BlogMLAuthorRef> Authors;

        [XmlArray("categories")]
        [XmlArrayItem("category", typeof(BlogMLCategoryRef))]
        public List<BlogMLCategoryRef> Categories;

        [XmlArray("comments")]
        [XmlArrayItem("comment", typeof(BlogMLComment))]
        public List<BlogMLComment> Comments;


        [XmlArray("trackbacks")]
        [XmlArrayItem("trackback", typeof(BlogMLTrackback))]
        public List<BlogMLTrackback> Trackbacks;

        [XmlArray("attachments")]
        [XmlArrayItem("attachment", typeof(BlogMLAttachment))]
        public List<BlogMLAttachment> Attachments;
    }

    public enum BlogPostTypes : short
    {
        [System.Xml.Serialization.XmlEnumAttribute("normal")]
        Normal = 1,
        [System.Xml.Serialization.XmlEnumAttribute("article")]
        Article = 2,
    }
}