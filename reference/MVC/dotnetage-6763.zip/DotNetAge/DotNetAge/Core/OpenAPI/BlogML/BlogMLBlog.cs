﻿//  Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Xml;
using System.Xml.Serialization;

namespace DNA.Mvc.OpenAPI.BlogML
{
    [Serializable]
    [XmlRoot("blog", Namespace = "http://www.blogml.com/2006/09/BlogML")]
    public struct BlogMLBlog
    {
        [XmlAttribute("root-url")]
        public string RootUrl;

        [XmlElement("title")]
        public string Title;

        [XmlElement("sub-title")]
        public string SubTitle;

        [XmlAttribute("date-created", DataType = "dateTime")]
        public DateTime DateCreated;

        [XmlArray("extended-properties")]
        [XmlArrayItem("property", typeof(BlogMLMeta))]
        public List<BlogMLMeta> ExtendedProperties;

        [XmlArray("authors")]
        [XmlArrayItem("author", typeof(BlogMLAuthor))]
        public List<BlogMLAuthor> Authors;


        [XmlArray("posts")]
        [XmlArrayItem("post", typeof(BlogMLPost))]
        public List<BlogMLPost> Posts;

        [XmlArray("categories")]
        [XmlArrayItem("category", typeof(BlogMLCategory))]
        public List<BlogMLCategory> Categories;
    }

}