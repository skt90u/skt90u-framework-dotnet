﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Linq;
using System.Xml.Serialization;

namespace DNA.Mvc.OpenAPI.Rss
{
    /// <summary>
    /// Defines the RSS2.0 Channel object.
    /// </summary>
    [XmlRoot("channel"),Serializable]
    public struct RssChannel
    {
        /// <summary>
        /// The name of the channel. It's how people refer to your service. If you have an HTML website that contains the same information as your RSS file, the title of your channel should be the same as the title of your website.	
        /// </summary>
        /// <remarks>Required channel elements</remarks>
        /// <example>www.dotnetage.com News Headlines</example>
        [XmlElement("title")]
        public string Title;

        /// <summary>
        /// Phrase or sentence describing the channel.	
        /// </summary>
        /// <remarks>Required channel elements</remarks>
        /// <example>The latest news from dotnetage.com, a opensource CMS web site.</example>
        [XmlElement("description")]
        public string Description;

        /// <summary>
        /// The URL to the HTML website corresponding to the channel.	
        /// </summary>
        /// <remarks>Required channel elements</remarks>
        /// <example>http://www.dotnetage.com</example>
        [XmlElement("link")]
        public string Link;

        /// <summary>
        /// The language the channel is written in. 
        /// This allows aggregators to group all Italian language sites, for example, on a single page. 
        /// A list of allowable values for this element, as provided by Netscape, is here.
        /// You may also use values defined by the W3C.	
        /// </summary>
        [XmlElement("language")]
        public string Language;

        /// <summary>
        /// Copyright notice for content in the channel.	
        /// </summary>
        [XmlElement("copyright")]
        public string Copyright;

        /// <summary>
        /// Email address for person responsible for editorial content.	
        /// </summary>
        /// <example>geo@gmail.com (George Matesky)</example>
        [XmlElement("managingEditor")]
        public string ManagingEditor;

        /// <summary>
        /// Email address for person responsible for technical issues relating to channel.	
        /// </summary>
        /// <example>csharp2002@gmail.com (Ray liang)</example>
        [XmlElement("webMaster")]
        public string WebMaster;

        /// <summary>
        /// The publication date for the content in the channel. 
        /// For example, the New York Times publishes on a daily basis, the publication date 
        /// flips once every 24 hours. That's when the pubDate of the channel changes. 
        /// All date-times in RSS conform to the Date and Time Specification of RFC 822, 
        /// with the exception that the year may be expressed with two characters or four
        /// characters (four preferred).	
        /// </summary>
        [XmlElement("pubDate")]
        public string PubDate;

        /// <summary>
        /// The last time the content of the channel changed.	
        /// </summary>
        [XmlElement("lastBuildDate")]
        public string LastBuildDate;

        /// <summary>
        /// Specify one or more categories that the channel belongs to. 
        /// Follows the same rules as the &lt;item&gt;-level category element. More info.	
        /// </summary>
        [XmlElement("category")]
        public List<string> Category;

        /// <summary>
        /// A URL that points to the documentation for the format used in the RSS file. 
        /// It's probably a pointer to this page. 
        /// It's for people who might stumble across an RSS file on a Web server 25 years from now and wonder what it is.	
        /// </summary>
        [XmlElement("docs")]
        public string DocUrl;

        /// <summary>
        /// Allows processes to register with a cloud to be notified of updates to the channel,
        /// implementing a lightweight publish-subscribe protocol for RSS feeds. 
        /// </summary>
        /// <example>
        /// <![CDATA[
        /// <cloud domain="rpc.sys.com" port="80" path="/RPC2"
        ///    registerProcedure="pingMe" 
        ///    protocol="soap"/>
        /// ]]>
        /// </example>
        [XmlElement("cloud", typeof(RssCloud))]
        public RssCloud Cloud;

        /// <summary>
        /// A string indicating the program used to generate the channel.	
        /// </summary>
        [XmlElement("generator")]
        public string Generator;

        /// <summary>
        /// ttl stands for time to live. It's a number of minutes that indicates how long a channel can be cached before refreshing from the source. This makes it possible for RSS sources to be managed by a file-sharing network such as Gnutella. 
        /// </summary>
        [XmlElement("ttl", Type = typeof(int))]
        public int TTL;

        /// <summary>
        /// The PICS rating for the channel.	
        /// </summary>
        [XmlElement("rating")]
        public string Rating;

        /// <summary>
        /// Specifies a text input box that can be displayed with the channel.
        /// </summary>
        [XmlElement("textInput", Type = typeof(RssTextInput))]
        public RssTextInput TextInput;

        /// <summary>
        /// A hint for aggregators telling them which hours they can skip
        /// </summary>
        [XmlElement("skipHours")]
        public string SkipHours;

        /// <summary>
        /// A hint for aggregators telling them which days they can skip
        /// </summary>
        [XmlElement("skipDays")]
        public string SkipDays;

        /// <summary>
        /// Specifies a GIF, JPEG or PNG image that can be displayed with the channel. 
        /// </summary>
        [XmlElement("image", Type = typeof(RssImage))]
        public RssImage Image;

        [XmlElement("item", Type = typeof(RssItem))]
        public List<RssItem> Items;
    }
}
