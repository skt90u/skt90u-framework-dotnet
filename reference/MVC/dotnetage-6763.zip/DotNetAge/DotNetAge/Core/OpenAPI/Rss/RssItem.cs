﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Linq;
using System.Xml.Serialization;

namespace DNA.Mvc.OpenAPI.Rss
{
    /// <summary>
    /// A channel may contain any number of items. 
    /// An item may represent a "story" -- much like a story in a newspaper or magazine; 
    /// if so its description is a synopsis of the story, and the link points to the full story.
    /// An item may also be complete in itself, if so, 
    /// the description contains the text (entity-encoded HTML is allowed; ), 
    /// and the link and title may be omitted. All elements of an item are optional,
    /// however at least one of title or description must be present.
    /// </summary>
    [XmlRoot("item"), Serializable]
    public struct RssItem
    {
        /// <summary>
        /// The title of the item.
        /// </summary>
        [XmlElement("title")]
        public string Title;

        /// <summary>
        /// The URL of the item.
        /// </summary>
        [XmlElement("link")]
        public string Link;

        /// <summary>
        /// The item synopsis
        /// </summary>
        [XmlElement("description")]
        public string Description;

        /// <summary>
        /// Indicates when the item was published
        /// </summary>
        [XmlElement("pubDate")]
        public string PubDate;

        /// <summary>
        /// It has one optional attribute, domain, a string that identifies a categorization taxonomy. 
        /// The value of the element is a forward-slash-separated string that identifies a hierarchic 
        /// location in the indicated taxonomy. Processors may establish conventions for the interpretation of categories.
        /// </summary>
        [XmlElement("category", typeof(RssCategory))]
        public List<RssCategory> Categories;

        /// <summary>
        /// URL of a page for comments relating to the item
        /// </summary>
        [XmlElement("comments")]
        public string Comments;

        /// <summary>
        /// Describes a media object that is attached to the item
        /// </summary>
        [XmlElement("enclosure", Type = typeof(RssEnclosure))]
        public RssEnclosure Enclosure;

        /// <summary>
        /// A string that uniquely identifies the item
        /// </summary>
        [XmlElement("guid")]
        public RssGuid Guid;
        /// <summary>
        /// Email address of the author of the item
        /// </summary>
        [XmlElement("author")]
        public string Author;
    }
}
