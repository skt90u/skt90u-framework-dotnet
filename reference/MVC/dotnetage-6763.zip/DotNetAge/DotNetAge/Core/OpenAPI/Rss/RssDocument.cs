﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Linq;
using System.Xml.Serialization;

namespace DNA.Mvc.OpenAPI.Rss
{
    [XmlRoot("rss"), Serializable]
    public struct RssDocument
    {
        [XmlAttribute("version")]
        public string Version { get { return "2.0"; } set { } }

        [XmlElement("channel")]
        public RssChannel Channel;
    }
}