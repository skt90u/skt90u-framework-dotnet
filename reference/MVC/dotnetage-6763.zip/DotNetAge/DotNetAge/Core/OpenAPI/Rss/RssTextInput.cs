﻿//  Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Xml.Serialization;

namespace DNA.Mvc.OpenAPI.Rss
{
    /// <summary>
    /// A channel may optionally contain a textInput sub-element, which contains four required sub-elements.
    /// </summary>
    [XmlRoot("textInput"),Serializable]
    public struct RssTextInput
    {
        /// <summary>
        /// The label of the Submit button in the text input area. 
        /// </summary>
        [XmlElement("title")]
        public string Title;

        /// <summary>
        /// Explains the text input area. 
        /// </summary>
        [XmlElement("description")]
        public string Description;

        /// <summary>
        /// The name of the text object in the text input area. 
        /// </summary>
        [XmlElement("name")]
        public string Name;

        /// <summary>
        /// The URL of the CGI script that processes text input requests. 
        /// </summary>
        [XmlElement("link")]
        public string Link;

    }
}