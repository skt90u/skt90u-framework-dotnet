﻿//  Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Xml.Serialization;

namespace DNA.Mvc.OpenAPI.Rss
{
    /// <summary>
    /// is an optional sub-element of RssChannel, which contains three required and
    /// three optional sub-elements.
    /// </summary>
    [XmlRoot("image"),Serializable]
    public struct RssImage
    {
        /// <summary>
        /// Describes the image, it's used in the ALT attribute of the HTML &lt;img&gt; tag when the channel is rendered in HTML. 
        /// </summary>
        [XmlElement("title")]
        public string Title;

        /// <summary>
        ///  is the URL of the site, when the channel is rendered, the image is a link to the site. 
        ///  (Note, in practice the image &lt;title&gt;  and &lt;link&gt;  
        ///  should have the same value as the channel's &lt;title&gt;  and &lt;link&gt; . 
        /// </summary>
        [XmlElement("link")]
        public string NavigateUrl;

        /// <summary>
        /// Numbers, indicating the width of the image in pixels. 
        /// </summary>
        [XmlElement("width")]
        public int Width;

        [XmlElement("description")]
        public string Description;

        /// <summary>
        /// Numbers, indicating the height of the image in pixels. 
        /// </summary>
        [XmlElement("height")]
        public int Height;

        /// <summary>
        /// Is the URL of a GIF, JPEG or PNG image that represents the channel.
        /// </summary>
        [XmlElement("url")]
        public string ImageUrl;
    }
}