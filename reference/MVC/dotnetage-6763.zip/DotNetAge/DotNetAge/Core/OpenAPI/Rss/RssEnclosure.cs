﻿//  Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Xml.Serialization;

namespace DNA.Mvc.OpenAPI.Rss
{
    /// <summary>
    /// It has three required attributes. url says where the enclosure is located, 
    /// length says how big it is in bytes, and type says what its type is, a standard 
    /// MIME type.
    /// </summary>
    [XmlRoot("enclosure"), Serializable]
    public class RssEnclosure
    {
        [XmlAttribute("length")]
        public int Length;

        [XmlAttribute("url")]
        public string Url;

        [XmlAttribute("type")]
        public string ContentType;
    }
}