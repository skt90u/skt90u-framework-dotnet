﻿//  Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CookComputing.XmlRpc;

namespace DNA.Mvc.OpenAPI.Blogging
{
    /// <summary>
    /// Defines the metaWeblog APIs
    /// </summary>
    public interface IMetaWeblog
    {
        /// <summary>
        /// The metaWeblog.newPost method posts a new entry to a blog
        /// </summary>
        /// <param name="blogid">This should be the string MyBlog, which indicates that the post is being created in the user’s blog.</param>
        /// <param name="username">The name of the user’s space</param>
        /// <param name="password">The user’s secret word.</param>
        /// <param name="content">A struct representing the content to update. The title, description, dateCreated, and categories fields are supported. All other elements are ignored. If multiple categories are specified, each category is added to the category list until the maximum is reached, and all remaining categories are ignored. An error is returned if no title is specified. If no description or categories are provided, the post has no body or category, respectively.</param>
        /// <param name="publish">If false, this is a draft post</param>
        /// <returns>The postid of the newly-created post.</returns>
        [XmlRpcMethod("metaWeblog.newPost")]
        string NewPost(string blogid,string username,string password,Post content,bool publish);

        /// <summary>
        /// The metaWeblog.editPost method edits an existing entry on a blog.
        /// </summary>
        /// <param name="postid">The ID of the post to update</param>
        /// <param name="username">The name of the user’s space.</param>
        /// <param name="password">The user’s secret word.</param>
        /// <param name="content">A struct representing the content to update. The title, description, dateCreated, and categories fields are supported. All other elements are ignored. If multiple categories are specified, each category is added to the category list until the maximum is reached, and all remaining categories are ignored.</param>
        /// <param name="publish">If false, this is a draft post.</param>
        /// <returns>Always returns true</returns>
        [XmlRpcMethod("metaWeblog.editPost")]
        bool EditPost(string postid,string username,string password,Post content,bool publish);
        
        /// <summary>
        /// The metaWeblog.getPost method returns a specific entry from a blog.
        /// </summary>
        /// <param name="postid">The ID of the post to update</param>
        /// <param name="username">The name of the user’s space.</param>
        /// <param name="password">The user’s secret word.</param>
        /// <returns>A struct that represents the post. Contains the following fields: title, description, postid, dateCreated, categories and publish</returns>
        [XmlRpcMethod("metaWeblog.getPost")]
        Post GetPost(string postid,string username,string password);

        /// <summary>
        /// The metaWeblog.getCategories method returns the list of categories that have been used in the blog.
        /// </summary>
        /// <param name="blogid">This should be the string MyBlog, which indicates that the post is being created in the user’s blog.</param>
        /// <param name="username">The name of the user’s space.</param>
        /// <param name="password">The user’s secret word.</param>
        /// <returns>An array of Category struct that contains one class for each category. Each category class contains both a description and title field which each contain the name of the category.</returns>
        [XmlRpcMethod("metaWeblog.getCategories")]
        CategoryInfo[] GetCategories(string blogid, string username, string password);

        /// <summary>
        /// The metaWeblog.getRecentPosts method returns the most recent draft and non-draft blog posts in descending order by publish date.
        /// </summary>
        /// <param name="blogid">The relationship name of the message container being edited. It is MyBlog in Wave 11, which is the user’s blog.</param>
        /// <param name="username">The name of the user’s space.</param>
        /// <param name="password">The user’s secret word.</param>
        /// <param name="numberOfPosts">The number of posts to return. The maximum value is 20.</param>
        /// <returns>An array of struct that represents each post. Each struct will contain the following fields: title, description, postid, dateCreated, and categories. Each struct in the array has the following structure:</returns>
        [XmlRpcMethod("metaWeblog.getRecentPosts")]
        Post[] GetRecentPosts(string blogid,string username,string password,int numberOfPosts);

        [XmlRpcMethod("metaWeblog.newMediaObject")]
        MediaObjectInfo NewMediaObject(string blogid, string username, string password,
            MediaObject mediaObject);
    }
        

}
