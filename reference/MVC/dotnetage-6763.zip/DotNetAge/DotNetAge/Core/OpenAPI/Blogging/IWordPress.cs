﻿//  Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CookComputing.XmlRpc;

namespace DNA.Mvc.OpenAPI.Blogging
{
    /// <summary>
    /// Defines the wp apis for Xml-Rpc service
    /// </summary>
    public interface IWordPress
    {
        /// <summary>
        /// Get list of all tags. 
        /// </summary>
        /// <param name="blogid">The blog name</param>
        /// <param name="username">The name of the user’s space.</param>
        /// <param name="password">The user’s secret word.</param>
        /// <returns></returns>
        [XmlRpcMethod("wp.getTags")]
       string[] GetTags(string blogid, string username, string password);

        /// <summary>
        /// Retrieve the blogs of the users. 
        /// </summary>
         /// <param name="username">The name of the user’s space.</param>
        /// <param name="password">The user’s secret word.</param>
        /// <returns></returns>
        [XmlRpcMethod("wp.getUsersBlogs")]
        BlogInfo[] GetUsesBlogs(string username, string password);

        /// <summary>
        /// Retrieve comment count for a specific post
        /// </summary>
        /// <param name="blogId">The blog name</param>
        /// <param name="username">The name of the user’s space.</param>
        /// <param name="password">The user’s secret word.</param>
        /// <param name="post_id"></param>
        /// <returns></returns>
        [XmlRpcMethod("wp.getCommentCount")]
        int GetCommentCount(string blogId, string username, string password, string post_id);

        /// <summary>
        /// Retrieve post statuses. 
        /// </summary>
        /// <returns></returns>
        [XmlRpcMethod("wp.getPostStatusList")]
        PageStatus GetPostStatusList(string blogId, string username, string password);

        /// <summary>
        /// Create a new page. Similar to metaWeblog.newPost. 
        /// </summary>
        /// <param name="blogId">The blog name</param>
        /// <param name="username">The name of the user’s space.</param>
        /// <param name="password">The user’s secret word.</param>
        /// <param name="page">The page parameter.</param>
        /// <param name="publish">Identity the page wheather publish.</param>
        /// <returns>Returns the page id.</returns>
        [XmlRpcMethod("wp.newPage")]
        int NewPage(string blogId, string username, string password, PageParam page, bool publish);

        /// <summary>
        /// Make changes to a blog page. 
        /// </summary>
        /// <param name="blogId">The blog name </param>
        /// <param name="pageId">The page id.</param>
        /// <param name="username">The user name of the blog owner.</param>
        /// <param name="password">The password of the user.</param>
        /// <param name="page">The page parameter.</param>
        /// <param name="publish">Identity the page wheather publish.</param>
        /// <returns>True value will be return if save successful.</returns>
        [XmlRpcMethod("wp.editPage")]
        bool EditPage(string blogId, string pageId, string username, string password, PageParam page, bool publish);

        /// <summary>
        /// Delete the page instance.
        /// </summary>
        /// <param name="blogId">The blog name.</param>
        /// <param name="pageId">The page id.</param>
        /// <param name="username">The name of the user’s space.</param>
        /// <param name="password">The user’s secret word.</param>
        /// <returns></returns>
        [XmlRpcMethod("wp.deletePage")]
        bool DeletePage(string blogId, string pageId, string username, string password);

        /// <summary>
        /// Get the page identified by the page id. 
        /// </summary>     
        /// <param name="blogId">The blog name</param>
        /// <param name="pageId">The page id.</param>
        /// <param name="username">The name of the user’s space.</param>
        /// <param name="password">The user’s secret word.</param>
        /// <returns></returns>
        [XmlRpcMethod("wp.getPage")]
        Page GetPage(string blogId, string pageId, string username, string password);

        /// <summary>
        /// 
        /// </summary>
        /// <param name="blogId">The blog name</param>
        /// <param name="username">The name of the user’s space.</param>
        /// <param name="password">The user’s secret word.</param>
        /// <returns></returns>
        [XmlRpcMethod("wp.getPages")]
        Page[] GetPages(string blogId, string username, string password);

        /// <summary>
        /// Get an array of all the pages on a blog. Just the minimum details, lighter than wp.getPages. 
        /// </summary>
        /// <param name="blogId">The blog name</param>
        /// <param name="username">The name of the user’s space.</param>
        /// <param name="password">The user’s secret word.</param>
        /// <returns></returns>
        [XmlRpcMethod("wp.getPageList")]
        PageInfo[] GetPageList(string blogId, string username, string password);

        /// <summary>
        /// Retrieve page templates.
        /// </summary>
        /// <param name="blogId">The blog name</param>
        /// <param name="username">The name of the user’s space.</param>
        /// <param name="password">The user’s secret word.</param>
        /// <returns></returns>
        [XmlRpcMethod("wp.getPageTemplates")]
        PageTemplate[] GetPageTemplates(string blogId, string username, string password);

        /// <summary>
        /// Get an array of available categories on a blog. 
        /// </summary>
        /// <returns></returns>
        [XmlRpcMethod("wp.getCategories")]
        CategoryInfo[] GetCategories(string blogId, string username, string password);

        /// <summary>
        /// Create a new category. 
        /// </summary>
        /// <param name="blogId">The blog name</param>
        /// <param name="username">The name of the user’s space.</param>
        /// <param name="password">The user’s secret word.</param>
        /// <param name="category"></param>
        /// <returns></returns>
        [XmlRpcMethod("wp.newCategory")]
        int NewCategory(string blogId, string username, string password, CategoryParam category);

        /// <summary>
        /// Get an array of categories that start with a given string. 
        /// </summary>
        /// <param name="blogId">The blog name</param>
        /// <param name="username">The name of the user’s space.</param>
        /// <param name="password">The user’s secret word.</param>
        /// <param name="category"></param>
        /// <param name="max_results"></param>
        /// <returns></returns>
        [XmlRpcMethod("wp.suggestCategories")]
        CategoryInfo[] GetSuggestCategories(string blogId, string username, string password, string category, int max_results);

        
        /// <summary>
        /// Delete a category. 
        /// </summary>
        /// <param name="blogId">The blog name</param>
        /// <param name="username">The name of the user’s space.</param>
        /// <param name="password">The user’s secret word.</param>
        /// <param name="category_id"></param>
        /// <returns></returns>
        [XmlRpcMethod("wp.deleteCategory")]
        bool DeleteCategory(string blogId, string username, string password,int category_id);

        /// <summary>
        /// Upload a file. 
        /// </summary>
        /// <param name="blogId">The blog name</param>
        /// <param name="username">The name of the user’s space.</param>
        /// <param name="password">The user’s secret word.</param>
        /// <param name="file"></param>
        /// <returns></returns>
        [XmlRpcMethod("wp.uploadFile")]
        MediaObjectInfo UploadFile(string blogId, string username, string password,MediaObject file);
    }



}