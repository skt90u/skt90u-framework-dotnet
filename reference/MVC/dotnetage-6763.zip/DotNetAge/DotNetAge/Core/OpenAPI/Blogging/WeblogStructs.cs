﻿//  Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CookComputing.XmlRpc;

namespace DNA.Mvc.OpenAPI.Blogging
{
    public struct BlogInfo
    {
        public string blogid;
        public string url;
        public string blogName;
        public string xmlrpc;//supports for wordpress
        public bool isAdmin;//supports for wordpress
    }

    [Serializable]
    public struct CategoryInfo
    {
        public string description;
        public string htmlUrl;
        public string rssUrl;
        public string title;
        public string categoryId;
        public int parentId;
        public string categoryName;
        public bool isPrimary;//Support fo movabletype
    }

    [XmlRpcMissingMapping(MappingAction.Ignore)]
    public struct CategoryParam
    {
        //MoveableType struct
        public string categoryName;
        public string categoryId;
        public bool isPrimary;
        //Wordpress struct
        public string name;
        public string description;
        public string slug;
        public int parent_id;
    }

    [XmlRpcMissingMapping(MappingAction.Ignore)]
    public struct Enclosure
    {
        public int length;
        public string type;
        public string url;
    }

    /// <summary>
    /// Post struct 
    /// </summary>
    [XmlRpcMissingMapping(MappingAction.Ignore)]
    public struct Post
    {
        /// <summary>
        /// Gets/Sets the post id.
        /// </summary>
        public string postid;

        /// <summary>
        /// Gets/Sets the title of the post.
        /// </summary>
        public string title;

        /// <summary>
        /// Gets/Sets the create date of the post.
        /// </summary>
        public XmlRpcDateTime dateCreated;

        /// <summary>
        /// Gets/Sets the post content
        /// </summary>
        public string description;

        /// <summary>
        /// Gets/Sets the absoult uri of the post.
        /// </summary>
        public string link;

        /// <summary>
        /// Gets/Sets the post slug of the post. 
        /// </summary>
        ///<remarks>
        ///  If you're using Pretty Permalinks, the Post Slug is the title of your article post within the link. 
        ///  The blogging tool software may simplify or truncate your title into a more appropriate form for using as a link. 
        ///  A title such as "I'll Make A Wish" might be truncated to "ill-make-a-wish".
        /// </remarks>
        public string wp_slug;

        /// <summary>
        /// Gets/Sets the excerpt of the post.
        /// </summary>
        public string mt_excerpt;

        /// <summary>
        /// Gets/Sets whether the post allow comments.
        /// </summary>
        /// <remarks>
        /// "0" to false.
        /// "1" to true.
        /// </remarks>
        public int mt_allow_comments;

        /// <summary>
        /// Gets/Sets whether the post allow ping back.
        /// </summary>
        /// <remarks>
        /// "0" to false.
        /// "1" to true.
        /// </remarks>
        public int mt_allow_pings;

        /// <summary>
        /// Gets/Sets whether the post is publish.
        /// </summary>
        public bool publish;

        /// <summary>
        /// Gets/Sets the tags of the post.
        /// </summary>
        public string mt_keywords;

        /// <summary>
        /// Gets/Sets the category names of the post.
        /// </summary>
        public string[] categories;

        public Enclosure enclosure;

        public string permalink;

        /// <summary>
        /// Gets/Sets the user id of this post.
        /// </summary>
        public string userid;

        public Source source;

        public string mt_text_more;
        public string mt_basename;
        public string[] mt_tb_ping_urls;
        public string mt_tags;
        public string wp_author;
        public string dna_parent_postid;
    }


    [XmlRpcMissingMapping(MappingAction.Ignore)]
    public struct Source
    {
        public string name;
        public string url;
    }

    public struct UserInfo
    {
        public string userid;
        public string firstname;
        public string lastname;
        public string nickname;
        public string email;
        public string url;
    }

    [XmlRpcMissingMapping(MappingAction.Ignore)]
    public struct MediaObject
    {
        public string name;
        public string type;
        public byte[] bits;
        public bool overwrite;
    }

    [Serializable]
    public struct MediaObjectInfo
    {
        public string file;
        public string url;
        public string type;
    }

    [XmlRpcMissingMapping(MappingAction.Ignore)]
    public struct Tag
    {
        public string tag_id;
        public string name;
        public string slug;
        public string html_url;
        public string rss_url;
        public int count;
    }

    [Serializable]
    public struct PageStatus
    { 
        public const string draft="Draft";
        [XmlRpcMember("private")]
        public const string _private="Private";
        public const string publish="Publish";
    }

    [Serializable]
    public struct Page
    {
        /// <summary>
        /// Gets/Sets the page created date.
        /// </summary>
        public XmlRpcDateTime dateCreated;

        /// <summary>
        /// Gets/Sets the owner user name of this page.
        /// </summary>
        public string userid;

        /// <summary>
        ///  Gets/Sets the integer page id.
        /// </summary>
        public int page_id;

        public string page_status;

        /// <summary>
        ///  Gets/Sets the title of the page.
        /// </summary>
        public string title;

        /// <summary>
        /// Gets/Sets the content of the page.
        /// </summary>
        public string description;

        /// <summary>
        ///  Gets/Sets the url links to this page.
        /// </summary>
        public string link;

        public string permaLink;

        /// <summary>
        /// Gets/Sets the categories of this page.
        /// </summary>
        /// <remarks>
        /// In Dna this value is not use.
        /// </remarks>
        public string[] categories;

        /// <summary>
        ///  Convert Breaks
        /// </summary>
        public string mt_convert_breaks;

        /// <summary>
        ///  Page keywords
        /// </summary>
        public string mt_keywords;

        public string excerpt;

        public string text_more;

        /// <summary>
        ///  (0 = closed, 1 = open) 
        /// </summary>
        public int mt_allow_comments;

        public int mt_allow_pings;

        public string wp_slug;

        public string wp_password;

        public string wp_author;

        public int wp_author_id;

        public int wp_page_order;

        /// <summary>
        /// Page Parent ID
        /// </summary>
        public int wp_page_parent_id;

        public string wp_page_parent_title;

        public string wp_author_display_name;

        public XmlRpcDateTime date_created_gmt;

        public CustomField[] custom_fields;

        public string wp_page_template;
    }

    [XmlRpcMissingMapping(MappingAction.Ignore)]
    public struct PageParam
    {
        public string wp_slug;
        public string wp_password;
        public string wp_page_parent_id;
        public string wp_page_order;
        public int wp_author_id;
        public string title;
        public string description;
        public string mt_excerpt;
        public string mt_text_more;
        public int mt_allow_comments;
        public int mt_all_pings;
        public XmlRpcDateTime dateCreated;
        public CustomField[] custom_fields;
    }

    [Serializable]
    public struct PageTemplate
    {
        public string name;
        public string description;
    }

    [Serializable]
    public struct CustomField
    {
        public string id;
        public string key;
        public string value;
    }

    /// <summary>
    /// Define the struct for wp.getPageList.
    /// </summary>
    [Serializable]
    public struct PageInfo
    {
        /// <summary>
        /// Gets/Sets the page id
        /// </summary>
        public int page_id;

        /// <summary>
        /// Gets/Sets the title of the page.
        /// </summary>
        public string page_title;

        /// <summary>
        /// Gets/Sets the parent page id.
        /// </summary>
        public int page_parent_id;

        /// <summary>
        /// Gets/Sets the page create date.
        /// </summary>
        public XmlRpcDateTime dateCreated;
    }
}