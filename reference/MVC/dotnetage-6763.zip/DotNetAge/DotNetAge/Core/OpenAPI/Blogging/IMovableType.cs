﻿//  Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using CookComputing.XmlRpc;

namespace DNA.Mvc.OpenAPI.Blogging
{
    /// <summary>
    /// Defines the MovableType inface.
    /// </summary>
    public interface IMovableType
    {
        /// <summary>
        ///  Returns a bandwidth-friendly list of the most recent posts in the system.
        /// </summary>
        /// <param name="blogid">This should be the string MyBlog, which indicates that the post is being created in the user’s blog.</param>
        /// <param name="username">The name of the user’s space</param>
        /// <param name="password">The user’s secret word.</param>
        /// <param name="numberOfPosts">Specified how many posts will returns.</param>
        /// <returns> on success, array of structs containing ISO.8601 dateCreated, String userid, String postid, String title; on failure, fault</returns>
        [XmlRpcMethod("mt.getRecentPostTitles")]
        PostTitle[] GetRecentPostTitles(string blogid, string username, string password, int numberOfPosts);

        /// <summary>
        /// Returns a list of all categories to which the post is assigned.
        /// </summary>
        /// <remarks>isPrimary denotes whether a category is the post’s primary category.</remarks>
        /// <param name="postid">The ID of the post to update</param>
        /// <param name="username">The name of the user’s space.</param>
        /// <param name="password">The user’s secret word.</param>
        /// <returns> on success, an array of structs containing String categoryName, String categoryId, and boolean isPrimary; on failure, fault</returns>
        [XmlRpcMethod("mt.getCategoryList")]
        CategoryInfo[] GetCategoryList(string postid, string username, string password);

        /// <summary>
        ///  Returns a list of all categories to which the post is assigned.
        /// </summary>
        /// <param name="postid">The ID of the post to update</param>
        /// <param name="username">The name of the user’s space.</param>
        /// <param name="password">The user’s secret word.</param>
        /// <returns>on success, an array of structs containing String categoryName, String categoryId, and boolean isPrimary; on failure, fault.</returns>
        ///<remarks>isPrimary denotes whether a category is the post’s primary category.</remarks>
        [XmlRpcMethod("mt.getPostCategories")]
        CategoryInfo[] GetPostCategories(string postid, string username, string password);

        /// <summary>
        /// Sets the categories for a post
        /// </summary>
        /// <param name="postid">The ID of the post to update</param>
        /// <param name="username">The name of the user’s space.</param>
        /// <param name="password">The user’s secret word.</param>
        /// <param name="categories">
        /// the array categories is an array of structs containing String categoryId and boolean isPrimary. Using isPrimary to set the primary category is optional–in the absence of this flag, the first struct in the array will be assigned the primary category for the post.
        /// </param>
        /// <returns> on success, boolean true value; on failure, fault</returns>
        [XmlRpcMethod("mt.setPostCategories")]
        bool SetPostCategories(string postid, string username, string password, CategoryParam[] categories);

        /// <summary>
        /// Retrieve information about the XML-RPC methods supported by the server.
        /// </summary>
        /// <returns> an array of method names supported by the server.</returns>
        /// <remarks> 
        /// an array of structs containing String key and String label. 
        /// key is the unique string identifying a text formatting plugin, 
        /// and label is the readable description to be displayed to a user. key is 
        /// the value that should be passed in the mt_convert_breaks parameter 
        /// to newPost and editPost.</remarks>
        [XmlRpcMethod("mt.supportedMethods")]
        string[] SupportedMethods();

        /// <summary>
        /// Retrieve the list of TrackBack pings posted to a particular entry.
        /// This could be used to programmatically retrieve the list of pings for 
        /// a particular entry, then iterate through each of those pings doing the same,
        /// until one has built up a graph of the web of entries referencing one another 
        /// on a particular topic
        /// </summary>
        /// <param name="postid">Specified the postid.</param>
        /// <returns>an array of structs containing String pingTitle 
        /// (the title of the entry sent in the ping), String pingURL (the URL of the entry), 
        /// and String pingIP (the IP address of the host that sent the ping).</returns>
        [XmlRpcMethod("mt.getTrackbackPings")]
        Ping[] GetTrackbackPings(string postid);

        /// <summary>
        /// Publish (rebuild) all of the static files related to an entry from your weblog. 
        /// Equivalent to saving an entry in the system (but without the ping).
        /// </summary>
        /// <param name="postid">The ID of the post to update</param>
        /// <param name="username">The name of the user’s space.</param>
        /// <param name="password">The user’s secret word.</param>
        /// <returns>on success, boolean true value; on failure, fault</returns>
        [XmlRpcMethod("mt.publishPost")]
        bool PublishPost(string postid, string username, string password);
    }

    [Serializable]
    public struct PostTitle
    {
        public XmlRpcDateTime dateCreated;
        public string userid;
        public string postid;
        public string title;
    }

    [Serializable]
    public struct Ping
    {
        public string pingTitle;
        public string pingUrl;
        public string pingIP;
    }
}