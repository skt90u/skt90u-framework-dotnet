﻿//  Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Xml;
using System.Xml.Serialization;

namespace DNA.Mvc.OpenAPI.Atom
{
    /// <summary>
    /// Atom RFC 4287 http://tools.ietf.org/html/rfc4287#page-18
    /// The "atom:feed" element is the document (i.e., top-level) element of an Atom Feed Document, 
    /// acting as a container for metadata and data associated with the feed. 
    /// Its element children consist of metadata elements followed by zero or more atom:entry child elements. 
    /// </summary>
    [XmlRoot("feed", Namespace = "http://www.w3.org/2005/Atom"),
     Serializable]
    public struct AtomFeed
    {
        [XmlElement("generator")]
        public AtomGenerator Generator;

        [XmlElement("link", Type = typeof(AtomLink))]
        public List<AtomLink> Links;

        [XmlElement("logo")]
        public string Logo;

        [XmlElement("entry", Type = typeof(AtomEntry))]
        public List<AtomEntry> Entries;

        [XmlElement("id")]
        public string ID;

        [XmlElement("icon")]
        public string Icon;

        [XmlElement("rights")]
        public string CopyRight;

        [XmlElement("updated")]
        public DateTime Updated;
 
        [XmlElement("title")]
        public string Title;

        [XmlElement("subtitle")]
        public string SubTitle;

        [XmlElement("category",Type=typeof(AtomCategory))]
        public List<AtomCategory> Categories;

        [XmlElement("contributor",Type=typeof(AtomPersonConstruct))]
        public List<AtomPersonConstruct> Contributors;
        
    }
}