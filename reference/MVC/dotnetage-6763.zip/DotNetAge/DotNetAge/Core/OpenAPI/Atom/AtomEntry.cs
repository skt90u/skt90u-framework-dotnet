﻿//  Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Xml;
using System.Xml.Serialization;

namespace DNA.Mvc.OpenAPI.Atom
{
    /// <summary>
    /// The "atom:entry" element represents an individual entry, acting as a
    ///container for metadata and data associated with the entry.  This
    ///element can appear as a child of the atom:feed element, or it can
    ///appear as the document (i.e., top-level) element of a stand-alone
    ///Atom Entry Document.
    /// </summary>
    [XmlRoot("entry", Namespace = "http://www.w3.org/2005/Atom"),
    Serializable]
    public struct AtomEntry
    {
        /// <summary>
        /// Gets/Sets a Text construct that conveys a human-readable title for an entry or feed.
        /// </summary>
        [XmlElement("title")]
        public string Title;

        /// <summary>
        /// Gets/Sets a collection defines a reference from an entry or feed to a Web resource.  This specification assigns no meaning to the content
        /// (if any) of this element
        /// </summary>
        [XmlElement("link", Type = typeof(AtomLink))]
        public List<AtomLink> Links;

        [XmlElement("category", Type = typeof(AtomCategory))]
        public List<AtomCategory> Categories;

        /// <summary>
        /// Gets/Sets conveys a permanent, universally unique  identifier for an entry or feed
        /// </summary>
        [XmlElement("id")]
        public string ID;

        /// <summary>
        /// Gets/Sets date indicating the most recent instant in time when an entry or feed was modified in a way
        /// the publisher considers significant.  Therefore, not all modifications necessarily result in a changed atom:updated value
        /// </summary>
        [XmlElement("updated")]
        public DateTime Updated;

        /// <summary>
        /// Gets/Sets date indicating an instant in time associated with an event early in the life cycle of the entry.
        /// </summary>
        [XmlElement("published")]
        public DateTime Published;

        /// <summary>
        /// Gets/Sets a collection of contributors that is a <c>AtomPersonConstruct</c> that indicates a
        /// person or other entity who contributed to the entry or feed
        /// </summary>
        [XmlElement("contributor", Type = typeof(AtomPersonConstruct))]
        public List<AtomPersonConstruct> Contributors;

        /// <summary>
        /// Gets/Sets <c>AtomPersonConstruct</c> object that indicates the author of the entry or feed
        /// </summary>
        [XmlElement("author", Type = typeof(AtomPersonConstruct))]
        public AtomPersonConstruct Author;

        /// <summary>
        ///Gets/Sets the cotnent either contains or links to the content of the entry. 
        /// </summary>
        [XmlElement("content", Type = typeof(AtomContent))]
        public AtomContent Content;

        /// <summary>
        /// Gets/Sets a Text construct that conveys a short summary, abstract, or excerpt of an entry.
        /// </summary>
        [XmlElement("summary")]
        public string Summary;

        /// <summary>
        /// If an <c>AtomEntry</c> is copied from one feed into another feed, then the
        ///source atom:feed's metadata (all child elements of atom:feed other
        ///than the atom:entry elements) MAY be preserved within the copied
        ///entry by adding an atom:source child element, if it is not already
        ///present in the entry, and including some or all of the source feed's
        ///Metadata elements as the atom:source element's children.  Such
        ///metadata SHOULD be preserved if the source atom:feed contains any of
        ///the child elements atom:author, atom:contributor, atom:rights, or
        ///atom:category and those child elements are not present in the source
        ///atom:entry.
        /// </summary>
        [XmlElement("source")]
        public AtomSource Source;
    }
}