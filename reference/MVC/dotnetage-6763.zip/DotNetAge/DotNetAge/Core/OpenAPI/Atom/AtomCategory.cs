﻿//  Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Xml.Serialization;

namespace DNA.Mvc.OpenAPI.Atom
{
    /// <summary>
    /// The "atom:category" element conveys information about a category associated with an entry or feed. 
    /// This specification assigns no meaning to the content (if any) of this element
    /// </summary>
    [XmlRoot("category", Namespace = "http://www.w3.org/2005/Atom"), Serializable]
    public struct AtomCategory
    {
        /// <summary>
        /// The "term" attribute is a string that identifies the category to which the entry or feed belongs. 
        /// Category elements MUST have a "term" attribute.
        /// </summary>
        [XmlAttribute("term")]
        public string Term;

        /// <summary>
        /// The "scheme" attribute is an IRI that identifies a categorization scheme. 
        /// Category elements MAY have a "scheme" attribute.
        /// </summary>
        [XmlAttribute("scheme")]
        public string Scheme;

        /// <summary>
        /// The "label" attribute provides a human-readable label for display in end-user applications. 
        /// The content of the "label" attribute is Language-Sensitive. Entities such as "&amp;" and "&lt;" represent their corresponding 
        /// characters ("&amp;" and "&lt;", respectively), not markup. Category elements MAY have a "label" attribute
        /// </summary>
        [XmlAttribute("label")]
        public string Text;


    }
}