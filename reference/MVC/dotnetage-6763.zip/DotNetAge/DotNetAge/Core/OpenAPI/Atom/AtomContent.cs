﻿//  Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Xml.Serialization;

namespace DNA.Mvc.OpenAPI.Atom
{
    /// <summary>
    /// The "atom:content" element either contains or links to the content of the entry. The content of atom:content is Language-Sensitive. 
    /// </summary>
    /// <example>
    /// <code language="xml">
    /// ...
    /// &lt;content type="xhtml"&gt;
    /// &lt;div xmlns="http://www.w3.org/1999/xhtml"&gt;
    /// This is &lt;b&gt;XHTML&lt;/b&gt; content.
    /// &lt;/div&gt;
    /// &lt;/content&gt;
    /// 
    /// ...
    /// &lt;content type="xhtml"&gt;
    ///&lt;xhtml:div xmlns:xhtml="http://www.w3.org/1999/xhtml"&gt;
    ///   This is &lt;xhtml:b&gt;XHTML&lt;/xhtml:b&gt; content.
    ///&lt;/xhtml:div&gt;
    ///&lt;/content&gt;
    ///
    /// </code>
    /// </example>
    [XmlRoot("content", Namespace = "http://www.w3.org/2005/Atom"),
    Serializable]
    public struct AtomContent
    {
        /// <summary>
        /// On the atom:content element, the value of the "type" attribute MAY be one of "text", "html", or "xhtml".
        /// Failing that, it MUST conform to the syntax of a MIME media type, but MUST NOT be a composite type (see Section 4.2.6 of [MIMEREG]).
        /// If neither the type attribute nor the src attribute is provided, Atom Processors MUST behave as though the type attribute were present with
        /// a value of "text".
        /// </summary>
        [XmlAttribute("type")]
        public string ContentType;

        /// <summary>
        /// atom:content MAY have a "src" attribute, whose value MUST be an IRI reference [RFC3987]. If the "src" attribute is present, 
        /// atom:content MUST be empty. Atom Processors MAY use the IRI to retrieve the content and MAY choose to ignore remote content or
        /// to present it in a different manner than local content.
        /// </summary>
        /// <remarks>
        /// If the "src" attribute is present, the "type" attribute SHOULD be provided and MUST be a MIME media type [MIMEREG],
        /// rather than "text", "html", or "xhtml". The value is advisory; that is to say, when the corresponding URI (mapped from an IRI, if necessary) is 
        /// dereferenced, if the server providing that content also provides a media type, the server-provided media type is authoritative.
        /// </remarks>
        [XmlAttribute("src")]
        public string SourceUrl;

        [XmlText]
        public string Text;
    }
}