﻿//  Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Xml.Serialization;

namespace DNA.Mvc.OpenAPI.Atom
{
    /// <summary>
    /// If an atom:entry is copied from one feed into another feed, then the source atom:feed's 
    /// metadata (all child elements of atom:feed other than the atom:entry elements) MAY be preserved within the copied entry by 
    /// adding an atom:source child element, if it is not already present in the entry, and including some or all of the source feed's Metadata 
    /// elements as the atom:source element's children. Such metadata SHOULD be preserved if the source atom:feed contains any of the child 
    /// elements atom:author, atom:contributor, atom:rights, or atom:category and those child elements are not present in the source atom:entry. 
    /// </summary>
    /// <remarks>
    /// The atom:source element is designed to allow the aggregation of entries from different feeds while retaining information about an entry's 
    /// source feed. For this reason, Atom Processors that are performing such aggregation SHOULD include at least the required feed-level Metadata 
    /// elements (atom:id, atom:title, and atom:updated) in the atom:source element.
    /// </remarks>
    [XmlRoot("source", Namespace = "http://www.w3.org/2005/Atom"), Serializable]
    public struct AtomSource
    {
        [XmlElement("category", Type = typeof(AtomCategory))]
        public List<AtomCategory> Categories;

        [XmlElement("author", Type = typeof(AtomPersonConstruct))]
        public List<AtomPersonConstruct> Authors;

        [XmlElement("contributor", Type = typeof(AtomPersonConstruct))]
        public List<AtomPersonConstruct> Contributors;

        [XmlElement("rights",Type=typeof(string))]
        public List<string> Rights;

        [XmlElement("id")]
        public string ID;

        [XmlElement("logo")]
        public string Logo;

        [XmlElement("subtitle")]
        public string SubTitle;

        [XmlElement("title")]
        public string Title;

        [XmlElement("updated")]
        public DateTime Updated;

        [XmlElement("generator")]
        public AtomGenerator Generator;
    }
}