﻿//  Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Xml.Linq;
using System.Xml.Serialization;

namespace DNA.Mvc.OpenAPI.Opml
{
    /// <summary>
    /// This document describes a format for storing outlines in XML 1.0 called Outline Processor Markup Language or OPML.
    /// The purpose of this format is to provide a way to exchange information between outliners and Internet services that can be browsed or controlled through an outliner.
    /// OPML is also the file format for an outliner application, which is why OPML files may contain information about the size, position and expansion state of the window the outline is displayed in.
    /// OPML has also become popular as a format for exchanging subscription lists between feed readers and aggregators.
    /// The design goal is to have a transparently simple, self-documenting, extensible and human readable format that's capable of representing a wide variety of data that's easily browsed and edited. It should be possible for a reasonably technical person to understand the format with a quick read of a few web pages.
    /// It's an open format, meaning that other outliner and service developers are welcome to use the format to be compatible with Radio UserLand, the OPML Editor, or for any other purpose. 
    /// lean more:http://www.opml.org/spec2
    /// </summary>
    [XmlRoot("opml"), Serializable]
    public struct OpmlDocument
    {
        [XmlAttribute("version")]
        public string Version { get { return "2.0"; } set { } }

        [XmlElement("head")]
        public OpmlHead Head;

        /// <summary>
        /// A body contains one or more outline elements.
        /// </summary>
        [XmlElement("body")]
        public OpmlBody Body;
    }
}