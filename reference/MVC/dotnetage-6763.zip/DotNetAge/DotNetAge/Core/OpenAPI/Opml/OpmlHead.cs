﻿//  Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Xml.Linq;
using System.Xml.Serialization;

namespace DNA.Mvc.OpenAPI.Opml
{
    [Serializable]
    public struct OpmlHead
    {
        /// <summary>
        /// title is the title of the document
        /// </summary>
        [XmlElement("title")]
        public string Title;

        /// <summary>
        /// dateCreated is a date-time, indicating when the document was created
        /// </summary>
        [XmlElement("dateCreated",Type=typeof(DateTime))]
        public DateTime Created;

        /// <summary>
        /// dateModified is a date-time, indicating when the document was last modified.
        /// </summary>
        [XmlElement("dateModified", Type = typeof(DateTime))]
        public DateTime Modified;

        /// <summary>
        /// ownerName is a string, the owner of the document.
        /// </summary>
        [XmlElement("ownerName")]
        public string OwnerName;

        /// <summary>
        /// ownerEmail is a string, the email address of the owner of the document.
        /// </summary>
        [XmlElement("ownerEmail")]
        public string OwnerEmail;

        /// <summary>
        /// ownerId is the http address of a web page that contains information that allows a human reader to communicate with the 
        /// author of the document via email or other means. It also may be used to identify the author. No two authors have the same ownerId.
        /// </summary>
        [XmlElement("ownerId")]
        public string OwnerID;

        /// <summary>
        /// docs is the http address of documentation for the format used in the OPML file. It's probably a pointer to this page for people who 
        /// might stumble across the file on a web server 25 years from now and wonder what it is.
        /// </summary>
        [XmlElement("docs")]
        public string Docs;
        
        /// <summary>
        /// ExpansionState is a comma-separated list of line numbers that are expanded. The line numbers in the 
        /// list tell you which headlines to expand. The order is important. For each element in the list,
        /// X, starting at the first summit, navigate flatdown X times and expand. Repeat for each element in the list.
        /// </summary>
        [XmlElement("expansionState")]
        public string ExpansionState;

        /// <summary>
        /// vertScrollState is a number, saying which line of the outline is displayed on the top line of the window. 
        /// This number is calculated with the expansion state already applied.
        /// </summary>
        [XmlElement("vertScrollState")]
        public int VertScrollState;

        /// <summary>
        /// windowTop is a number, the pixel location of the top edge of the window.
        /// </summary>
        [XmlElement("windowTop")]
        public int WindowTop;

        /// <summary>
        /// windowRight is a number, the pixel location of the right edge of the window
        /// </summary>
        [XmlElement("windowRight")]
        public int WindowRight;

        [XmlElement("windowBottom")]
        public int WindowBottom;

        /// <summary>
        /// windowLeft is a number, the pixel location of the left edge of the window.
        /// </summary>
        [XmlElement("windowLeft")]
        public int WindowLeft;
    }
}