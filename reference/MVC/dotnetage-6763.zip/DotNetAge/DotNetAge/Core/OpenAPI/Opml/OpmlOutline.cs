﻿//  Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Xml.Linq;
using System.Xml.Serialization;

namespace DNA.Mvc.OpenAPI.Opml
{
    [Serializable]
    public struct OpmlOutline
    {
        [XmlAttribute("text")]
        public string Text;

        /// <summary>
        /// description is the top-level description element from the feed. htmlUrl is the top-level link element.
        /// </summary>
        [XmlAttribute("description")]
        public string Description;

        [XmlAttribute("htmlUrl")]
        public string HtmlUrl;

        /// <summary>
        ///  language is the value of the top-level language element. 
        /// </summary>
        [XmlAttribute("language")]
        public string Language;

        /// <summary>
        /// title is probably the same as text, it should not be omitted. title contains the top-level title element from the feed.
        /// </summary>
        [XmlAttribute("title")]
        public string Title;

        [XmlAttribute("type")]
        public string Type;

        /// <summary>
        /// version varies depending on the version of RSS that's being supplied. It was invented at a time when we thought there 
        /// might be some processors that only handled certain versions, but that hasn't turned out to be a major issue. 
        /// The values it can have are: RSS1 for RSS 1.0; RSS for 0.91, 0.92 or 2.0; scriptingNews for scriptingNews format. 
        /// There are no known values for Atom feeds, but they certainly could be provided. 
        /// </summary>
        [XmlAttribute("version")]
        public string Version;

        [XmlAttribute("xmlUrl")]
        public string XmlUrl;

        [XmlAttribute("url")]
        public string Url;

        /// <summary>
        /// isComment is a string, either "true" or "false", indicating whether the outline is commented or not. 
        /// By convention if an outline is commented, all subordinate outlines are considered to also be commented. If it's not present, the value is false.
        /// </summary>
        [XmlAttribute("isComment ")]
        public bool IsComment;

        /// <summary>
        /// isBreakpoint is a string, either "true" or "false", indicating whether a breakpoint is set on this outline. 
        /// This attribute is mainly necessary for outlines used to edit scripts. If it's not present, the value is false.
        /// </summary>
        [XmlAttribute("isBreakpoint")]
        public bool IsBreakpoint;

        /// <summary>
        /// category is a string of comma-separated slash-delimited category strings, in the format defined by the RSS 2.0 category element. 
        /// To represent a "tag," the category string should contain no slashes.
        /// </summary>
        /// <example>
        /// 1. category="/Boston/Weather". 
        /// 2. category="/Harvard/Berkman,/Politics".
        /// </example>
        [XmlAttribute("category")]
        public string Category;

        [XmlElement("outline")]
        public List<OpmlOutline> Outlines;
    }
}