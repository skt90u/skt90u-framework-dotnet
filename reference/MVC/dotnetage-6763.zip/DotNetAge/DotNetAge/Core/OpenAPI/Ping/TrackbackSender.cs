﻿//  Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Text;

namespace DNA.Mvc.OpenAPI.Ping
{
    /// <summary>
    /// Use to send the Http trackback request
    /// </summary>
    public static class TrackbackSender
    {
        /// <summary>
        /// Send the trackback httprequest
        /// </summary>
        /// <param name="msg">The TrackbackMessage object contains the values to send</param>
        public static bool Send(TrackbackMessage msg)
        {
            StringBuilder formParams = new StringBuilder();
            formParams.AppendFormat("blog_name={0}", HttpUtility.UrlEncode(msg.BlogTitle));
            formParams.AppendFormat("&url={0}", HttpUtility.UrlEncode(msg.UrlToNotifyTrackback.ToString()));
            formParams.AppendFormat("&title={0}", HttpUtility.UrlEncode(msg.Title));
            formParams.AppendFormat("&excerpt={0}", HttpUtility.UrlEncode(msg.Excerpt));

            try
            {
                HttpClient client = new HttpClient();
                client.PostRequest(msg.DestinationUrl, "DotNetAge trackback sender",
                    20000, formParams.ToString());
                return true;
            }
            catch { return false; }
        }
    }
}