﻿//  Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Text;

namespace DNA.Mvc.OpenAPI.Ping
{
    public class TrackbackMessage
    {
        /// <summary>
        /// Gets/Sets the blog title
        /// </summary>
        public string BlogTitle { get; set; }

        /// <summary>
        ///     Gets or sets the excerpt.
        /// </summary>
        /// <value>The excerpt.</value>
        public string Excerpt { get; set; }

        /// <summary>
        ///     Gets or sets the title.
        /// </summary>
        /// <value>The title.</value>
        public string Title { get; set; }

        /// <summary>
        /// Gets/Sets the destination url to sned this trackback request.
        /// </summary>
        public Uri DestinationUrl { get; set; }

        /// <summary>
        ///  Gets or sets the URL of this blog that allows remove server to trackback.
        /// </summary>
        /// <value>The URL to notify trackback.</value>
        public Uri UrlToNotifyTrackback { get; set; }
    }
}