﻿//  Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Xml.Serialization;

namespace DNA.Mvc.OpenAPI.Rsd
{
    /// <summary>
    /// The rsd service container element.
    /// </summary>
    [XmlRoot("service"),Serializable]
    public class RsdService
    {
        private string engineName = "DotNetAge CMS";
        private List<RsdAPI> rsdAPIs;

        /// <summary>
        /// Gets/Sets the collection of RsdAPI
        /// </summary>
        [XmlArray("apis"),XmlArrayItem(ElementName="api",Type=typeof(RsdAPI))]
        public List<RsdAPI> RsdAPIs
        {
            get 
            {
                if (rsdAPIs == null)
                    rsdAPIs = new List<RsdAPI>();
                return rsdAPIs; 
            }
            set { rsdAPIs = value; }
        }

        /// <summary>
        /// Gets/Sets a string that is the name of the engine that is providing the services being described.
        /// </summary>
        [XmlElement("engineName")]
        public string EngineName
        {
            get { return engineName; }
            set { engineName = value; }
        }

        /// <summary>
        /// Gets/Sets the URL to the home of the engine.
        /// </summary>
        [XmlElement("engineLink")]
        public string EngineLink { get; set; }

        /// <summary>
        /// Gets/Sets  the URL of the users homepage.
        /// </summary>
        [XmlElement("homePageLink")]
        public string HomePageLink { get; set; }
    }
}