﻿//  Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Xml.Serialization;

namespace DNA.Mvc.OpenAPI.Rsd
{
    /// <summary>
    /// RFC: Really Simple Discoverability 1.0
    /// </summary>
    [Serializable]
    [XmlRoot("rsd", Namespace = "http://archipelago.phrasewise.com/rsd")]
    public class RsdDoc
    {
        private string _version = "1.0";
        private RsdService service;
        [XmlElement("service")]
        public RsdService Service
        {
            get 
            {
                if (service == null)
                    service = new RsdService();
                return service; 
            }
            set { service = value; }
        }

        [XmlAttribute("version")]
        public string Version
        {
            get { return _version; }
            set { _version = value; }
        }
    }
}