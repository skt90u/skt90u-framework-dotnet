﻿//  Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Xml.Serialization;


namespace DNA.Mvc.OpenAPI.Rsd
{
    [XmlRoot("api"),Serializable]
    public class RsdAPI
    {  
        private bool preferred = false;
        private RsdAPISettings settings;
        
        /// <summary>
        /// Information required by more flexible or capable systems can be expressed here. 
        /// settings is a container element and is required if you are going to include the following
        /// optional sub-elements.
        /// </summary>
        [XmlElement("settings",Type=typeof(RsdAPISettings))]
        public RsdAPISettings Settings
        {
            get
            {
                if (settings == null)
                    settings = new RsdAPISettings();
                return settings;
            }
            set { settings = value; }
        }

        /// <summary>
        /// Gets/Sets a name does not need to be listed here or
        /// elsewhere to be valid Multiple api elements are allowed
        /// </summary>
        [XmlAttribute("name")]
        public string Name { get; set; }

        /// <summary>
        /// Gets/Sets  a common bit of data that most APIs currently require. 
        /// It can be specified here. If your system doesn't require it, include the attribute,
        /// but leave it blank like so blogID="" (this is demonstrated in the example.)
        /// </summary>
        [XmlAttribute("blogID")]
        public string BlogID { get; set; }

        /// <summary>
        /// Gets/Sets URL for this API. The location the client should speak to.
        /// </summary>
        [XmlAttribute("apiLink")]
        public string Link { get; set; }

        /// <summary>
        /// Gets/Sets is a boolean and takes either "true" or "false". 
        /// The point is to allow weblog software to list all the APIs supported, 
        /// but choose which one to "recommend" to the client software. 
        /// Only one API should set as prefered.
        /// </summary>
        [XmlAttribute("preferred")]
        public bool Preferred
        {
            get { return preferred; }
            set { preferred = value; }
        }

    }
}