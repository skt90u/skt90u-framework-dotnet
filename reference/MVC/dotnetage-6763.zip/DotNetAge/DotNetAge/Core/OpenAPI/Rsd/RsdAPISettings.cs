﻿//  Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Xml.Serialization;

namespace DNA.Mvc.OpenAPI.Rsd
{
    [XmlRoot("settings"), Serializable]
    public class RsdAPISettings
    {        
        private List<RsdAPISetting> settings;
        
        /// <summary>
        /// Gets/Sets a URL that points to the documentation for this API.
        /// </summary>
        [XmlElement("docs")]
        public string Docs { get; set; }

        /// <summary>
        /// Gets/Sets text that should be used to explain features and their settings. 
        /// Intended to be human readable.
        /// </summary>
        [XmlElement("notes")]
        public string Notes { get; set; }

        /// <summary>
        /// requires a single attribute "name" a string which refers to the name of the
        /// "service-specific-setting". The value is the service setting.
        /// Multiple setting elements are allowed.
        /// </summary>
        [XmlElement("setting")]
        public List<RsdAPISetting> Settings
        {
            get
            {
                if (settings == null) 
                    settings = new List<RsdAPISetting>(); 
                return settings;
            }
            set { settings = value; }
        }
    }
}