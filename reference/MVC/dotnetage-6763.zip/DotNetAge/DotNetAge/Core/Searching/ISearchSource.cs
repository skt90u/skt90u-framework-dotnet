﻿//  Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DNA.Mvc.Searching
{
    public interface ISearchSource<TOptions, TResult>
        where TOptions : SearchOption
        where TResult : SearchResult
    {
        IEnumerable<TResult> Search(TOptions options);
    }
  
}