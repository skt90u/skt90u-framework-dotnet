﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;

namespace DNA.Mvc
{
    public class ListViewNodeUIBuilder:NodeUIBuilder
    {
        public override NodeUIBuilder WriteNodeContent(INavigtable node)
        {
            Writer.WriteBeginTag("div");
            Writer.WriteAttribute("class", "ui-listview-item-img");
            Writer.Write(HtmlTextWriter.TagRightChar);
            Writer.WriteFullBeginTag("p");
            Writer.Write(WebResourceExtensions.ImageResourceCore(new Uri(node.Value.ToString()),64,64,null));
            Writer.WriteEndTag("p");
            Writer.WriteEndTag("div");

            Writer.WriteBeginTag("div");
            Writer.WriteAttribute("title", node.Title);
            Writer.Write(HtmlTextWriter.TagRightChar);
            if (node.Title.Length > 10)
                Writer.Write(node.Title.Substring(0, 10) + "...");
            else
                Writer.Write(node.Title);

            Writer.WriteEndTag("div");
            Writer.WriteBeginTag("input");
            Writer.WriteAttribute("type", "hidden");
            Writer.WriteAttribute("value", node.Value.ToString());
            Writer.Write(HtmlTextWriter.SelfClosingTagEnd);
   return this;
        }
     
    }
}
