﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Text;
using System.Text.RegularExpressions;
using System.Web.Mvc;
using System.Web.UI;
using System.IO;
using System.Web.Script.Serialization;
using System.Reflection;

//2010-8-13 changed.

namespace DNA.Mvc.Text
{
    public static class MarkupExtensions
    {
        private static string filePath = "~/content/parsers/";

        public static MvcHtmlString FormatMarkup(this HtmlHelper helper, TextFormats formats, string raw)
        {
            switch (formats)
            {
                case TextFormats.Xhtml:
                    return FormatXhtml(helper, raw);
                case TextFormats.BBCode:
                    return FormatBBCode(helper, FormatXhtml(helper, raw).ToString());
                case TextFormats.WiKi:
                    return FormatWiKi(helper, raw);
                default:
                    return MvcHtmlString.Create(raw);
            }
        }

        public static MvcHtmlString FormatWikiFile(this HtmlHelper helper, string filename)
        {
            if (File.Exists(filename))
                return helper.FormatWiKi(File.ReadAllText(filename));
            return MvcHtmlString.Empty;
        }

        public static MvcHtmlString FormatWiKi(this HtmlHelper helper, string raw)
        {
            return MvcHtmlString.Create(ConvertWikiToHtml(raw));
        }

        public static MvcHtmlString FormatBBCode(this HtmlHelper helper, string raw)
        {
            return MvcHtmlString.Create(FormatMarkup<MarkupParser>(helper, raw, filePath + "bbcode.json"));
        }

        public static MvcHtmlString FormatXhtml(this HtmlHelper helper, string raw)
        {
            string formatted = FormatMarkup<SecurityXHtmlFormatter>(helper, raw, filePath + "securityXhtml.json");
            return MvcHtmlString.Create(HttpContext.Current.Server.HtmlDecode(formatted));
        }

        public static string FormatMarkup<Parser>(this HtmlHelper helper, string raw, string parserFile)
            where Parser : MarkupParser
        {
            return FormatMarkup<Parser>(raw, parserFile);
        }

        public static string ConvertWikiToHtml(string raw)
        {
            return FormatMarkup<WikiMarkupParser>(raw, filePath + "wiki.json");
        }

        public static string FormatMarkup<Parser>(string raw, string parserFile)
  where Parser : MarkupParser
        {
            return FormatMarkup<Parser>(raw, parserFile, null);
        }

        public static string FormatMarkup<Parser>(string raw, string parserFile, IDictionary<string, string> snippets)
   where Parser : MarkupParser
        {
            StreamReader file = File.OpenText(HttpContext.Current.Server.MapPath(parserFile));
            string formatText = file.ReadToEnd();
            file.Close();

            JavaScriptSerializer ser = new JavaScriptSerializer();
            Parser parser = ser.Deserialize<Parser>(formatText);
            if (snippets == null)
                return parser.Parse(raw);
            else
                return parser.Parse(raw, snippets);
            //object obj= ser.DeserializeObject(formatText);
            //  return raw;
        }
    }
}
