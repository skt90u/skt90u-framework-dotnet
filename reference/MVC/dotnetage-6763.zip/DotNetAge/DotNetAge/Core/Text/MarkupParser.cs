﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Reflection;
using System.IO;
using System.Web.Script.Serialization;
using System.Text.RegularExpressions;
using System.Text;

namespace DNA.Mvc.Text
{
    public class MarkupParser
    {
        private List<Markup> markups;

        protected void ScanText(Func<Match, string> macroDelegate)
        {
            var match = Match();
            int startIndex = 0;
            int length = 0;
            string formatted = "";

            while (match.Success)
            {
                length = (match.Index - startIndex);
                formatted += ContentText.Substring(startIndex, length);

                formatted += macroDelegate(match);
                startIndex += (length + match.Length);
                match = match.NextMatch();

            }

            if (!string.IsNullOrEmpty(formatted))
            {
                if (ContentText.Length > startIndex)
                    ContentText = formatted + ContentText.Substring(startIndex);
                else
                    ContentText = formatted;
            }
        }

        /// <summary>
        /// Gets/Sets the MarkupParser's Title
        /// </summary>
        public string Title { get; set; }

        /// <summary>
        /// Gets/Sets the Remarks of the MarkupParser
        /// </summary>
        public string Remarks { get; set; }

        /// <summary>
        /// Gets the current Markup instance
        /// </summary>
        protected Markup Current { get; private set; }

        /// <summary>
        /// Gets/Sets the parsing content text.
        /// </summary>
        protected string ContentText { get; set; }

        public List<Markup> Markups
        {
            get
            {
                return markups;
            }
            set { markups = value; }
        }

        [System.Web.Script.Serialization.ScriptIgnore]
        public IDictionary<string, string> Snippets { get; private set; }

        public Markup Markup(string name)
        {
            return Markups.FirstOrDefault(m => m.Name == name);
        }

        protected Match Match()
        {
            return Current.GetMatch(ContentText);
        }

        protected Match Match(int startAt)
        {
            return Current.GetMatch(ContentText, startAt);
        }

        protected Match Match(string input, int startAt)
        {
            return Current.GetMatch(input, startAt);
        }

        /// <summary>
        /// Replace current parsing text
        /// </summary>
        /// <param name="replacement"></param>
        protected void Replace(string replacement)
        {
            ContentText = Current.Replace(ContentText, replacement);
        }

        protected bool IsMatch
        {
            get
            {
                return Current.IsMatch(ContentText);
            }
        }

        public string Parse(string raw, IDictionary<string, string> snippets)
        {
            //Pre parse snippets
            Snippets = new Dictionary<string, string>();
            foreach (var key in snippets.Keys)
            {
                if (!string.IsNullOrEmpty(snippets[key]))
                    Snippets.Add(key, Parse(snippets[key]));
            }
            //Snippets = snippets;
            return Parse(raw);
        }

        public string Parse(string raw)
        {
            ContentText = raw;
            foreach (Markup markup in Markups)
            {
                Current = markup;
                if (!string.IsNullOrEmpty(markup.Marco))
                {
                    Type type = this.GetType();
                    MethodInfo method = type.GetMethod(markup.Marco);
                    if (this.IsMatch)
                    {
                        if (method != null)
                        {
                            //if (markup.IsMany)
                            //ScanText();
                            //else
                            method.Invoke(this, null);
                        }
                    }
                }
                else
                {
                    if (markup.IsExplicitly)
                        ContentText = markup.FormatExplicitly(ContentText);
                    else
                        ContentText = markup.Format(ContentText);
                }
            }
            //return ContentText.Replace("\r\n","<br/>");
            return ContentText;
        }

        public static MarkupParser LoadUrl(string url)
        {
            return Load(HttpContext.Current.Server.MapPath(url));
        }

        public static MarkupParser Load(string parserFile)
        {
            StreamReader file = File.OpenText(parserFile);
            string formatText = file.ReadToEnd();
            file.Close();
            JavaScriptSerializer ser = new JavaScriptSerializer();
            return ser.Deserialize<MarkupParser>(formatText);
        }
    }

    //public delegate string MarcoDelegate(Match match);
}
