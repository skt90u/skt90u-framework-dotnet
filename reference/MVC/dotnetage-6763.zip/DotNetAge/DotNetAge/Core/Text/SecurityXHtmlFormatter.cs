﻿//  Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Web.Mvc;

namespace DNA.Mvc.Text
{
    public class SecurityXHtmlFormatter : MarkupParser
    {
        public void FormatScript()
        {
            ScanText(FormatScriptCore);
        }

        private string FormatScriptCore(Match match)
        {
            string replacementText = "";
            string lang = match.Result("$1").Trim().ToLower();
            string body = match.Result("$3");

            if (lang.StartsWith("type"))
            {
                var _regex = new Regex("type=\"text\\/((.|\n|\r)+?)\"");
                var _m = _regex.Match(lang);
                if (_m.Success)
                    lang = _m.Result("$1");
                else
                {
                    _regex = new Regex("type='text\\/((.|\n|\r)+?)'");
                    _m = _regex.Match(lang);
                    if (_m.Success)
                        lang = _m.Result("$1");
                }
            }

            TagBuilder codeContainer = new TagBuilder("div");
            codeContainer.AddCssClass("ui-corner-all ui-widget-content ui-state-highlight");
            codeContainer.InnerHtml += CodeFormatterExtensions.Code(lang, body);
            replacementText = "<div style='padding:5px;'><b>" + lang + "</b></div>"+codeContainer.ToString();
            return replacementText;
        }
    }
}
