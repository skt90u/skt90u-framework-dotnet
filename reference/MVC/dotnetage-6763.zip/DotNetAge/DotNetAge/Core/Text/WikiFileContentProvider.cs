﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Web;

namespace DNA.Mvc.Text
{
    public class WikiFileContentProvider : IContentProvider
    {
        string _basePath = "~/shared/public/wiki/";

        public string BasePath
        {
            get { return _basePath; }
        }

        public WikiFileContentProvider() { }
        
        public WikiFileContentProvider(string basePath)
        {
            _basePath = basePath;
        }

        public Content Load(string pageName)
        {
            //  if (string.IsNullOrEmpty(url))
            //      throw
            string url = _basePath + pageName + ".cs";
            string filePath = HttpContext.Current.Server.MapPath(url);
            StreamReader reader = File.OpenText(filePath);
            Content content = new Content();
            content.Title = reader.ReadLine();
            string[] authorAndCreated = reader.ReadLine().Split(new char[] { '|' });
            content.Author = authorAndCreated[0];
            content.Created = DateTime.Parse(authorAndCreated[1]);
            reader.ReadLine();//##PAGE##
            content.Body = reader.ReadToEnd();
            reader.Close();
            return content;
        }

        public void Save(WiKiFileContent content)
        {
            StringBuilder fileContent = new StringBuilder();
            fileContent.AppendLine(content.Title)
                .AppendLine(content.Author + "|" + content.Created.ToString())
                .AppendLine(content.Body);
            File.WriteAllText(content.FileName, fileContent.ToString());
        }


        public string SnippetPath
        {
            get 
            {
                return HttpContext.Current.Server.MapPath("~/Shared/Public/Wiki/Snippets");
            }
        }

        #region IContentProvider 成员
        public string[] List()
        {
            string path=HttpContext.Current.Server.MapPath(_basePath);
            var _files=Directory.GetFiles(path);
            var _results = new List<string>();
            foreach (var p in _files)
                _results.Add(p.Replace(path,"").Replace(".cs",""));
            return _results.ToArray();
        }

        public Content Load(object contentKey)
        {
            return Load(contentKey.ToString());
        }

        public void Save(Content content)
        {
            if (content.GetType() != typeof(WiKiFileContent))
                throw new Exception("Only wiki file content can save to file.");
            Save((WiKiFileContent)content);
        }

        public IDictionary<string, string> AllSnippets()
        {
            IDictionary<string, string> snippets = new Dictionary<string, string>();
            string[] files = Directory.GetFiles(SnippetPath, "*.cs");
            foreach (string file in files)
                snippets.Add(Path.GetFileNameWithoutExtension(file), File.ReadAllText(file));
            return snippets;
        }

        public void AddSnippet(string name, string body)
        {
            File.WriteAllText(SnippetPath + "\\" + name + ".cs", body);
        }

        public void DeleteSnippet(string name)
        {
            string fileName=SnippetPath+"\\"+name+".cs";
            if (File.Exists(fileName))
                File.Delete(fileName);
        }

        public void EditSnippet(string name, string body)
        {
            DeleteSnippet(name);
            AddSnippet(name, body);
        }

        #endregion
    }
}
