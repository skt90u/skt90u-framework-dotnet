﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DNA.Mvc.Text
{
    public interface IContentProvider
    {
        string[] List();

        Content Load(object contentKey);

        void Save(Content content);

        IDictionary<string, string> AllSnippets();

        void AddSnippet(string name,string body);

        void DeleteSnippet(string name);

        void EditSnippet(string name, string body);
    }
}
