﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Text;
using System.Text.RegularExpressions;
using System.Web.Mvc;
using System.Web.UI;
using System.IO;
using System.Web.Script.Serialization;
using System.Reflection;
using DNA.Mvc.Models;

namespace DNA.Mvc.Text
{
    public class WikiMarkupParser : MarkupParser
    {
        /// <summary>
        /// The format list marco
        /// </summary>
        public void FormatList()
        {
            Match match = Match();
            StringBuilder sb = new StringBuilder(ContentText);

            while (match.Success)
            {
                int end = match.Index + match.Length;
                sb.Remove(match.Index, match.Length);
                int d = 0;
                try
                {
                    sb.Insert(match.Index, GenerateList(match.Value.Split(new char[] { '\n' }, StringSplitOptions.RemoveEmptyEntries), 0, 0, ref d) + "\n");
                }
                catch
                {
                    sb.Insert(match.Index, @"<b style=""color: #FF0000;"">FORMATTER ERROR (Malformed List)</b>");
                }
                match = Match(sb.ToString(), end);
            }
            ContentText = sb.ToString();
        }

        private string GenerateList(string[] lines, int line, int level, ref int currLine)
        {
            StringBuilder sb = new StringBuilder();
            if (lines[currLine][level] == '*') sb.Append("<ul>");
            else if (lines[currLine][level] == '#') sb.Append("<ol>");
            while (currLine <= lines.Length - 1 && CountBullets(lines[currLine]) >= level + 1)
            {
                if (CountBullets(lines[currLine]) == level + 1)
                {
                    sb.Append("<li>");
                    sb.Append(lines[currLine].Substring(CountBullets(lines[currLine])).Trim());
                    sb.Append("</li>");
                    currLine++;
                }
                else
                {
                    sb.Remove(sb.Length - 5, 5);
                    sb.Append(GenerateList(lines, currLine, level + 1, ref currLine));
                    sb.Append("</li>");
                }
            }
            if (lines[line][level] == '*') sb.Append("</ul>");
            else if (lines[line][level] == '#') sb.Append("</ol>");
            return sb.ToString();
        }

        private static int CountBullets(string line)
        {
            int res = 0, count = 0;
            while (line[count] == '*' || line[count] == '#')
            {
                res++;
                count++;
            }
            return res;
        }

        public void FormatUser()
        {
            ScanText(FormatUserCore);
        }

        private string FormatUserCore(Match match)
        {
            string userName = "-";
            if (HttpContext.Current.Request.IsAuthenticated)
                userName = HttpContext.Current.User.Identity.Name;
            return Current.Replace(ContentText, "<a>" + userName + "</a>");
        }

        /// <summary>
        ///  Format the code area
        /// </summary>
        public void FormatCodeBlock()
        {
            ScanText(FormatCodeBlockCore);
        }
       
        private string FormatCodeBlockCore(Match match)
        {
            string replacementText = "";
            if (match.Value.StartsWith("{{{"))
            {
                replacementText = CodeFormatterExtensions.Code("c#", match.Result("$1"));
            }
            else
            {
                string lang = match.Result("$1");
                string body = match.Result("$2");
                TagBuilder codeContainer = new TagBuilder("div");
                codeContainer.AddCssClass("ui-corner-all ui-widget-content ui-state-highlight");
                codeContainer.InnerHtml = CodeFormatterExtensions.Code(lang, body);
                replacementText = codeContainer.ToString();
            }
            return replacementText;
        }

        private string FormatImageUrlCore(Match match)
        {
            string title = match.Groups["title"].Value;
            string path = match.Groups["url"].Value;
            if (path.StartsWith("{UP}"))
                path = path.Replace("{UP}", WebContext.Current.Web.GetWebRootUri().ToString());
            string url = path;

            //if ((!path.StartsWith("http:")) && (!path.StartsWith("ftp:")) && (!path.StartsWith("https:")))
            //{
            //    //url = VirtualPathUtility.ToAbsolute("~/FileSharing/GetFile") + "?path=webfile://";
            //    //url = url + path;

            //}
            return "<img src=\"" + url + "\" alt=\"" + title + "\" />";
        }

        /// <summary>
        /// Format the [img] tag
        /// </summary>
        public void FormatImageUrl()
        {
            ScanText(FormatImageUrlCore);
        }

        /// <summary>
        /// Generate the toc table on the top of the article.
        /// </summary>
        /// <remarks>
        /// When using this marco the parser file must have Header tag defination
        /// Named:Header1 ,Header2, Header3, Header4
        /// </remarks>
        public void FormatToc()
        {
            ///UNDONE:This marco only can parse h1
            var h1 = Markup("Header1");
            var h2 = Markup("Header2");
            //var h3 = Markup("Header3");
            //var h4 = Markup("Header4");
            var sb = new StringBuilder(ContentText);
            var hPos = DetectedHeaders(ContentText, 0, h1);

            //插入A标记
            int offset = 0;
            var contents = new TagBuilder("div");
            contents.AddCssClass("dna-wiki-toc");
            var headerBuilder = new TagBuilder("ul");//CreateUL();
            //headerBuilder.AddCssClass("ui-helper-reset ui-widget-conent ui-corner-all tablecontent");

            for (int i = 0; i < hPos.Count; i++)
            {
                var _pos = hPos[i];
                TagBuilder li = CreateLI(_pos.Title, _pos.Id);
                li.AddCssClass("dna-wiki-toc");
                //int extLength = 0;
                //if ((i + 1) < hPos.Count)
                //{
                //    string _txt = GetText(_pos, hPos[i + 1], sb.ToString(), extLength);
                //    var h2Pos = DetectedHeaders(_txt, 1, h2);
                //    if (h2Pos.Count > 0)
                //    {
                //        var ul2 = CreateUL();
                //        foreach (var h2p in h2Pos)
                //        {
                //            h2p.InsertTag(ref sb, ref extLength);
                //            ul2.InnerHtml += CreateLI(h2p.Title, h2p.Id);
                //        }
                //        li.InnerHtml += ul2.ToString();
                //    }
                //}
                _pos.InsertTag(ref sb, ref offset);
                //offset += extLength;
                headerBuilder.InnerHtml += li.ToString();
            }

            //创建Table contents
            ContentText = sb.ToString();
            var contentHeader = new TagBuilder("h3");
            contentHeader.InnerHtml = "Contents";
            contentHeader.AddCssClass("dna-wiki-toc");
            //contentHeader.MergeAttribute("style","border-bottom:1px solid #cccccc;margin:0px;padding:10px;margin-left:5px;margin-right:5px;");
            contents.InnerHtml =contentHeader.ToString()+ headerBuilder.ToString();
            Replace(contents.ToString());
        }

        private string GetText(HeaderPosition pos1, HeaderPosition pos2, string input, int offset)
        {
            int startAt = pos1.End + offset;
            int length = 0;

            if (pos2 != null)
                length = pos2.StartAt + offset;
            else
                length = input.Length - (pos1.End + offset);

            if ((length + startAt) > input.Length)
                return input.Substring(startAt);
            else
                return input.Substring(startAt, length);
        }

        private List<HeaderPosition> DetectedHeaders(string input, int level, Markup headerMarkup)
        {
            List<HeaderPosition> hPos = new List<HeaderPosition>();
            var match = headerMarkup.GetMatch(input);
            int count = 0;
            int end = 0;

            string prefix = Guid.NewGuid().ToString().Substring(0, 5) + "_" + level.ToString();
            while (match.Success)
            {
                end = match.Index + match.Length;
                string title = match.Result("$1");

                if ((!title.StartsWith("=")) && (!title.StartsWith("!")))
                {
                    hPos.Add(new HeaderPosition()
                    {
                        Index = count++,
                        Length = match.Length,
                        Prefix = prefix,
                        Title = title,
                        StartAt = match.Index
                    });
                }
                match = headerMarkup.GetMatch(input, end);
            }
            return hPos;
        }

        internal class HeaderPosition
        {
            internal int Index { get; set; }
            internal int StartAt { get; set; }
            internal string Title { get; set; }
            internal int Length { get; set; }
            internal string Prefix { get; set; }
            internal int End { get { return StartAt + Length; } }
            public string Id
            {
                get
                {
                    return Prefix + "_" + Index.ToString();
                }
            }

            public void InsertTag(ref StringBuilder sb, ref int offset)
            {
                TagBuilder a = new TagBuilder("a");
                //a.GenerateId(Id);
                a.Attributes.Add("name", Id);
                a.Attributes.Add("id", Id);
                sb.Insert(StartAt + offset, a.ToString() + "\n");
                offset += a.ToString().Length + 1;
            }
        }

        private TagBuilder CreateUL()
        {
            TagBuilder ul = new TagBuilder("ul");
            ul.MergeAttribute("class", "ui-helper-reset");

            return ul;
        }

        private TagBuilder CreateLI(string text, string id)
        {
            TagBuilder li = new TagBuilder("li");
            TagBuilder a = new TagBuilder("a");
            a.MergeAttribute("href", "#" + id);
            a.SetInnerText(text);
            li.InnerHtml = a.ToString();
            return li;
        }

        private string FormatPageUrlCore(Match match)
        {    
            string url = VirtualPathUtility.ToAbsolute("~/WiKi/" + match.Result("$1").Replace(".ashx", ""));
            string txt = match.Result("$2");
            TagBuilder link = new TagBuilder("a");
            link.MergeAttribute("href", url);
            link.SetInnerText(txt);
            return link.ToString();
        }

        public void FormatPageUrl()
        {
            ScanText(FormatPageUrlCore);
        }

        public void FormatSnippet()
        {
            var match = Match();
            string snippetName = match.Groups["name"].Value;
            string snippetParams = match.Groups["params"].Value;
            string[] _params = null;

            if (string.IsNullOrEmpty(snippetParams))
                _params = snippetParams.Split(new char[] { '|' });

            if (Snippets != null)
            {
                if (Snippets.ContainsKey(snippetName))
                {
                    StringBuilder sb = new StringBuilder();
                    if (_params != null)
                        sb.AppendFormat(Snippets[snippetName], _params);
                    else
                        sb.Append(Snippets[snippetName]);
                    Replace(sb.ToString());
                }
            }
        }
    }
}
