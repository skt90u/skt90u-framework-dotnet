﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Text;
using System.Text.RegularExpressions;
using System.Web.Mvc;

namespace DNA.Mvc.Text
{
    /// <summary>
    /// Use to format the text.
    /// </summary>
    public static class TextFormatterExtensions
    {
        /// <summary>
        /// Search the specified text and hight it.
        /// </summary>
        /// <param name="helper">The helper object</param>
        /// <param name="matchText">The text to search</param>
        /// <param name="raw">The raw text for search</param>
        /// <returns>The formatted text that including highlight text</returns>
        public static string Highlight(this HtmlHelper helper, string matchText, string raw)
        {
            if (string.IsNullOrEmpty(matchText))
                return raw;
            try
            {
                Regex regex = new Regex(matchText, RegexOptions.Compiled | RegexOptions.IgnoreCase);
                Match match = regex.Match(raw);
                //StringBuilder sb = new StringBuilder(raw);
                if (match.Success)
                    return regex.Replace(raw, "<span class='ui-state-highlight'>$0</span>");
            }
            catch { return raw; }
            return raw;
        }

        public static string ClearHtmlText(this HtmlHelper helper, string htmlString)
        {
            return TextUtility.ClearHtml(htmlString);
        }

        public static string ClearMakups(this HtmlHelper helper, string input)
        {
            return helper.ClearHtmlText(helper.FormatWiKi(input).ToHtmlString());
        }

    }
}
