﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Text;
using System.Text.RegularExpressions;
using System.Web.Mvc;
using System.Web.UI;
using System.IO;
using System.Web.Script.Serialization;
using System.Reflection;

namespace DNA.Mvc.Text
{
    public class Markup
    {
        public string Name { get; set; }

        public string Match { get; set; }

        public string Replacement { get; set; }

        public string Syntax { get; set; }

        public string Remarks { get; set; }

        public string Marco { get; set; }

        private bool _isMany = false;

        public bool IsExplicitly
        {
            get { return _isMany; }
            set { _isMany = value; }
        }

        public Regex Regex
        {
            get
            {
                if (regex == null)
                    regex = new Regex(this.Match, RegexOptions.Compiled | RegexOptions.IgnoreCase | RegexOptions.Multiline);
                return regex;
            }
        }

        private Regex regex;

        public string Format(string raw)
        {
            if (!string.IsNullOrEmpty(raw))
            {
                if (!string.IsNullOrEmpty(this.Match) && (!string.IsNullOrEmpty(Replacement)))
                {
                    if (Regex.Match(raw).Success)
                        return Regex.Replace(raw, this.Replacement);
                }
            }
            return raw;
        }

        public string FormatExplicitly(string raw)
        {
            var match = GetMatch(raw);
            int startIndex = 0;
            int length = 0;
            string formatted = "";
            string _raw = raw;
           
            while (match.Success)
            {
                length = (match.Index - startIndex);
                formatted += _raw.Substring(startIndex, length);

                formatted += Regex.Replace(formatted, this.Replacement);
                startIndex += (length + match.Length);
                match = match.NextMatch();
            }

            if (!string.IsNullOrEmpty(formatted))
            {
                if (_raw.Length > startIndex)
                    _raw = formatted + _raw.Substring(startIndex);
                else
                    _raw = formatted;
            }
            return _raw;
        }

        public Match GetMatch(string input)
        {
            return this.Regex.Match(input);
        }

        public Match GetMatch(string input, int startat)
        {
            return this.Regex.Match(input, startat);
        }

        public bool IsMatch(string input)
        {
            if (string.IsNullOrEmpty(input))
                return false;
            bool tmp= this.Regex.IsMatch(input);
            return tmp;
        }

        public string Replace(string input, string replacement)
        {
            return this.Regex.Replace(input, replacement);
        }
    }
}
