﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Mvc;
using System.Web;
using System.Web.UI;
using System.IO;
using System.Globalization;
using System.Drawing;
using System.Drawing.Imaging;
using Manoli.Utils.CSharpFormat;

namespace DNA.Mvc.Text
{
    public static class CodeFormatterExtensions
    {
        public static string Code(this HtmlHelper helper, string codetext)
        {
            return Code(Languages.Html, codetext);
        }

        public static string Code(this HtmlHelper helper, Languages language, string codetext)
        {
            return Code(language, codetext);
        }
        
        public static string Code(Languages language, string codetext)
        {
            SourceFormat format = CreateFormat(language);
            format.EmbedStyleSheet = false;
            return format.FormatCode(codetext);
        }
        
        public static string Code(string language, string codetext)
        {
            SourceFormat format = CreateFormat(language);
            format.EmbedStyleSheet = false;
            return format.FormatCode(codetext);
        }

        public static string Code(this HtmlHelper helper, string language, string codetext)
        {
            return Code(language, codetext);
        }

        public static string CodeFile(this HtmlHelper helper, string url)
        {
            return helper.CodeFile(Languages.Html, url);
        }

        public static string CodeFile(this HtmlHelper helper, string language, string url)
        {
            string text = File.ReadAllText(HttpContext.Current.Server.MapPath(url));
            return Code(language, text);
        }

        public static string CodeFile(this HtmlHelper helper, Languages language, string url)
        {
            string text = File.ReadAllText(HttpContext.Current.Server.MapPath(url));
            return Code(language, text);
        }

        public static SourceFormat CreateFormat(string language)
        {
            SourceFormat format = null;
            format = new HtmlFormat();
            if (language.ToLower().Trim() == "sql")
                format = new TsqlFormat();
            if ((language.ToLower().Trim() == "javascript") || (language.ToLower().Trim() == "js") || (language.ToLower().Trim() == "jscript"))
                format = new JavaScriptFormat();
            if ((language.ToLower().Trim() == "c#") || (language.ToLower().Trim() == "csharp"))
                format = new CSharpFormat();
            if ((language.ToLower().Trim() == "vb") || (language.ToLower().Trim() == "visualbasic") || (language.ToLower().Trim() == "vbscript"))
                format = new VisualBasicFormat();
            return format;
        }

        public static SourceFormat CreateFormat(Languages language)
        {
            SourceFormat format = null;
            switch (language)
            {
                case Languages.Csharp:
                    format = new CSharpFormat();
                    break;
                case Languages.MSH:
                    format = new MshFormat();
                    break;
                case Languages.TSQL:
                    format = new TsqlFormat();
                    break;
                case Languages.VB:
                    format = new VisualBasicFormat();
                    break;
                case Languages.Javascript:
                    format = new JavaScriptFormat();
                    break;
                default:
                    format = new HtmlFormat();
                    break;
            }
            return format;
        }


    }
}
