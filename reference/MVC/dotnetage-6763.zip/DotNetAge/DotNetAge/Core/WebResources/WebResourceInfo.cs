﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;

namespace DNA.Mvc
{
    /// <summary>
    /// Describe the web resource info.
    /// </summary>
    public class WebResourceInfo:INavigtable
    {
        /// <summary>
        /// Gets/Sets the resource uri.
        /// </summary>
        public Uri Url { get; set; }

        public WebResourceInfo(string url)
        {
            Url = new Uri(url);
        }

        public WebResourceInfo(Uri url) { Url = url; }

        /// <summary>
        /// Gets the resource owner
        /// </summary>
        public string Owner
        {
            get
            {
                if (Url.Host.ToLower() == "root")
                    return "";
                else
                    return Url.Host;
            }
        }

        private string contentType = "";

        /// <summary>
        /// Gets the resource content type.
        /// </summary>
        public string ContentType 
        {
            get 
            {
                if (IsFile)
                {
                    string mime = "application/octetstream";
                    Microsoft.Win32.RegistryKey rk = Microsoft.Win32.Registry.ClassesRoot.OpenSubKey(Extension);
                    if (rk != null && rk.GetValue("Content Type") != null)
                        mime = rk.GetValue("Content Type").ToString();
                    contentType= mime;
                }
                return contentType;
            }
        }
       
        /// <summary>
        /// Gets/Sets the resource size.
        /// </summary>
        public long FileSize 
        {
            get 
            {
                if (Url != null)
                {
                    var path = WebSite.CurrentWeb().MapPath(Url);
                    if (System.IO.File.Exists(path))
                    {
                        var f = new System.IO.FileInfo(path);
                        filesize = f.Length;
                    }
                    else
                        filesize = 0;
                }
                return filesize;
            }
            set 
            {
                filesize = value;
            }
        }
        private long filesize = 0;

        /// <summary>
        /// Gets wheather this resource is point to a file.
        /// </summary>
        public bool IsFile
        { 
            get{ return !string.IsNullOrEmpty(Extension);}
        }

        /// <summary>
        /// Gets the resource file name or path name.
        /// </summary>
        public string Name { get { return VirtualPathUtility.GetFileName(Url.LocalPath); } }

        /// <summary>
        /// Gets the resource file extension.
        /// </summary>
        public string Extension 
        {
            get { return VirtualPathUtility.GetExtension(Url.LocalPath).ToLower(); } 
        }

        string INavigtable.Title
        {
            get { return this.Name;}
        }

        string INavigtable.Description
        {
            get { return this.ContentType; }
        }

        string INavigtable.NavigateUrl
        {
            get { return this.Url.ToString(); }
        }

        string INavigtable.ImageUrl
        {
            get { return ""; }
        }

        string INavigtable.Target
        {
            get { return "_self"; }
        }

        object INavigtable.Value
        {
            get { return this.Url; }
        }
    }
}
