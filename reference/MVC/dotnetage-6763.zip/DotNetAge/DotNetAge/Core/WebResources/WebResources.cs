﻿//  Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using DNA.Mvc.DynamicUI;
using DNA.Mvc.OpenAPI.Rss;


namespace DNA.Mvc
{
    /// <summary>
    /// This is a wapper class to provides the methods to control the web resources
    /// </summary>
    public static class WebResources
    {
        private static IWebResourceService Service
        {
            get { return WebSite.WebRes; }
        }


        /// <summary>
        /// Deletes the specified file. 
        /// </summary>
        /// <param name="url">Specified the resource uri to delete.</param>
        /// <example>
        ///   //Delete the root files
        ///   Service.DeleteFile("webfile://root:/doc/readme.txt");
        ///   //Delete the personal files
        ///   Service.DeleteFile("webfile://ray/doc/readme.txt");
        /// </example>
        public static void Delete(Uri url)
        {
            Service.Delete(url);
        }


        /// <summary>
        /// Create the parth for specified uri.
        /// </summary>
        /// <param name="url">The directory path to create.</param>
        public static void CreatePath(Uri url)
        {
            Service.CreatePath(url);
        }

        /// <summary>
        ///  Save the data to destaintion path.
        /// </summary>
        /// <param name="data">The raw data of file.</param>
        /// <param name="fileName"></param>
        /// <param name="destURI">the specified destaintion path where to save.</param>
        /// <returns>The saved resource uri.</returns>
        public static Uri SaveFile(byte[] data, string fileName, Uri destURI)
        {
            return SaveFile(data, fileName, destURI);
        }

        /// <summary>
        /// Save the posted file to specified destaintion.
        /// </summary>
        /// <param name="file">The HttpPostedFile object</param>
        /// <param name="destURI">the specified destaintion path where to save.</param>
        /// <returns>The saved resource uri.</returns>
        public static Uri SaveFile(HttpPostedFileBase file, Uri destURI)
        {
            return SaveFile(FileUtilty.ReadStream(file.InputStream), System.IO.Path.GetFileName(file.FileName), destURI);
        }

        /// <summary>
        ///  Move a file or a directory and its contents to a new location.
        /// </summary>
        /// <param name="sourceURI"> The path of the file or directory to move.</param>
        /// <param name="destURI">The path to the new location for sourceURI</param>
        public static void Move(Uri sourceURI, Uri destURI)
        {
            Service.Move(sourceURI,destURI);
        }

        /// <summary>
        /// Get the file's raw data for specified filename
        /// </summary>
        /// <param name="url">The uri of the resource file</param>
        /// <returns>A byte array contains the file raw data.</returns>
        public static byte[] Open(Uri url)
        {
            return Service.Open(url);
        }


        /// <summary>
        /// Gets the file info objects by the specified path.
        /// </summary>
        /// <param name="url">The specified path</param>
        /// <returns>A collection contains resource uri.</returns>
        public static IEnumerable<Uri> GetFiles(Uri url)
        {
            return Service.GetFiles(url);
        }

        /// <summary>
        ///  Gets the sub path uris by the specified path.
        /// </summary>
        /// <param name="url">The specified path.</param>
        /// <returns>A collection contains resource path uri.</returns>
        public static IEnumerable<Uri> GetPaths(Uri url)
        {
            return Service.GetPaths(url);
        }
    }
}