﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Mvc;
using System.Web;
using System.Web.UI;
using System.IO;
using System.Globalization;
using System.Drawing;
using System.Drawing.Imaging;
using DNA.Mvc.jQuery;

namespace DNA.Mvc
{
    public static class WebResourceExtensions
    {

        #region ImageResource extensions

        /// <summary>
        /// Render a img html element that can auto fit the image size after the image loaded.And this img can accept
        /// the webresource uri.
        /// </summary>
        /// <param name="helper">The ajax helper object</param>
        /// <param name="url">Specified the image file resource file. i.e : 'webfile://root/image/logo.jpg' </param>
        /// <param name="maxWidth">Specified the max width of the image.</param>
        /// <param name="maxHeight">Specified the max height of the image</param>
        /// <param name="htmlAttributes">The html attributes object.</param>
        /// <returns>The html elements for img.</returns>
        public static MvcHtmlString ImageResource(this AjaxHelper helper, Uri url, int maxWidth, int maxHeight, object htmlAttributes)
        {
            return ImageResourceCore(url, maxWidth, maxHeight, htmlAttributes);
        }

        internal static MvcHtmlString ImageResourceCore(Uri url, int maxWidth, int maxHeight, object htmlAttributes)
        {
            var file = new WebResourceInfo(url);
            TagBuilder imgTag = new TagBuilder("img");
            if (htmlAttributes != null)
                imgTag.MergeAttributes<string, object>(ObjectHelper.ConvertObjectToDictionary(htmlAttributes));

            imgTag.Attributes.Add("src", file.Url.ToString());

            if (file.ContentType.StartsWith("image"))
            {
                imgTag.MergeAttribute("style", "cursor:pointer");
                imgTag.MergeAttribute("onclick", "uiHelper.previewBox('" + file.Name + "','" + imgTag.Attributes["src"] + "');");
                imgTag.MergeAttribute("onload", "if ($(this).width()>" + maxWidth.ToString() + ") $(this).width(" + maxWidth.ToString() + ");if ($(this).height()>" + maxHeight.ToString() + ") $(this).height(" + maxHeight.ToString() + ");");
            }
            string imageString = System.Web.HttpContext.Current.Server.HtmlDecode(imgTag.ToString(TagRenderMode.SelfClosing));
            return MvcHtmlString.Create(imageString);
        }

        /// <summary>
        /// Render a img html element that can auto fit the image size after the image loaded.
        /// And this img can accept the webresource uri. 
        /// </summary>
        /// <param name="helper">The ajax helper object</param>
        /// <param name="url">Specified the image file resource file. i.e : 'webfile://root/image/logo.jpg' </param>
        /// <param name="htmlAttributes">The html attributes object.</param>
        /// <returns>The html elements for img.</returns>
        public static MvcHtmlString ImageResource(this AjaxHelper helper, Uri url, object htmlAttributes)
        {
            return helper.ImageResource(url, 64, 64, htmlAttributes);
        }

        /// <summary>
        /// Render a img html element that can auto fit the image size after the image loaded.
        /// And this img can accept the webresource uri.
        /// </summary>
        /// <param name="helper">The ajax helper object</param>
        /// <param name="url">Specified the image file resource file. i.e : 'webfile://root/image/logo.jpg' </param>
        /// <returns>The html elements for img.</returns>
        public static MvcHtmlString ImageResource(this AjaxHelper helper, Uri url)
        {
            return helper.ImageResource(url, 64, 64, null);
        }

        #endregion

        #region ResourceLink extensions

        /// <summary>
        /// Render a link element that link to the specified web resouce.
        /// </summary>
        /// <param name="helper">The ajax helper object</param>
        /// <param name="uri">Specified the web resource uri.</param>
        /// <returns>The link html element.</returns>
        public static MvcHtmlString ResourceLink(this AjaxHelper helper, Uri uri)
        {
            return helper.ResourceLink(string.Empty, uri, null);
        }

        /// <summary>
        ///  Render a link element that link to the specified web resouce.
        /// </summary>
        /// <param name="helper">The ajax helper object</param>
        /// <param name="uri">Specified the web resource uri.</param>
        /// <param name="htmlAttributes">Specified the link element html attributes.</param>
        /// <returns>The link html element.</returns>
        public static MvcHtmlString ResourceLink(this AjaxHelper helper, Uri uri, object htmlAttributes)
        {
            return helper.ResourceLink(string.Empty, uri, htmlAttributes);
        }

        /// <summary>
        ///  Render a link element that link to the specified web resouce.
        /// </summary>
        /// <param name="helper">The ajax helper object</param>
        /// <param name="text">Specified the link text.</param>
        /// <param name="uri">Specified the web resource uri.</param>
        /// <param name="htmlAttributes">Specified the link element html attributes.</param>
        /// <returns>The link html element.</returns>
        public static MvcHtmlString ResourceLink(this AjaxHelper helper, string text, Uri uri, object htmlAttributes)
        {
            TagBuilder link = new TagBuilder("a");
            if (htmlAttributes != null)
                link.MergeAttributes<string, object>(ObjectHelper.ConvertObjectToDictionary(htmlAttributes));
            var file = new WebResourceInfo(uri);
            link.Attributes.Add("src", file.Url.ToString());
            link.Attributes.Add("target", "_blank");
            link.InnerHtml = string.IsNullOrEmpty(text) ? file.Name : text;
            return MvcHtmlString.Create(link.ToString());
        }

        #endregion

        public static string FileListView(this AjaxHelper helper, string name, string path, ListViewOptions options)
        {
            TagBuilder tag = new TagBuilder("div");
            tag.GenerateId(name);
            tag.Attributes.Add("style", "overflow: scroll; height: 100%; width: 100%;");
            var fileUris = WebResources.GetFiles(new Uri(path));
            var nodes = new List<INavigtable>();
            if (fileUris != null)
            {
                foreach (var fileUri in fileUris)
                    nodes.Add(new WebResourceInfo(fileUri));

                var builder = new ListViewNodeUIBuilder();
                builder.WriteNodes(nodes);
                tag.InnerHtml = builder.ToString();
            }
            options.ItemField = ">ul>li";
            jQueryExtensions.jQuery(helper, "#" + name, "listview", options);
            return tag.ToString();
        }
    }
}
