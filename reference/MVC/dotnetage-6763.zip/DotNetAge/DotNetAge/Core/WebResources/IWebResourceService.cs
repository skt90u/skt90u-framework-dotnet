﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DNA.Mvc
{
    /// <summary>
    /// Defines the methods to mulit the web resource file.
    /// </summary>
     public interface IWebResourceService
    {
        /// <summary>
        /// Deletes the specified file. 
        /// </summary>
        /// <param name="url">Specified the resource uri to delete.</param>
        /// <example>
        ///   //Delete the root files
        ///   Service.DeleteFile("webfile://root:/doc/readme.txt");
        ///   //Delete the personal files
        ///   Service.DeleteFile("webfile://ray/doc/readme.txt");
        /// </example>
        void Delete(Uri url);

         /// <summary>
         /// Map the uri to the server path.
         /// </summary>
         /// <param name="url"></param>
        string MapPath(Uri url);

        /// <summary>
        /// Create the parth for specified uri.
        /// </summary>
        /// <param name="url">The directory path to create.</param>
        void CreatePath(Uri url);

        /// <summary>
        ///  Save the data to destaintion path.
        /// </summary>
        /// <param name="data">The raw data of file.</param>
        /// <param name="fileName"></param>
        /// <param name="destURI">the specified destaintion path where to save.</param>
        Uri SaveFile(byte[] data,string fileName,Uri destURI);

        /// <summary>
        ///  Move a file or a directory and its contents to a new location.
        /// </summary>
        /// <param name="sourceURI"> The path of the file or directory to move.</param>
        /// <param name="destURI">The path to the new location for sourceURI</param>
        void Move(Uri sourceURI, Uri destURI);

        /// <summary>
        /// Get the file's raw data for specified filename
        /// </summary>
        /// <param name="url">The uri of the resource file</param>
        /// <returns>A byte array contains the file raw data.</returns>
        byte[] Open(Uri url);


        /// <summary>
        /// Gets the file info objects by the specified path.
        /// </summary>
        /// <param name="url">The specified path</param>
        /// <returns>A collection contains resource uri.</returns>
        IEnumerable<Uri> GetFiles(Uri url);

        /// <summary>
        ///  Gets the sub path uris by the specified path.
        /// </summary>
        /// <param name="url">The specified path.</param>
        /// <returns>A collection contains resource path uri.</returns>
        IEnumerable<Uri> GetPaths(Uri url);
    }
}
