//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Web.Configuration;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using DNA.Mvc.Installation;
using DNA.Mvc.Models;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Web.Security;
using DNA.IO.Compress;
using System.Xml;
using DNA.Mvc.jQuery;

namespace DNA.Mvc.Controllers
{
    [Localization]
    [HandleError]
    public class InstallationController : Controller
    {
        [HostAuthorize]
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult LogOn()
        {
            if (string.IsNullOrEmpty(WebHost.Config.Deployment.HostPassword))
            {
                //WebHost.Config.Deployment.PublicKeyToken = WebHost.GenerateTokenKey(24);
                //WebHost.UpdateConfig();
                string tokenKey = WebHost.GenerateTokenKey(4);
                DeploymentHelper.UpdateWebConfig("/configuration/dna/deploy", "password", tokenKey, "web.config");
            }
            return View();
        }

        //[ValidateAntiForgeryToken]
        //[HostAuthorize]
        //[HttpPost]
        //public ActionResult ConfigDB(SQLInstallationModel sqlSettings)
        //{
        //    ViewData.Model = sqlSettings;

        //    string conStr = "";
        //    string adminConstr = "";

        //    try
        //    {
        //        conStr = sqlSettings.GenerateConnectionString();
        //        if ((!sqlSettings.IsGenerateConnectionOnly) && (sqlSettings.DataBaseEngine.Equals("sqlserver", StringComparison.OrdinalIgnoreCase)))
        //            adminConstr = sqlSettings.GenerateSQLAdminConnectionString();
        //        else
        //            adminConstr = conStr;
        //    }
        //    catch (Exception e)
        //    {
        //        ViewData["Error"] ="Open SQLServer connection fail. The details message is:"+"\t\n"+ e.Message;
        //        return View();
        //    }

        //    var dnaStr = "metadata=res://*/Models.DNADB.csdl|res://*/Models.DNADB.ssdl|res://*/Models.DNADB.msl;provider=System.Data.SqlClient;provider connection string=\"" + conStr.ToString() + "MultipleActiveResultSets=True;\"";
        //    var authStr = "metadata=res://*/Areas.Publishing.Models.PubDB.csdl|res://*/Areas.Publishing.Models.PubDB.ssdl|res://*/Areas.Publishing.Models.PubDB.msl;provider=System.Data.SqlClient;provider connection string=\"" + conStr.ToString() + "MultipleActiveResultSets=True\"";
        //    var forumStr = "metadata=res://*/Areas.Community.Models.ForumsDB.csdl|res://*/Areas.Community.Models.ForumsDB.ssdl|res://*/Areas.Community.Models.ForumsDB.msl;provider=System.Data.SqlClient;provider connection string=\"" + conStr.ToString() + "MultipleActiveResultSets=True\"";

        //    if (!sqlSettings.IsGenerateConnectionOnly)
        //    {
        //        //Check admin connection avalidable
        //        using (var conn = new SqlConnection(adminConstr))
        //        {
        //            try
        //            {
        //                conn.Open();
        //            }
        //            catch (Exception e)
        //            {
        //                ViewData["Error"] ="Open SQLServer connection fail. The details message is:"+"\t\n" +e.Message;
        //                return View();
        //            }

        //            //string instalSQL = Server.MapPath("~/install.sql");
        //            var installSQLs = new List<string>();
        //            string installationPath = Server.MapPath("~/packages/sql/1.1/");

        //            /* Installation scripts for v1.0.3895
        //            if ((sqlSettings.IsCreateNewInstance) && (sqlSettings.DataBaseEngine.Equals("sqlserver", StringComparison.OrdinalIgnoreCase)))
        //                installSQLs.Add(installationPath + "createdb.sql");

        //            installSQLs.Add(installationPath + "aspnetdb.sql");
        //            installSQLs.Add(installationPath + "dnatables.sql");
        //            installSQLs.Add(installationPath + "data.sql");*/

        //            /*-------------------  Install the aspnet_db   --------------------*/

        //            installSQLs.Add(installationPath + "aspnet_common.sql");
        //            installSQLs.Add(installationPath + "aspnet_membership.sql");
        //            installSQLs.Add(installationPath + "aspnet_profile.sql");
        //            installSQLs.Add(installationPath + "aspnet_roles.sql");

        //            /*--------------------   Install dna db   --------------------------*/

        //            installSQLs.Add(installationPath + "dna_core.sql");
        //            installSQLs.Add(installationPath + "dna_publishing.sql");
        //            installSQLs.Add(installationPath + "dna_community.sql");
        //            installSQLs.Add(installationPath + "dna_data.sql");

        //            foreach (var installSQL in installSQLs)
        //            {
        //                var sqls = DeploymentHelper.ReadSQLCommandBlocksFromFile(installSQL);
        //                foreach (var sql in sqls)
        //                {

        //                    var _sql = sql;
        //                    if (sql.IndexOf("PlaceholderForDbName") > 0)
        //                        _sql = sql.Replace("PlaceholderForDbName", sqlSettings.DataBaseName);
        //                    try
        //                    {
        //                        if (sqlSettings.DataBaseEngine.Equals("sqldatafile", StringComparison.OrdinalIgnoreCase))
        //                        {
        //                            //SQLExpress does not support "Use [database]"
        //                            if (_sql.StartsWith("use", StringComparison.OrdinalIgnoreCase))
        //                                continue;
        //                        }

        //                        DeploymentHelper.RunSQLCommand(conn, _sql);
        //                    }
        //                    catch (Exception sqlexeption)
        //                    {
        //                        ViewData["Error"] ="There is an error occur when executing the sql installation script the detail message is :"+ sqlexeption.Message;
        //                        return View();
        //                    }
        //                }
        //            }

        //        }
        //    }
        //    else
        //    {
        //        //Check target db connection avalidable.
        //        using (var conn = new SqlConnection(conStr.ToString()))
        //        {
        //            try
        //            {
        //                conn.Open();
        //            }
        //            catch (Exception e)
        //            {
        //                ViewData["Error"] = e.Message;
        //                return View();
        //            }
        //        }
        //    }

        //    //Replace the web.config
        //    DeploymentHelper.UpdateWebConfig("/configuration/connectionStrings/add[@name='ApplicationServices']", "connectionString", conStr.ToString(), "Web.config");
        //    DeploymentHelper.UpdateWebConfig("/configuration/connectionStrings/add[@name='DNAEntities']", "connectionString", dnaStr, "Web.config");
        //    DeploymentHelper.UpdateWebConfig("/configuration/connectionStrings/add[@name='PubDBEntities']", "connectionString", authStr, "Web.config");
        //    DeploymentHelper.UpdateWebConfig("/configuration/connectionStrings/add[@name='iForumDBEntities']", "connectionString", forumStr, "Web.config");
        //    DeploymentHelper.UpdateWebConfig("/configuration/dna/deploy", "database", sqlSettings.DataBaseName, "web.config");

        //    //If the widget not load that will cause some template could not create widgets.
        //    //DNA.Mvc.DynamicUI.WidgetLoader.Load();

        //    return RedirectToAction("SiteTemplate");
        //}

        //[HostAuthorize]
        //public ActionResult ConfigDB()
        //{
        //    return View();
        //}

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult LogOn(LogOnModel model, string returnUrl)
        {
            if (ModelState.IsValid)
            {
                if (WebHost.Config.Deployment.HostPassword.Equals(model.Password))
                {
                    FormsAuthentication.SetAuthCookie("host", false);
                    if (!String.IsNullOrEmpty(returnUrl))
                    {
                        return Redirect(returnUrl);
                    }
                    else
                    {
                        if (!WebHost.IsInstalled)
                            return RedirectToAction("SiteTemplate");
                        // return RedirectToAction("ConfigDB");
                        else
                            return RedirectToAction("Index", "Installation");
                    }
                }
                else
                {
                    ModelState.AddModelError("", "User name or passoword not found.");
                }
            }
            return View(model);
        }

        [HostAuthorize]
        public ActionResult LanguagePack()
        {
            return View();
        }

        public ActionResult Packs(string name)
        {
            var d = new DirectoryInfo(ControllerContext.HttpContext.Server.MapPath("~/App_GlobalResources/" + name));
            ViewData["Dir"] = d;
            ViewData.Model = d.GetFiles();
            return View();
        }

        private string GetContentType(string extension)
        {
            string mime = "application/octetstream";
            Microsoft.Win32.RegistryKey rk = Microsoft.Win32.Registry.ClassesRoot.OpenSubKey(extension);
            if (rk != null && rk.GetValue("Content Type") != null)
                mime = rk.GetValue("Content Type").ToString();
            return mime;
        }

        public FileResult ZipFile(string file, string package)
        {
            string root = "~/Shared/packages";
            string pkgFile = "";

            if (!package.StartsWith("/"))
                pkgFile = "/" + package;
            else
                pkgFile = package;
            pkgFile = Server.MapPath(root + pkgFile + ".zip");

            string extension = System.IO.Path.GetExtension(file);

            try
            {
                if (System.IO.File.Exists(pkgFile))
                {
                    var zip = new ZipExtract(pkgFile);
                    var stream = new System.IO.MemoryStream();
                    zip.ExtractSingleFile(file, stream);
                    zip.Dispose();
                    stream.Position = 0;
                    return File(stream, GetContentType(extension));
                }
            }
            catch { return File(new byte[0], "application/octetstream"); }
            return File(new byte[0], "application/octetstream");
        }

        [HostAuthorize]
        [AcceptVerbs(HttpVerbs.Post)]
        [ValidateAntiForgeryToken]
        public ActionResult LanguagePack(FormCollection form)
        {
            return View();
        }

        /// <summary>
        /// Upload the package to the tempory directory
        /// </summary>
        /// <param name="forms"></param>
        /// <returns></returns>
        [HttpPost]
        [HostAuthorize]
        public ActionResult UploadLanguage(string name, FormCollection forms)
        {
            if (string.IsNullOrEmpty(name))
                throw new ArgumentNullException("name");
            if (HttpContext.Request.Files.Count > 0)
            {
                var root = HttpContext.Server.MapPath("~/App_GlobalResources/");
                var zip = new ZipExtract(HttpContext.Request.Files[0].InputStream);

                if (name == ".")
                    zip.ExtractTo(root);
                else
                    zip.ExtractTo(root + name + "\\");
            }
            return RedirectToAction("Packs", new { name = name });
        }

        [HostAuthorize]
        public ActionResult DownloadLanguage(string name, string lang)
        {
            if (string.IsNullOrEmpty(name))
                throw new ArgumentNullException("name");
            if (HttpContext.Request.Files.Count > 0)
            {
                string mapRoot = HttpContext.Server.MapPath("~/App_GlobalResources/" + name + "/");
                var zip = new ZipCompress() { Root = mapRoot };
                if ((lang == "en-US") || (string.IsNullOrEmpty(lang)))
                    zip.AddFile(mapRoot + name + ".resx");
                else
                    zip.AddFile(mapRoot + name + "." + lang + ".resx");
                var stream = zip.Compress();
                return File(stream, "application/x-zip-compressed", name + "_" + lang + ".zip");
            }
            throw new FileNotFoundException();
        }

        [HttpPost]
        [HostAuthorize]
        [ValidateAntiForgeryToken]
        public ActionResult Themes(FormCollection forms)
        {
            if (HttpContext.Request.Files.Count > 0)
            {
                var root = HttpContext.Server.MapPath("~/Content/Themes/");
                if (HttpContext.Request.Files.Count > 0)
                {
                    var zip = new ZipExtract(HttpContext.Request.Files[0].InputStream);
                    var files = zip.ReadFiles();
                    if (files.Count() > 0)
                    {
                        if (!files.Contains("manifest.xml"))
                        {
                            ViewData["Error"] = "Could not found the manifest.xml file in the upload theme package.";
                            return Themes();
                        }
                        else
                        {
                            try
                            {
                                var mainifestXmlText = zip.ReadFileAsText("manifest.xml");
                                var package = (PackageDescriptor)DNA.Utility.XmlSerializerUtility.DeserializeFromXmlText(mainifestXmlText, typeof(PackageDescriptor));
                                if (string.IsNullOrEmpty(package.Name))
                                {
                                    ViewData["Error"] = "manifest.xml file define error: The package name is required.";
                                    return Themes();
                                }
                                if (!System.IO.Directory.Exists(root + package.Name))
                                    System.IO.Directory.CreateDirectory(root + package.Name);
                                zip.ExtractTo(root + package.Name + "\\");
                            }
                            catch (Exception e)
                            {
                                ViewData["Error"] = e.Message;
                                return Themes();
                            }
                        }
                    }
                    else
                    {
                        ViewData["Error"] = "The package has no file.";
                    }
                }
            }

            return Themes();
        }

        [HostAuthorize]
        public ActionResult SiteTemplate()
        {
            //ViewData.Model = DeploymentHelper.LoadPackages(HttpContext.Server.MapPath("~/Shared/packages/public"));
            return View();
        }

        [HostAuthorize]
        [Pagable]
        public ActionResult GetPackages()
        {
            var pkgs = DeploymentHelper.LoadPackages(HttpContext.Server.MapPath("~/Shared/packages/public"));
            return View(new ModelWrapper()
            {
                Model = pkgs,
                Total = pkgs.Count()
            });
        }

        [HttpPost]
        [HostAuthorize]
        [ValidateAntiForgeryToken]
        public ActionResult SiteTemplate(string package)
        {
            if (!string.IsNullOrEmpty(package))
            {
                string file = HttpContext.Server.MapPath("~/Shared/packages/public/" + package + ".zip");
                var vPath = HttpContext.Request.ApplicationPath;
                if (!vPath.EndsWith("/"))
                    vPath += "/";

                string[] admins = System.Web.Security.Roles.GetUsersInRole("administrators");

                DeploymentHelper.Deploy(file, new
                {
                    name = "home",
                    title = "Your web site title",
                    description = "Your web site  description.",
                    appPath = vPath,
                    owner = admins[0]
                });
                DeploymentHelper.UpdateWebConfig("/configuration/dna/deploy", "installed", "true", "Web.config");
                DeploymentHelper.RestartWeb();
                FormsAuthentication.SignOut();
                return Redirect(Url.Action("Index", "Home"));
            }
            return View();
        }

        //[HostAuthorize]
        //public ActionResult SiteSetup()
        //{
        //    ViewData.Model = DeploymentHelper.LoadPackages(HttpContext.Server.MapPath("~/App_Data/packages/public"));
        //    return View();
        //}

        [HostAuthorize]
        public ActionResult CollectBase(string id)
        {
            //if (!string.IsNullOrEmpty(id))
            //{
            //    string file = HttpContext.Server.MapPath("~/packages/apps/" + id + ".zip");
            //    ViewData.Model= DeploymentHelper.ReadPackage(file);
            //}
            return View();
        }

        //public ActionResult CollectBase(string id,Web web)
        //{
        //    if (!string.IsNullOrEmpty(id))
        //    {
        //        string file = HttpContext.Server.MapPath("~/packages/apps/" + id + ".zip");
        //        DeploymentHelper.Deploy(file);
        //    }
        //    return RedirectToAction("Finish");
        //}

        [HostAuthorize]
        public ActionResult Finish()
        {
            DeploymentHelper.UpdateWebConfig("/configuration/dna/deploy", "installed", "true", "Web.config");
            DeploymentHelper.RestartWeb();
            FormsAuthentication.SignOut();
            return View();
            //return RedirectToAction("Index","Home");
        }

        ///// <summary>
        ///// Get the installed/wait for install package info detail
        ///// </summary>
        ///// <returns></returns>
        //public ActionResult Info(int id)
        //{
        //    ViewData.Model = Service.GetPackageInfo(id);
        //    return View();
        //}

        [HostAuthorize]
        public ActionResult Themes()
        {
            var themePath = HttpContext.Server.MapPath("~/Content/Themes/");
            var dirs = Directory.GetDirectories(themePath);
            var packages = new List<PackageDescriptor>();
            foreach (var dir in dirs)
            {
                PackageDescriptor descriptor = null;
                var dirInfo = new DirectoryInfo(dir);
                if (System.IO.File.Exists(dir + "\\manifest.xml"))
                {
                    descriptor = DeploymentHelper.ReadPackage(dir + "\\manifest.xml");
                    //foreach (var img in descriptor.Images)
                    //{
                    //    if (!string.IsNullOrEmpty(img.ImageUrl))
                    //    {
                    //        if (System.IO.File.Exists(HttpContext.Server.MapPath(Url.Content("~/Content/Themes/" + dirInfo.Name + "/" + img.ImageUrl))))
                    //            img.ImageUrl = Url.Content("~/Content/Themes/" + dirInfo.Name + "/" + img.ImageUrl);
                    //    }
                    //}
                }
                else
                {
                    descriptor = new PackageDescriptor()
                    {
                        Author = new AuthorElement() { Name = "<Unknow>" },
                        Name = dirInfo.Name,
                    };
                    if (System.IO.File.Exists(HttpContext.Server.MapPath(Url.Content("~/Content/Themes/" + dirInfo.Name + "/images/preview.gif"))))
                        descriptor.Images.Add(new ImageElement() { ImageUrl = Url.Content("~/Content/Themes/" + dirInfo.Name + "/images/preview.gif") });
                }
                packages.Add(descriptor);
            }

            ViewData.Model = packages;
            return View();
        }

        private static IInstallationService Service { get { return WebSite.GetService<IInstallationService>("InstallationService"); } }
    }
}
