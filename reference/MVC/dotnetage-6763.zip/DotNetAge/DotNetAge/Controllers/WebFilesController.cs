﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using DNA.Mvc.Models;
using System.IO;
using DNA.Mvc.Security;
using DNA.Mvc.jQuery;
using System.Drawing;
using System.Drawing.Imaging;

namespace DNA.Mvc.Controllers
{
    public class WebFilesController : Controller
    {
        private Web Web
        {
            get
            {
                if (WebContext.Current.Web == null)
                    return WebSite.Open();
                else
                    return WebContext.Current.Web;
            }
        }

        [SecurityAction("Create paths",
            PermssionSet = "Web file system",
            Description = "Allows user to create the directory on the server.",
            ThrowOnDeny = true)]
        [AcceptVerbs("MKCOL")]
        public ActionResult CreatePath()
        {
            Web.CreatePath(HttpContext.Request.Url);
            return Json(new WebResourceInfo(HttpContext.Request.Url),JsonRequestBehavior.AllowGet);
        }

        public ActionResult CreatePath(Uri destination)
        {
            if (destination == null)
                throw new ArgumentNullException("destination");
            Web.CreatePath(destination);
            return Json(new WebResourceInfo(destination), JsonRequestBehavior.AllowGet);
        }

        [SecurityAction("Move files and paths",
            PermssionSet = "Web file system",
            Description = "Allows user can move the files and paths.",
            ThrowOnDeny = true)]
        [AcceptVerbs("MOVE")]
        public ActionResult Move(Uri destination)
        {
            Web.MovePath(HttpContext.Request.Url, destination);
            return Json(new WebResourceInfo(destination), JsonRequestBehavior.AllowGet);
        }

        public ActionResult Move(Uri sourceUri,Uri destination)
        {
            Web.MovePath(sourceUri, destination);
            return Json(new WebResourceInfo(destination), JsonRequestBehavior.AllowGet);
        }

        /// <summary>
        /// Gets path and files by specified path.
        /// </summary>
        /// <param name="path"></param>
        /// <returns></returns>
        [AcceptVerbs("LIST")]
        public ActionResult List(string path)
        {
            return Content("Not support");
        }

        [SecurityAction("List paths",
             PermssionSet = "Web file system",
             Description = "Allows user list the paths from web file system",
             ThrowOnDeny = true)]
        [AcceptVerbs("PLIST")]
        public ActionResult PathList()
        {
            var dirNodes = GetPathNodes(HttpContext.Request.Url);
            return Json(dirNodes, JsonRequestBehavior.AllowGet);
        }

        public ActionResult GetPaths(Uri url)
        {
            var dirNodes = GetPathNodes(url);
            return Json(dirNodes, JsonRequestBehavior.AllowGet);
        }

        private List<NavigatableNode> GetPathNodes(Uri url)
        {
            //var url = HttpContext.Request.Url;
            var dirs = Web.GetPaths(url);
            var dirNodes = new List<NavigatableNode>();
            foreach (var dir in dirs)
            {
                var info = new WebResourceInfo(dir);
                dirNodes.Add(new NavigatableNode()
                {
                    Text = info.Name,
                    Value = info.Url,
                    ImageUrl = Url.Content("~/content/images/folder.gif"),
                    NavigateUrl = "javascript:void(0);"
                });
            }
            return dirNodes;
        }

        [SecurityAction("List files",
            PermssionSet = "Web file system",
            Description = "Allows user list the files from path",
            ThrowOnDeny = true)]
        [AcceptVerbs("FLIST")]
        [Pagable]
        public ActionResult FileList(QueryParams _params)
        {
            var uris = Web.GetFiles(HttpContext.Request.Url);
            var skipCount = (_params.Index > 0 ? _params.Index - 1 : _params.Index) * _params.Size;
            var infos = (from url in uris
                         select new WebResourceInfo(url))
                         .Skip(skipCount)
                         .Take(_params.Size)
                         .ToList();

            return View(new ModelWrapper()
            {
                Model = infos,
                Total = uris.Count()
            });
        }

        [Pagable]
        public ActionResult GetFiles(Uri url, QueryParams _params)
        {
            var uris = Web.GetFiles(url);
            var skipCount = (_params.Index > 0 ? _params.Index - 1 : _params.Index) * _params.Size;

            var infos = (from _url in uris
                         select new WebResourceInfo(_url))
                         .Skip(skipCount)
                         .Take(_params.Size)
                         .ToList();

            return View(new ModelWrapper()
            {
                Model = infos,
                Total = uris.Count()
            });
        }

        [SecurityAction("Delete paths",
             PermssionSet = "Web file system",
             Description = "Allows user to delete the directory on the server.",
             ThrowOnDeny = true)]
        [HttpDelete]
        public ActionResult Delete()
        {
            try
            {
                Web.DeletePath(HttpContext.Request.Url);
            }
            catch (Exception e)
            {
                return Content(e.Message);
            }
            return Content("OK");
        }

        public ActionResult Delete(Uri url)
        {
            try
            {
                Web.DeletePath(HttpContext.Request.Url);
            }
            catch (Exception e)
            {
                return Content(e.Message);
            }
            return Content("OK");
        }

        [HttpGet]
        public FileResult GetFile(string path, bool? thumb = false)
        {
            if (Web.IsTrusted(HttpContext.Request.Url))
            {
                var serverPath = Web.MapPath(HttpContext.Request.Url);

                if (thumb.Value)
                {
                    var info = new WebResourceInfo(HttpContext.Request.Url);
                    return Thumb(serverPath, info);
                }

                return File(serverPath, FileUtilty.GetContentType(serverPath));
            }
            else
            {
                if (!string.IsNullOrEmpty(Web.MasterTools.UrlForUntrustLink))
                {
                    var ulink = Url.Content(Web.MasterTools.UrlForUntrustLink);
                    return File(ulink, FileUtilty.GetContentType(ulink));
                }
                throw new FileNotFoundException();
            }
        }

        public FileResult Thumb(string path, WebResourceInfo info)
        {
            string fPath = System.IO.Path.GetDirectoryName(path);
            int width = 64;
            int height = 64;
            var wResult = ValueProvider.GetValue("w");
            var hResult = ValueProvider.GetValue("h");

            if (wResult != null)
                int.TryParse(wResult.AttemptedValue, out width);

            if (hResult != null)
                int.TryParse(hResult.AttemptedValue, out height);

            //string thumbFileName = fPath + (fPath.EndsWith("\\") ? "" : "\\") +System.IO.Path.GetFileNameWithoutExtension(info.Name) + "_thumb_"+width.ToString()+"x"+height.ToString()+".jpg";
            //if (System.IO.File.Exists(thumbFileName))
            //    return File(thumbFileName, "image/jpeg");

            var thumb = new Bitmap(path);

            var img = thumb.GetThumbnailImage(width, height, null, System.IntPtr.Zero);
            var stream = new MemoryStream();

            ///UNDONE:Maybe cause thread error
            //img.Save(thumbFileName);
            img.Save(stream, ImageFormat.Png);
            stream.Position = 0;
            return File(stream, info.ContentType);

        }

        [AcceptVerbs("COPY")]
        public ActionResult Copy(string path, string destination)
        {
            return Content("Not support");
        }

        //[HttpPut]
        //public ActionResult Replace(string path, HttpFileCollection files)
        //{
        //    return View();
        //}

        [SecurityAction("Upload files",
             PermssionSet = "Web file system",
             Description = "Allows user to upload the file to the server.",
             ThrowOnDeny = true)]
        [HttpPost]
        public ActionResult Upload(string path)
        {
            try
            {
                if (Request.Files.Count == 0)
                {
                    HttpContext.Response.StatusCode = 204;
                    return Content("No Content");
                }

                foreach (string key in Request.Files.Keys)
                {
                    var file = Request.Files[key];
                    var fileInfo = new FileInfo(file.FileName);

                    if (!WebSite.Open().IsAllowUpload(fileInfo.Extension))
                    {
                        HttpContext.Response.StatusCode = 415;
                        return Content("Unsupported Media Type - This file type \"" + fileInfo.Extension + "\" is not allow upload to server.The file would not be saved.");
                    }

                    if (file.ContentLength > (WebSite.Open().MaximumFileSize * 1000000))
                    {
                        HttpContext.Response.StatusCode = 403;
                        return Content("Forbidden - The upload file size is over then the maximum file size.The file would not be saved.");
                    }
                    Web.SaveFile(file.FileName, FileUtilty.ReadStream(file.InputStream), HttpContext.Request.Url);
                    //Web.SaveFile(FileUtilty.ReadStream(file.InputStream),fileInfo.Name,HttpContext.Request.Url);
                }
            }
            catch (Exception e)
            {
                HttpContext.Response.StatusCode = 424;
                return Content("Method Failure - " + e.Message);
            }

            HttpContext.Response.StatusCode = 201;
            return Content("OK");
        }

        #region UI Actions

        [SiteControlPanel(ResKey = "RES_FILE_MGT", Order = 4)]
        [MyControlPanel(ResKey = "RES_FILE_MGT", Order =4, ShowInPersonalSiteOnly = true)]
        public ActionResult Explorer()
        {
            //if (HttpContext.Request.Browser.Browser == "IE")
                //return Content("<div style='padding:20px;' class='ui-state-error'>Your browser does not support this feature.Please update to Firefox,Chrome,Opera,Safari ect.</div>");
            ViewData["RootPath"] = Web.GetWebRootUri().ToString();
            return PartialView("FileExplorer");
        }

        public ActionResult MimeIcon(string extension)
        {
            var ext = extension.Replace(".", "");
            var fileName = Server.MapPath("~/content/images/mime/" + ext + ".gif");
            if (System.IO.File.Exists(fileName))
                return File(fileName, "image/gif");
            return File(Server.MapPath("~/content/images/mime/unknow.gif"), "image/gif");
        }

        public ActionResult ListView(string path)
        {
            ViewData["Path"] = path;
            return View();
        }

        #endregion

        //public ActionResult GetFolders(string path)
        //{
        //    var url = string.IsNullOrEmpty(path) ? new Uri("http://" + Request.Url.Authority + "/webshared/home/") : new Uri(path);

        //    var currentWeb = WebSite.Open();
        //    var dirs = currentWeb.GetPaths(url);
        //    var dirNodes = new List<NavigatableNode>();
        //    foreach (var dir in dirs)
        //    {
        //        var info = new WebResourceInfo(dir);
        //        dirNodes.Add(new NavigatableNode()
        //        {
        //            Text = info.Name,
        //            Value = Url.Action("GetFolders", "WebFiles", new { path = info.Url.ToString(), Area = "" }),
        //            ImageUrl = Url.Content("~/content/images/folder.gif"),
        //            NavigateUrl = "javascript:void(0);"
        //        });
        //    }
        //    return Json(dirNodes, JsonRequestBehavior.AllowGet);
        //}
    }
}
