//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Security.Principal;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using System.Web.UI;
using DNA.Mvc.Security;
using DNA.Mvc.Models;

namespace DNA.Mvc.Controllers
{
    /// <summary>
    /// The controller manages user membership in roles for authorization checking in an ASP.NET application. 
    /// </summary>
    [HandleError]
    public class SecurityController : Controller
    {
        private SecurityServiceBase Service
        {
            get
            {
                return WebSite.SecurityService;
            }
        }

        /// <summary>
        /// Get the role list view of the Portal
        /// </summary>
        /// <returns></returns>
        [SiteControlPanel(ResKey = "RES_SECURITY", Order = 1)]
        [SecurityAction("Security console", PermssionSet = "Security", Description = "Allows user to access the security control panel")]
        public ActionResult SecurityPanel()
        {
            int totalRecords = 0;
            Membership.GetAllUsers(0, 20, out totalRecords);
            var pager = new Pager()
            {
                PageIndex = 1,
                PageSize = 20,
                TotalRecords = totalRecords
            };

            ViewData["Pager"] = pager;
            return PartialView();
        }

        [SecurityAction("Security", "Manage Roles", "Allows users to manage the roles of the web.")]
        public ActionResult ManageRoles()
        {
            ViewData.Model = Roles.GetAllRoles();
            return PartialView();
        }

        /// <summary>
        /// Adds a new role to the data source.
        /// </summary>
        /// <param name="NewRoleName">The name of the role to create.</param>
        /// <returns>if create role successful</returns>
        [HttpPost]
        [SecurityAction("Create roles", PermssionSet = "Security", Description = "Allows user to create the roles for the Portal Application.")]
        [ValidateAntiForgeryToken]
        public ActionResult Create(string NewRoleName)
        {
            if (!string.IsNullOrEmpty(NewRoleName))
                try
                {
                    Roles.CreateRole(NewRoleName);
                }
                catch (Exception e)
                {
                    ModelState.AddModelError("NewRoleName", e);
                    return RedirectToAction("ManageRoles");
                }
            else
                ModelState.AddModelError("NewRoleName", "The role name is required!");
            return RedirectToAction("ManageRoles");
        }

        /// <summary>
        /// Removes a role from the data source.
        /// </summary>
        /// <param name="roleName">The name of the role to delete.</param>
        /// <returns>The ActionResult.</returns>
        [HttpPost]
        [SecurityAction("Delete roles", PermssionSet = "Security", Description = "Allows user to delete the roles of the Portal Application.")]
        public ActionResult Delete(string roleName)
        {
            Roles.DeleteRole(roleName);
            return RedirectToAction("ManageRoles");
        }

        /// <summary>
        /// Adds the specified user to the specified role.
        /// </summary>
        /// <param name="user"> The user name to add to the specified role.</param>
        /// <param name="roleName"> The role to add the specified user name to.</param>
        /// <returns>If successful return true.</returns>
        [HttpPost]
        [SecurityAction("Add roles to user", PermssionSet = "Security", Description = "Allows to add the exists roles to the users.")]
        public bool AddUser(string user, string roleName)
        {
            Roles.AddUserToRole(user, roleName);
            return true;
        }

        /// <summary>
        /// Removes the specified user from the specified role.
        /// </summary>
        /// <param name="user">The user to remove from the specified role.</param>
        /// <param name="roleName">The role to remove the specified user from.</param>
        /// <returns>If successful return true.</returns>
        [AcceptVerbs(HttpVerbs.Post)]
        [SecurityAction("Remove roles from user", PermssionSet = "Security", Description = "Allows to remove the roles from the exists users.")]
        public bool RemoveUser(string user, string roleName)
        {
            Roles.RemoveUserFromRole(user, roleName);
            return true;
        }

        ///// <summary>
        ///// Get the roles view for the specified user.
        ///// </summary>
        ///// <param name="userName">The user to get the roles.</param>
        ///// <returns></returns>
        //[AcceptVerbs(HttpVerbs.Post)]
        //[SecurityAction("Manage user roles", PermssionSet = "Security", Description = "Allows to get the user role managment view.")]
        //public ActionResult UserRoles(string userName)
        //{
        //    ViewData["UserName"] = userName;
        //    ViewData.Model = new object[] { new SelectList(Roles.GetAllRoles()), new SelectList(Roles.GetRolesForUser(userName)) };
        //    return PartialView();
        //}

        /// <summary>
        /// Get the permissions view for the specified role
        /// </summary>
        /// <param name="role">the name of the role to list</param>
        /// <returns></returns>
        public ActionResult RoleDetail(string role)
        {
            ViewData.Model =Service.PermissionSets;
            ViewData["Role"] = role;
            return PartialView();
        }

        [HttpPost]
        [SecurityAction("Security", "Manage the permissions", "Allows users to manage the permissions of the role.")]
        [ValidateAntiForgeryToken]
        public ActionResult Apply(string roleName, FormCollection forms)
        {
            List<int> keys = new List<int>();
            foreach (string key in forms.Keys)
            {
                var selected = false;
                bool.TryParse(forms[key], out selected);
                if (!selected) continue;

                if (key.StartsWith("perm_"))
                {
                    int k = int.MinValue;
                    if (int.TryParse(key.Substring(5), out k))
                        keys.Add(k);
                }
            }
            Service.AddPermissionsToRole(keys.ToArray(), roleName);
            return Content("<div class='dna-state-info ui-corner-all'>The Permissions is saved.</div>");
        }

        public ActionResult AccessDenied()
        {
            return View();
        }

        public ActionResult UserDetail(string id)
        {
            return View(Membership.GetUser(id));
        }

        public void UpdateUserRoles(string username, string roles)
        {
            if (string.IsNullOrEmpty(username))
                throw new ArgumentNullException("username");

            if (string.IsNullOrEmpty(roles))
                throw new ArgumentNullException("roles");

            var userRoles = Roles.GetRolesForUser(username);
            Roles.RemoveUserFromRoles(username,userRoles);
            Roles.AddUserToRoles(username,roles.Split(','));
          
        }

        public void Bend(string username)
        {
            var user=Membership.GetUser(username);
            user.IsApproved = false;
            Membership.UpdateUser(user);
        }

        public void Unlock(string username)
        {
            var user = Membership.GetUser(username);
            user.IsApproved = true;
            Membership.UpdateUser(user);
            user.UnlockUser();
        }
    }
}
