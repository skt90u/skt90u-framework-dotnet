//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Mvc.Ajax;

namespace DNA.Mvc.Text
{
    public class TextController : Controller
    {
        public ActionResult WikiContent(string pageName)
        {
            var provider = new WikiFileContentProvider();
            var content = provider.Load(pageName);
            string output= MarkupExtensions.FormatMarkup<WikiMarkupParser>(content.Body,Url.Content("~/Shared/Public/Parsers/wiki.json"),provider.AllSnippets());
            content.Body = output;
            ViewData.Model = content;
            return PartialView();
            //return Content(output);
        }
    }
}
