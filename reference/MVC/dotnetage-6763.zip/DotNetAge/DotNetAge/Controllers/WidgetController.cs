//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Mvc.Ajax;
using System.Web.Script.Serialization;
using System.Reflection;
using System.IO;
using DNA.Mvc.Models;
using DNA.Mvc.DynamicUI;
using DNA.Mvc.Security;
using DNA.Mvc.jQuery;
using DNA.IO.Compress;

namespace DNA.Mvc.Controllers
{
    [HandlePartialError]
    public partial class WidgetController : Controller
    {
        /// <summary>
        /// Add new widget instance to the specified widget zone.
        /// </summary>
        /// <param name="wid">specified WidgetDescriptor ID</param>
        /// <param name="url">the target page url</param>
        /// <param name="zoneID">the specified widget zone id</param>
        /// <param name="pos">the position of the widget in wiget zone</param>
        /// <returns></returns>
        [HttpPost]
        [SecurityAction("Widget engine", "Add widget to page", "Allows user add a new widget instance to the exists page.")]
        public ActionResult AddTo(int wid, Uri url, string zoneID, int pos)
        {
            WidgetDescriptor descriptor = Service.GetWidgetDescriptor(wid);
            if (descriptor == null)
                throw new Exception("The widget not found");

            var widgetInstance=AddWidgetHelper(url, zoneID, pos, descriptor);
             ResolveUrls(widgetInstance);
            return Json(widgetInstance, JsonRequestBehavior.AllowGet);
        }

        private void ResolveUrls(WidgetInstance widgetInstance)
        {
            string website = "";
            if (RouteData.Values.ContainsKey("website"))
                website = RouteData.Values["website"] as string;
            if (!string.IsNullOrEmpty(widgetInstance.IconUrl))
                widgetInstance.IconUrl = Url.Content(widgetInstance.IconUrl);

            if (!string.IsNullOrEmpty(widgetInstance.TitleLinkUrl))
                widgetInstance.TitleLinkUrl = Url.Content(widgetInstance.TitleLinkUrl);
            widgetInstance.Url = !string.IsNullOrEmpty(website) ? Url.Action(widgetInstance.Action, widgetInstance.Controller, new { Area = string.IsNullOrEmpty(widgetInstance.Url) ? "" : widgetInstance.Url, website = website, id = 0 }) : Url.Action(widgetInstance.Action, widgetInstance.Controller, new { Area = string.IsNullOrEmpty(widgetInstance.Url) ? "" : widgetInstance.Url });
        }

        private WidgetInstance AddWidgetHelper(Uri url, string zoneID, int pos, WidgetDescriptor descriptor)
        {
            var context=new WebContext(url);
            string vPath = context.Page.Path;

            var widgetInstance = Service.AddWidget(descriptor, vPath, zoneID, pos);

              return widgetInstance;
        }

        /// <summary>
        /// Move the widget to anthor widget zone or new position.
        /// </summary>
        /// <param name="id">The specified widget id.</param>
        /// <param name="zoneID">The target widget zone id.</param>
        /// <param name="position">The new  position of the widget</param>
        [HttpPost]
        [SecurityAction("Widget engine", "Move widget position", "Allows user move the widget on the page.", ThrowOnDeny = true)]
        public void MoveTo(Guid id, string zoneID, int position)
        {
            Service.MoveTo(id, zoneID, position);
        }

        /// <summary>
        /// Delete the widget by specified id. 
        /// </summary>
        /// <param name="id">The id of the widget.</param>
        [HttpPost]
        [SecurityAction("Widget engine", "Delete widget", "Allows users can delete the exists widget.", ThrowOnDeny = true)]
        public void Delete(Guid id)
        {
            Service.DeleteWidget(id);
        }

        /// <summary>
        /// Apply the common settings of the widget.
        /// </summary>
        /// <param name="id">The specified widget id</param>
        [HttpPost]
        [SecurityAction("Widget engine", "Apply widget settings", "Allows users can apply the common widget settings changes", ThrowOnDeny = true)]
        public void Apply(Guid id)
        {
            var widget = Service.GetWidget(id);
            if (TryUpdateModel<WidgetInstance>(widget, new string[] {
                "ShowBorder",
                "ShowHeader",
                "IsClosable",
                "Title",
                "TitleLinkUrl",
                "IconUrl",
                "BackgroundColor",
                "ForeColor" }))
                Service.UpdateWidget(widget);
        }

        [HttpPost]
        [SecurityAction("Widget engine", "Toggle widget state", "Allows users can toggle the widget state 'collapse','expanded'", ThrowOnDeny = true)]
        public void Toggle(Guid id)
        {
            Service.Toggle(id);
        }


        private static WidgetUIServiceBase Service
        {
            get { return WebSite.WidgetService; }
        }

        [SecurityAction("Widget engine", "Design page", "Allows users can toggle the page design mode.")]
        public ActionResult Explorer()
        {
            string root = HttpContext.Server.MapPath("~/content/widgets/");
            return View(GetPathNodes(root, root));
        }
        
        /// <summary>
        /// List the installed widget paths (Only avalidable in DNA2)
        /// </summary>
        /// <param name="path"></param>
        /// <returns></returns>
        [Pagable]
        public ActionResult List(string path)
        {
            var descriptors=Service.GetWidgetDescriptors(path);
            string website = "";
            if (RouteData.Values.ContainsKey("website"))
                website = RouteData.Values["website"] as string;
            foreach (var descriptor in descriptors)
            {
                if (!string.IsNullOrEmpty(descriptor.ImageUrl))
                    descriptor.ImageUrl = Url.Content(descriptor.ImageUrl);
                if (!string.IsNullOrEmpty(descriptor.IconUrl))
                    descriptor.IconUrl = Url.Content(descriptor.IconUrl);

                if (!string.IsNullOrEmpty(descriptor.Controller))
                {
                    Type controllerType = Type.GetType(descriptor.Controller);
                    if (controllerType != null)
                        descriptor.Controller = controllerType.Name.Replace("Controller", "");
                    descriptor.Url = !string.IsNullOrEmpty(website) ? Url.Action(descriptor.Action, descriptor.Controller, new { Area = string.IsNullOrEmpty(descriptor.Url) ? "" : descriptor.Url, website = website, id = 0 }) : Url.Action(descriptor.Action, descriptor.Controller, new { Area = string.IsNullOrEmpty(descriptor.Url) ? "" : descriptor.Url });
                }
                else
                {
                    descriptor.Url = Url.Content(descriptor.Action);
                }
            }

            return View(new ModelWrapper<WidgetDescriptor>(descriptors));
        }

        private List<NavigatableNode> GetPathNodes(string path, string root)
        {
            var dirInfo = new DirectoryInfo(path);
            var dirs = dirInfo.GetDirectories();

            var dirNodes = new List<NavigatableNode>();
            foreach (var dir in dirs)
            {
                var files = dir.GetFiles("config.xml");
                if (files.Length > 0)
                    continue;

                dirNodes.Add(new NavigatableNode()
                {
                    Text = dir.Name,
                    Value =dir.Name ,// Url.Action("GetPaths", "Host", new { name = dir.FullName.Replace(root, "") }),
                    ImageUrl = Url.Content("~/content/images/icon_cat_16.gif"),
                    NavigateUrl = "javascript:void(0);"
                });
            }
            return dirNodes;
        }

        /// <summary>
        /// Get the specified WidgetDescriptor install information.
        /// </summary>
        /// <param name="id">The specified widget descriptor id.</param>
        /// <returns></returns>
        public ActionResult Info(int id)
        {
            ViewData.Model =  Service.GetWidgetDescriptor(id);
            return PartialView();
        }
        
        public ActionResult LoadData(Uri url)
        {
            var _widgets = Service.GetWidgets(url);
            if (_widgets == null)
                return Content("");
            
            string website = "";
            if (RouteData.Values.ContainsKey("website"))
                website =RouteData.Values["website"] as string;

            foreach (var w in _widgets)
            {
                if (!string.IsNullOrEmpty(w.IconUrl)) w.IconUrl = Url.Content(w.IconUrl);
                if (!string.IsNullOrEmpty(w.TitleLinkUrl)) w.TitleLinkUrl = Url.Content(w.TitleLinkUrl);
                w.Url = !string.IsNullOrEmpty(website) ? Url.Action(w.Action, w.Controller, new { Area = string.IsNullOrEmpty(w.Url) ? "" : w.Url, website = website, id = 0 }) : Url.Action(w.Action, w.Controller, new { Area = string.IsNullOrEmpty(w.Url) ? "" : w.Url });
            }

            List<DynamicGroupResult> widgets = null;
           // if (!User.IsWebOwner())
            //{
                widgets = _widgets.OrderBy(w=>w.Pos).GroupByMany(w=>w.ZoneID).ToList();
                if (widgets.Count() == 0)
                    return Content("");
            //}

            return Json(widgets, JsonRequestBehavior.AllowGet);
        }

        /// <summary>
        /// Load widgets instance data from specified url 
        /// </summary>
        /// <param name="url">The url that contains widgets.</param>
        /// <returns>Returns the widgets object data in JSON string format.</returns>
        public ActionResult Load(Uri url, string mode)
        {
            bool isDesign = false;
            if (!string.IsNullOrEmpty(mode))
            {
                if (mode.ToLower() == "design")
                    isDesign = true;
            }

            if ((!HttpContext.Request.IsAuthenticated) || (!this.IsAuthorize("Explorer")))
                isDesign = false;

            var _widgets = Service.GetWidgets(url);
            if (_widgets == null)
                return Content("");
            
            var widgets=_widgets;
            if (!User.IsWebOwner())
            {
                widgets = _widgets.Where(w => w.Scope == 0).ToList();
                if (widgets.Count == 0)
                    return Content("");
            }

            var zones = widgets.Select(w => w.ZoneID);
            if (zones != null)
                zones = zones.Distinct();
            
            var jsonPage = new Dictionary<string, object>();
            jsonPage.Add("auth", HttpContext.Request.IsAuthenticated);
            var ser = new System.Web.Script.Serialization.JavaScriptSerializer();
           // var _baseUrl = Url.Content("~/Widget/");
            foreach (string zone in zones)
            {
                var jsonWidgets = (from w in widgets
                                   where w.ZoneID == zone
                                   orderby w.Pos
                                   select w.ToJSON(isDesign, Url));

                jsonPage.Add(zone, ser.Serialize(jsonWidgets));
            }
            return Json(jsonPage, JsonRequestBehavior.AllowGet);
        }

        /// <summary>
        /// Export the specified widget settings to the file.
        /// </summary>
        /// <param name="wid">The specified widgetinstance id</param>
        /// <returns></returns>
        [SecurityAction("Widget engine", "Export user preferences",
            "Allows users can export the user preferences data and download it.")]
        public FileResult Export(Guid wid)
        {
            var widget = Service.GetWidget(wid);
            if (widget == null)
                throw new Exception("Widget not found");
            var stream = new MemoryStream();
            var writer = new StreamWriter(stream);
            //var exportData = new WidgetDataContract(widget);
            //string s = (new JavaScriptSerializer()).Serialize(exportData);
            
            writer.Write(widget.ToXml());
            writer.Flush();
            stream.Position = 0;
            return File(stream, "text/xml", TextUtility.Slug(widget.Title + DateTime.Now.ToString("yy-MM-dd")) + ".dat");
            //return File(stream, "application/oct-stream", widget.Title + ".json");
            //return Content(widget.ToXml(), "text/xml");
        }

        /// <summary>
        /// Add a new widget instance from the import data file
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        [SecurityAction("Widget engine", "Import user preferences", "Allows users can upload the widget user preferences data file and import to the exists page.", ThrowOnDeny = true)]
        public ActionResult Import(Uri url, string zoneID, int pos)
        {
            var postedFile = Request.Files["importedFile"];
            var reader = new StreamReader(postedFile.InputStream);
            string src = reader.ReadToEnd();
            var context = new WebContext(url);
            var widgetInstance = context.Page.ImportWidget(src);
            widgetInstance.ZoneID = zoneID;
            widgetInstance.Pos = pos;
            widgetInstance.Update();
            this.ResolveUrls(widgetInstance);
            return Content((new JavaScriptSerializer()).Serialize(widgetInstance));
            //return Json(widgetInstance, JsonRequestBehavior.AllowGet);
        }

        [SiteControlPanel("Widgets", Order = 5)]
        public ActionResult WidgetManager()
        {
            string root = HttpContext.Server.MapPath(DESCRIPTOR_PATH);
            return View(GetPathNodes(root, root));
        }

        public ActionResult GetPaths(string name)
        {
            string root = HttpContext.Server.MapPath(DESCRIPTOR_PATH);
            string fullPath = root + name;
            return Json(GetPathNodes(fullPath, root), JsonRequestBehavior.AllowGet);
        }

        public void Sync()
        {
            WidgetLoader.SyncWidgetLibrary();
        }
        private const string DESCRIPTOR_PATH ="~/content/widgets/";
        
        public ActionResult ListWidgets(string name)
        {
            string root = HttpContext.Server.MapPath(DESCRIPTOR_PATH);
            string fullPath = root + name;
            var dirInfo = new DirectoryInfo(fullPath);
            var dirs = dirInfo.GetDirectories();
            var widgets = new List<WidgetTemplate>();

            foreach (var dir in dirs)
            {
                var files = dir.GetFiles("config.xml");
                if (files.Length > 0)
                {
                    var tmpl = (WidgetTemplate)DNA.Utility.XmlSerializerUtility.DeserializeFormXmlFile(files[0].FullName, typeof(WidgetTemplate));
                    widgets.Add(tmpl);
                }
            }
            ViewData["Path"] = name;
            return View(widgets);
        }

        public ActionResult PackWidget(string path,string name)
        {
            ///UNDONE:This method needs to publish the widget to Google Gedget ,Widget Gedget,Yahoo widget and W3C widget.
            string root = DESCRIPTOR_PATH;
            string pkgPath =Server.MapPath(root +path+"/"+ name );
            string rootPath = Server.MapPath(root + path + "/");
            try
            {
                var zip = new ZipCompress();
                var files = Directory.GetFiles(pkgPath);
                for (int i = 0; i < files.Length; i++)
                {
                    var file=new FileInfo(files[i]);
                    zip.AddFile(file.FullName, file.FullName.Replace(pkgPath+"\\", ""));
                }
                var stream = zip.Compress();
                stream.Position = 0;
                return File(stream, "application/x-zip-compressed", name + ".wgt");
            }
            catch(Exception e)
            {
                return File(new byte[0], "application/octetstream"); 
            }
            return File(new byte[0], "application/octetstream");
            //return View();
        }

        public bool Unregister(string path, string name)
        {
            var tmpl=GetWidgetTemplate(path, name);
            var descriptor = Service.GetWidgetDescriptor(path + "\\" + name);
            if (descriptor != null)
                Service.DeleteDescriptor(descriptor.ID);
            return true;
        }

        private WidgetTemplate GetWidgetTemplate(string path, string name)
        {
            string fullPath = HttpContext.Server.MapPath(DESCRIPTOR_PATH) + path + "/" + name + "\\config.xml";
            return  (WidgetTemplate)DNA.Utility.XmlSerializerUtility.DeserializeFormXmlFile(fullPath, typeof(WidgetTemplate));
        }

        public bool Register(string path,string name)
        {
            var tmpl = GetWidgetTemplate(path, name);
            this.CurrentWeb().AddWidgetDescriptor(tmpl, path + "\\" + name);
            return true;
        }

        public void ExtractWidget()
        { 
        }

        public ActionResult Detail(string path,string name)
        {
            ViewData["Path"] = path;
            return View(GetWidgetTemplate(path,name));
        }
    }
}
