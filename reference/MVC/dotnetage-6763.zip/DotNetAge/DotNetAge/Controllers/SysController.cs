//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Mvc.Ajax;
using DNA.Mvc.Models;
using DNA.Mvc.DynamicUI;
using DNA.Mvc.Security;

namespace DNA.Mvc.Controllers
{
    /// <summary>
    /// Provides the actions of the system settings of the website.
    /// </summary>
    public class SysController : Controller
    {
       // [SiteMapAction(Title = "WebSite ControlPanel", ShowInMenu = false)]
        [SecurityAction("Management base", "Control panel", "Allows users can acces the control panel")]
        public ActionResult Index()
        {
            //SecurityActionService.Instance().IsAuthorize(
            ViewData.Model = Url.ControlPanelActions<SiteControlPanelAttribute>();
            return View();
        }

        //public ActionResult Debug()
        //{
        //    return View();
        //}

        [SiteControlPanel(ResKey = "RES_WEB_SETTING", Order = 0)]
        [MyControlPanel(ResKey = "RES_WEB_SETTING", Order = 0, ShowInPersonalSiteOnly = true)]
        [SecurityAction("Management base", "View site settings", "Allows users can view the common site settings.")]
        public ActionResult SiteSettings()
        {
            ViewData.Model = this.CurrentWeb();
            if (!this.CurrentWeb().IsRoot)
                this.CurrentWeb().EnsurePersonalWebFiles();
            return PartialView();
        }

        [AcceptVerbs(HttpVerbs.Post)]
        //[ValidateAntiForgeryToken]
        [ValidateInput(false)]
        [SecurityAction("Management base", "Save site settings", "Allows users can save the common site settings.")]
        public ActionResult SiteSettings(FormCollection forms)
        {
            var web = this.CurrentWeb();

            if (TryUpdateModel<Web>(web, "Web"))
            {
                TryUpdateModel<WebMasterTools>(web.MasterTools, "MasterTools");
                web.Update();
            }

            ViewData.Model = web;

            return PartialView();
        }

        [MyControlPanel(ResKey = "RES_THEME_SETTINGS", Order = 4,ShowInPersonalSiteOnly=true)]
        [SiteControlPanel(ResKey = "RES_THEME_SETTINGS", Order = 3)]
        public ActionResult ThemeSettings()
        {
//            ViewData.Model = ;
            return PartialView(this.CurrentWeb());
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult ThemeSettings(FormCollection forms,bool? saveAsNew=false)
        {
            var web = this.CurrentWeb();
            if (TryUpdateModel<Web>(web, "Web"))
            {
                //web.LogoLayout = (LogoLayouts)Enum.Parse(typeof(LogoLayouts), forms["MasterTools.LogoLayout"]);
                web.Update();
            }

            if (saveAsNew.Value)
            {

                string themeRoot = HttpContext.Server.MapPath("~/Content/Themes/");
                string currentThemePath = themeRoot + web.Theme;
                string distance = themeRoot + forms["NewThemeName"];

                if (!System.IO.Directory.Exists(distance))
                {
                    //Copy current theme to new folder
                    DNA.Mvc.Installation.DeploymentHelper.CopyDirectory(currentThemePath, distance);

                    if (!string.IsNullOrEmpty(web.CssText))
                    {
                        //Copy the css Text to screen.css
                        var writer = System.IO.File.CreateText(distance + "\\screen.css");
                        writer.Write(web.CssText);
                        writer.Close();
                        web.CssText = "";
                    }

                    //Change the current theme.
                    web.Theme = forms["NewThemeName"];
                    web.Update();
                }
            }
            return PartialView(web);
        }

        /// <summary>
        /// Change the current language for the current user.
        /// </summary>
        /// <param name="lang">The specified Language ID</param>
        /// <returns></returns>
        public ActionResult ChangeLanguage(string lang)
        {
            if (lang == null)
                return View("Home");
            else
            {
                if (Request.IsAuthenticated)
                {
                    if (HttpContext.Profile["Language"] != null)
                        HttpContext.Profile["Language"] = lang;
                }
                else
                {
                    string key = Request.AnonymousID;
                    HttpCookie cookie = Request.Cookies[key];
                    if (cookie == null)
                    {
                        cookie = new HttpCookie(key);
                        Response.Cookies.Add(cookie);
                    }
                    if (cookie.Values["Language"] == null)
                        cookie.Values.Add("Language", lang);
                    else
                        cookie.Values["Language"] = lang;
                }
                if (!string.IsNullOrEmpty(Request.QueryString["ReturnUrl"]))
                    return Redirect(Server.UrlDecode(Request.QueryString["ReturnUrl"]));
                else
                    return Redirect("/");
            }
        }

        /// <summary>
        /// Change the current theme of the website.
        /// </summary>
        /// <param name="theme"></param>
        /// <returns></returns>
        [AcceptVerbs(HttpVerbs.Post)]
        [SecurityAction("Management base", "Change theme", "Allows users can site theme.")]
        public ActionResult ChangeTheme(string theme)
        {
            var web = WebSite.Open(RouteData);
            web.Theme = theme;
            web.Update();
            return Content(HtmlUIExtensions.Theme(theme));
        }

        public ActionResult LoadTheme(string theme)
        {
            return Content(HtmlUIExtensions.Theme(theme));
        }

        public ActionResult UIDesigner(string id)
        {
            if (id.Equals("page", StringComparison.OrdinalIgnoreCase))
            {
                ViewData["IDPrefix"] = "Page";
                ViewData["Element"] = "body";
                ViewData["ImagePath"] = Url.Content("~/webshared/home/images/backgrounds");
            }

            if (id.Equals("header", StringComparison.OrdinalIgnoreCase))
            {
                ViewData["IDPrefix"] = "Header";
                ViewData["Element"] = "#dna-page-header";
                ViewData["ImagePath"] = Url.Content("~/webshared/home/images/textures");
            }

            if (id.Equals("content", StringComparison.OrdinalIgnoreCase))
            {
                ViewData["IDPrefix"] = "Content";
                ViewData["Element"] = "#dna-page-content";
                ViewData["ImagePath"] = Url.Content("~/webshared/home/images/backgrounds");
            }

            if (id.Equals("footer", StringComparison.OrdinalIgnoreCase))
            {
                ViewData["IDPrefix"] = "Footer";
                ViewData["Element"] = "#dna-page-footer";
                ViewData["ImagePath"] = Url.Content("~/webshared/home/images/textures");
            }

            if (id.Equals("sitetools", StringComparison.OrdinalIgnoreCase))
            {
                ViewData["IDPrefix"] = "SiteTools";
                ViewData["Element"] = "#dna-page-toolbox";
                ViewData["ImagePath"] = Url.Content("~/webshared/home/images/textures");
            }

            return View();
        }
    }
}
