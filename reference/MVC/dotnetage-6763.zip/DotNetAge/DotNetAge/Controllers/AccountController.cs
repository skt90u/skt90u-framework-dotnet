﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Security.Principal;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using System.Web.UI;
using System.Reflection;
using System.IO;
using DNA.Mvc.Security;
using DNA.Mvc.Models;
using DNA.Mvc.Notification;
using DNA.Mvc.DynamicUI;
using DNA.Mvc.jQuery;

namespace DNA.Mvc.Controllers
{
    [HandleError(ExceptionType = typeof(PageNotFoundException), View = "NotFound")]
    [HandleError(View = "Error")]
    public class AccountController : Controller
    {
        [Authorize]
        public ActionResult Console()
        {
            if (WebHost.Config.Deployment.EnablePersonalWeb)
            {
                var website = HttpContext.Request.RequestContext.RouteData.Values["website"] as string;
                if ((!string.IsNullOrEmpty(website) && (website.Equals(User.Identity.Name, StringComparison.OrdinalIgnoreCase))))
                {
                    if (WebSite.Open(website) == null)
                        return Redirect(Url.Content("~/DynamicUI/SetupMysite"));
                }
            }
            ViewData.Model = Url.ControlPanelActions<MyControlPanelAttribute>();
            return View();
        }

        public ActionResult Receive()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Receive(string email)
        {
            if (!string.IsNullOrEmpty(email))
            {
                var userName = Membership.GetUserNameByEmail(email);
                if (string.IsNullOrEmpty(userName))
                {
                    ViewData["Summary"] = "There is not user use this email,please choice another one.";
                    return View();
                }
                var user = Membership.GetUser(userName, false);
                var pwd = "";

                if (Membership.EnablePasswordRetrieval)
                    pwd = user.GetPassword();
                else
                    pwd = user.ResetPassword();

                var body = new System.Text.StringBuilder();
                body.Append("The password has been reset for you account.")
                        .AppendLine("User name:" + userName)
                        .AppendLine("Password:" + pwd)
                        .AppendLine("Click the link below to login to our web.")
                        .AppendLine(Request.Url.Scheme + "://" + Request.Url.Authority + Url.Action("LogOn"));

                var mail = new MailMessageModel()
                {
                    Subject = "Password reset request",
                    Receiver = email,
                    MailBody = body.ToString()
                };

                this.MailTo(mail);
                return RedirectToAction("PasswordSent", new { email = email });
            }
            ViewData["Summary"] = "The email could not be empty!please supply the email to receive your password.";
            return View();
        }

        public ActionResult PasswordSent(string email)
        {
            ViewData.Model = email;
            return View();
        }

        //[OutputCache(CacheProfile = "UserProfileCache")]
        public ActionResult Info(string userName)
        {
            if (!string.IsNullOrEmpty(userName))
                ViewData["UserName"] = userName;
            else
            {
                if (HttpContext.Request.IsAuthenticated)
                    ViewData["UserName"] = HttpContext.Profile.UserName;
                else
                    throw new PageNotFoundException();
            }
            return View();
        }

        [Authorize]
        [MyControlPanel(ResKey = "RES_PROFILE", Order = 1)]
        public ActionResult Profile()
        {
            return PartialView();
        }

        [Authorize]
        [HttpPost]
        public ActionResult Profile(FormCollection form)
        {
            System.Web.Profile.ProfileBase profile = HttpContext.Profile;
            profile["Avatar"] = form["Avatar"];
            profile["DisplayName"] = form["DisplayName"];
            profile["Location"] = form["Location"];
            profile["Language"] = form["Language"];
            profile["Phone"] = form["Phone"];
            profile["Mobile"] = form["Mobile"];
            int timeZone = int.MinValue;

            if (int.TryParse(form["TimeZone"], out timeZone))
                profile["TimeZone"] = timeZone;

            if (!string.IsNullOrEmpty(form["Birthday"]))
            {
                DateTime birthday = DateTime.MinValue;
                if (DateTime.TryParse(form["Birthday"], out birthday))
                {
                    if (birthday != DateTime.MinValue)
                        profile["Birthday"] = birthday;
                }
            }

            profile["Signature"] = form["Signature"];
            profile["Email"] = form["Email"];
            profile["Address"] = form["Address"];
            //Contents
            profile["Blog"] = form["Blog"];
            profile["WebSite"] = form["WebSite"];
            profile["Yahoo"] = form["Yahoo"];
            profile["MSN"] = form["MSN"];
            profile["ICQ"] = form["ICQ"];

            profile.Save();
            return PartialView();
        }

        //public ActionResult UserList()
        //{
        //    int totalRecords = 0;
        //    ViewData.Model = Membership.GetAllUsers(0, 20, out totalRecords);
        //    return View();
        //}
        //public ActionResult Index()
        //{
        //    return View();
        //}

        [Pagable]
        public ActionResult UserList(QueryParams _params)
        {
            int total = 0;
            MembershipUserCollection members = null;

            if (!string.IsNullOrEmpty(_params.Filter))
            {
                var filters = _params.GetFilterExpressions();
                var filter = filters[0];
                if (!string.IsNullOrEmpty(filter.Term))
                    members = Membership.FindUsersByName(filter.Term.Replace("'", ""), _params.Index == 0 ? _params.Index : _params.Index - 1, _params.Size, out total);
                else
                    members = Membership.GetAllUsers(_params.Index == 0 ? _params.Index : _params.Index - 1, _params.Size, out total);
            }
            else
                members = Membership.GetAllUsers(_params.Index == 0 ? _params.Index : _params.Index - 1, _params.Size, out total);

            var values = new List<MembershipUser>();
            foreach (MembershipUser member in members)
                values.Add(member);

            return View(new ModelWrapper()
            {
                Model = values,
                Total = total
            });
            //return Json(this.JsonWrapper(values, total), JsonRequestBehavior.AllowGet);
        }
        //[HttpPost]
        //public ActionResult UserList(Pager pager)
        //{
        //    if (pager.PageSize == 0)
        //        pager.PageSize = 20;
        //    MembershipUserCollection users = null;
        //    int totalRecords = 0;

        //    if (pager.PageIndex > 0)
        //        pager.PageIndex--;

        //    if (!string.IsNullOrEmpty(pager.SearchText))
        //    {
        //        if (pager.SearchText.IndexOf("@") > 0)
        //            users = Membership.FindUsersByEmail(pager.SearchText, pager.PageIndex, pager.PageSize, out totalRecords);
        //        else
        //            users = Membership.FindUsersByName(pager.SearchText, pager.PageIndex, pager.PageSize, out totalRecords);
        //    }
        //    else
        //        users = Membership.GetAllUsers(pager.PageIndex, pager.PageSize, out totalRecords);

        //    pager.TotalRecords = totalRecords;
        //    ViewData.Model = users;
        //    return PartialView();
        //}

        private IFormsAuthentication FormsAuth
        {
            get { return WebSite.FormAuth; }
        }

        private IMembershipService MembershipService
        {
            get { return WebSite.MembershipService; }
        }

        [SiteMapAction(Title = "Login",
            IsShared = true,
            ShowInMenu = false)]
        public ActionResult LogOn()
        {
            return View();
        }

        [HttpPost]
        // [ValidateAntiForgeryToken]
        public ActionResult LogOn(LogOnModel model, string returnUrl)
        {
            if (ModelState.IsValid)
            {
                if (MembershipService.ValidateUser(model.UserName, model.Password))
                {
                    FormsAuth.SignIn(model.UserName, model.RememberMe);
                    if (!String.IsNullOrEmpty(returnUrl))
                    {
                        return Redirect(returnUrl);
                    }
                    else
                    {
                        if (WebHost.Config.Deployment.EnablePersonalWeb)
                            return Redirect(WebSite.ApplicationPath + "/sites/" + model.UserName + "/index.html");
                        return Redirect((!string.IsNullOrEmpty(WebSite.CurrentWeb().DefaultUrl) ? WebSite.CurrentWeb().DefaultUrl : WebSite.CurrentWeb().AppUrl.ToString()));
                        //return RedirectToAction("Index", "Home");
                    }
                }
                else
                {
                    ModelState.AddModelError("", "User name or passoword not found.");
                }
            }
            return View(model);
        }

        public ActionResult LogOff()
        {
            FormsAuth.SignOut();
            var web = WebSite.Open();
            return Redirect(string.IsNullOrEmpty(web.DefaultUrl) ? web.AppUrl.ToString() : web.DefaultUrl);
            //RedirectToAction("Index", "Home");
        }

        [SiteMapAction(Title = "Register", IsShared = true, ShowInMenu = false)]
        public ActionResult Register()
        {
            if (this.CurrentWeb().EnableUserRegistration)
            {
                ViewData["PasswordLength"] = MembershipService.MinPasswordLength;
                return View();
            }
            else
            {
                throw new PageNotFoundException();
                //  return View("NotFound");
            }
        }

        [HttpPost]
        //[ValidateAntiForgeryToken]
        public ActionResult Register(RegisterModel model)
        {
            if (ModelState.IsValid)
            {
                string[] reserves = new string[] { "host", "home", "index", "default", "{blog}", "sites", "{site}" };
                if (reserves.Contains(model.UserName.ToLower()))
                {
                    ModelState.AddModelError("", "The name of \"" + model.UserName + "\" has been reserved, please use another user name.");
                }
                else
                {
                    MembershipCreateStatus createStatus = MembershipService.CreateUser(model.UserName, model.Password, model.Email);

                    if (createStatus == MembershipCreateStatus.Success)
                    {
                        FormsAuth.SignIn(model.UserName, true);
                        Roles.AddUserToRole(model.UserName, "guests");//default user role


                        var notifity = new EmailNotifier();
                        notifity.Send(model.UserName, Messages.RegisterSuccessful, HttpContext.Request.Url.Authority, model.UserName, model.Password);

                        if (WebHost.Config.Deployment.EnablePersonalWeb)
                            return Redirect(WebSite.ApplicationPath + "/sites/" + model.UserName + "/index.html");

                        return Redirect((!string.IsNullOrEmpty(WebSite.CurrentWeb().DefaultUrl) ? WebSite.CurrentWeb().DefaultUrl : WebSite.CurrentWeb().AppUrl.ToString()));
                        //return RedirectToAction("Index", "Home");

                    }
                    else
                    {
                        ModelState.AddModelError("", AccountValidation.ErrorCodeToString(createStatus));
                    }
                }
            }


            ViewData["PasswordLength"] = MembershipService.MinPasswordLength;
            return View(model);
        }

        [Authorize]
        public ActionResult ChangePassword()
        {

            ViewData["PasswordLength"] = MembershipService.MinPasswordLength;
            return View();
        }

        [Authorize]
        [HttpPost]
        //[ValidateAntiForgeryToken]
        public ActionResult ChangePassword(ChangePasswordModel model)
        {
            if (ModelState.IsValid)
            {
                if (MembershipService.ChangePassword(User.Identity.Name, model.OldPassword, model.NewPassword))
                {
                    return RedirectToAction("ChangePasswordSuccess");
                }
                else
                {
                    ModelState.AddModelError("", "The current password is incorrect or the new password is invalid.");//当前密码不正确或新密码无效。
                }
            }

            ViewData["PasswordLength"] = MembershipService.MinPasswordLength;
            return View(model);
        }

        public ActionResult ChangePasswordSuccess()
        {

            return View();
        }

        protected override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            if (filterContext.HttpContext.User.Identity is WindowsIdentity)
            {
                throw new InvalidOperationException("Windows authentication is not supported.");
            }
        }

        [HttpGet]
        public ActionResult SendMail(string username)
        {
            ViewData["Receiver"] = username;
            return View();
        }

        [HttpPost]
        [ValidateInput(false)]
        public ActionResult SendMail(FormCollection forms)
        {
            var notifier = new EmailNotifier();
            var msg = new NotificationMessage();
            string username = forms["txtReceiver"];
            msg.Subject = forms["txtEmailText"];
            msg.Content = new NotificationMessageContent()
            {
                ContentType = "text/html",
                Text = forms["txtEmailBody"]
            };
            notifier.Send(username, msg);
            return View("MailSent");
        }
    }
}
