﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using DNA.Mvc.DynamicUI;
using System.Xml;
using System.Net;
using DNA.Mvc.OpenAPI.Rss;
using DNA.Mvc.OpenAPI.Atom;

namespace DNA.Mvc.Controllers
{
    [HandlePartialError]
    public class AsyncWidgetController : AsyncController
    {
        [Widget("Feeds",
            Description = "Feeds is a widget that allows you subscript rss feed or atom feed.",
            ImageUrl = "~/Content/Images/Widgets/rss.png",
            IconUrl = "~/Content/Images/Widgets/rss_16.png")]
        [Property("Url", DisplayName = "Url",
            DefaultValue = "http://www.dotnetage.com/feeds/home/rss")]
        [Property("Rows",
            DisplayName = "Display rows",
            ValueType = typeof(int),
            DefaultValue = 5)]
        [Property("ShowFeedInfo", DisplayName = "Show feed info", ValueType = typeof(bool), DefaultValue = true, PropertyControl = ControlTypes.Checkbox)]
        public void FeedsAsync(string url, int rows)
        {
            if (!string.IsNullOrEmpty(url))
            {
                var request = (HttpWebRequest)WebRequest.Create(url);
                request.Headers["Accept-Encoding"] = "gzip";
                request.Credentials = CredentialCache.DefaultNetworkCredentials;
                request.AutomaticDecompression = DecompressionMethods.GZip;

                AsyncManager.OutstandingOperations.Increment();

                request.BeginGetResponse(new AsyncCallback(n =>
                {
                    var response = request.EndGetResponse(n);
                    var stream = response.GetResponseStream();
                    string xml = "";
                    using (var reader = new System.IO.StreamReader(stream))
                    {
                        xml = reader.ReadToEnd();
                    }
                    AsyncManager.Parameters["contentType"] = response.ContentType;
                    AsyncManager.Parameters["xml"] = xml;
                    AsyncManager.Parameters["rows"] = rows;
                    AsyncManager.OutstandingOperations.Decrement();
                }), rows);
            }
        }

        public ActionResult FeedsCompleted(string contentType, string xml, int rows)
        {
            if (!string.IsNullOrEmpty(xml))
            {
                var xmlDoc = new XmlDocument();
                xmlDoc.LoadXml(xml);
                if (xmlDoc.DocumentElement.LocalName.Equals("feed", StringComparison.OrdinalIgnoreCase))
                {
                    var feed = DNA.Utility.XmlSerializerUtility.DeserializeFromXmlText(xml, typeof(AtomFeed));
                    return View("~/Views/Widget/AtomFeed.ascx", feed);
                }
                else
                {
                    var channel = DNA.Utility.XmlSerializerUtility.DeserializeFromXmlText(xmlDoc.DocumentElement.InnerXml, typeof(RssChannel));
                    return View("~/Views/Widget/RssFeed.ascx", channel);
                }
            }
            return View("~/Views/Widget/RssFeed.ascx");
        }
    }
}
