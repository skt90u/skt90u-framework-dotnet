﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using DNA.Mvc.DynamicUI;

namespace DNA.Mvc.Controllers
{
    [Log]
    [MasterLayout]
    [HandleError(View = "Error")]
    public class HomeController : Controller
    {
        [SiteMapAction]
        public ActionResult Index()
        {
            if (!WebHost.IsInstalled)
                return RedirectToAction("Index", "Installation");
            var web = WebSite.Open();
            if (!string.IsNullOrEmpty(web.DefaultUrl))
            {
                string _url = web.DefaultUrl.ToLower();
                if ((!_url.Equals("~/home/index")) &&
                    (!_url.Equals("~/home")) &&
                    (!_url.Equals("~/home/")) &&
                    (!_url.Equals("~/")) &&
                    (!_url.Equals("~/default.aspx")))
                    return Redirect(Url.Content(_url));
            }
            return View();
        }
    }
}
