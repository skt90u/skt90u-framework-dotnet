//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Mvc.Ajax;
using System.Web.Script.Serialization;
using DNA.Mvc.Models;
using DNA.Mvc.DynamicUI;
using System.IO;
using DNA.Mvc.Security;
using System.Text;
using System.Xml;
using System.Xml.Linq;
using DNA.Mvc.OpenAPI.Rss;
using DNA.Mvc.Areas.Publishing.Models;
using DNA.Mvc.Installation;
namespace DNA.Mvc.Controllers
{
    [Log]
    [MasterLayout]
    [HandleError(ExceptionType = typeof(PageNotFoundException), View = "NotFound")]
    [HandleError(View = "Error")]
    public class DynamicUIController : Controller
    {
        /// <summary>
        /// Create the Dynamic page
        /// </summary>
        /// <param name="page">The page object create from controller</param>
        /// <returns></returns>
        [HttpPost]
        [SecurityAction("Dynamic UI", "Save new page", "Allows user to save new web page")]
        //[ValidateAntiForgeryToken]
        public ActionResult Create(WebPage page)
        {
            var web = this.CurrentWeb();
            ModelState.Remove("ID");
            ModelState.Remove("ParentID");
            ModelState.Remove("Path");
            if (ModelState.IsValid)
            {
                var _page = web.CreatePage(page, GetRolesCore());
                ClearPageCache();
                //if (HttpContext.Request.IsAjaxRequest())
                //    return Edit(_page.ID);
                //else
                return Redirect(_page.ClientUrl + "?design=true");
            }
            else
                return View();
        }

        /// <summary>
        /// Return the create page view
        /// </summary>
        /// <returns></returns>
        [SecurityAction("Dynamic UI", "Create page", "Allows user can create page.")]
        public ActionResult Create()
        {
            return View();
        }

        /// <summary>
        /// Return the edit page view
        /// </summary>
        /// <param name="id">Specified the page id to edit.</param>
        /// <param name="forms"></param>
        /// <returns>The edit page view</returns>
        [HttpPost]
        [SecurityAction("Dynamic UI", "Save page changes", "Allows the users can save the page changes.")]
        //[ValidateAntiForgeryToken]
        public ActionResult Edit(int id, FormCollection forms)
        {
            //WebPage page = Service.GetPage(id);
            var web = this.CurrentWeb();
            var page = web.GetPage(id);

            ModelState.Remove("ParentID");

            if (ModelState.IsValid)
            {
                if (TryUpdateModel<WebPage>(page, new string[] { "Title", "Description", "LinkUrl", "ViewName", "Target", "ParentID", "ShowInMenu", "AllowAnonymous" }))
                {
                    if (page.AllowAnonymous)
                        page.Update(new string[] { });
                    else
                        page.Update(GetRolesCore());
                }

                ClearPageCache();
                if (HttpContext.Request.IsAjaxRequest())
                    return Edit(id);
                else
                    return Redirect(page.ClientUrl);
            }
            else
                return View();
        }

        [NonAction]
        private string[] GetRolesCore()
        {
            List<string> roles = new List<string>();

            foreach (string key in HttpContext.Request.Form.Keys)
            {
                if (key.StartsWith("Role_"))
                {
                    if (bool.Parse(HttpContext.Request.Form[key]))
                    {
                        string roleName = key.Replace("Role_", "");
                        roles.Add(roleName);
                    }
                }
            }
            return roles.ToArray();
        }

        /// <summary>
        /// Save the page changes
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [SecurityAction("Dynamic UI", "Edit page", "Allows the users can view the page properties.")]
        public ActionResult Edit(int id)
        {
            var page = this.CurrentWeb().GetPage(id);

            if (page == null)
                throw new PageNotFoundException();

            ViewData.Model = page;
            return View();
        }

        /// <summary>
        /// Delete the page by specified page id.
        /// </summary>
        ///<param name="id">The page id.</param>
        [HttpPost]
        [SecurityAction("Dynamic UI", "Delete page", "Allows the users can delete the page.")]
        public void Delete(int id)
        {
            this.CurrentWeb().DeletePage(id);
            ClearPageCache();
        }

        /// <summary>
        /// Display the dyanmic page by specified page name.
        /// </summary>
        /// <remarks>
        ///  If the specified page name not found this action will redirect to the NotFound page.
        /// </remarks>
        /// <param name="layout">The dynamic page name</param>
        /// <returns></returns>
        [SiteMapAction]
        public ActionResult Index(string layout)
        {
            var page = WebContext.Current.Page;

            if (page == null)
            {

                if ((HttpContext.Request.IsAuthenticated) && (this.CurrentWeb() == null) && (HttpContext.Request.Url.LocalPath.EndsWith("index.html", StringComparison.OrdinalIgnoreCase)))
                {
                    if (WebHost.Config.Deployment.EnablePersonalWeb)
                    {
                        var website = HttpContext.Request.RequestContext.RouteData.Values["website"] as string;
                        if ((!string.IsNullOrEmpty(website) && (website.Equals(User.Identity.Name, StringComparison.OrdinalIgnoreCase))))
                            return Redirect(Url.Content("~/DynamicUI/SetupMysite"));
                    }
                    else
                        return Redirect(User.GetPermalinkUrl().ToString());
                }
                throw new PageNotFoundException();
            }

            if (!HttpContext.Request.IsAuthenticated)
            {
                if (!page.AllowAnonymous)
                    return new HttpUnauthorizedResult();
            }

            if (!string.IsNullOrEmpty(page.LinkUrl))
                return Redirect(Url.Content(page.LinkUrl));

            ViewData["Layout"] = page.ViewName;
            return View();
        }

        [Authorize]
        public ActionResult SetupMysite()
        {
            return View();
        }

        [HttpPost]
        [Authorize]
        //[ValidateAntiForgeryToken()]
        public ActionResult SetupMysite(string title, string description)
        {
            if (string.IsNullOrEmpty(title))
                return View();

            DeploymentHelper.DeployPackage("personal/blog",
                new
                {
                    name = User.Identity.Name,
                    title = title,
                    appPath=WebSite.ApplicationPath,
                    description = description,
                    owner = User.Identity.Name
                });

            var mySite = WebSite.Open(User.Identity.Name);
            mySite.EnsurePersonalWebFiles();
            return Redirect(Url.Content(mySite.GetFullUrl() + "/index.html"));
        }

        [SiteControlPanel(ResKey = "RES_PAGEMAN", Order = 2)]
        [MyControlPanel(ResKey = "RES_PAGEMAN", Order = 2, ShowInPersonalSiteOnly = true)]
        [SecurityAction("Dynamic UI", "Page manager", "Allows the users can access the page manager")]
        public ActionResult PageManager()
        {
            return PartialView();
        }

        public ActionResult SubPages(int parentID)
        {
            ViewData.Model = this.CurrentWeb().Children(parentID).OrderBy(p => p.Pos);// Service.GetChildPages(parentID);
            ViewData["Page"] =this.CurrentWeb().GetPage(parentID);
            return PartialView();
        }

        /// <summary>
        /// Move the page position
        /// </summary>
        /// <param name="id">Specified the page id</param>
        /// <param name="parentID">Specified the new parent id of the page</param>
        /// <param name="pos">Specified the page new pos</param>
        [HttpPost]
        [SecurityAction("Dynamic UI", "Move position", "Allows users can move the page to a new position")]
        public void Move(int id, int parentID, int pos)
        {
            //Set parentid=-1 is means the page is move in same parent.
            //Service.Move(parentID, id, pos);
            this.CurrentWeb().MovePage(parentID, id, pos);
            ClearPageCache();
        }

        private void ClearPageCache()
        {
            if (HttpContext.Items.Contains("MainMenuNodes"))
                HttpContext.Items.Remove("MainMenuNodes");
        }

        /// <summary>
        /// Set the specified page to default page
        /// </summary>
        /// <param name="id">Specified the page id</param>
        [HttpPost]
        [SecurityAction("Dynamic UI", "Set default page", "Allows users can set the page as default page of the web.")]
        public void SetDefault(int id)
        {
            this.CurrentWeb().SetDefaultPage(id);
            ClearPageCache();
        }

        [HttpPost]
        public void SetVisible(int id, bool value)
        {
            var p = this.CurrentWeb().GetPage(id);
            p.ShowInMenu = value;
            p.Update();
            ClearPageCache();
        }

        /// <summary>
        /// Import the page json data file and insert page instance into system.
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        [SecurityAction("Dynamic UI", "Import page data", "Allows users can upload the page data file and create a new page.")]
        public ActionResult Import(int id)
        {
            var postedFile = Request.Files[0];
            var reader = new StreamReader(postedFile.InputStream);
            string src = reader.ReadToEnd();
            reader.Close();
            var p = this.CurrentWeb().GetPage(id);
            p.Import(src);
            return Content("");
            //var data = (new JavaScriptSerializer()).Deserialize<WebPageDataContract>(src);
            //this.CurrentWeb().GetPage(id).Import(data);
            //return Content(this.CurrentWeb().GetPage(id).Title);
        }

        /// <summary>
        /// Export specified page instance to the json data file.
        /// </summary>
        /// <param name="id">Specified the page id</param>
        /// <returns>Json data file</returns>
        [SecurityAction("Dynamic UI", "Export page data", "Allows users can export and download the exists page data.")]
        public FileResult Export(int id)
        {
            var page = this.CurrentWeb().GetPage(id);// Service.GetPage(id);
            if (page == null)
                throw new Exception("Page not found");
            var stream = new MemoryStream();
            var writer = new StreamWriter(stream);

            ////if (!page.Widgets.IsLoaded)
            ////    page.Widgets.Load();
            //writer.Write((new JavaScriptSerializer()).Serialize(new WebPageDataContract(page)));
            //writer.Flush();
            //stream.Position = 0;
            //return File(stream, "application/oct-stream", page.Title + ".json");

            #region д��2
            //DNA.Utility.XmlSerializerUtility.SerizlizeToStream(stream, typeof(WebPageStruct),GetPageStruct(page));
            //writer.Flush();
            //stream.Position = 0;
            //return File(stream, "text/xml",page.Title+".xml");
            #endregion

            writer.Write(page.ToXml());
            writer.Flush();
            stream.Position = 0;
            return File(stream, "text/xml", TextUtility.Slug(page.Title) + "-" + DateTime.Now.ToString("yy-MM-dd") + ".xml");
        }

        public FileResult ExportAll()
        {
            //var pages = this.CurrentWeb().ExportPages();//Service.Export();
            //if (pages == null)
            //    throw new Exception("No page found");
            //var stream = new MemoryStream();
            //var writer = new StreamWriter(stream);
            //writer.Write((new JavaScriptSerializer()).Serialize(pages));
            //writer.Flush();
            //stream.Position = 0;
            //return File(stream, "application/oct-stream", "template.json");

            //return Content(this.CurrentWeb().ToXml(), "text/xml");

            var stream = new MemoryStream();
            var writer = new StreamWriter(stream);
            writer.Write(this.CurrentWeb().ToXml());
            writer.Flush();
            stream.Position = 0;
            string fileName = string.IsNullOrEmpty(this.CurrentWeb().Title) ? "" : TextUtility.Slug(this.CurrentWeb().Title);
            fileName += DateTime.Now.ToString("yy-MM-dd") + ".xml";
            return File(stream, "text/xml", fileName);
        }

        public ActionResult PageDetail(int id)
        {
            return View(this.CurrentWeb().GetPage(id));
        }

        [OutputCache(Duration = int.MaxValue, VaryByParam = "none")]
        public ActionResult GoogleSiteMap()
        {
            StringBuilder xmlBuilder = new StringBuilder();
            xmlBuilder.AppendLine("<?xml version=\"1.0\" encoding=\"utf-8\" ?>");
            xmlBuilder.AppendLine("<urlset xmlns=\"http://www.sitemaps.org/schemas/sitemap/0.9\">");
            // .AppendLine("xmlns=\"http://www.sitemaps.org/schemas/sitemap-image/1.1\"")
            // .AppendLine("xmlns=\"http://www.sitemaps.org/schemas/sitemap-video/1.1\">");

            using (var db = DBMan.Instance())
            {
                var pages = from p in db.WebPages
                            where p.AllowAnonymous
                            select p;

                foreach (var page in pages)
                {
                    xmlBuilder.AppendLine("<url>");
                    xmlBuilder.AppendLine("<loc>" + page.PermalinkUrl.ToString() + "</loc>");
                    xmlBuilder.AppendLine("<lastmod>" + page.LastModified.ToString("yyyy-MM-dd") + "</lastmod>");
                    xmlBuilder.AppendLine("<changefreq>weekly</changefreq>");
                    xmlBuilder.AppendLine("</url>");
                }

                var articles = WebSite.Open().DefaultCategory().GetDescendantArticles();

                foreach (var article in articles)
                {
                    xmlBuilder.AppendLine("<url>");
                    xmlBuilder.AppendLine("<loc>" + article.GetPermaLinkUrl() + "</loc>");
                    xmlBuilder.AppendLine("<lastmod>" + article.LastModified.ToString("yyyy-MM-dd") + "</lastmod>");
                    xmlBuilder.AppendLine("<changefreq>weekly</changefreq>");
                    xmlBuilder.AppendLine("</url>");
                }

                xmlBuilder.AppendLine("</urlset>");
                return Content(xmlBuilder.ToString(), "text/xml");
            }
        }

        [OutputCache(Duration = 36000, VaryByParam = "none")]
        public ActionResult RssFeed()
        {
            var doc = this.CurrentWeb().GetRssFeed();
            string xml = DNA.Utility.XmlSerializerUtility.SerializeToXml(typeof(DNA.Mvc.OpenAPI.Rss.RssDocument), doc);
            //xml = xml.Replace("<?xml version=\"1.0\" encoding=\"utf-8\"?>", "<rss version=\"2.0\">");
            return Content(xml, "text/xml");
        }

        [OutputCache(Duration = 36000, VaryByParam = "none")]
        public ActionResult AtomFeed()
        {
            var feed = this.CurrentWeb().GetAtomFeed();
            string xml = DNA.Utility.XmlSerializerUtility.SerializeToXml(typeof(DNA.Mvc.OpenAPI.Atom.AtomFeed), feed);
            return Content(xml, "text/xml");
        }
    }
}
