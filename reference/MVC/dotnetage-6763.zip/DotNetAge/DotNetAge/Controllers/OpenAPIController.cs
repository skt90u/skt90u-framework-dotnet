﻿//  Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Xml;
using DNA.Mvc.OpenAPI.Rsd;
using DNA.Mvc.Models;
using DNA.Mvc.Areas.Publishing.Models;
using System.Net;

namespace DNA.Mvc.Controllers
{
    /// <summary>
    /// The Controller provides the OpenAPI function
    /// </summary>
    public class OpenAPIController : Controller
    {
        public ActionResult Rsd()
        {
            var web = this.CurrentWeb();
            var root = WebSite.Open();
            var doc = new RsdDoc()
            {
                Service = new RsdService()
                {
                    EngineLink = root.GetFullUrl(),
                    HomePageLink = web.GetFullUrl()
                }
            };
            string xmlrpcUrl = root.GetFullUrl() + Url.Content("~/xmlrpc.metaweblog");
            doc.Service.RsdAPIs.Add(new RsdAPI()
            {
                BlogID = web.Name,
                Link = xmlrpcUrl,
                Name = "WordPress",
                Preferred = false,
            });

            doc.Service.RsdAPIs.Add(new RsdAPI()
            {
                BlogID = web.Name,
                Link = xmlrpcUrl,
                Name = "Movable Type",
                Preferred = false,
            });

            doc.Service.RsdAPIs.Add(new RsdAPI()
            {
                BlogID = web.Name,
                Link = xmlrpcUrl,
                Name = "MetaWeblog",
                Preferred = true,
            });

            doc.Service.RsdAPIs.Add(new RsdAPI()
            {
                BlogID = web.Name,
                Link = xmlrpcUrl,
                Name = "Blogger",
                Preferred = false,
            });

            //TODO: Add atom publishing protocol.
            var xmlDoc = DNA.Utility.XmlSerializerUtility.SerializeToXml(typeof(RsdDoc), doc);
            return Content(xmlDoc, "text/xml");
        }

        public ActionResult WlWManifest()
        {
            string baseUrl = ControllerContext.RequestContext.HttpContext.Request.Url.Scheme + "://" + ControllerContext.RequestContext.HttpContext.Request.Url.Authority;
            var web = this.CurrentWeb();
            var xmlDoc = new XmlDocument();
            xmlDoc.Load(HttpContext.Server.MapPath("~/wlwmanifest.xml"));
            var mgr = new XmlNamespaceManager(xmlDoc.NameTable);
            mgr.AddNamespace("n1", "http://schemas.microsoft.com/wlw/manifest/weblog");
            var pageEditUrlNode = xmlDoc.SelectSingleNode("//n1:postEditingUrl", mgr);
            var adminUrlNode = xmlDoc.SelectSingleNode("//n1:adminUrl", mgr);
            var webLayoutNode = xmlDoc.SelectSingleNode("//n1:view[@type='WebLayout']", mgr);
            var webPreviewNode = xmlDoc.SelectSingleNode("//n1:view[@type='WebPreview']", mgr);

            pageEditUrlNode.InnerXml = "<![CDATA[" + baseUrl + ControllerContext.HttpContext.Server.UrlDecode(Url.Action("Trackback", new { Area = "", id = "{post-id}" })) + "]]>";
            adminUrlNode.InnerXml = "<![CDATA[" + baseUrl +
                (web.IsRoot ?
                Url.Action("Index", "Sys", new { Area = "" }) :
                 Url.RouteUrl("dna_mysite", new { website = web.Owner.ToLower(), action = "Console", controller = "Account", Area = "" })) + "]]>";
            webLayoutNode.Attributes["src"].Value = Url.Action("WebLayout", "Article", new { Area = "Publishing", website = web.Name, id = 0 });
            webPreviewNode.Attributes["src"].Value = Url.Action("WebPreview", "Article", new { Area = "Publishing", website = web.Name, id = 0 });

            return Content(xmlDoc.OuterXml, "text/xml");
        }

        public ActionResult Trackback(int id)
        {
            var article = this.CurrentWeb().FindArticle(id);
            if (article != null)
                return Redirect(article.GetPermaLinkUrl());
            throw new PageNotFoundException();
        }

        private bool TestSourceUrl(Uri source, Uri mustHaveThisLink)
        {
            try
            {
                using (var client = new WebClient())
                {
                    client.Credentials = CredentialCache.DefaultNetworkCredentials;
                    var html = client.DownloadString(source);
                    return html.ToUpperInvariant().Contains(mustHaveThisLink.ToString().ToUpperInvariant());
                }
            }
            catch
            {
                return false;
            }
        }

        [HttpPost]
        public ActionResult Trackback(int id, string blog_name, string title, Uri url, string excerpt)
        {
            if (url == null)
                return Content("<?xml version=\"1.0\" encoding=\"iso-8859-1\"?><response><error>Invalid url parameter</error></response>", "text/xml");

            var article = this.CurrentWeb().FindArticle(id);
            if (article == null)
                return Content("<?xml version=\"1.0\" encoding=\"iso-8859-1\"?><response><error>The target entity is not exists.</error></response>", "text/xml");

            if (url.Authority.Equals(WebSite.AppUrl.Authority, StringComparison.OrdinalIgnoreCase))
            {
                var related = this.CurrentWeb().FindArticle(url);
                if (related != null)
                {
                    article.AddRelatedPost(related.ID);
                    return Content("<?xml version=\"1.0\" encoding=\"iso-8859-1\"?><response><error>0</error></response>", "text/xml");
                }
            }

            if (!HttpContext.Request.Url.Host.Equals(url.Host, StringComparison.OrdinalIgnoreCase))
            {
                bool isSpammer = TestSourceUrl(url, new Uri(article.GetTrackbackUrl()));
                if (isSpammer)
                    return Content("<?xml version=\"1.0\" encoding=\"iso-8859-1\"?><response><error>The source URI does not contain a link to the target URI, and so cannot be used as a source</error></response>", "text/xml");
            }

            if (!article.AllowComments)
            {
                Response.StatusCode = 404;
                return Content("<?xml version=\"1.0\" encoding=\"iso-8859-1\"?><response><error>Content not found.</error></response>", "text/xml");
            }

            var comments = article.GetComments();
            if (comments.Count() > 0)
            {
                var _exists = comments.Where(c => c.IsTrackback)
                                                  .FirstOrDefault(c => c.WebSite.Equals(url.ToString(), StringComparison.OrdinalIgnoreCase));
                if (_exists != null)
                    return Content("<?xml version=\"1.0\" encoding=\"iso-8859-1\"?><response><error>Trackback already registered</error></response>", "text/xml");
            }
            article.AddTrackbackComment(blog_name, title, url, excerpt, HttpContext.Request.UserHostAddress);

            //Returns what?
            return Content("<?xml version=\"1.0\" encoding=\"iso-8859-1\"?><response><error>0</error></response>", "text/xml");
        }
    }
}