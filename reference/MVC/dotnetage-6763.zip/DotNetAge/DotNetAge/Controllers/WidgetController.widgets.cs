﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System.Collections.Generic;
using System;
using System.Web;
using System.Web.Mvc;
using System.Web.Script.Serialization;
using DNA.Mvc.Models;
using DNA.Mvc.DynamicUI;
using DNA.Mvc.Text;
using System.Text;
using System.Web.Profile;

namespace DNA.Mvc.Controllers
{
    /// <summary>
    /// 
    /// </summary>
    public partial class WidgetController
    {
        [Widget("Flash", "Embedded the Flash object in the widget.",
            ShowBorder = false,
            ShowHeader = false,
            ImageUrl = "~/Content/Images/Widgets/flash.png",
            IconUrl = "~/Content/Images/Widgets/flash_16.png"
            )]
        [Property("Url", DefaultValue = "")]
        [Property("Width", ValueType = typeof(int), DefaultValue = 100)]
        [Property("Height", ValueType = typeof(int), DefaultValue = 100)]
        [Property("FlashVars", DefaultValue = "")]
        [Property("WMODE", DefaultValue = "opaque")]
        [Property("Quality", DefaultValue = "high")]
        [Property("BackgroundColor", DefaultValue = "#ffffff")]
        // [OutputCache(Duration = 600, VaryByParam = "*")]
        public ActionResult Flash()
        {
            return PartialView();
        }

        [Widget("Favorites", "Gerenate the a link list for favorites",
            ShowBorder = true,
            ShowHeader = true,
            ImageUrl = "~/Content/Images/Widgets/favorite.png",
            IconUrl = "~/Content/Images/Widgets/favorite_16.png"
         )]
        [Property("LinkList")]
        public ActionResult Favorites(string linkList)
        {
            if (!string.IsNullOrEmpty(linkList))
            {
                var serializer = new JavaScriptSerializer();
                ViewData.Model = serializer.Deserialize<List<NavigatableNode>>(linkList);
            }

            return PartialView();
        }

        //[Widget("Flickr", ImageUrl = "~/Content/Images/Widgets/flickr.png", IconUrl = "~/Content/Images/Widgets/icon_flickr_16.png")]
        //public ActionResult Flickr()
        //{
        //    return PartialView();
        //}

        //[Widget("WebNote",
        //     ImageUrl = "~/Content/Images/Widgets/WebNote.png")]
        //[Property("Text", DisplayName = "NoteText")]
        //public ActionResult WebNote()
        //{
        //    return PartialView();
        //}

        //[Widget("ToDoList", ImageUrl = "~/Content/Images/Widgets/ToDoList.png")]
        //[Property("List")]
        //public ActionResult ToDoList()
        //{
        //    return PartialView();
        //}

        [Widget("Donation",
            Description = "The PayPal donate widget.Post the donate information to the paypal.",
            ShowBorder = true,
            ShowHeader = true,
            ImageUrl = "~/Content/Images/Widgets/heart.png",
            IconUrl = "~/Content/Images/Widgets/heart_16.png"
         )]
        [Property("Business", "Paypal ID or email", DefaultValue = "Example@dotnetage.com")]
        [Property("Summary", PropertyControl = ControlTypes.TextArea, DefaultValue = "If you like this site please buy me a beer.")]
        [Property("ItemName", "Donation title", DefaultValue = "Example donation")]
        [Property("ItemNumber", "Item Number", DefaultValue = "2010")]
        [Property("Amount", ValueType = typeof(float), PropertyControl = ControlTypes.Number, DefaultValue = 10.0)]
        [Property("ReturnUrl", DisplayName = "Return after donate")]
        public ActionResult Donation()
        {
            return PartialView();
        }

        [Widget("ImageLink",
            Description = "Display the image by specified url.",
            ShowHeader = false,
            ShowBorder = false,
            ImageUrl = "~/Content/Images/Widgets/link.png",
            IconUrl = "~/Content/Images/Widgets/link_16.png"
            )]
        [Property("ImageUrl", DisplayName = "Url")]
        [Property("LinkUrl", DisplayName = "LinkUrl")]
        [Property("ImageHeight", DisplayName = "Height", ValueType = typeof(int), PropertyControl = ControlTypes.Number)]
        [Property("ImageWidth", DisplayName = "Width", ValueType = typeof(int), PropertyControl = ControlTypes.Number)]
        [Property("Alignment", "Alignment", DefaultValue = "center")]
        [Property("Target", "Target", DefaultValue = "_blank")]
        public ActionResult ImageLink()
        {
            // throw new Exception("This exception is for test!");
            return PartialView();
        }

        [Widget("SimpleHtml", Description = "This widget allows you editing the html on the page in WYSAWYG mode.",
             ImageUrl = "~/Content/Images/Widgets/markup.png", ShowBorder = false, ShowHeader = false)]
        [Property("Text", PropertyControl = ControlTypes.Richtext)]
        [ValidateInput(false)]
        public ActionResult SimpleHtml(string text)
        {
            string t = text;
            return PartialView();
        }

        [Widget("UserInfo",
            Description = "Display current user public information.",
            ShowHeader = true,
            ShowBorder = true,
            ImageUrl = "~/Content/Images/Widgets/user.png",
            IconUrl = "~/Content/Images/Widgets/user_16.png"
             )]
        //[Property("UserName")]
        public ActionResult UserInfo()
        {
            ViewData.Model = System.Web.Security.Membership.GetUser(WebContext.Current.Web.Owner).GetProfile();
            return PartialView();
        }

        [Widget("WhoIsOnline",
            Description = "Display the statistics information of the website.",
             ImageUrl = "~/Content/Images/Widgets/users.png",
             IconUrl = "~/Content/Images/Widgets/users_16.png"
            )]
        [Property("Minutes", DisplayName = "Minutes since last in active",
            PropertyControl = ControlTypes.Number,
            ValueType = typeof(int), DefaultValue = 20)]
        public ActionResult WhoIsOnline(int minutes)
        {
            var web = WebSite.Open(RouteData);
            ViewData.Model = web.GetStatistics(minutes);
            ViewData["Guests"] = web.GetOnlineUsers(false, minutes);
            ViewData["Registers"] = web.GetOnlineUsers(true, minutes);
            return PartialView();
        }

        [Widget("Referring",
            Description = "Display which site refer to this website.",
            ShowBorder = true,
            ShowHeader = true,
            ImageUrl = "~/Content/Images/Widgets/icon_referrer.png",
            IconUrl = "~/Content/Images/Widgets/icon_referrer_16.png"
            )]
        public ActionResult Referring()
        {
            ViewData.Model = this.CurrentWeb().UrlRefers;
            return PartialView();
        }

        [Widget("WikiViewer",
            Description = "This widget can display the widget format file.",
            ShowBorder = false,
            ShowHeader = false,
            ImageUrl = "~/Content/Images/Widgets/wikiviewer.png",
            IconUrl = "~/Content/Images/Widgets/wikiviewer_16.png"
            )]
        [Property("FileUrl")]
        //[Property("PageName")]
        public ActionResult WikiViewer(string fileUrl)
        {
            if (!string.IsNullOrEmpty(fileUrl))
            {
                Uri uri = null;
                Uri.TryCreate(fileUrl, UriKind.Absolute, out uri);
                if (uri == null)
                    ViewData.ModelState.AddModelError("", "Bad uri.");

                if (!WebSite.AppUrl.Authority.Equals(uri.Authority, StringComparison.OrdinalIgnoreCase))
                    ViewData.ModelState.AddModelError("", "The external uri is no support.");

                if (ModelState.IsValid)
                {
                    string fileName = WebContext.Current.Web.MapPath(uri);
                    try
                    {
                        ViewData["Content"] = System.IO.File.ReadAllText(fileName);
                    }
                    catch
                    {
                        ViewData.ModelState.AddModelError("", "Read file error.");
                    }
                }
            }
            else
                ViewData.ModelState.AddModelError("","No wiki file found.");
            return PartialView();
        }

        //2010-8-13 added for DNA beta.
        [Widget("Wiki",
            Description = "The Wiki widget allows you write the article in wiki format.",
            ShowBorder = true,
            ShowHeader = true,
               ImageUrl = "~/Content/Images/Widgets/wiki.png",
            IconUrl = "~/Content/Images/Widgets/wiki_16.png"
            )]
        [Property("Body", DefaultValue = "")]
        [ValidateInput(false)]
        public ActionResult Wiki()
        {
            return PartialView();
        }

        [Widget("ContactCard",
            Description = "Display the contact info to clients",
            ShowHeader = true,
            ShowBorder = true,
            ImageUrl = "~/Content/Images/Widgets/contact.png",
            IconUrl = "~/Content/Images/Widgets/contact_16.png"
            )]
        [Property("Company")]
        [Property("Contact")]
        [Property("Phone")]
        [Property("Mobile")]
        [Property("Fax")]
        [Property("Email")]
        [Property("WebSite")]
        [Property("Address", PropertyControl = ControlTypes.TextArea)]
        [Property("PostCode")]
        public ActionResult ContactCard()
        {
            return PartialView();
        }

        [Widget("AdSense",
            Description = "Google Ad sense",
            ShowBorder = false,
            ShowHeader = false,
             ImageUrl = "~/Content/Images/Widgets/icon_google_36.png",
             IconUrl = "~/Content/Images/Widgets/icon_google_16.png")]
        [Property("SlotID", DefaultValue = "")]
        [Property("ClientCode", DefaultValue = "")]
        [Property("AdHeight", ValueType = typeof(int), DefaultValue = 250)]
        [Property("AdWidth", ValueType = typeof(int), DefaultValue = 300)]
        public ActionResult AdSense()
        {
            return PartialView();
        }

        [Widget("BidVertister", "BidVertister Ad")]
        [Property("PID", DefaultValue = "")]
        [Property("BID", DefaultValue = "")]
        [Property("AdHeight", ValueType = typeof(int), DefaultValue = 250)]
        public ActionResult BidVertister()
        {
            return PartialView();
        }

        public ActionResult BidVertisterCode(string pid, string bid)
        {
            if (string.IsNullOrEmpty(pid) || string.IsNullOrEmpty(bid))
                return Content("<html><body></body></html>", "text/html");

            StringBuilder html = new StringBuilder();
            html.Append("<html><head><title></title></head>")
                   .AppendLine("<body><center>")
                   .AppendLine("<script language=\"javascript\" src=\"http://bdv.bidvertiser.com/BidVertiser.dbm?pid=" + pid.ToString() + "&bid=" + bid.ToString() + "\" type=\"text/javascript\"></script>")
                   .AppendLine("<noscript><a href=\"http://www.bidvertiser.com/bdv/BidVertiser/bdv_advertiser.dbm\">internet advertising</a></noscript>")
                   .AppendLine("</center></body></html>");
            return Content(html.ToString(), "text/html");
        }

        public ActionResult AdSenseCode(string id, string clientCode, int height, int width)
        {
            StringBuilder html = new StringBuilder();
            html.Append("<html><head><title></title></head>")
                   .AppendLine("<body><center>")
                   .AppendLine("<script type=\"text/javascript\"><!--")
                   .AppendLine("google_ad_client = \"" + clientCode + "\";")
                   .AppendLine("google_ad_slot = \"" + id + "\";")
                   .AppendLine("google_ad_width = " + width.ToString() + ";")
                   .AppendLine("google_ad_height = " + height + ";")
                   .AppendLine("//-->")
                   .AppendLine("</script>")
                   .AppendLine("<script type=\"text/javascript\" src=\"http://pagead2.googlesyndication.com/pagead/show_ads.js\"></script>")
                   .AppendLine("</center></body></html>");
            return Content(html.ToString(), "text/html");
        }

        [Widget("SendMail",
    Description = "Provides the form to get user info and send to the site admin",
    ShowHeader = true,
    ShowBorder = true,
    ImageUrl = "~/Content/Images/Widgets/mail_send.png",
    IconUrl = "~/Content/Images/Widgets/mail_send_16.png"
    )]
        [Property("Receiver")]
        [Property("Subject")]
        [OutputCache(Duration = int.MaxValue, VaryByParam = "*")]
        public ActionResult SendMail()
        {
            return PartialView();
        }

        [HttpPost]
        public ActionResult SendMailTo(MailMessageModel mail)
        {
            if (ModelState.IsValid)
            {
                var web = WebSite.Open("");

                if (!string.IsNullOrEmpty(web.SiteMailAccount))
                {
                    StringBuilder builder = new StringBuilder();
                    string senderName = mail.Sender + " (" + mail.SenderName + ")";
                    builder.Append(senderName)
                              .Append(" contacted you thougth ")
                              .Append(Request.Url.Authority)
                              .AppendLine("The following is the message from " + senderName)
                              .AppendLine(mail.MailBody);
                    mail.MailBody = builder.ToString();
                    this.MailTo(mail);
                    return Content("<div class='ui-state-highlight' style='padding:15px;'>The mail was sent.</div>");
                }
            }
            return RedirectToAction("SendMail");
        }

        #region Administrator widgets kits.
        
        [Widget("PageViewer",
            Description="This widget designed for user to run ascx file")]
        [Property("ViewName")]
        public ActionResult PageViewer()
        {
            return PartialView();
        }

        [Widget("HtmlViewer",
    Description = "This widget allows user links to external web page by url.")]
        [Property("TargetName")]
        [Property("Url")]
        [Property("Height",ValueType=typeof(int),PropertyControl=ControlTypes.Number,DefaultValue=300)]
        public ActionResult HtmlViewer()
        {
            return PartialView();
        }

    //    [Widget("NavBar",
    //Description = "This widget display the Navbar from xml datasource.")]
    //    [Property("DataSourceUrl")]
    //    public ActionResult NavBar()
    //    {
    //        return PartialView();
    //    }

        [Widget("TreeView",
            Description="This widget could read the xml datasource into treeview.")]
        [Property("DataSourceUrl")]
        public ActionResult Tree()
        { 
            return PartialView();
        }

        #endregion

        //[Widget("GeneralWidget",
        //    "This widget supports the widget implement the w3c widget.",
        //    Browsable=false
        //    )]
        public ActionResult GeneralWidget(Guid wid)
        {
            var widget=Service.GetWidget(wid);
            if (widget != null)
            { 

            }
            return View();
        }
    }


}
