﻿$(function () {
    window.urlHelper = {
        // public method for url encoding
        encode: function (string) {
            return escape(this._utf8_encode(string));
        },

        // public method for url decoding
        decode: function (string) {
            return this._utf8_decode(unescape(string));
        },

        // private method for UTF-8 encoding
        _utf8_encode: function (string) {
            string = string.replace(/\r\n/g, "\n");
            var utftext = "";

            for (var n = 0; n < string.length; n++) {
                var c = string.charCodeAt(n);
                if (c < 128) {
                    utftext += String.fromCharCode(c);
                }
                else if ((c > 127) && (c < 2048)) {
                    utftext += String.fromCharCode((c >> 6) | 192);
                    utftext += String.fromCharCode((c & 63) | 128);
                }
                else {
                    utftext += String.fromCharCode((c >> 12) | 224);
                    utftext += String.fromCharCode(((c >> 6) & 63) | 128);
                    utftext += String.fromCharCode((c & 63) | 128);
                }
            }
            return utftext;
        },

        // private method for UTF-8 decoding
        _utf8_decode: function (utftext) {
            var string = "";
            var i = 0;
            var c = c1 = c2 = 0;
            while (i < utftext.length) {
                c = utftext.charCodeAt(i);
                if (c < 128) {
                    string += String.fromCharCode(c);
                    i++;
                }
                else if ((c > 191) && (c < 224)) {
                    c2 = utftext.charCodeAt(i + 1);
                    string += String.fromCharCode(((c & 31) << 6) | (c2 & 63));
                    i += 2;
                }
                else {
                    c2 = utftext.charCodeAt(i + 1);
                    c3 = utftext.charCodeAt(i + 2);
                    string += String.fromCharCode(((c & 15) << 12) | ((c2 & 63) << 6) | (c3 & 63));
                    i += 3;
                }
            }
            return string;
        }
    }
    window.uiHelper = {
        htmlEncode: function (strHtml) {
            if (strHtml)
                return strHtml.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
            else
                return "";
        },
        htmlDecode: function (strHtml) {
            if (this.isHtmlEncode(strHtml))
                return strHtml.replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>');
            return strHtml;
        },
        addBookMark: function (title) {
            var url = location.href;
            if ($.browser.mozilla) {
                window.sidebar.addPanel(title, url, '');
                return false;
            } else if ($.browser.msie) {
                window.external.AddFavorite(url, title);
                return false;
            } else {
                alert('Please use CTRL + D to bookmark this website.');
            }
        },
        isHtmlEncode: function (strHtml) {
            if (strHtml.search(/&amp;/g) != -1 || strHtml.search(/&lt;/g) != -1 || strHtml.search(/&gt;/g) != -1)
                return true;
            else
                return false;
        },
        previewBox: function (title, src) {
            var img = $('<img alt="' + title + '"style="display:none;padding: 8px;" />')
						.attr('src', src).appendTo('body');
            uiHelper.blockUI();
            img.load(function () {
                uiHelper.unblockUI();
                var _dlg = img.dialog({
                    title: title,
                    width: img.width(),
                    height: img.height(),
                    modal: true,
                    close: function () { img.remove(); }
                });
                img.dialog("widget").css({ "text-align": "center" });
            });
        },
        createDefaultLoader: function () {
            var _loader = $("<div></div>").appendTo(document.body)
            .addClass("ui-widget-content ui-corner-all ui-state-active")
            .css({
                padding: 10,
                height: 40,
                width: 150
            });
            $("<div>Loading...</div>").appendTo(_loader)
            .css({
                "text-align": "center",
                "display": "block",
                "margin-bottom": "5px"
            });
            var pgbar = $("<div></div>").appendTo(_loader).css({ height: 10 });
            if ($.fn.progressbar) {
                pgbar.progressbar();
                var iid = setInterval(function () {
                    if (pgbar) {
                        var _v = pgbar.progressbar("option", 'value');
                        if (_v == 100)
                            pgbar.progressbar("option", "value", 0);
                        else
                            pgbar.progressbar("option", "value", _v + 10);
                    }
                    else
                        clearInterval(iid);
                }, 1000);
            }
            return _loader;
        },
        blockUI: function (el, loader) {
            var _loader = null;

            if (el) {
                if ($(el).length == 0)
                    return;
                if ($(".ui-blocking:first", el).length > 0)
                    return;
            }
            else {
                if (this.blocker)
                    return;
            }

            if (loader) {
                if ($.isFunction(loader))
                    _loader = loader();
                else
                    _loader = loader;

            } else
                _loader = this.createDefaultLoader();

            var $el = null;
            //var bgLayer = null; //just use in ff
            var _w = document.documentElement.scrollWidth, _h = document.documentElement.scrollHeight, _l = 0, _t = 0;
            //block element

            if (el) {
                _w = $(el).outerWidth(true);
                _h = $(el).outerHeight(true);
                $el = $('<div></div>').appendTo(el)
			.addClass('ui-blocking')
			.css({
			    width: _w,
			    height: _h
			});
                var _pos = $(el).position();
                _l = _pos.left;
                _t = _pos.top;
            }
            else {
                //block screen
                $el = $('<div></div>')
                                .appendTo(document.body)
                                .addClass('ui-blocking')
                                .css({ width: _w, height: _h });
                document.body.style.overflow = "hidden";

            }

            //if (!$.browser.msie) {
            //$el.removeClass("ui-widget-overlay");
            $el.append($("<div></div>")
                                 .addClass("ui-widget-overlay")
                                 .css({
                                     width: _w,
                                     height: _h,
                                     left: _l,
                                     top: _t,
                                     "position": "absolute"
                                 }));
            //}
            _loader.appendTo($el);
            //$el.append(_loader);

            var _top = ($el.outerHeight(true) / 2) - (_loader.outerHeight(true) / 2);
            var _left = ($el.outerWidth(true) / 2) - (_loader.outerWidth(true) / 2);
            if ($.browser.safari)
                _left = ($el.width() / 2) - (_loader.width() / 2);

            if (el) {
                _top = _t + _top;
                _left = _l + _left;
            }
            _loader.css({
                left: _left,
                top: _top,
                position: "absolute",
                "-moz-opacity": "1",
                "filter": "Alpha(Opacity=100)"
            });

            if (el == undefined)
                this.blocker = $el;
        },
        unblockUI: function (el) {
            if (el) {
                var _blocker = $(".ui-blocking:first", el);
                if (_blocker.length > 0) {
                    _blocker.fadeOut("normal");
                    _blocker.remove();
                }
            } else {
                if (this.blocker) {
                    this.blocker.fadeOut("normal");
                    this.blocker.remove();
                    this.blocker = null;
                    document.body.style.overflow = "";
                }
            }
        },
        rgbToHex: function (str) {
            str = str.replace(/rgb\(|\)/g, "").split(",");
            str[0] = parseInt(str[0], 10).toString(16).toLowerCase();
            str[1] = parseInt(str[1], 10).toString(16).toLowerCase();
            str[2] = parseInt(str[2], 10).toString(16).toLowerCase();
            str[0] = (str[0].length == 1) ? '0' + str[0] : str[0];
            str[1] = (str[1].length == 1) ? '0' + str[1] : str[1];
            str[2] = (str[2].length == 1) ? '0' + str[2] : str[2];
            return ('#' + str.join(""));
        },
        inputDialog: function (strTitle, strInputText, fCallback) {
            var _dlg = $("<div></div>").appendTo("body").attr("title", strTitle);
            $("<div></div>").appendTo(_dlg).text(strInputText);
            $("<div></div>").appendTo(_dlg).append("<input />");
            var _input = $("input", _dlg);
            if ($.ui.textbox) _input.textbox({ value: "" });

            _dlg.dialog({
                bgiframe: true,
                show: "slide",
                hide: "slide",
                resizable: false,
                modal: true,
                buttons: {
                    "OK": function () {
                        if (_input.val()) {
                            if ($.isFunction(fCallback))
                                fCallback(_input.val());
                            $(this).dialog("close");
                        }
                        else
                            _input.focus();
                    },
                    "Cancel": function () { $(this).dialog("close"); }
                }
            });
        },
        confirm: function (title, msg, callback) {
            var _d = $("<div title='" + title + "'><p><span class=\"ui-icon ui-icon-alert\" style=\"float:left; margin:0 7px 20px 0;\"></span>" + msg + "</p></div>");
            _d.dialog({
                show: "slide",
                hide: "slide",
                modal: true,
                resizable: false,
                buttons: {
                    "Yes": function () {
                        if (callback)
                            callback();
                        _d.dialog("close");
                        _d.remove();
                    },
                    "No": function () {
                        _d.dialog("close");
                        _d.remove();
                    }
                }
            });
        },
        showMsg: function (title, msg) {
            var _d = $("<div title='" + title + "'>" + msg + "</div>");
            _d.dialog({
                show: "slide",
                hide: "slide",
                modal: true,
                overlay: {
                    backgroundColor: '#000000',
                    opacity: 0.5
                },
                buttons: {
                    "OK": function () {
                        _d.dialog("close");
                        _d.remove();
                    }
                }
            });
        },
        formatDate: function (jsonDate) {
            var tick = parseInt(jsonDate.substring(6, 19));
            return (new Date(tick)).toDateString();
        },
        showDlg: function (title, msg) { this.showMsg(title, msg); }
    }

    $.dna=$dna = uiHelper;
});