﻿/// <reference path="../jquery-1.4.4.js" />
/// <reference path="../jquery-1.4.4-vsdoc.js" />

/*!  
** Copyright (c) 2011 Ray Liang (http://www.dotnetage.com)
** Dual licensed under the MIT and GPL licenses:
** http://www.opensource.org/licenses/mit-license.php
** http://www.gnu.org/licenses/gpl.html
** 
**----------------------------------------------------------------
** title        : DJME button
** version   : 2.0.0
** modified: 2010-2-24
** depends:
**    jquery.ui.core.js
**    jquery.ui.widget.js
**    WidgetClientTemplate.ascx 
**----------------------------------------------------------------
*/

(function ($) {
    $.widget("ui.portable", {
        options:
        {
            items: ".d-widget-zone",
            url: null,  //"/Widget/Load",
            mode: null,
            baseUrl: null
        },
        _create: function () {
            var self = this, opts = this.options, el = this.element,
             _zones = this.element.find(opts.items);
            if (_zones.length > 0) {
                if (opts.mode == "design") {
                    _zones.sortable({
                        connectWith: opts.items,
                        placeholder: "d-widget-placeholder", //"ui-state-highlight",
                        forceHelperSize: true,
                        forcePlaceholderSize: true,
                        revert: true,
                        opacity: 0.8,
                        helper: 'clone',
                        cursor: "move",
                        handle: "h2",
                        update: function (event, ui) {
                            try {
                                var widgets = $(".d-widget", this), _pos = -1;
                                if (widgets.length > 0)
                                    _pos = widgets.index(ui.item);
                                if (_pos != -1)
                                    ui.item.portlet("move", $(this).attr("id"), _pos);
                            }
                            catch (e) {
                                $(ui.sender).sortable('cancel');
                            }
                        }
                    });

                    _zones.addClass("d-widget-zone-design")
                               .droppable({
                                   accept: ".d-widget",
                                   activeClass: "d-widget-zone-allow-drop",
                                   hoverClass: "ui-state-highlight"
                               });
                }

                $.ajax({
                    url: opts.url,
                    cache: false,
                    data: { url: document.URL },
                    dataType: "json",
                    error: function (response) {
                        uiHelper.showDlg(response.statusText, response.responseText);
                    },
                    success: function (data) {
                        $.each(data, function (i, group) {
                            var _dockZone = $("#" + group.Key);
                            if (_dockZone.length) {
                                $("#widget_template").tmpl(group.Items).appendTo(_dockZone);
                            }
                        });
                        $(".d-widget", _zones).portlet({ design: true, baseUrl: self.options.baseUrl });
                    }
                });
            }
        }
    });


    $.widget("ui.portlet", {
        options: {
            preview: false,
            design: true,
            zoneId: "",
            dataItem: null,
            baseUrl: "/Widget/",
            exportActionUrl: "Export",
            applyActionUrl: "Apply",
            moveActionUrl: "MoveTo",
            removeActionUrl: "Delete",
            toggleActionUrl: "Toggle",
            userPreferences: "form.d-widget-userpreferences"
        },
        _create: function () {
            var self = this, opts = this.options, el = this.element;

            //fixed the url issuse
            if (opts.baseUrl) {
                opts.exportActionUrl = opts.baseUrl + opts.exportActionUrl;
                opts.applyActionUrl = opts.baseUrl + opts.applyActionUrl;
                opts.moveActionUrl = opts.baseUrl + opts.moveActionUrl;
                opts.removeActionUrl = opts.baseUrl + opts.removeActionUrl;
                opts.toggleActionUrl = opts.baseUrl + opts.toggleActionUrl;
            }

            var dat = this.options.dataItem = this.element.tmplItem().data;

            /*-------------------------Init verbs---------------------------------------*/

            var verb_export = $(">.d-widget-header .d-widget-verb-export", this.element);
            if (verb_export.length) verb_export.click(function () { self._export(); });

            var verb_del = $(">.d-widget-header .d-widget-verb-delete", this.element);
            if (verb_del.length) verb_del.click(function () { self._delete(); });


            var verb_refresh = $(">.d-widget-header .d-widget-verb-refresh", this.element);
            if (verb_refresh.length) verb_refresh.click(function () {
                self._load();
            });

            var verb_toggle = $(">.d-widget-header .d-widget-verb-toggle", this.element);
            if (verb_toggle.length) verb_toggle.click(function () { self._toggle(); });

            if (this.options.preview) {
                verb_export.remove();
                verb_del.remove();
                verb_toggle.remove();
                $(">.d-widget-footer", this.element).hide();
            }

            var verb_uf = $(">.d-widget-header .d-widget-verb-setting", this.element);
            if (verb_uf.length) verb_uf.click(function () {
                /*------TODO:Show User Prefences settings there------*/
                $(this).hide();
                self.element.find(opts.userPreferences).slideDown("fast");
            });

            if ((dat.IsExpanded) && (dat.Url)) this._load();

            var commonsettings = $(".d-widget-common-settings", this.element);
            if (commonsettings.length) {
                commonsettings.click(function () {
                    var dlg = $("#widget_setting_dlg_tmpl").tmpl(self.options.dataItem).appendTo("body");
                    dlg.dialog({
                        modal: true,
                        dialogClass: "d-dialog",
                        resizable: false,
                        buttons: {
                            "OK": function () {
                                var _form = $("form", this);
                                $.ajax({
                                    type: "POST",
                                    url: _form.attr("action"),
                                    data: _form.serialize(),
                                    error: function (response) {
                                        uiHelper.showDlg(response.statusText, response.responseText);
                                    },
                                    success: function () {
                                        with (self.options.dataItem) {
                                            Title = $("#txtWidgetTitle", _form).val();
                                            TitleLinkUrl = $("#txtWidgetTitleLink", _form).val();
                                            IconUrl = $("#txtWidgetIconLink", _form).val();
                                            ShowBorder = $("#cbShowBorder", _form).val() == "true" ? true : false;
                                            ShowHeader = $("#cbShowHeader", _form).val() == "true" ? true : false;
                                        }
                                        self._updateUI();
                                        dlg.dialog("close");
                                    }
                                });
                            },
                            "Close": function () { $(this).dialog("close"); }
                        },
                        close: function () { dlg.remove(); },
                        open: function () {
                            $("input[type='text']", this).textbox();
                        }
                    });
                });
            }
        },
        _updateUI: function () {
            var dat = this.options.dataItem, _header = $(".d-widget-header", this.element), _icon = $(".d-widget-title-icon", _header),
             _txt = $(".d-widget-title-text", _header), _link = $(".d-widget-title-link", _header);

            if (dat.ShowHeader) _header.removeClass("d-widget-header-hide");
            else _header.addClass("d-widget-header-hide");

            if (dat.ShowBorder) this.element.removeClass("d-widget-no-border");
            else this.element.addClass("d-widget-no-border");

            if (dat.IconUrl) {
                _icon.attr("src", dat.IconUrl);
                _icon.show();
            }
            else {
                _icon.hide();
            }
            _link.attr("href", dat.TitleLinkUrl ? dat.TitleLinkUrl : "javascript:void(0);");
            _txt.text(dat.Title);
        },
        _refresh: function () {
            this._load();

        },
        _export: function () { window.open(this.options.exportActionUrl + "?wid=" + this.options.dataItem.ID); },
        _delete: function () {
            var self = this, el = this.element;
            uiHelper.confirm("Are you sure?", "Are you sure to delete this widget?", function () {
                $.post(self.options.removeActionUrl, { id: self.options.dataItem.ID }, function () {
                    self.destroy();
                    el.remove();
                });
            });
        },
        _toggle: function () {
            var self = this;
            $.post(self.options.toggleActionUrl, { id: self.options.dataItem.ID });

            self.options.dataItem.IsExpanded = !self.options.dataItem.IsExpanded;
            if (self._isloaded)
                self._toggleElements();
            else
                self._load();
        },
        _toggleElements: function () {
            var self = this;
            var verb_toggle = $(">.d-widget-header .d-widget-verb-toggle", this.element),
             _body = $(">.d-widget-body", self.element)
            _body.stop().animate({
                width: 'toggle',
                height: 'toggle'
            }, {
                duration: 200,
                specialEasing: {
                    width: 'swing',
                    height: 'swing'
                },
                complete: function () {
                    self.element.toggleClass("d-widget-collapsed");
                }
            });
        },
        _load: function () {
            var self = this, opts = this.options, _body = $(">.d-widget-body", self.element);
            $.ajax({
                url: opts.dataItem.Url,
                data: {
                    wid: opts.dataItem.ID,
                    preview: opts.preview,
                    design: opts.design
                },
                beforeSend: function () {
                    _body.empty()
                    .append($("<div/>").addClass("d-loader"));
                },
                error: function (response, textStatus, errorThrown) { _body.html(response.responseText).show(); },
                success: function (htm) {

                    /*------------------Render iframe to supports W3C widgets---------------------------*/
                    _body.html(htm);
                    self._bodyWidth = _body.width();
                    self._bodyHeight = _body.height();
                    self._isloaded = true;

                    /*--------------------------------Setting form-----------------------------------------------------*/
                    var verb_up = $(">.d-widget-header .d-widget-verb-setting", self.element);
                    if (_body.find(opts.userPreferences).length) {
                        self._createUserPreferencesButtons();
                        verb_up.show();
                    }
                    else
                        verb_up.hide();

                    self.element.removeClass("d-widget-collapsed");
                    _body.show();
                }
            });
        },
        _apply: function () {
            var opts = this.options;
            this.title.text(opts.title);
            if (opts.titlelink)
                this.title.attr("href", urlHelper.encode(opts.titlelink));
            else
                this.title.attr("href", "javascript:void(0);");
            if (opts.icon)
                this.titleicon = $("<span></span>").prependTo(this.title)
                                                      .css({
                                                          "width": "16px",
                                                          "height": "16px",
                                                          "float": "left",
                                                          "margin-right": "3px",
                                                          "background-image": "url(" + opts.icon + ")"
                                                      });
            if (!this.options.showHeader) this.header.css({ opacity: "0.5" });
            this._initBodyStyle();
        },
        _initBodyStyle: function () {
            var opts = this.options;
            if (this.body) {
                if (opts.bgColor)
                    this.body.css({
                        "background-color": opts.bgColor,
                        "background-image": "none"
                    });
                if (opts.color) this.body.css({ "color": opts.color });
                if (opts.showHeader)
                    this.body.css({
                        "border-top-style": "solid",
                        "border-top-width": "1px",
                        "border-top-color": "transparent"
                    });

                if (opts.design) {
                    if (!opts.showBorder)
                        this.body.css({
                            "border-style": "dashed",
                            "border-width": "1px"
                        });
                }
                else {
                    if (!opts.showBorder)
                        this.body.css({ "border": "none" });
                }
                if (!opts.expanded) this.body.hide();
            }
        },
        _createUserPreferencesButtons: function () {
            var self = this, opts = this.options, _form = this.element.find(opts.userPreferences);

            if (_form.length) {
                //if (this.settings.buttonPanel) this.settings.buttonPanel.remove();
                var _buttonPanel = $("<div/>").appendTo(_form)
                                                               .css({
                                                                   "overflow": "auto",
                                                                   "padding": "5px"
                                                               });
                //&apply=true
                _form.submit(function (e) {
                    if (!e.isDefaultPrevented()) {
                        $.ajax({
                            type: "PUT",
                            url: opts.dataItem.Url + "?wid=" + opts.dataItem.ID + "&preview=" + opts.preview,
                            data: _form.serialize(),
                            error: function (response) { uiHelper.showDlg(response.statusText, response.responseText); },
                            success: function () {
                                _form.slideUp("fast");
                                self._load();
                            }
                        });
                    }
                    e.preventDefault();
                });

                var _btnSave = $("<button/>").appendTo(_buttonPanel)
                                                                  .click(function (event) {
                                                                      event.preventDefault();
                                                                      _form.submit();
                                                                  })
                                                                  .button({ label: "Save" });

                var _btnCancel = $("<button/>").appendTo(_buttonPanel)
                                                                                     .click(function (event) {
                                                                                         event.preventDefault();
                                                                                         _form.slideUp();
                                                                                         $(">.d-widget-header .d-widget-verb-setting", self.element).show();
                                                                                     })
                                                                                    .button({ label: "Cancel" });
            }
        },
        move: function (zid, pos) {
            $.ajax({
                type: "POST",
                url: this.options.moveActionUrl,
                data: {
                    id: this.options.dataItem.ID,
                    zoneID: zid,
                    position: pos
                },
                error: function (response) {
                    uiHelper.showDlg(response.statusText, response.responseText);
                }
            });
        },
        widget: function () {
            return this.element;
        },
        destroy: function () {
            //$(".ui-widget-menu", this.element).unbind();
            $.Widget.prototype.destroy.call(this);
        }
    });

})(jQuery);   