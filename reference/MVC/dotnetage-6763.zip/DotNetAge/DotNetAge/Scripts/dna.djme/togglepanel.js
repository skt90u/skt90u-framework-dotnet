﻿/// <reference path="../jquery-1.4.4.js" />
/// <reference path="../jquery-1.4.4-vsdoc.js" />

/*!  
** Copyright (c) 2011 Ray Liang (http://www.dotnetage.com)
** Dual licensed under the MIT and GPL licenses:
** http://www.opensource.org/licenses/mit-license.php
** http://www.gnu.org/licenses/gpl.html
** 
**----------------------------------------------------------------
** title        : DJME TogglePanel
** version   : 2.0.0
** modified: 2010-1-28
** depends:
**    jquery.ui.core.js
**    jquery.ui.widget.js
**    jquery.ui.mouse.js
**    jquery.ui.draggable.js
**    jquery.ui.droppable.js
**    jquery.ui.resizable.js
**----------------------------------------------------------------
*/
(function ($) {
    $.widget("ui.togglePanel", {
        options: {
            showEffect: "slide",
            hideEffect: "slide",
            draggable: false,
            droppable: false,
            resizable: false,
            duration: 200,
            //isExpanded: true,
            expanded: null,
            collapsed: null
        },
        _create: function () {
            var el = this.element, self = this, eventPrefix = this.widgetEventPrefix;
            if (!el.hasClass("d-panel")) el.addClass("d-panel");
            self.header = $(">.d-panel-header", el);
            self.body = $(">.d-panel-body", el);
            if (this.options.collapsed)
                el.bind(eventPrefix + "collapsed", this.options.collapsed);
            if (this.options.expanded)
                el.bind(eventPrefix + "expanded", this.options.expanded);

            if (el.hasClass("d-panel-collapsed")) { self.body.hide(); }

            self.header.click(function () {
                if (el.data("isdrag")) { el.data("isdrag", false); return; }
                if (el.hasClass("d-panel-collapsed"))
                    self.expand();
                else
                    self.collapse();
            });

            self.setResize();

            if (self.options.draggable) {
                el.draggable({
                    handle: self.header,
                    iframeFix: true,
                    stop: function () { el.data("isdrag", true); }
                });
            }
        },
        _fx: function () {
            return {};
        },
        setResize: function () {
            if (this.options.resizable) {
//                if (this.body.hasClass("ui-resizable"))
//                    this.body.removeClass("ui-resizable");
                this.body.resizable({
                    alsoResize: this.element,
                    helper: "ui-state-highlight"
                });
            }
        },
        _triggerEvent: function (eventName, eventArgs) {
            this.element.trigger(this.widgetEventPrefix + eventName, eventArgs);
        },
        expand: function () {
            var $h = this.header, $b = this.body, self = this;
            if (this.element.hasClass("d-panel-collapsed")) {
                $b.show(this.options.showEffect, self._fx(), this.options.duration, function () {
                    self.element.removeClass("d-panel-collapsed");
                    self._triggerEvent("expanded", { "header": $h, "body": $b });
                });
            }
        },
        collapse: function () {
            var $h = this.header, $b = this.body, self = this;
            if (this.element.hasClass("d-panel-collapsed")) return;
            this.element.css("height", "auto");
            $b.hide(this.options.hideEffect, self._fx(), this.options.duration, function () {
                self.element.addClass("d-panel-collapsed");
                self._triggerEvent("collapsed", { "header": $h, "body": $b });
            });
        },
        destroy: function () {
            $.Widget.prototype.destroy.call(this);
        }
    });

})(jQuery);   