﻿/// <reference path="../jquery-1.4.1-vsdoc.js" />
///  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
///  Dual licensed under the MIT and GPL licenses:
///  http://www.opensource.org/licenses/mit-license.php
///  http://www.gnu.org/licenses/gpl.html

(function ($) {
    $.widget("ui.rating", {
        options: {
            value: 0,
            maxrating: 5,
            readOnly: false,
            starIcon: "ui-icon ui-icon-star",
            cssClass: "ui-state-default",
            hoverClass: "ui-state-active",
            change: null
        },
        _create: function () {
            var self = this, opts = this.options, el = this.element;
            if (opts.change)
                this.element.bind("ratingchange", opts.change);

            _starts = $("<ul></ul>").appendTo(el)
                                               .addClass("ui-helper-reset");
                                               //.css({ "display": "inline-block" });
            if (!opts.readOnly) {
                _starts.bind("mouseenter", function () {
                    self.mouseOn = true;
                });
                _starts.bind("mouseleave", function () {
                    self._setRatings(opts.value);
                    self.mouseOn = false;
                });
            }

            for (var i = 1; i < opts.maxrating + 1; i++) {
                _start = $("<li></li>").appendTo(_starts)
                                   .addClass(opts.cssClass)
                                   .css({
                                       "float": "left",
                                       "border": "none",
                                       "background": "none",
                                       "cursor": "pointer"
                                   })
                                   .attr("title", i)
                                   .append($("<span></span>").addClass(opts.starIcon));

                if (!opts.readOnly) {
                    _start.hover(function () {
                        //$(this).addClass(opts.hoverClass);
                        self._setRatings(parseInt($(this).attr("title")));
                    },
                function () {
                    if (!self.mouseOn)
                        $(this).removeClass(opts.hoverClass);
                });

                    _start.bind("click", function () {
                        opts.value = parseInt($(this).attr("title"));
                        el.trigger("ratingchange", opts.value);
                    });
                }
            }
            self._setRatings(opts.value);
        },
        _setRatings: function (_value) {
            var opts = this.options, _starts = $("li", this.element);
            _starts.removeClass(opts.hoverClass);
            _starts.each(function (i, n) {
                var _start = $(this), _rating = parseInt(_start.attr("title"));
                if (_rating <= _value)
                    _start.addClass(opts.hoverClass);
            });
        },
        setValue: function (_value) {
            this._setRatings(_value);
        },
        destroy: function () {
            $("li", this.element).unbind();
            $(">ul", this.element).unbind().remove();
            $.Widget.prototype.destroy.call(this);
        }
    });

})(jQuery);   