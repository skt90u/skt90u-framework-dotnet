﻿/// <reference path="../jquery-1.4.4.js" />
/// <reference path="../jquery-1.4.4-vsdoc.js" />

/*!  
** Copyright (c) 2011 Ray Liang (http://www.dotnetage.com)
** Dual licensed under the MIT and GPL licenses:
** http://www.opensource.org/licenses/mit-license.php
** http://www.gnu.org/licenses/gpl.html
** 
**----------------------------------------------------------------
** title        : DJME dropdownable
** version   : 2.0.1
** modified: 2010-1-13
** depends:
**    jquery.ui.core.js
**    jquery.ui.widget.js
**----------------------------------------------------------------
*/
(function ($) {
    $.widget("ui.dropdownable", {
        options: {
            target: null,
            showEffect: "slide",
            hideEffect: "slide",
            pos: "left bottom",
            opened: null,
            closed: null,
            speed: 100,
            fx: { direction: "up" }
        },
        _create: function () {
            var self = this, el = this.element, eventPrefix = this.widgetEventPrefix;
            if (this.options.opened)
                el.bind(eventPrefix + "opened", this.options.opened);
            if (this.options.closed)
                el.bind(eventPrefix + "closed", this.options.closed);
            $(document).bind("click", function () {
                self.close();
            });

            el.addClass("d-dropdownable");
            if (this.options.target) {
                el.position({
                    my: "left top",
                    at: self.options.pos,
                    of: $(this.options.target),
                    collision: "flip"
                }).hide();
            }
        },
        open: function () {
            var self = this;
            if (this.element.hasClass("d-state-open")) return;

            clearTimeout(self.element.data("timer"));

            if (this.options.target) {
                var _pos = $(self.options.target).position(),
                t = (_pos.top + $(self.options.target).outerHeight(true)) + "px",
                l = _pos.left + "px";

                self.element.css({ top: t, left: l });

                //                self.element.position({
                //                    my: "left top",
                //                    at: self.options.pos,
                //                    of: $(self.options.target)
                //                }).hide();
            }

            self.element.data("timer", setTimeout(function () {
                self.element.show(self.options.showEffect, self.options.fx, self.options.speed, function () {
                    self.element.addClass("d-state-open");
                    self._triggerEvent("opened");
                });
            }, 100));
        },
        close: function () {
            var self = this;
            if (this.element.hasClass("d-state-open")) {
                clearTimeout(self.element.data("timer"));
                self.element.data("timer", setTimeout(function () {
                    self.element.hide(self.options.hideEffect, self.options.fx, self.options.speed, function () {
                        self.element.removeClass("d-state-open");
                        self._triggerEvent("closed");
                    });
                }, 100));
            }
        },
        _triggerEvent: function (eventName, eventArgs) {
            this.element.trigger(this.widgetEventPrefix + eventName, eventArgs);
        },
        destroy: function () {
            $.Widget.prototype.destroy.call(this);
        }
    });
})(jQuery);   