﻿/// <reference path="../jquery-1.4.4.js" />
/// <reference path="../jquery-1.4.4-vsdoc.js" />

/*!  
** Copyright (c) 2011 Ray Liang (http://www.dotnetage.com)
** Dual licensed under the MIT and GPL licenses:
** http://www.opensource.org/licenses/mit-license.php
** http://www.gnu.org/licenses/gpl.html
** 
**----------------------------------------------------------------
** title        : DJME watermark
** version   : 2.0.0
** modified: 2010-1-6
** depends:
**    jquery.ui.core.js
**    jquery.ui.widget.js
**----------------------------------------------------------------
*/

(function ($) {
    $.widget("ui.watermark", {
        options: {
            waterMark: null,
            waterMarkClass: ""
        },
        _create: function () {
            var self = this, opts = this.options, el = this.element;

            self._setWaterMark();

            el.bind("focus", function () {
                self._removeWaterMark();
            });

            el.bind("blur", function () {
                self._setWaterMark();
            });

            var _form = el.closest("form");
            if (_form.length) {
                _form.submit(function () {
                    self._removeWaterMark();
                });
            }
        },
        _setWaterMark: function () {
            var opts = this.options, el = this.element;
            if (opts.waterMark) {
                if (el.val() == "") {
                    if (opts.waterMarkClass)
                        el.addClass(opts.waterMarkClass);
                    el.val(opts.waterMark);
                }
            }
        },
        _removeWaterMark: function () {
            var opts = this.options, el = this.element;
            if (opts.waterMark) {
                if (el.val() == opts.waterMark) {
                    if (opts.waterMarkClass)
                        el.removeClass(opts.waterMarkClass);
                    el.val("");
                }
            }
        },
        destroy: function () {
            this.element.unbind();
            $.Widget.prototype.destroy.call(this);
        }
    });

})(jQuery);   