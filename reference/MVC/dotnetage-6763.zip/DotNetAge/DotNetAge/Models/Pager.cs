﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DNA.Mvc.Models
{
    /// <summary>
    /// The Pager data model
    /// </summary>
    public class Pager
    {
        /// <summary>
        /// Gets/Sets the page size
        /// </summary>
        public int PageSize { get; set; }

        /// <summary>
        /// Gets/Sets totoal records
        /// </summary>
        public int TotalRecords { get; set; }

        /// <summary>
        /// Gets/Sets current page index.
        /// </summary>
        public int PageIndex { get; set; }

        /// <summary>
        /// Gets/Sets the search text.
        /// </summary>
        public string SearchText { get; set; }

        public int TotalPages
        {
            get
            {
                if ((TotalRecords > 0) && (PageSize > 0))
                    return Convert.ToInt32(Convert.ToDouble(TotalRecords) / Convert.ToDouble(PageSize));
                return 0;
            }
        }
    }
}
