﻿//  Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Globalization;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using DNA.Mvc.Security;
using System.Text;

namespace DNA.Mvc.Models
{
    /// <summary>
    /// Define the SQLInstallation data model
    /// </summary>
    public class SQLInstallationModel
    {
        private string dataBaseEngine = "SQLServer";

        /// <summary>
        /// Gets/Sets the data base engine name.
        /// </summary>
        public string DataBaseEngine
        {
            get { return dataBaseEngine; }
            set { dataBaseEngine = value; }
        }

        /// <summary>
        /// Gets/Sets the database name of the SQLServer.
        /// </summary>
        [Required]
        public string DataBaseName { get; set; }

        /// <summary>
        /// Gets/Sets the server name.
        /// </summary>
        [Required]
        public string ServerName { get; set; }

        /// <summary>
        /// Gets/Sets the SQLServer administrator name
        /// </summary>
        public string SQLAdminName { get; set; }

        /// <summary>
        /// Gets/Sets the SQLServer administrator password
        /// </summary>
        public string SQLAdminPassword { get; set; }

        /// <summary>
        /// Gets/Sets the password of the user.
        /// </summary>
        public string Password { get; set; }

        /// <summary>
        /// Gets/Sets the confirm password 
        /// </summary>
        public string ConfirmPassword { get; set; }

        /// <summary>
        /// Gets/Sets the user name allows to access the SQLServer.
        /// </summary>
        public string UserName { get; set; }

        /// <summary>
        /// Gets/Sets whether the sqlconnection use SSI connection option.
        /// </summary>
        public bool IntegratedSecurity { get; set; }

        public bool IsCreateNewInstance { get; set; }

        public bool IsGenerateConnectionOnly { get; set; }

        public bool IsWindowIdentity { get; set; }

        private string GenerateConnectionStringCore(Dictionary<string, string> options)
        {
            var opts = new List<string>();
            foreach (var key in options.Keys)
                opts.Add(key + "=" + options[key]);
            return String.Join(";", opts.ToArray())+";";
        }

        public string GenerateSQLAdminConnectionString()
        {
            if (!IsWindowIdentity)
            {
                if (string.IsNullOrEmpty(SQLAdminName))
                    throw new Exception("The sql server adminstrator name is required.");
            }

            var options = new Dictionary<string, string>();
            options.Add("Data Source", ServerName);
            options.Add("Initial Catalog", "master");

            GenerateSecurityOptions(options, SQLAdminName, SQLAdminPassword);
            return GenerateConnectionStringCore(options);
        }

        private void GenerateSecurityOptions(Dictionary<string, string> options, string username, string password)
        {
            if (IntegratedSecurity)
                options.Add("Integrated Security", "SSPI");
            else
            {
                options.Add("User ID", !string.IsNullOrEmpty(username) ? username : "");
                options.Add("Password", !string.IsNullOrEmpty(password) ? password : "");
            }
        }

        /// <summary>
        /// Generate connection string.
        /// </summary>
        /// <returns></returns>
        public string GenerateConnectionString()
        {
            if (!IntegratedSecurity)
            {
                if (string.IsNullOrEmpty(UserName))
                    throw new Exception("The database user name is required.");

                if (string.IsNullOrEmpty(Password))
                    throw new Exception("The database password is required.");

                if (string.IsNullOrEmpty(ConfirmPassword) || !ConfirmPassword.Equals(Password))
                    throw new Exception("The password and confirmpassword must be same.");
            }

            var options = new Dictionary<string, string>();
            options.Add("Data Source", ServerName);
            if (DataBaseEngine.ToLower().Equals("sqlserver"))
                options.Add("Initial Catalog", DataBaseName);
            else  //data file
            {
                if (DataBaseName.EndsWith(".mdf", StringComparison.OrdinalIgnoreCase))
                    options.Add("AttachDbFilename", "|DataDirectory|\\" + DataBaseName);
                else
                    options.Add("AttachDbFilename", "|DataDirectory|\\" + DataBaseName + ".mdf");
                options.Add("User Instance", "True");
            }

            GenerateSecurityOptions(options, UserName, Password);
            return GenerateConnectionStringCore(options);
        }
    }
}
