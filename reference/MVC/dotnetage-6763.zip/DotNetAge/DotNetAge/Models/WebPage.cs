﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using System.ComponentModel.DataAnnotations;
using System.Xml;
using System.Xml.Serialization;
using System.IO;

namespace DNA.Mvc.Models
{
    [XmlRoot("template")]
    [MetadataType(typeof(WebPageMeta))]
    public partial class WebPage 
    {
        /// <summary>
        /// Gets current user is this page 's onwner
        /// </summary>
        public bool IsOwner
        {
            get
            {
                if (!string.IsNullOrEmpty(Owner))
                {
                    if (HttpContext.Current.Request.IsAuthenticated)
                        return (HttpContext.Current.Profile.UserName.ToLower() == Owner.ToLower());
                }
                return false;
            }
        }

        /// <summary>
        /// Gets the client url from browser using for ajax request.
        /// </summary>
        public string ClientUrl
        {
            get
            {
                if (!String.IsNullOrEmpty(Path))
                    try
                    {
                        return VirtualPathUtility.ToAbsolute(Path);
                    }
                    catch (Exception e) { return ""; }
                else
                    return "";
            }
        }

        Uri permalinkUri = null;

        /// <summary>
        /// Gets the permalink of this page.
        /// </summary>
        public Uri PermalinkUrl
        {
            get
            {
                if (permalinkUri == null)
                    Uri.TryCreate(WebSite.ApplicationPath + ClientUrl, UriKind.Absolute, out permalinkUri);
                return permalinkUri;
            }
        }

        ///// <summary>
        ///// Create the Json object of the page
        ///// </summary>
        ///// <returns>Json object of the page</returns>
        //public object ToJSON()
        //{
        //    var jsonWidgets = (from w in Widgets
        //                       orderby w.Pos
        //                       select w.ToJSON(false));
        //    return new
        //    {
        //        AllowAnonymous = AllowAnonymous,
        //        Description = string.IsNullOrEmpty(Description) ? "" : Description,
        //        ShowInMenu = ShowInMenu,
        //        Path = Path,
        //        Target = Target,
        //        Title = Title,
        //        ViewName = string.IsNullOrEmpty(ViewName) ? "" : ViewName,
        //        LinkUrl = string.IsNullOrEmpty(LinkUrl) ? "" : LinkUrl,
        //        Data = string.IsNullOrEmpty(ViewData) ? "" : ViewData,
        //        Widgets = jsonWidgets
        //    };
        //}

        class WebPageMeta
        {
            [Required]
            public string Title { get; set; }

            [Required]
            public string Path { get; set; }
        }

        //System.Xml.Schema.XmlSchema IXmlSerializable.GetSchema()
        //{
        //    return null;
        //}

        //void IXmlSerializable.ReadXml(XmlReader reader)
        //{
        //    if (reader.Name.Equals("template"))
        //        reader.Read();
            
        //    //reader.ReadStartElement("page");
        //    if (reader.Name.Equals("page"))
        //    {
        //        if (reader.HasAttributes)
        //        {
        //            var anonymous = reader.GetAttribute("allowAnonymous");
        //            var _show = reader.GetAttribute("showInMenu");
        //            var _static = reader.GetAttribute("static");
        //            this.IsStatic = bool.Parse(string.IsNullOrEmpty(_static) ? "false" : _static);
        //            if (this.IsStatic)
        //                this.IsShared = true;
        //            this.AllowAnonymous = bool.Parse(string.IsNullOrEmpty(anonymous) ? "true" : anonymous);
        //            this.ShowInMenu = bool.Parse(string.IsNullOrEmpty(_show) ? "false" : _show);
        //            if (string.IsNullOrEmpty(reader.GetAttribute("href")) && (string.IsNullOrEmpty(this.Path)))
        //                throw new ArgumentNullException("href attribute not found.");

        //            this.Path = reader.GetAttribute("href");
        //            this.Target = string.IsNullOrEmpty(reader.GetAttribute("target")) ? "_self" : reader.GetAttribute("target");
        //        }
        //    }
            
            
        //    if (reader.Read())
        //    {
        //        if (reader.Name.Equals("title"))
        //            this.Title = reader.ReadElementString("title");

        //        if (reader.Name.Equals("description"))
        //            this.Description = reader.ReadElementString("description");

        //        if (reader.Name.Equals("data"))
        //            this.ViewData = reader.ReadElementString("data");

        //        if (reader.Name.Equals("layout"))
        //            this.ViewName = reader.ReadElementString("layout");

        //        if (reader.Name.Equals("widgets"))
        //        { 
        //        }

        //        if (reader.Name.Equals("pages"))
        //        {
        //        }
        //    }
        //    //this.IsStatic= reader.GetAttribute("static");
        //}

        //void IXmlSerializable.WriteXml(XmlWriter writer)
        //{
        //    writer.WriteStartElement("page");
        //    writer.WriteAttributeString("target", Target);
        //    writer.WriteAttributeString("allowAnonymous", AllowAnonymous.ToString().ToLower());
        //    writer.WriteAttributeString("showInMenu", ShowInMenu.ToString().ToLower());
        //    writer.WriteAttributeString("href", this.Path.ToLower());
        //    writer.WriteAttributeString("static", IsStatic.ToString().ToLower());

        //    if (!string.IsNullOrEmpty(this.ViewData))
        //        writer.WriteElementString("data", ViewData);

        //    if (!string.IsNullOrEmpty(this.ViewName))
        //        writer.WriteElementString("layout", this.ViewName);

        //    writer.WriteElementString("title", Title);
        //    if (!string.IsNullOrEmpty(Description))
        //        writer.WriteElementString("description", Description);
        //    var _widgets = this.GetWidgets();
        //    if (_widgets.Count() > 0)
        //    {
        //        writer.WriteStartElement("widgets");
        //        foreach (var w in _widgets)
        //        {
        //            ((IXmlSerializable)w).WriteXml(writer);
        //        }
        //        writer.WriteEndElement();
        //    }

        //    var children = this.Children();

        //    if (children.Count() > 0)
        //    {
        //        writer.WriteStartElement("pages");
        //        foreach (var child in children)
        //        {
        //            if ((child.IsStatic) && (!child.IsShared))
        //                continue;
        //            ((IXmlSerializable)child).WriteXml(writer);
        //        }
        //        writer.WriteEndElement();
        //    }
        //    writer.WriteEndElement();
        //}

        //public void ReadXml(string xml)
        //{
        //    var tmp=DNA.Utility.XmlSerializerUtility.DeserializeFromXmlText(xml, typeof(WebPage));
        //}

        //public string ToXml()
        //{
        //    return DNA.Utility.XmlSerializerUtility.SerializeToXml(typeof(WebPage), this);
        //}


    }
}
