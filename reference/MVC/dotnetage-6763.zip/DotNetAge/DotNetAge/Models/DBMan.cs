﻿//  Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Objects;
using System.Data.Objects.DataClasses;
using System.Data.EntityClient;
using System.Data;
using System.Web.Caching;

namespace DNA.Mvc.Models
{
    /// <summary>
    /// This class use to manage the database instance and data connection
    /// to impoving the EF preformance.
    /// </summary>
    public static class DBMan
    {
        public static EntityConnection CreateConnection()
        {
            string connString = System.Web.Configuration.WebConfigurationManager.ConnectionStrings["DNAEntities"].ConnectionString;
            return new EntityConnection(connString);
        }

        public static EntityConnection Connection
        {
            get
            {
                Cache cache = HttpContext.Current.Cache;
                string key = "dna_global_connection";
                var connection=cache.Get(key);
                if (connection == null)
                {
                    connection = CreateConnection();
                    cache.Add(key, connection, null, Cache.NoAbsoluteExpiration, TimeSpan.FromMinutes(30), CacheItemPriority.High, null);
                }
                return (EntityConnection)connection;
            }
        }

        public static void KeepConnectionOpen()
        {
            if (Connection.State == ConnectionState.Closed)
                Connection.Open();
        }

        public static DNAEntities Instance()
        {
            return Instance(true);
        }

        public static DNAEntities Instance(bool keepConnectionOpen)
        {
            var db = new DNAEntities(Connection);

            if (keepConnectionOpen)
                KeepConnectionOpen();

            return db;
        }
    }
}