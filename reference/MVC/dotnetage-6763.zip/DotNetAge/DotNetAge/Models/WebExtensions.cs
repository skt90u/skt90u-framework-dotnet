﻿//  Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using DNA.Mvc.DynamicUI;
using DNA.Mvc.OpenAPI.Rss;
using DNA.Mvc.OpenAPI.Atom;
using DNA.Mvc.Models;
using System.IO;

namespace DNA.Mvc
{
    /// <summary>
    /// Defines the helper methods to extend the web instance to muliate the database.
    /// </summary>
    public static class WebExtensions
    {
        private static IDynamicPageServcie Service
        {
            get
            {
                return WebSite.UIService;
            }
        }

        private static WidgetUIServiceBase Widgets
        {
            get
            {
                return WebSite.WidgetService;
            }
        }

        private static IWebResourceService WebRes
        {
            get { return WebSite.WebRes; }
        }

        /// <summary>
        /// Gets wheather the specified path of page is exists.
        /// </summary>
        /// <param name="web">The Web object</param>
        /// <param name="path">Specified the path of the page.</param>
        /// <returns>Returns true if the page is exists</returns>
        public static bool IsPageExists(this Web web, string path)
        {
            return web.GetPage(path) != null;
        }

        public static string GetCurrentLanguage(this Web web)
        {
            if (!HttpContext.Current.Request.IsAuthenticated)
            {
                var request = HttpContext.Current.Request;
                string key = request.AnonymousID;
                HttpCookie cookie = request.Cookies[key];
                if ((cookie != null) && (cookie.Values.AllKeys.Contains("Language")))
                    return cookie.Values["Language"];
            }
            else
            {
                if (!string.IsNullOrEmpty(HttpContext.Current.Profile["Language"] as string))
                    return HttpContext.Current.Profile["Language"].ToString();
            }
            return WebSite.CurrentWeb().DefaultLanguage;

        }

        public static bool IsPageExists(this Web web, int pageID)
        {
            return Service.GetPage(pageID) != null;
        }

        public static bool IsPageExists(this Web web, System.Web.Routing.RequestContext context)
        {
            string vpath = UrlUtility.ParseVirtualPath(context);
            return web.IsPageExists(vpath);
        }

        #region CreatePage methods
        /// <summary>
        /// Create the children page of the web.
        /// </summary>
        /// <param name="web">The Web object</param>
        /// <param name="path">Specified the target page path.</param>
        /// <param name="title">Specified the page title</param>
        /// <param name="description">Specified the page description.</param>
        /// <param name="allowAnonymous">Set to true to allow anonymous user can access this page</param>
        /// <param name="layout">Specified the page layout.</param>
        /// <param name="roles">Specified which roles can access this page the "allowAnonymouse" must set to false.</param>
        /// <returns>A new page instance </returns>
        public static WebPage CreatePage(this Web web, string path, string title, string description, bool allowAnonymous, string layout, string[] roles)
        {
            var _path = path;
            if ((string.IsNullOrEmpty(web.Name)) || web.Name.Equals("home", StringComparison.OrdinalIgnoreCase))
                _path = "~/sites/home" + path.ToLower();
            else
                _path = "~/sites/" + web.Name.ToLower() + "/" + path.ToLower();

            if (_path.EndsWith(".html", StringComparison.OrdinalIgnoreCase))
                _path += ".html";

            if (web.IsPageExists(_path))
                throw new ArgumentException("The page path is exists.");


            return web.CreatePage(new WebPage()
            {
                Title = title,
                Description = description,
                ShowInMenu = true,
                Path = _path,
                AllowAnonymous = allowAnonymous,
                WebID = web.Id,
                ViewName = layout
            }, roles);
        }

        /// <summary>
        /// Create the children page of the web.
        /// </summary>
        /// <param name="web">The Web object</param>
        /// <param name="path">Specified the target page path.</param>
        /// <param name="title">Specified the page title</param>
        /// <param name="description">Specified the page description.</param>
        /// <param name="roles">Specified which roles can access this page.If this parameter is not null thate AllowAnonymouse propery will be set to false.</param>
        /// <returns>A new page instance </returns>
        public static WebPage CreatePage(this Web web, string path, string title, string description, string[] roles)
        {
            return web.CreatePage(path, title, description, false, "Layout_1", roles);
        }

        public static WebPage CreatePage(this Web web, WebPage page)
        {
            page.WebID = web.Id;
            if (string.IsNullOrEmpty(page.ViewName))
                page.ViewName = "Layout_1";
            return Service.Create(page, null);
        }

        /// <summary>
        /// Create the children page of the web.
        /// </summary>
        /// <param name="web">The Web object</param>
        /// <param name="path">Specified the target page path.</param>
        /// <param name="title">Specified the page title</param>
        /// <param name="description">Specified the page description.</param>
        /// <returns>A new page instance </returns>
        public static WebPage CreatePage(this Web web, string path, string title, string description)
        {
            return web.CreatePage(path, title, description, true, "Layout_1", null);
        }

        /// <summary>
        /// Create the children page of the web.
        /// </summary>
        /// <param name="web">The Web object</param>
        /// <param name="path">Specified the target page path.</param>
        /// <param name="title">Specified the page title</param>
        /// <param name="description">Specified the page description.</param>
        /// <param name="layout">Specified the page layout.</param>
        /// <returns>A new page instance </returns>
        public static WebPage CreatePage(this Web web, string path, string title, string description, string layout)
        {
            return web.CreatePage(path, title, description, true, layout, null);
        }

        /// <summary>
        /// Create the children page of the web.
        /// </summary>
        /// <param name="web">The Web object</param>
        /// <param name="page">The WebPage object</param>
        /// <param name="roles">Specified which roles can access this page.If this parameter is not null thate AllowAnonymouse propery will be set to false.</param>
        /// <returns>A new page instance </returns>
        public static WebPage CreatePage(this Web web, WebPage page, string[] roles)
        {
            page.WebID = web.Id;
            return Service.Create(page, roles);
        }

        #endregion

        /// <summary>
        ///  Get the page by sepcified path
        /// </summary>
        /// <param name="web">The Web object</param>
        /// <param name="path">Specified the page path</param>
        /// <returns>If the page found returns the WebPage instance else returns null.</returns>
        public static WebPage GetPage(this Web web, string path)
        {
            return Service.GetPage(path);
        }

        /// <summary>
        /// Gets the page by specified page id.
        /// </summary>
        /// <param name="web">The Web object</param>
        /// <param name="pageID">Specified the page id.</param>
        /// <returns>If the page found returns the WebPage instance else returns null.</returns>
        public static WebPage GetPage(this Web web, int pageID)
        {
            return Service.GetPage(pageID);
        }

        /// <summary>
        /// Delete the page by sepcified the page id.
        /// </summary>
        /// <param name="web">The Web object</param>
        /// <param name="pageID">Specified the integer page id value.</param>
        public static void DeletePage(this Web web, int pageID)
        {
            if (!web.IsPageExists(pageID))
                throw new ArgumentOutOfRangeException("Page not found -> pageID.");
            Service.Delete(pageID);
        }

        /// <summary>
        ///  Save the WebPage values to database.
        /// </summary>
        /// <param name="web">The Web object</param>
        /// <param name="page">The specified WebPage object</param>
        /// <param name="roles">The access roles of the page.</param>
        public static void UpdatePage(this Web web, WebPage page, string[] roles)
        {
            if (page == null)
                throw new ArgumentNullException("page");

            Service.Update(page, roles);
        }

        public static void Update(this Web web)
        {
            using (var db = DBMan.Instance())
            {
                if (web.Properties.Count == 0)
                    web.Data = "";
                else
                    web.Data = (new System.Web.Script.Serialization.JavaScriptSerializer()).Serialize(web.Properties);
                var originalWeb = db.Webs.FirstOrDefault(w => w.Id == web.Id);
                db.Webs.ApplyCurrentValues(web);
                db.SaveChanges();

                string key = "DNA_WEB_" + web.Name;
                if (HttpContext.Current.Items.Contains(key))
                    HttpContext.Current.Items.Remove(key);
            }
        }

        ///// <summary>
        ///// Export all children page to WebPageDataContract collection.
        ///// </summary>
        ///// <param name="web">The Web object</param>
        ///// <returns>A WebPageDataContract collection.</returns>
        //public static IEnumerable<WebPageDataContract> ExportPages(this Web web)
        //{
        //    var pageList = new List<WebPageDataContract>();
        //    var pages = web.Children();
        //    foreach (var w in pages)
        //    {
        //        var contract = new WebPageDataContract(w);
        //        pageList.Add(contract);
        //        AddChildren(web, w.ID, contract);
        //    }
        //    return pageList;
        //}

        //private static void AddChildren(Web web, int id, WebPageDataContract contract)
        //{
        //    if (web.ChildrenCount(id) > 0)
        //    {
        //        var pages = web.Children(id);
        //        foreach (var w in pages)
        //        {
        //            var child = new WebPageDataContract(w);
        //            contract.Children.Add(child);
        //            AddChildren(web, w.ID, child);
        //        }
        //    }
        //}

        /// <summary>
        /// Gets anonymous allowed pages
        /// </summary>
        /// <param name="web">The Web object</param>
        /// <returns>The WebPage collection.</returns>
        public static IEnumerable<WebPage> GetAnonymousPages(this Web web)
        {
            using (var db = DBMan.Instance())
            {
                return db.WebPages.Where(a => (a.AllowAnonymous && (a.WebID == web.Id))).ToList();
            }
        }

        /// <summary>
        /// Set the page as the default page of web by specified page id.
        /// </summary>
        /// <param name="web">The Web object</param>
        /// <param name="pageID">Specified the integer value of page id</param>
        public static void SetDefaultPage(this Web web, int pageID)
        {
            var page = web.GetPage(pageID);
            if (page != null)
            {
                web.DefaultUrl = page.Path;
                web.Update();
            }
            else
                throw new PageNotFoundException();
        }

        /// <summary>
        /// Gets the children pages of specified page id.
        /// </summary>
        /// <param name="web">The Web object</param>
        /// <param name="parentID">Specified the parent page id.</param>
        /// <returns>The page collection.</returns>
        public static IEnumerable<WebPage> Children(this Web web, int parentID)
        {
            return Service.GetChildPages(web.Id, parentID);
        }

        public static IEnumerable<WebPage> GetStaticPages(this Web web)
        {
            return Service.GetStaticPages(web.Id);
        }

        public static IEnumerable<WebPage> GetAllPages(this Web web)
        {
            return Service.GetDescendantPages(web.Id, 0);
        }

        /// <summary>
        /// Get all pages of this Web
        /// </summary>
        /// <param name="web">The Web object</param>
        /// <returns>The page instance collection of this web.</returns>
        public static IEnumerable<WebPage> Children(this Web web)
        {
            return web.Children(0);
        }

        /// <summary>
        /// Gets the total page count of this web
        /// </summary>
        /// <param name="web">The Web object</param>
        /// <returns>The integer value of page count.</returns>
        public static int PageCount(this Web web)
        {
            return web.Children().Count();
        }

        /// <summary>
        /// Gets the top page count of this web.
        /// </summary>
        /// <param name="web">The Web object</param>
        /// <returns>The integer value of page count</returns>
        public static int ChildrenCount(this Web web)
        {
            return web.ChildrenCount(0);
        }

        /// <summary>
        /// Gets the page count of sepcified page id.
        /// </summary>
        /// <param name="web">The Web object</param>
        /// <param name="pageID">Specified the parent page id.</param>
        /// <returns>The integer value of page count</returns>
        public static int ChildrenCount(this Web web, int pageID)
        {
            return Service.GetChildPages(web.Id, pageID).Count();
        }

        /// <summary>
        /// Move the page to a new position
        /// </summary>
        /// <param name="web">The Web object</param>
        /// <param name="parentPageID">Specified the new parent page id to move to.</param>
        /// <param name="pageID">Specified the target page id to move.</param>
        /// <param name="position">Specified the new position value</param>
        public static void MovePage(this Web web, int parentPageID, int pageID, int position)
        {
            Service.Move(parentPageID, pageID, position);
        }

        /// <summary>
        /// Gets the full url of the web including protocol, domain,port and path.
        /// </summary>
        /// <param name="web">The Web object</param>
        /// <returns>The string value contains the path of this web.</returns>
        public static string GetFullUrl(this Web web)
        {
            var request = HttpContext.Current.Request;
            string url = request.Url.Scheme + "://" + request.Url.Authority;
            if (!request.ApplicationPath.Equals("/"))
                url += request.ApplicationPath;

            if ((!string.IsNullOrEmpty(web.Name)) && (!web.Name.Equals("home", StringComparison.OrdinalIgnoreCase)))
                url += "/sites/" + web.Name;
            return url;
        }

        /// <summary>
        /// Convert this Web and children pages to RssChannel object and RssItem objects.
        /// </summary>
        /// <param name="web">The Web object</param>
        /// <returns>The RssChannel object and contains RssItems.</returns>
        public static RssDocument GetRssFeed(this Web web)
        {
            var doc = new RssDocument();
            var channel = new RssChannel()
            {
                Title = web.Title,
                Description = web.Description,
                Copyright = web.Copyright,
                Generator = "DotNetAge" + System.Reflection.Assembly.GetExecutingAssembly().GetName().Version.ToString(),
                Language = web.DefaultLanguage,
                Link = web.GetFullUrl(),
                WebMaster = System.Web.Security.Membership.GetUser(web.Owner).Email + " (" + web.Owner + ")",
                PubDate = web.Created.ToUniversalTime().ToString("r")
            };

            if (!string.IsNullOrEmpty(web.LogoImageUrl))
            {
                channel.Image.ImageUrl = WebSite.ApplicationPath + VirtualPathUtility.ToAbsolute(web.LogoImageUrl);
                channel.Image.Title = web.Title;
                channel.Image.Description = web.Description;
            }

            var pages = web.GetAnonymousPages();
            channel.Items = new List<RssItem>();
            foreach (var page in pages)
            {
                if (!page.ShowInMenu)
                    continue;
                channel.Items.Add(new RssItem()
                {
                    Title = page.Title,
                    Description = page.Description,
                    Author = page.Owner,
                    Link = page.PermalinkUrl.ToString(),
                    Guid = new RssGuid() { IsPermaLink = true, Value = page.PermalinkUrl.ToString() },
                    PubDate = page.Created.ToUniversalTime().ToString("r")
                });
            }
            doc.Channel = channel;
            return doc;
        }

        public static AtomFeed GetAtomFeed(this Web web)
        {
            var feed = new AtomFeed()
            {
                Generator = new AtomGenerator()
                {
                    NavigateUrl = web.GetFullUrl(),
                    Text = "DotNetAge",
                    Version = System.Reflection.Assembly.GetExecutingAssembly().GetName().Version.ToString()
                },
                CopyRight = web.Copyright,
                Icon = web.ShortcutIconUrl,
                Logo = web.LogoImageUrl,
                ID = web.GetFullUrl(),
                Title = web.Title
            };

            var pages = web.GetAnonymousPages();
            feed.Entries = new List<AtomEntry>();
            foreach (var page in pages)
            {
                if (!page.ShowInMenu)
                    continue;
                feed.Entries.Add(new AtomEntry()
                {
                    ID = page.PermalinkUrl.ToString(),
                    Author = new AtomPersonConstruct()
                    {
                        Name = page.Owner
                    },
                    Content = new AtomContent()
                    {
                        Text = !string.IsNullOrEmpty(page.Description) ? page.Description : page.Title,
                        ContentType = "text/html",
                        SourceUrl = page.PermalinkUrl.ToString()
                    },
                    Summary = page.Description,
                    Title = page.Title,
                    Published = page.Created,
                    Updated = page.LastModified
                });
            }
            return feed;
        }

        /// <summary>
        /// Get the WidgetDescriptor by specified id.
        /// </summary>
        /// <param name="web">The Web object</param>
        /// <param name="id">The WidgetDescriptor id.</param>
        /// <returns>The WidgetDescriptor instance.</returns>
        public static WidgetDescriptor GetWidgetDescriptor(this Web web, int id)
        {
            return Widgets.GetWidgetDescriptor(id);
        }

        public static WidgetDescriptor AddWidgetDescriptor(this Web web, WidgetTemplate tmpl, string installedPath)
        {
            Type controllerType = null;

            if (!string.IsNullOrEmpty(tmpl.Defaults.Controller))
                controllerType = Type.GetType(tmpl.Defaults.Controller);

            #region For common properties
            var descriptor = new WidgetDescriptor()
            {
                Description = tmpl.Description,
                InstalledPath = installedPath,
                Version = tmpl.Version,
                Title = string.IsNullOrEmpty(tmpl.Defaults.Title) ? tmpl.Name : tmpl.Defaults.Title,
                IconUrl = tmpl.Defaults.IconUrl,
                Action = tmpl.Defaults.Action,
                ShowBorder = true,
                ShowHeader = true
            };

            if (tmpl.UserPreferences.Count > 0)
            {
                var properties = new Dictionary<string, object>();
                foreach (WidgetUserPreference userPreperence in tmpl.UserPreferences)
                {
                    var valueType = typeof(string);
                    Type typeDef = null;
                    if (!string.IsNullOrEmpty(userPreperence.Type))
                        typeDef = Type.GetType(userPreperence.Type);
                    object value = (typeDef != null) ? Convert.ChangeType(userPreperence.Value, typeDef) : "";
                    properties.Add(userPreperence.Name, value);
                }
                descriptor.Properties = properties;
            }
            #endregion

            if (controllerType != null)
            {
                if (!string.IsNullOrEmpty(tmpl.Defaults.Action))
                {
                    var actionMethod = controllerType.GetMethod(tmpl.Defaults.Action);
                    string controllerShortName = controllerType.Name.Replace("Controller", "");
                    descriptor.Action = tmpl.Defaults.Action;
                    //If the controlType.FullName that maybe cause the DNA could not find the ControllerType in runtime.
                    descriptor.Controller = controllerType.AssemblyQualifiedName;
                    descriptor.Url = GetArea(tmpl.Defaults.Action, controllerShortName);
                    WidgetAttribute widgetAttr = (WidgetAttribute)actionMethod.GetCustomAttributes(typeof(WidgetAttribute), true)[0];
                    if (widgetAttr != null)
                    {
                        if (!string.IsNullOrEmpty(widgetAttr.IconUrl) && string.IsNullOrEmpty(descriptor.IconUrl))
                            descriptor.IconUrl = widgetAttr.IconUrl;
                        if (!string.IsNullOrEmpty(widgetAttr.ImageUrl) && string.IsNullOrEmpty(descriptor.ImageUrl))
                            descriptor.ImageUrl = widgetAttr.ImageUrl;
                        descriptor.ShowHeader = widgetAttr.ShowHeader;
                        descriptor.ShowBorder = widgetAttr.ShowBorder;
                        descriptor.Title = widgetAttr.Title;
                        descriptor.IsClosable = widgetAttr.IsClosable;
                        descriptor.IsDeletable = widgetAttr.IsDeletable;
                        descriptor.TitleLinkUrl = widgetAttr.TitleLink;
                        if (!string.IsNullOrEmpty(widgetAttr.Description) && string.IsNullOrEmpty(descriptor.Description))
                            descriptor.Description = widgetAttr.Description;
                    }
                }
            }
            return Widgets.AddDescriptor(descriptor);
            //return descriptor;
        }

        private static string GetArea(string action, string controller)
        {
            if (!Directory.Exists(HttpContext.Current.Server.MapPath("~/Areas")))
                return "";
            string path = "";
            string shared = "";

            //1.Search the Area
            string[] dirs = System.IO.Directory.GetDirectories(HttpContext.Current.Server.MapPath("~/Areas"));
            foreach (var dir in dirs)
            {
                path = dir + "\\Views\\" + controller + "\\" + action + ".ascx";
                shared = dir + "\\Shared\\" + action + ".ascx";

                if (System.IO.File.Exists(path))
                    return ((new System.IO.DirectoryInfo(dir)).Name);

                if (System.IO.File.Exists(shared))
                    return ((new System.IO.DirectoryInfo(dir)).Name);
            }

            return "";
        }
        /// <summary>
        /// Gets the WidgetDescriptor by specified assembly name,controller name and action name.
        /// </summary>
        /// <param name="web">The Web object</param>
        /// <param name="asmName">Specified the Assembly name contains the widget action.</param>
        /// <param name="controllerName">Specified the Controller name that contains the widget action.</param>
        /// <param name="action">Specified the Widget Action name.</param>
        /// <returns>The WidgetDescriptor instance.</returns>
        public static WidgetDescriptor GetWidgetDescriptor(this Web web,  string controllerName, string action)
        {
            return Widgets.GetWidgetDescriptor( controllerName, action);
        }

        public static WidgetDescriptor GetWidgetDescriptor(this Web web, string installedPath)
        {
            return Widgets.GetWidgetDescriptor(installedPath);
        }

        ///// <summary>
        ///// Gets the categories of widgets.
        ///// </summary>
        ///// <param name="web">The Web object</param>
        ///// <returns>A widget category collection.</returns>
        //public static IEnumerable<WidgetCategory> GetWidgetCategories(this Web web)
        //{
        //    return Widgets.AllCategories;
        //}

        /// <summary>
        /// Gets the web resource root uri
        /// </summary>
        /// <param name="web"></param>
        /// <returns></returns>
        public static Uri GetWebRootUri(this Web web)
        {
            return new Uri(WebSite.Open().GetFullUrl() + "/webshared/" + web.Name + "/");
        }

        public static string ToXml(this Web web)
        {
            if (!HttpContext.Current.User.IsAdministrator())
                throw new UnauthorizedAccessException("You have not enough permission to complete this opteration.");
            return DNA.Utility.XmlSerializerUtility.SerializeToXml(typeof(WebTemplate), web.GetTemplate());
        }

        public static WebTemplate GetTemplate(this Web web)
        {
            if (!HttpContext.Current.User.IsAdministrator())
                throw new UnauthorizedAccessException("You have not enough permission to complete this opteration.");
            var template = new WebTemplate()
            {
                Title = web.Title,
                Description = web.Description,
                DefaultUrl = web.DefaultUrl,
                Language = web.DefaultLanguage,
                Copyright = web.Copyright,
                CssText = web.CssText,
                LogoImageUrl = web.LogoImageUrl,
                ShortcutIconUrl = web.ShortcutIconUrl,
                EnableUserRegistation = web.EnableUserRegistration,
                Theme = web.Theme,
                Type = (WebTypes)web.Type,
                MasterPage = web.MasterName,
                SearchKeywords = web.SearchKeywords
            };
            var pages = web.GetAllPages();
            if (pages.Count() > 0)
            {
                template.WebPages = new List<WebPageTemplate>();
                var topLvPages = pages.Where(p => p.ParentID == 0).ToList();

                foreach (var page in topLvPages)
                {
                    if ((page.IsStatic) && (!page.IsShared))
                        continue;
                    template.WebPages.Add(page.GetPageTemplate());
                }
            }
            return template;
        }

        public static WebPage CreatePage(this Web web, int parentID, WebPageTemplate template)
        {
            if (template == null)
                throw new ArgumentNullException("template");

            var newPage = new WebPage()
            {
                Title = template.Title,
                Description = template.Description,
                LinkUrl = template.LinkUrl,
                Target = template.Target,
                ViewData = template.Data,
                ViewName = template.Layout,
                AllowAnonymous = template.AllowAnonymous,
                ShowInMenu = template.ShowInMenu,
                IsShared = template.IsShared,
                IsStatic = template.IsStatic,
                Path = template.Path,
                ParentID = parentID,
                WebID = web.Id
            };

            if (template.Path.IndexOf("{website}") > -1)
                newPage.Path = template.Path.ToLower().Replace("{website}", web.Name.ToLower());

            newPage = Service.Create(newPage, null);
            foreach (var widgetTemp in template.Widgets)
            {
                var descriptor = Widgets.GetWidgetDescriptor(widgetTemp.Defaults.Controller, widgetTemp.Defaults.Action);
                if (descriptor == null)
                    throw new Exception("Widget runtime files not found.");
                var widgetInstance = Widgets.AddWidget(descriptor, newPage.Path, widgetTemp.Defaults.ZoneID, widgetTemp.Defaults.Position);
                widgetInstance.Update(widgetTemp);
            }

            if (template.Children != null)
                newPage.ImportChildren(template.Children);

            return newPage;
        }

        #region Web Resource methods
        /// <summary>
        /// Get all file uri under web root path.
        /// </summary>
        /// <param name="web">The web object</param>
        /// <returns>The collection contains file uri</returns>
        public static IEnumerable<Uri> GetFiles(this Web web)
        {
            //if (web.IsRoot)
            //    return WebRes.GetFiles(new Uri("webfile://root/"));
            //else
            //    return WebRes.GetFiles(new Uri("webfile://" + web.Name + "/"));
            return web.GetFiles(web.GetWebRootUri());
        }

        /// <summary>
        /// Gets the file urls by specified relative path
        /// </summary>
        /// <param name="web">The Web object</param>
        /// <param name="path">The target path</param>
        /// <returns>A collection contains file urls. </returns>
        public static IEnumerable<Uri> GetFiles(this Web web, string path)
        {
            return web.GetFiles(new Uri(web.AppUrl + "webshared/" + web.Name + (path.StartsWith("/") ? path : "/" + path)));
        }

        /// <summary>
        /// Gets the file urls by specified path
        /// </summary>
        /// <param name="web">The Web object</param>
        /// <param name="path">The target path</param>
        /// <returns>A collection contains file urls. </returns>
        public static IEnumerable<Uri> GetFiles(this Web web, Uri path)
        {
            //if (web.IsRoot)
            //    return WebRes.GetFiles(new Uri("webfile://root/" + path));
            //else
            //    return WebRes.GetFiles(new Uri("webfile://" + web.Name + "/" + path));
            return WebRes.GetFiles(path);
        }

        //public static void MovePath(this Web web, Uri sourceUri, Uri destUri)
        //{
        //    return WebRes.Move(sourceUri, destUri);
        //}

        public static IEnumerable<Uri> GetPaths(this Web web)
        {
            //if (web.IsRoot)
            //    return WebRes.GetPaths(new Uri("webfile://root/"));
            //else
            //    return WebRes.GetPaths(new Uri("webfile://" + web.Name + "/"));
            return web.GetPaths(web.GetWebRootUri());
        }

        public static IEnumerable<Uri> GetPaths(this Web web, Uri path)
        {
            //if (web.IsRoot)
            //    return WebRes.GetPaths(new Uri("webfile://root/" + path));
            //else
            //    return WebRes.GetPaths(new Uri("webfile://" + web.Name + "/" + path));
            return WebRes.GetPaths(path);
        }

        public static Uri SaveFile(this Web web, string fileName, byte[] bits, Uri path)
        {
            return WebRes.SaveFile(bits, fileName, path);
            //if (web.IsRoot)
            //    return WebRes.SaveFile(bits, fileName, new Uri("webfile://root/" + path + "/"));
            //else
            //    return WebRes.SaveFile(bits, fileName, new Uri("webfile://" + web.Name + "/" + path + "/"));
        }

        public static Uri SaveFile(this Web web, string fileName, byte[] bits)
        {
            //if (web.IsRoot)
            return WebRes.SaveFile(bits, fileName, web.GetWebRootUri());
            //else
            //    return WebRes.SaveFile(bits, fileName, new Uri("webfile://" + web.Name + "/"));
        }

        public static void DeletePath(this Web web, Uri path)
        {
            //if (web.IsRoot)
            //    WebRes.Delete(new Uri("webfile://root/" + path));
            //else
            //    WebRes.Delete(new Uri("webfile://" + web.Name + "/" + path));
            WebRes.Delete(path);
        }

        public static string MapPath(this Web web, Uri path)
        {
            return WebRes.MapPath(path);
        }


        public static void EnsurePersonalWebFiles(this Web web)
        {
            string path = web.MapPath(web.GetWebRootUri());
            if (!System.IO.Directory.Exists(path))
            {
                System.IO.Directory.CreateDirectory(path);
            }
        }

        public static byte[] OpenFile(this Web web, string fileName)
        {
            //if (web.IsRoot)
            //    return WebRes.Open(new Uri("webfile://root/" + fileName));
            //else
            //    return WebRes.Open(new Uri("webfile://" + web.Name + "/" + fileName));
            return WebRes.Open(new Uri(web.GetWebRootUri().ToString() + fileName));
        }

        public static void CreatePath(this Web web, Uri path)
        {
            WebRes.CreatePath(path);
        }

        public static void MovePath(this Web web, Uri srcPath, Uri targetPath)
        {
            WebRes.Move(srcPath, targetPath);
        }

        public static IHierarchicalNodeProvider GetNodeProvider(this Web web)
        {
            return Service as IHierarchicalNodeProvider;
        }
        #endregion

    }
}