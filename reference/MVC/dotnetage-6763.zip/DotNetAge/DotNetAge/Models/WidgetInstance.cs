﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Web.Script.Serialization;
using System.Web;
using System.Web.Mvc;
using System.Xml;
using System.Xml.Serialization;

namespace DNA.Mvc.Models
{
    /// <summary>
    /// Extend the widget's behaviors
    /// </summary>
    public partial class WidgetInstance
    {
        /// <summary>
        /// Save the user preferences data to Data property.
        /// </summary>
        /// <param name="data">The data to be saved.</param>
        public void SaveUserPreferences(IDictionary<string, object> data)
        {
            if (data != null)
            {
                if (data.Count > 0)
                {
                    MemoryStream stream = new MemoryStream();
                    BinaryFormatter formatter = new BinaryFormatter();
                    formatter.Serialize(stream, data);
                    stream.Position = 0;
                    Data = stream.ToArray();
                    stream.Close();
                }
            }
            else
                Data = null;
        }

        /// <summary>
        /// Read the user preferences data into the Dictionary object
        /// </summary>
        /// <param name="widget">The widget object</param>
        /// <returns></returns>
        public Dictionary<string, object> ReadUserPreferences()
        {
            var properties = new Dictionary<string, object>();
            if (Data != null)
            {
                MemoryStream stream = new MemoryStream();
                stream.Write(Data, 0, Data.Length);
                stream.Position = 0;
                BinaryFormatter formatter = new BinaryFormatter();
                properties = (Dictionary<string, object>)formatter.Deserialize(stream);
                stream.Close();
            }
            return properties;
        }

        /// <summary>
        /// Serialize the widget object to json string.
        /// </summary>
        /// <returns>The Json string of the widget</returns>
         [Obsolete]
        public string ToJSONStr(UrlHelper helper)
        {
            return ToJSONStr(false, helper);
        }

        /// <summary>
        /// Serialize the widget object to json string.
        /// </summary>
        /// <param name="isDesign">Specified the widget is in design mode</param>
        /// <returns>The Json string of the widget</returns>
         [Obsolete]
        public string ToJSONStr(bool isDesign, UrlHelper helper)
        {
            return (new JavaScriptSerializer()).Serialize(ToJSON(isDesign, helper));
        }

        /// <summary>
        /// Create the JSON object of widget
        /// </summary>
        /// <returns>The json object of widget</returns>
        [Obsolete]
        public object ToJSON(UrlHelper helper)
        {
            return ToJSON(false, helper);
        }

        /// <summary>
        /// Create the JSON object of widget
        /// </summary>
        /// <param name="helper">The Url helper object.</param>
        /// <param name="isDesign">Specified the widget is in design mode</param>
        /// <returns>The json object of widget</returns>
        [Obsolete]
        public object ToJSON(bool isDesign, UrlHelper helper)
        {
            string website = "";
            if (helper.RequestContext.RouteData.Values.ContainsKey("website"))
                website = helper.RequestContext.RouteData.Values["website"] as string;
            // string _u = helper.Action(Action, Controller, new { Area = string.IsNullOrEmpty(Url) ? "" : Url, website = website, id = 0 });
            return new
            {
                id = ID.ToString(),
                closable = IsClosable,
                deletable = IsDeletable,
                expanded = IsExpanded,
                bgColor = BackgroundColor,
                color = ForeColor,
                pos = Pos,
                showHeader = ShowHeader,
                showBorder = ShowBorder,
                title = Title,
                titlelink = !string.IsNullOrEmpty(TitleLinkUrl) ? helper.Content(TitleLinkUrl) : "",
                icon = !string.IsNullOrEmpty(IconUrl) ? helper.Content(IconUrl) : "",
                url = !string.IsNullOrEmpty(website) ? helper.Action(Action, Controller, new { Area = string.IsNullOrEmpty(Url) ? "" : Url, website = website, id = 0 }) : helper.Action(Action, Controller, new { Area = string.IsNullOrEmpty(Url) ? "" : Url }),
                design = isDesign,
                zoneId = ZoneID,
                baseUrl = helper.Content("~/Widget/")
            };
        }

        //System.Xml.Schema.XmlSchema IXmlSerializable.GetSchema()
        //{
        //    return null;
        //}

        //void IXmlSerializable.ReadXml(XmlReader reader)
        //{
            
        //}

        //void IXmlSerializable.WriteXml(XmlWriter writer)
        //{
        //    writer.WriteStartElement("widget");

        //    writer.WriteAttributeString("showBorder", this.ShowBorder.ToString().ToLower());
        //    writer.WriteAttributeString("showHeader", this.ShowHeader.ToString().ToLower());
        //    writer.WriteAttributeString("pos", this.Pos.ToString());
        //    writer.WriteAttributeString("zone", this.ZoneID);
        //    if (this.IsStatic)
        //        writer.WriteElementString("guid", this.ID.ToString());

        //    writer.WriteStartElement("title");
        //    if (string.IsNullOrEmpty(TitleLinkUrl))
        //        writer.WriteAttributeString("href", TitleLinkUrl);
        //    writer.WriteValue(this.Title);
        //    writer.WriteEndElement();

        //    if (!string.IsNullOrEmpty(this.IconUrl))
        //        writer.WriteElementString("iconUrl", this.IconUrl);
        //    writer.WriteElementString("action", this.Action);
        //    writer.WriteElementString("controller", this.Controller);
        //    writer.WriteElementString("assembly", this.GetDescriptor().GetPackage().AssemblyName);

        //    if (!string.IsNullOrEmpty(ForeColor))
        //        writer.WriteElementString("color", this.ForeColor);

        //    if (!string.IsNullOrEmpty(BackgroundColor))
        //        writer.WriteElementString("bgColor", this.BackgroundColor);

        //    var _preferences = ReadUserPreferences();

        //    if (_preferences.Count > 0)
        //    {
        //        writer.WriteStartElement("properties");
        //        foreach (var key in _preferences.Keys)
        //        {
        //            writer.WriteStartElement("property");
        //            writer.WriteAttributeString("name", key);
        //            writer.WriteAttributeString("type", _preferences[key].GetType().ToString());
        //            writer.WriteValue(_preferences[key]);
        //            writer.WriteEndElement();
        //        }
        //        writer.WriteEndElement();
        //    }

        //    writer.WriteEndElement();
        //}

        //public string ToXml()
        //{
        //    return DNA.Utility.XmlSerializerUtility.SerializeToXml(typeof(Widget), this);
        //}
    }
}
