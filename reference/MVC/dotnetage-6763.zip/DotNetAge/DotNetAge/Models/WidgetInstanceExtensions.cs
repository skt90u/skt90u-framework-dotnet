﻿//  Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using DNA.Mvc.DynamicUI;
using DNA.Mvc.Models;

namespace DNA.Mvc
{
    /// <summary>
    /// Extends the Widget to manipulate the widget data.
    /// </summary>
    public static class WidgetInstanceExtensions
    {
        private static WidgetUIServiceBase WidgetService
        {
            get
            {
                return WebSite.WidgetService;
            }
        }

        /// <summary>
        /// Save the changes to database 
        /// </summary>
        /// <param name="widget">The Widget instance.</param>
        public static void Update(this WidgetInstance widget)
        {
            WidgetService.UpdateWidget(widget);
        }

        /// <summary>
        /// Delete this widget from database
        /// </summary>
        /// <param name="widget">The Widget instance</param>
        public static void Delete(this WidgetInstance widget)
        {
            WidgetService.DeleteWidget(widget.ID);
        }

        /// <summary>
        /// Toggle this widget's state.
        /// </summary>
        /// <param name="widget">The Widget instance</param>
        public static void Toggle(this WidgetInstance widget)
        {
            WidgetService.Toggle(widget.ID);
        }

        public static WidgetDescriptor GetDescriptor(this WidgetInstance widget)
        {
            return WidgetService.GetWidgetDescriptor(widget.DescriptorID);
        }

        /// <summary>
        /// Move the widget to new zone or new pos.
        /// </summary>
        /// <param name="widget">The Widget instance</param>
        /// <param name="zoneID">Specified the zoneid that the widget move to.</param>
        /// <param name="pos">Specified the position value that the widget move to.</param>
        public static void Move(this WidgetInstance widget, string zoneID, int pos)
        {
            if ((!widget.ZoneID.Equals(zoneID, StringComparison.OrdinalIgnoreCase)) || (widget.Pos != pos))
                WidgetService.MoveTo(widget.ID, zoneID, pos);
        }

        /// <summary>
        /// Apply the widget settings  to the widget.
        /// </summary>
        /// <param name="widget">The Widget instance</param>
        /// <param name="settings">The setting value object.</param>
        public static void Apply(this WidgetInstance widget, object settings)
        {
            WidgetService.ApplySettings(widget.ID, settings);
        }

        //public static IEnumerable<WidgetDescriptor> GetDescriptors(this WidgetCategory category)
        //{
        //    return WidgetService.GetWidgetDescriptors(category.Id);
        //}

        //public static WidgetCategory GetParentCategory(this WidgetDescriptor descriptor)
        //{
        //    return WidgetService.GetWidgetCategory(descriptor.CatID);
        //}

        //public static PackageInfo GetPackage(this WidgetDescriptor descriptor)
        //{
        //    return WidgetService.GetPackage(descriptor.PackageID);
        //}

        public static WidgetTemplate GetWidgetTemplate(this WidgetInstance widget)
        {
            if (widget.IsStatic)
                throw new FormatException("The static widget can not generate template");
            var descriptor = widget.GetDescriptor();
            var tmpl = descriptor.GetTemplate();
            //var pkg = descriptor.GetPackage();
            tmpl.Defaults = new WidgetDefaults()
             {
                 Title = widget.Title,
                 TitleLinkUrl = widget.TitleLinkUrl,
                 IconUrl = widget.IconUrl,
                 ShowBorder = widget.ShowBorder,
                 ShowHeader = widget.ShowHeader,
                 BackgroundColor = widget.BackgroundColor,
                 ForeColor = widget.ForeColor,
                 Action = descriptor.Action,
                 ZoneID = widget.ZoneID,
                 Position = widget.Pos,
                 Controller = descriptor.Controller // widget.Controller,
                 //PackageAssemblyName = widget.GetDescriptor().GetPackage().AssemblyName,
             };
            tmpl.ID = widget.ID.ToString();
            ///TODO:Mybe changed in fature
            //Author=descriptor.Defaults.
            //Author = new WidgetAuthor()
            //{
            //    Name = pkg.AuthorName,
            //    Email = pkg.AuthorEmail,
            //    Uri = pkg.AuthorWebSite
            //}

            //if (!string.IsNullOrEmpty(descriptor.ImageUrl))
            //{
            //    _ws.Icons = new List<WidgetIcon>();
            //    _ws.Icons.Add(new WidgetIcon()
            //    {
            //        Source = descriptor.ImageUrl
            //    });
            //}

            //if (!string.IsNullOrEmpty(descriptor.ImageUrl))
            //{
            //    if (_ws.Icons == null)
            //        _ws.Icons = new List<WidgetIcon>();

            //    _ws.Icons.Add(new WidgetIcon()
            //    {
            //        Source = descriptor.IconUrl
            //    });
            //}

            var _preferences = widget.ReadUserPreferences();
            tmpl.UserPreferences = new List<WidgetUserPreference>();
            foreach (var key in _preferences.Keys)
            {
                tmpl.UserPreferences.Add(new WidgetUserPreference()
                {
                    Type = _preferences[key].GetType().ToString(),
                    Name = key,
                    Value = _preferences[key].ToString()
                });
            }
            return tmpl;
        }

        /// <summary>
        /// Serialize the widget to xml template file
        /// </summary>
        /// <param name="widget"></param>
        /// <returns></returns>
        public static string ToXml(this WidgetInstance widget)
        {
            return DNA.Utility.XmlSerializerUtility.SerializeToXml(typeof(WidgetTemplate), widget.GetWidgetTemplate());
        }

        public static bool IsInstalled(this WidgetTemplate tmpl, string path)
        {
            return WidgetService.GetWidgetDescriptor(path + "\\" + tmpl.Name) != null;
        }

        /// <summary>
        /// Returns how many widget instances are using this widget template.
        /// </summary>
        /// <param name="tmpl"></param>
        /// <param name="path"></param>
        /// <returns></returns>
        public static int GetInusingCount(this WidgetTemplate tmpl, string path)
        {
            return WidgetService.GetInusingWidgetsCount(path + "\\" + tmpl.Name);
        }

        public static bool IsUnknowAuthor(this WidgetTemplate tmpl)
        {
            return string.IsNullOrEmpty(tmpl.Author.Name);
        }

        public static WidgetTemplate GetTemplate(this WidgetDescriptor descriptor)
        {
            string fullPath = HttpContext.Current.Server.MapPath("~/content/widgets/") + descriptor.InstalledPath + "\\config.xml";
            return (WidgetTemplate)DNA.Utility.XmlSerializerUtility.DeserializeFormXmlFile(fullPath, typeof(WidgetTemplate));
        }
    }
}