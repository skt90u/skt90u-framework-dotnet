﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel.DataAnnotations;

namespace DNA.Mvc.Models
{
    //[MetadataType(typeof(MailMessageMeta))]
    public class MailMessageModel
    {
        private bool _isHtml = false;

        public bool IsHtml
        {
            get { return _isHtml; }
            set { _isHtml = value; }
        }

        /// <summary>
        /// Gets/Sets the receiver email address
        /// </summary>
        public string Receiver { get; set; }
        
        /// <summary>
        /// Gets/Sets the sender email address
        /// </summary>
        [DataType(DataType.EmailAddress)]
        [Required]
        public string Sender { get; set; }

        /// <summary>
        /// Gets/Sets the display name of the email sender
        /// </summary>
        public string SenderName { get; set; }

        /// <summary>
        /// Gets/Sets the email body
        /// </summary>
        [Required]
        public string MailBody { get; set; }

        /// <summary>
        /// Gets/Sets the subject of the mail
        /// </summary>
        [Required]
        public string Subject { get; set; }
        
        //public class MailMessageMeta
        //{
        //    public string Receiver { get; set; }

        //    public string Sender { get; set; }
            
        //    public string SenderName { get; set; }
        //    [Required]
        //    public string MailBody { get; set; }
        //}
    }
}
