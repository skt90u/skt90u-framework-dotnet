﻿//  Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace DNA.Mvc.Models
{
    public class WebMasterTools
    {
        private Web parent;
        private UrlHelper Url;

        public WebMasterTools(Web parentWeb)
        {
            parent = parentWeb;

        }

        public Web Parent
        {
            get { return parent; }
        }

        private void SetValue(string key, object value)
        {
            if (parent.Properties.ContainsKey(key))
                parent.Properties[key] = value;
            else
                parent.Properties.Add(key, value);
        }

        private string GetValue(string key)
        {
            if (parent.Properties.ContainsKey(key))
                return parent.Properties[key] as string;
            else
                return "";
        }

        private T GetValue<T>(string key)
        {
            if (parent.Properties.ContainsKey(key))
                return (T)parent.Properties[key];
            return default(T);
        }


        public string GAAccount
        {
            get
            {
                return GetValue("GAAccount");
            }
            set
            {
                SetValue("GAAccount", value);
            }
        }

        public string AddThisCode
        {
            get
            {
                return GetValue("AddThisCode");
            }
            set
            {
                SetValue("AddThisCode", value);
            }
        }

        public string GoogleWebMasterTools
        {
            get
            {
                return GetValue("GoogleWebMasterTools");
            }
            set
            {
                SetValue("GoogleWebMasterTools", value);
            }
        }

        public string YahooSiteExplorer
        {
            get
            {
                return GetValue("YahooVerfityKey");
            }
            set
            {
                SetValue("YahooVerfityKey", value);
            }
        }

        public string BingWebMasterCenter
        {
            get
            {
                return GetValue("BingWebMasterCenter");
            }
            set
            {
                SetValue("BingWebMasterCenter", value);
            }
        }

        public string GoogleSiteMapUrl
        {
            get
            {
                if (Url == null)
                    Url = UrlUtility.CreateUrlHelper();
                return parent.GetFullUrl() + Url.Action("GoogleSiteMap", "DynamicUI", new { Area = "" });
            }
        }

        public bool PreventUntrustLinks
        {
            get
            {
                return GetValue<bool>("PreventUntrustLinks");
            }
            set
            {
                SetValue("PreventUntrustLinks", value);
            }
        }

        public string UrlForUntrustLink
        {
            get
            {
                return GetValue("UrlForUntrustLink");
            }
            set
            {
                SetValue("UrlForUntrustLink", value);
            }
        }

        /// <summary>
        /// Gets the domain names allows to link the shared resource 
        /// </summary>
        public string TrustDomains
        {
            get
            {
                return GetValue("TrustDomains");
            }
            set
            {
                SetValue("TrustDomains", value);
            }
        }

        public string[] GetTrustDomains()
        {
            if (!string.IsNullOrEmpty(TrustDomains))
                return TrustDomains.ToLower().Split(',');
            return new string[] { };
        }

        public void Update()
        {
            parent.Update();
        }
    }
}