﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Web.Script.Serialization;
using System.Web.Mvc;

namespace DNA.Mvc.Models
{
    public partial class WidgetDescriptor
    {
        private Dictionary<string, object> properties = null;
        //private PackageInfo pkgInfo = null;

        public Dictionary<string, object> Properties
        {
            get
            {
                if (properties == null)
                {
                    properties = new Dictionary<string, object>();
                    if (!string.IsNullOrEmpty(this.Defaults))
                        properties = (new JavaScriptSerializer()).Deserialize<Dictionary<string, object>>(this.Defaults);
                }
                return properties;
            }
            set
            {
                if (value != null)
                    this.Defaults = (new JavaScriptSerializer()).Serialize(value);
                else
                    this.Defaults = "{}";
            }
        }
        
        [ScriptIgnore]
        public string ControllerShortName
        {
            get 
            {
                if (!string.IsNullOrEmpty(this.Controller))
                {
                    var type = Type.GetType(this.Controller);
                    if (type != null)
                        return type.Name.Replace("Controller", "");
                }
                return this.Controller;
            }
        }

        [Obsolete]
        public string ToJSON(UrlHelper urlHelper)
        {
            var json = new
            {
                id = Guid.NewGuid(),
                closable = IsClosable,
                deletable = IsDeletable,
                expanded = true,
                pos = 0,
                showHeader = ShowHeader,
                showBorder=ShowBorder,
                title = Title,
                url = string.IsNullOrEmpty(Url) ? urlHelper.Action(Action, Controller) : urlHelper.Content(Url)
            };
            return (new JavaScriptSerializer()).Serialize(json);
        }
    }
}
