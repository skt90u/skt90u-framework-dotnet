﻿//  Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Xml;
using System.Xml.Serialization;

namespace DNA.Mvc.Models
{
    [
    XmlRoot("widget", Namespace = "http://www.w3.org/ns/widgets"),
    Serializable
    ]
    public class WidgetTemplate
    {
        #region From W3C
        [XmlAttribute("id")]
        public string ID;

        [XmlElement("author")]
        public WidgetAuthor Author;

        [XmlAttribute("version")]
        public string Version;

        [XmlElement("name")]
        public string Name;

        [XmlElement("description")]
        public string Description;

        [XmlElement("icon", Type = typeof(WidgetIcon))]
        public List<WidgetIcon> Icons;
        #endregion

        [XmlElement("defaults", Namespace = "http://www.dotnetage.com/XML/Schema/widget")]
        public WidgetDefaults Defaults;
        

        [XmlElement("license", Type = typeof(WidgetLicense))]
        public List<WidgetLicense> Licenses;

        [XmlElement("preference", Type = typeof(WidgetUserPreference))]
        public List<WidgetUserPreference> UserPreferences;

        private bool isInstalled = false;

        [XmlIgnore]
        internal bool Installed
        {
            get { return isInstalled; }
             set { isInstalled = value; }
        }
    }

    [Serializable]
    public struct WidgetDefaults
    {
        [XmlElement("title")]
        public string Title;

        [XmlElement("titleUrl")]
        public string TitleLinkUrl;

        [XmlElement("iconUrl")]
        public string IconUrl;

        [XmlElement("showBorder")]
        public bool ShowBorder;

        [XmlElement("showHeader")]
        public bool ShowHeader;

        [XmlElement("bgColor")]
        public string BackgroundColor;

        [XmlElement("color")]
        public string ForeColor;

        [XmlElement("zoneID")]
        public string ZoneID;

        [XmlElement("pos")]
        public int Position;

        [XmlElement("action")]
        public string Action;

        [XmlElement("controller")]
        public string Controller;

        [XmlElement("assembly")]
        public string PackageAssemblyName;
    }

    [Serializable]
    public struct WidgetLicense
    {
        [XmlText]
        public string Text;

        [XmlAttribute("href")]
        public string Source;
    }

    [Serializable]
    public struct WidgetAuthor
    {
        [XmlText]
        public string Name;

        [XmlAttribute("href")]
        public string Uri;

        [XmlAttribute("email")]
        public string Email;
    }
    [Serializable]
    public struct WidgetIcon
    {
        [XmlAttribute("src")]
        public string Source;

        [XmlAttribute("width")]
        public int Width;

        [XmlAttribute("height")]
        public int Height;
    }

    [Serializable]
    public struct WidgetFeature
    {
        [XmlAttribute("name")]
        public string Url;

        [XmlAttribute("required")]
        public bool IsRequried;

        [XmlElement("param", Type = typeof(WidgetFeatureParam))]
        public List<WidgetFeatureParam> Params;
    }

    [Serializable]
    public struct WidgetContent
    {
        [XmlAttribute("src")]
        public string Source;

        [XmlAttribute("type")]
        public string ContentType;

        [XmlAttribute("encoding")]
        public string Encoding;

        [XmlText]
        public string Text;
    }

    [Serializable]
    public struct WidgetFeatureParam
    {
        [XmlAttribute("name")]
        public string Name;

        [XmlAttribute("value")]
        public string Value;
    }

    [Serializable]
    public struct WidgetUserPreference
    {
        [XmlAttribute("name")]
        public string Name;

        [XmlAttribute("type")]
        public string Type;

        [XmlAttribute("readonly")]
        public bool IsReadonly;

        [XmlAttribute("value")]
        public string Value;
    }
}