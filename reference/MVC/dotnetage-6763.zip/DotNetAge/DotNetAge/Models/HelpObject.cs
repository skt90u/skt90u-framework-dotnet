﻿//  Copyright (c) 2011 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Xml.Serialization;
using System.Xml;

namespace DNA.Mvc.Models
{
    [XmlRoot("help")]
    public class HelpDocs
    {
        [XmlElement("doc")]
        public List<HelpObject> Docs { get; set; }
    }

    [XmlRoot("doc")]
    public struct HelpObject
    {
        [XmlAttribute("id")]
        public int HelpID;

        [XmlAttribute("title")]
        public string Title;

        [XmlAttribute("url")]
        public string HelpUrl;
    }


}