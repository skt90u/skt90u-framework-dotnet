﻿//  Copyright (c) 2009 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Security;
using DNA.Mvc.Security;
using DNA.Mvc.DynamicUI;
using DNA.Mvc.Models;

namespace DNA.Mvc
{
    /// <summary>
    /// Extends the WebPage data model
    /// </summary>
    public static class WebPageExtensions
    {
        private static IDynamicPageServcie Service
        {
            get
            {
                return WebSite.UIService;
            }
        }

        private static WidgetUIServiceBase WidgetService
        {
            get
            {
                return WebSite.WidgetService;
            }
        }

        /// <summary>
        /// Returns the current user whether can access the page.
        /// </summary>
        /// <param name="page">The WebPage object</param>
        /// <returns>If pass return true</returns>
        public static bool IsAuthorize(this WebPage page)
        {
            if (page.AllowAnonymous)
                return true;

            if (HttpContext.Current.Request.IsAuthenticated)
            {
                //if (!page.Roles.IsLoaded)
                //    page.Roles.Load();
                var roles = page.GetRoles();
                foreach (WebPageRole role in roles)
                {
                    if (Roles.IsUserInRole(role.RoleName))
                        return true;
                }
            }
            return false;
        }

        public static WebPage GetParent(this WebPage page)
        {
            if (page.ParentID <= 0)
                return null;
            return Service.GetPage(page.ParentID);
        }

        public static IEnumerable<WebPage> GetDescendantPages(this WebPage page)
        {
            return Service.GetDescendantPages(page.WebID, page.ParentID);
        }

        public static string[] GetIgnoreRouteKeys(this WebPage page)
        {
            var keys = new string[] { };
            if (!string.IsNullOrEmpty(page.ViewData))
                return page.ViewData.Split(new char[] { ',' });
            return keys;
        }

        /// <summary>
        /// Gets whether the specified role can access this page.
        /// </summary>
        /// <param name="page">The WebPage object</param>
        /// <param name="role">Specified the role name</param>
        /// <returns>If pass return true</returns>
        public static bool IsAuthorize(this WebPage page, string role)
        {
            if (page.AllowAnonymous)
                return true;

            if (string.IsNullOrEmpty(role))
                throw new ArgumentNullException("role");

            //if (!page.Roles.IsLoaded)
            //    page.Roles.Load();
            //return (page.Roles.FirstOrDefault(r => r.RoleName == role) != null);
            return page.GetRole(role) != null;
        }

        public static WebPageRole GetRole(this WebPage page, string roleName)
        {
            return Service.GetPageRole(page.ID, roleName);
        }

        public static IEnumerable<WidgetInstance> GetWidgets(this WebPage page)
        {
            return WidgetService.GetWidgets(page.ID);
        }

        /// <summary>
        /// Delete this page from database.
        /// </summary>
        /// <param name="page">The WebPage object</param>
        public static void Delete(this WebPage page)
        {
            Service.Delete(page.ID);
        }

        /// <summary>
        /// Save the changes to database.
        /// </summary>
        /// <param name="page">The WebPage object</param>
        public static void Update(this WebPage page)
        {
            var roles = page.GetRoles();
            if (roles.Count() > 0)
                Service.Update(page, roles.Select(r => r.RoleName).ToArray());
            else
                Service.Update(page, new string[] { });
        }

        /// <summary>
        /// Save the changes to database.
        /// </summary>
        /// <param name="page">The WebPage object</param>
        /// <param name="roles">Specified the access roles of this page.</param>
        public static void Update(this WebPage page, string[] roles)
        {
            if ((roles != null) && (roles.Length > 0))
                page.AllowAnonymous = false;
            Service.Update(page, roles);
        }

        /// <summary>
        /// Move the page to a new position
        /// </summary>
        /// <param name="page">The web page object</param>
        /// <param name="parentPageID">Specified the new parent page id to move to.</param>
        /// <param name="position">Specified the new position value</param>
        public static void Move(this WebPage page, int parentPageID, int position)
        {
            Service.Move(parentPageID, page.ID, position);
        }

        /// <summary>
        /// Gets the children pages of this page.
        /// </summary>
        /// <param name="page">The WebPage object</param>
        /// <returns>The page collection returns.</returns>
        public static IEnumerable<WebPage> Children(this WebPage page)
        {
            return Service.GetChildPages(page.WebID, page.ID);
        }

        /// <summary>
        /// Gets the children page count of this page.
        /// </summary>
        /// <param name="page">The WebPage object</param>
        /// <returns>The integer value of the page count.</returns>
        public static int ChildrenCount(this WebPage page)
        {
            return page.Children().Count();
        }

        ///// <summary>
        ///// Import the page data and widgets into this page.
        ///// </summary>
        ///// <param name="page">The WebPage object</param>
        ///// <param name="data">The WebPageDataContract object</param>
        //public static void Import(this WebPage page, WebPageDataContract data)
        //{
        //    if (data == null)
        //        throw new ArgumentNullException("data");

        //    data.UpdateModel(page);

        //    Service.Update(page, new string[] { });

        //    foreach (var widgetData in data.Widgets)
        //    {
        //        var descriptor = WidgetService.GetWidgetDescriptor(widgetData.PackageAssemblyName, widgetData.Controller, widgetData.Action);
        //        var widgetInstance = WidgetService.AddWidget(descriptor, page.Path, widgetData.ZoneID, widgetData.Position);
        //        widgetData.UpdateModel(widgetInstance);
        //        //widgetInstance.IsStatic = false;
        //        WidgetService.UpdateWidget(widgetInstance);
        //    }
        //}

        public static WidgetInstance GetWidget(this WebPage page, Guid id)
        {
            return WidgetService.GetWidget(id);
        }

        public static IEnumerable<WebPageRole> GetRoles(this WebPage page)
        {
            return Service.GetPageRoles(page.ID);
        }

        /// <summary>
        /// Add the widget to this page and create an widget instance.
        /// </summary>
        /// <param name="page">The WebPage object</param>
        /// <param name="descriptor">The WidgetDescriptor object</param>
        /// <param name="zoneID">Specified the zone id of the page that the widget adds to.</param>
        /// <param name="position">Specified the position to place the widget.</param>
        /// <returns>A widget instance that added to this page.</returns>
        public static WidgetInstance AddWidget(this WebPage page, WidgetDescriptor descriptor, string zoneID, int position)
        {
            return WidgetService.AddWidget(descriptor, page.Path, zoneID, position);
        }

        public static WidgetInstance AddWidget(this WebPage page, string installedPath, string zoneID, int position)
        {
            return page.AddWidget(Guid.NewGuid(), installedPath, zoneID, position);
        }

        public static WidgetInstance AddWidget(this WebPage page, Guid id, string installedPath, string zoneID, int position)
        {
            if (string.IsNullOrEmpty(installedPath))
                throw new ArgumentNullException("installedPath");

            //if (string.IsNullOrEmpty(controller))
            //    throw new ArgumentNullException("controller");

            //if (string.IsNullOrEmpty(asmname))
            //    throw new ArgumentNullException("asmname");

            if (id == Guid.Empty)
                throw new ArgumentNullException("id");

            var descriptor = WidgetService.GetWidgetDescriptor(installedPath);

            if (descriptor == null)
                throw new ArgumentOutOfRangeException("The widget is not installed.");

            return WidgetService.AddWidget(id, descriptor, page.Path, zoneID, position);
        }

        public static WebPageTemplate GetPageTemplate(this WebPage page)
        {
            //if ((page.IsStatic) && (!page.IsShared))
            //    throw new System.FormatException("The static page could not generate any page template.");
            var web = page.GetParentWeb();
            
            var _pg = new WebPageTemplate()
            {
                Title = page.Title,
                Description = page.Description,
                LinkUrl = page.LinkUrl,
                Target = page.Target,
                Data = page.ViewData,
                Layout = page.ViewName,
                IsStatic=page.IsStatic,
                IsShared=page.IsShared,
                AllowAnonymous = page.AllowAnonymous,
                ShowInMenu = page.ShowInMenu,
                Path = page.Path
            };
            
            if (web.Type == (int)WebTypes.Personal)
                _pg.Path = _pg.Path.ToLower().Replace(web.Name.ToLower(), "{website}");

            var widgets = page.GetWidgets();
            if (widgets.Count() > 0)
            {
                _pg.Widgets = new List<WidgetTemplate>();
                foreach (var widget in widgets)
                {
                    if (!widget.IsStatic)
                        _pg.Widgets.Add(widget.GetWidgetTemplate());
                }
            }

            var children = page.Children();
            if (children.Count() > 0)
            {
                _pg.Children = new List<WebPageTemplate>();
                foreach (var pc in children)
                    _pg.Children.Add(pc.GetPageTemplate());
            }
            return _pg;
        }

        public static Web GetParentWeb(this WebPage page)
        {
            return Service.GetWebByID(page.WebID);
        }

        public static string ToXml(this WebPage page)
        {
            return DNA.Utility.XmlSerializerUtility.SerializeToXml(typeof(WebPageTemplate), page.GetPageTemplate());
        }

        public static void Import(this WebPage page, string xml)
        {
            var template = (WebPageTemplate)DNA.Utility.XmlSerializerUtility.DeserializeFromXmlText(xml, typeof(WebPageTemplate));
            Update(page, template);
        }

        public static void ImportChildren(this WebPage page, List<WebPageTemplate> children)
        {
            if (children == null)
                throw new ArgumentNullException("children");
            var web = page.GetParentWeb();

            foreach (var child in children)
            {
                var _path = child.Path.ToLower();
                if (_path.IndexOf("{website}") > -1)
                    _path = _path.Replace("{website}",web.Name);

                var pageInDB = Service.GetPage(_path);
                if (pageInDB != null) //Update page
                    pageInDB.Update(child);
                else //create page
                    page.GetParentWeb().CreatePage(page.ID, child);
            }
        }

        public static void Update(this WebPage page, WebPageTemplate template)
        {
            page.Title = template.Title;
            page.Description = template.Description;
            page.LinkUrl = template.LinkUrl;
            page.Target = template.Target;
            if (!page.IsShared)
                page.ViewData = template.Data;
            page.ViewName = template.Layout;
            page.AllowAnonymous = template.AllowAnonymous;
            page.ShowInMenu = template.ShowInMenu;
            Service.Update(page, null);

            foreach (var widgetTemp in template.Widgets)
            {
                var descriptor = WidgetService.GetWidgetDescriptor(widgetTemp.Defaults.Controller, widgetTemp.Defaults.Action);
                var widgetInstance = WidgetService.AddWidget(descriptor, page.Path, widgetTemp.Defaults.ZoneID, widgetTemp.Defaults.Position);
                widgetInstance.Update(widgetTemp);
            }
        }

        internal static void Update(this WidgetInstance widget, WidgetTemplate template)
        {
            widget.Title = template.Defaults.Title;
            widget.TitleLinkUrl = template.Defaults.TitleLinkUrl;
            widget.IconUrl = template.Defaults.IconUrl;
            widget.ShowBorder = template.Defaults.ShowBorder;
            widget.ShowHeader = template.Defaults.ShowHeader;
            widget.BackgroundColor = template.Defaults.BackgroundColor;
            widget.ForeColor = template.Defaults.ForeColor;
            if (template.UserPreferences != null)
            {
                var dict = new Dictionary<string, object>();
                foreach (var preference in template.UserPreferences)
                {
                    var type = Type.GetType(preference.Type);
                    dict.Add(preference.Name, Convert.ChangeType(preference.Value, type));
                }
                if (dict.Count > 0)
                    widget.SaveUserPreferences(dict);
            }

            if (widget.PageID > 0)
                WidgetService.UpdateWidget(widget);
        }

        public static WidgetInstance ImportWidget(this WebPage page, string xml)
        {
            if (string.IsNullOrEmpty(xml))
                throw new ArgumentNullException("xml");
            var widgetTemp = (WidgetTemplate)DNA.Utility.XmlSerializerUtility.DeserializeFromXmlText(xml, typeof(WidgetTemplate));
            var descriptor = WidgetService.GetWidgetDescriptor(widgetTemp.Defaults.Controller, widgetTemp.Defaults.Action);
            var widgetInstance = WidgetService.AddWidget(descriptor, page.Path, widgetTemp.Defaults.ZoneID, widgetTemp.Defaults.Position);
            widgetInstance.Update(widgetTemp);
            return widgetInstance;
            //widget.IsStatic = template.is;
        }
    }
}
