﻿//  Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using DNA.Mvc.Logging;

namespace DNA.Mvc.Models
{
    public partial class Web
    {
        private WebMasterTools masterTools;
        private IDictionary<string, object> properties;
        private IEnumerable<UrlRefer> refers=null;

        public IEnumerable<UrlRefer> UrlRefers
        {
            get
            {
                if (refers == null)
                    refers = WebSite.LoggingService.GetUrlRefers(this.Name ,10);
                return refers;
            }
        }

        public WebStatistics GetStatistics(int interval)
        {
            return WebSite.LoggingService.GetStatistics(this.Name, interval);
        }

        public string[] GetOnlineUsers(bool isAuthorized, int interval)
        {
            return WebSite.LoggingService.GetOnlineUsers(this.Name, isAuthorized, interval);
        }

        public WebMasterTools MasterTools
        {
            get
            {
                if (masterTools == null)
                    masterTools = new WebMasterTools(this);
                return masterTools;
            }
        }
        private Uri appUrl = null;
        public Uri AppUrl
        {
            get
            {
                if (appUrl == null)
                    Uri.TryCreate(this.GetFullUrl(), UriKind.Absolute, out appUrl);
                return appUrl;
            }
        }

        public bool IsTrusted(Uri url)
        {

            if (AppUrl.Authority.Equals(url.Authority, StringComparison.OrdinalIgnoreCase))
                return true;

            if (MasterTools.PreventUntrustLinks) 
            {
                if (!string.IsNullOrEmpty(MasterTools.TrustDomains))
                    return MasterTools.GetTrustDomains().Contains(url.Authority.ToLower());
                return false;
            }
            return true;
        }

        /// <summary>
        /// Gets the additional setting values for the website.
        /// </summary>
        public IDictionary<string, object> Properties
        {
            get
            {
                if (properties == null)
                {
                    if (!string.IsNullOrEmpty(Data))
                    {
                        var serializer = new System.Web.Script.Serialization.JavaScriptSerializer();
                        properties = (IDictionary<string, object>)serializer.DeserializeObject(Data);
                    }
                    else
                        properties = new Dictionary<string, object>();
                }
                return properties;
            }
        }

        private void SetValue(string key, object value)
        {
            if (Properties.ContainsKey(key))
                Properties[key] = value;
            else
                Properties.Add(key, value);
        }

        private string GetValue(string key)
        {
            if (Properties.ContainsKey(key))
                return Properties[key] as string;
            else
                return "";
        }

        private T GetValue<T>(string key)
        {
            if (Properties.ContainsKey(key))
                return (T)Properties[key];
            return default(T);
        }

        public LogoLayouts LogoLayout
        {
            get
            {
                //if (string.IsNullOrEmpty(GetValue("LogoLayout")))
                //{
                //    SetValue("LogoLayout", (int)LogoLayouts.LogoOnly);
                //    return LogoLayouts.LogoOnly;
                //}
                //return (LogoLayouts)Convert.ToInt16(GetValue("LogoLayout"));
                return GetValue<LogoLayouts>("LogoLayout");
            }
            set
            {
                SetValue("LogoLayout", value);
            }
        }

        public TimeZoneInfo TimeZoneInfo
        {
            get
            {
                if (string.IsNullOrEmpty(this.TimeZone))
                    return TimeZoneInfo.Local;
                else
                    return TimeZoneInfo.FindSystemTimeZoneById(this.TimeZone);
            }
        }

        /// <summary>
        /// Sets the extensions allow to upload to the website
        /// </summary>
        /// <param name="extension"></param>
        /// <returns></returns>
        public bool IsAllowUpload(string extension)
        {
            if (string.IsNullOrEmpty(this.AllowExtensions))
                return false;

            string[] exts = AllowExtensions.ToLower().Split(new char[] { '|' });
            return exts.Contains(extension.ToLower());
        }

        public bool IsRoot
        {
            get
            {
                return Name.Equals("home", StringComparison.OrdinalIgnoreCase);
            }
        }
    }
}