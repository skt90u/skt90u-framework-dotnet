﻿//  Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Xml;
using System.Xml.Serialization;

namespace DNA.Mvc.Models
{
    [XmlRoot("page", Namespace = "http://www.dotnetage.com/XML/Schema/page"),
    Serializable]
    public class WebPageTemplate
    {
        [XmlElement("title")]
        public string Title;

        [XmlElement("description")]
        public string Description;

        [XmlElement("link")]
        public string LinkUrl;

        [XmlAttribute("target")]
        public string Target;

        [XmlElement("data")]
        public string Data;

        [XmlElement("layout")]
        public string Layout;

        [XmlAttribute("anonymous")]
        public bool AllowAnonymous;

        [XmlAttribute("showInMenu")]
        public bool ShowInMenu;

        [XmlAttribute("static")]
        public bool IsStatic;

        [XmlAttribute("shared")]
        public bool IsShared;

        [XmlAttribute("href")]
        public string Path;

        [XmlArray("pages"), XmlArrayItem("page", Type = typeof(WebPageTemplate), Namespace = "http://www.dotnetage.com/XML/Schema/page")]
        public List<WebPageTemplate> Children;

        [XmlArray("widgets"), XmlArrayItem("widget", Type = typeof(WidgetTemplate), Namespace = "http://www.w3.org/ns/widgets")]
        public List<WidgetTemplate> Widgets;
    }
}