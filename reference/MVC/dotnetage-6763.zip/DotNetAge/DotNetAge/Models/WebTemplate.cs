﻿//  Copyright (c) 2010 Ray Liang (http://www.dotnetage.com)
//  Dual licensed under the MIT and GPL licenses:
//  http://www.opensource.org/licenses/mit-license.php
//  http://www.gnu.org/licenses/gpl.html

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Xml;
using System.Xml.Serialization;

namespace DNA.Mvc.Models
{
    [XmlRoot("template", 
        Namespace = "http://www.dotnetage.com/XML/Schema/template"),
    Serializable]
    public class WebTemplate
    {
        [XmlElement("title")]
        public string Title;

        [XmlElement("description")]
        public string Description;

        [XmlElement("keywords")]
        public string SearchKeywords;

        [XmlAttribute("theme")]
        public string Theme;

        [XmlAttribute("lang")]
        public string Language;

        [XmlElement("shortcutIconUri")]
        public string ShortcutIconUrl;

        [XmlElement("logoUri")]
        public string LogoImageUrl;

        [XmlElement("copyright")]
        public string Copyright;

        [XmlElement("style")]
        public string CssText;

        [XmlAttribute("type")]
        public WebTypes Type;

        [XmlAttribute("allowNewUser")]
        public bool EnableUserRegistation;
        
        [XmlElement("masterPage")]
        public string MasterPage;

        [XmlElement("defaultUri")]
        public string DefaultUrl;

        [XmlArray("pages"), 
        XmlArrayItem("page", 
            typeof(WebPageTemplate), 
            Namespace = "http://www.dotnetage.com/XML/Schema/page")]
        public List<WebPageTemplate> WebPages;
    }
}